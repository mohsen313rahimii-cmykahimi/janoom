<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$checks = [
    'assets/content-wizard-v15.js' => [
        'function render(animate=false)',
        "function toolMode()",
        'mode-choice-grid',
        'goal-card',
        'function paintGoalResults()',
        "occasionMode()",
        'همه مناسبت‌ها',
        'انتخاب مناسبت',
        'function paintOccasionList()',
        'selected-tray',
        "render(true)",
    ],
    'assets/content-wizard-v14.css' => [
        '.mode-choice-grid',
        '.mode-choice-grid.compact',
        '.selected-tray',
        '.goal-grid',
        '.goal-card',
        '.occasion-card-grid',
        '.occasion-card',
        '@keyframes mahda-stage-in{from{opacity:.84}',
    ],
    'templates/pages/content/new.php' => ['20260918-studio-edit-v2'],
];
$errors=[];
foreach($checks as $file=>$needles){
    $text=@file_get_contents($root.'/'.$file);
    if($text===false){$errors[]="missing: $file";continue;}
    foreach($needles as $needle){if(strpos($text,$needle)===false)$errors[]="$file missing $needle";}
}
if($errors){fwrite(STDERR,implode("\n",$errors)."\n");exit(1);} 
echo "Selection UI verification passed.\n";
