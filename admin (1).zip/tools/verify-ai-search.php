<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$root = dirname(__DIR__);
require_once $root . '/app/Core/Autoloader.php';
\Mahda\Core\Autoloader::register($root . '/app');

$fail = static function(string $message): never { fwrite(STDERR, "AI search verification failed: {$message}\n"); exit(1); };
$mustContain = static function(string $file, array $needles) use ($fail): void {
    $text = (string)@file_get_contents($file);
    foreach ($needles as $needle) if (!str_contains($text,$needle)) $fail(basename($file) . " missing {$needle}");
};

$mustContain($root.'/api/v1/index.php', ["POST /search/ai","GET /search/ai/quota"]);
$mustContain($root.'/app/Modules/AiSearch/AiSearchRepository.php', ["c.review_status='approved'","c.visibility='showcase'"]);
$mustContain($root.'/app/Modules/AiSearch/migrations.php', ['mahda_ai_search_usages','ux_ai_usage_daily_slot']);
$mustContain($root.'/assets/search-v10.js', ["addEventListener('input'","smartSearch","aiSearchBtn","global_search"]);
$mustContain($root.'/templates/pages/search/index.php', ['جستجوی هوشمند','search-v10.js']);
$mustContain($root.'/.htaccess', ['.mahda-ai.env','Require all denied']);
$mustContain($root.'/mahda-api/bootstrap.php', ['mahda_migrate_ai_search_v29']);

$normalizer = new \Mahda\Modules\AiSearch\PersianNormalizer();
if ($normalizer->normalize('بازي محرم براي ۷ ساله') !== 'بازی محرم برای 7 ساله') $fail('Persian normalization mismatch');

$secretPath=$root.'/.mahda-ai.env';
if(!is_file($secretPath))$fail('deployment secret template missing');
$secret=(string)file_get_contents($secretPath);
if(!str_contains($secret,'AI_API_KEY=')||!str_contains($secret,'AI_SEARCH_ENABLED='))$fail('AI secret config template incomplete');
$key='';foreach(preg_split('/\R/',$secret)?:[] as $line){if(str_starts_with($line,'AI_API_KEY=')){$key=trim(substr($line,11));break;}}
if($key!=='' && str_starts_with($key,'sk-')){
    $iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
    foreach($iterator as $file){if(!$file->isFile()||$file->getPathname()===$secretPath)continue;$body=@file_get_contents($file->getPathname());if(is_string($body)&&$body!==''&&str_contains($body,$key))$fail('secret leaked outside secret file: '.$file->getPathname());}
}

fwrite(STDOUT,"AI search verification passed.\n");
