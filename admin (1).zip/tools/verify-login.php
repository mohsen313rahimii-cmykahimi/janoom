<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$checks = [
    'templates/pages/auth/login.php' => [
        "post('auth_login',{identifier:id,password:pass})",
        'id="loginIdentifier"',
        'id="loginPassword"',
        'ورود با رمز عبور',
    ],
    'app/Modules/Auth/api.php' => [
        "\$data['identifier']",
        'loginByPassword',
    ],
    'app/Modules/Auth/AuthService.php' => [
        'function loginByPassword',
        'password_verify',
    ],
    'app/Modules/Auth/AuthRepository.php' => [
        'function findByLoginIdentifier',
        'u.admin_username',
        'u.email',
    ],
];

$errors = [];
foreach ($checks as $relative => $needles) {
    $path = $root . '/' . $relative;
    $text = is_file($path) ? (string)file_get_contents($path) : '';
    if ($text === '') {
        $errors[] = "missing:$relative";
        continue;
    }
    foreach ($needles as $needle) {
        if (!str_contains($text, $needle)) {
            $errors[] = "missing-contract:$relative:$needle";
        }
    }
}

$loginPage = (string)file_get_contents($root . '/templates/pages/auth/login.php');
if (str_contains($loginPage, "const enabled=authMode==='test'")) {
    $errors[] = 'password-login-is-still-gated-by-phone-test-mode';
}

if ($errors) {
    fwrite(STDERR, "Login verification failed:\n- " . implode("\n- ", $errors) . "\n");
    exit(1);
}

echo "Login verification passed.\n";
