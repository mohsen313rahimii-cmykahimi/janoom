<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$fail=static function(string $m): never { fwrite(STDERR,"FAIL: {$m}\n"); exit(1); };
$must=static function(string $file,array $needles) use($fail): void { $s=@file_get_contents($file); if(!is_string($s))$fail("missing {$file}"); foreach($needles as $n){ if(!str_contains($s,$n))$fail("{$file} missing {$n}"); }};
$must($root.'/templates/pages/auth/login.php',['ساخت پروفایل واقعی','۳ از ۳','ساخت حساب و ورود','/showcase/me','atlasType']);
$must($root.'/app/Modules/Auth/AuthService.php',['resolveCity($city)','invalid_city','specialties','primaryRole']);
$must($root.'/app/Modules/Auth/AuthRepository.php',['city_id,province_id','atlas_visible','profileComplete']);
$must($root.'/templates/pages/showcase/index.php',['ویترین من','/showcase/me']);
$must($root.'/templates/pages/search/index.php',['search-v9.js']);
$forbidden=[
  $root.'/app/Modules/AiSearch', $root.'/config/ai.php', $root.'/.mahda-ai.env', $root.'/mahda-ai.env', $root.'/assets/search-v10.js'
];
foreach($forbidden as $path){ if(file_exists($path))$fail("AI artifact remains: {$path}"); }
foreach([$root.'/api/v1/index.php',$root.'/app/Api/Kernel.php',$root.'/mahda-api/bootstrap.php',$root.'/templates/pages/search/index.php'] as $file){$s=file_get_contents($file);if(str_contains($s,'ai_search')||str_contains($s,'جستجوی هوشمند'))$fail("AI route/UI remains in {$file}");}
echo "Account onboarding + own showcase + AI removal verification passed.\n";
