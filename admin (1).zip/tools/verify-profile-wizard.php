<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$checks = [
    'templates/pages/content/new.php' => ['content-wizard-v14.css', 'content-wizard-v15.js', 'گام ۱ از ۹', '20260918-studio-edit-v2'],
    'assets/content-wizard-v15.js' => ["const TOTAL_STEPS=9", "'کاور','توضیح محتوا','فایل همراه','پیش‌نمایش'", "['video','image','text']", 'function renderStep9()', 'live-detail-preview', 'detail-cover-actions', 'prepareImageUpload', 'videoDuration', 'video_transcode_unavailable'],
    'assets/content-wizard-v14.css' => ['.content-method-grid', '.cover-stage-card', '.attachment-stage-card', '.live-detail-preview', '.detail-hero-card', '.detail-preview-actions', '@keyframes mahda-stage-in'],
    'app/Modules/Content/workflow-api.php' => ['min(9', "['video','image','audio','text']", 'current_step=9', 'video_transcode_unavailable', 'videoDirectMaxBytes'],
    'mahda-api/bootstrap.php' => ['mahda_probe_video_duration_v12', 'video_transcode_unavailable', 'Videos already within the final 20 MB budget', 'Browser-side preparation usually already delivers a <=200 KB image'],
    'app/Modules/Content/registration-contract.php' => ["['video','image','audio','text']"],
    'app/Modules/OfflineSync/DraftSyncService.php' => ['min(9'],
    // Preserve the original showcase; only force the avatar geometry to a true circle.
    'app/Modules/Showcase/views.php' => ['profile-hero', 'profile-top', 'showcase-grid'],
    'templates/pages/showcase/index.php' => ['.profile-avatar{width:106px;height:106px;min-width:106px;max-width:106px;aspect-ratio:1/1', 'border-radius:999px', '.showcase-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))'],
];

foreach ($checks as $file => $needles) {
    $path = $root . '/' . $file;
    if (!is_file($path)) {
        fwrite(STDERR, "Missing file: {$file}\n");
        exit(1);
    }
    $content = (string)file_get_contents($path);
    foreach ($needles as $needle) {
        if (!str_contains($content, $needle)) {
            fwrite(STDERR, "Missing marker in {$file}: {$needle}\n");
            exit(1);
        }
    }
}

echo "Profile restore + upload + live preview verification passed.\n";
