<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$root = dirname(__DIR__);
require_once $root . '/mahda-api/bootstrap.php';
require_once $root . '/app/Modules/Content/registration-contract.php';
require_once $root . '/app/Modules/ContentChin/api.php';

try {
    $db = mahda_db();
    mahda_run_all_migrations($db);
    fwrite(STDOUT, "Mahda migrations completed.\n");
    exit(0);
} catch (Throwable $e) {
    fwrite(STDERR, "Migration failed: " . $e->getMessage() . "\n");
    exit(1);
}
