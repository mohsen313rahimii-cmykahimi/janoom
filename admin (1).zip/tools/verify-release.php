<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$errors = [];

$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($iterator as $file) {
    if (!$file->isFile()) continue;
    $path = $file->getPathname();
    $relative = substr($path, strlen($root) + 1);
    if (strtolower($file->getExtension()) === 'html') {
        $errors[] = "Static HTML remains: {$relative}";
    }
    if (preg_match('/(?:^|\/)(?:app\.html|dist)(?:$|\/)/i', $relative)) {
        $errors[] = "Retired bundled frontend artifact remains: {$relative}";
    }
}

require_once $root . '/app/Core/Autoloader.php';
\Mahda\Core\Autoloader::register($root . '/app');
$view = new \Mahda\Core\View($root . '/templates');
$router = new \Mahda\Core\Router();
$register = require $root . '/config/routes.php';
$register($router, $view);

$routes = [
    '/' => '<!doctype html',
    '/profile' => '<!doctype html',
    '/content' => '<!doctype html',
    '/content/item/1' => '<!doctype html',
    '/search' => '<!doctype html',
    '/library' => '<!doctype html',
    '/notifications' => '<!doctype html',
    '/atlas' => '<!doctype html',
    '/contentchin' => '<!doctype html',
    '/contentchin/new' => '<!doctype html',
    '/contentchin/view/1' => '<!doctype html',
    '/academy' => '<!doctype html',
    '/heiat' => '<!doctype html',
];
foreach ($routes as $uri => $needle) {
    $_SERVER['REQUEST_URI'] = $uri;
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $request = new \Mahda\Core\Request($_SERVER);
    $result = $router->dispatch($request);
    if (!is_string($result) || stripos($result, $needle) === false) {
        $errors[] = "Route failed: {$uri}";
    }
}


// Authentication regression checks that do not require a live database.
$oldPrivateConfig = getenv('MAHDA_PRIVATE_CONFIG');
$oldPhoneAuth = getenv('MAHDA_TEST_PHONE_AUTH');
$oldPhoneCode = getenv('MAHDA_TEST_PHONE_AUTH_CODE');
$tempConfig = tempnam(sys_get_temp_dir(), 'mahda-verify-');
if ($tempConfig === false) {
    $errors[] = 'Could not create temporary auth verification config.';
} else {
    file_put_contents($tempConfig, "<?php return ['dsn'=>'mysql:host=localhost;dbname=unused','user'=>'x','password'=>'y','test_phone_auth'=>true,'test_phone_auth_code'=>'123456'];\n");
    putenv('MAHDA_PRIVATE_CONFIG=' . $tempConfig);
    putenv('MAHDA_TEST_PHONE_AUTH=1');
    putenv('MAHDA_TEST_PHONE_AUTH_CODE=123456');
    \Mahda\Core\Database::reset();
    $validator = new \Mahda\Modules\Auth\AuthValidator();
    foreach (['09121234567', '+989121234567', '00989121234567', '9121234567', '۰۹۱۲۱۲۳۴۵۶۷'] as $phone) {
        try {
            if ($validator->phone($phone) !== '989121234567') {
                $errors[] = 'Phone normalization regression: ' . $phone;
            }
        } catch (Throwable $error) {
            $errors[] = 'Phone validation regression: ' . $phone;
        }
    }
    if ($validator->phoneMode() !== 'test') {
        $errors[] = 'Test phone auth did not enable with a valid server code.';
    }
    try {
        $validator->assertTestCode('123456');
    } catch (Throwable $error) {
        $errors[] = 'Valid test phone code was rejected.';
    }
    try {
        $validator->assertTestCode('654321');
        $errors[] = 'Invalid test phone code was accepted.';
    } catch (RuntimeException $error) {
        if ($error->getMessage() !== 'invalid_otp') {
            $errors[] = 'Unexpected invalid phone code error.';
        }
    }
    @unlink($tempConfig);
}
foreach ([
    'MAHDA_PRIVATE_CONFIG' => $oldPrivateConfig,
    'MAHDA_TEST_PHONE_AUTH' => $oldPhoneAuth,
    'MAHDA_TEST_PHONE_AUTH_CODE' => $oldPhoneCode,
] as $name => $value) {
    if ($value === false) {
        putenv($name);
    } else {
        putenv($name . '=' . $value);
    }
}
\Mahda\Core\Database::reset();

if ($errors) {
    fwrite(STDERR, "Release verification failed:\n- " . implode("\n- ", $errors) . "\n");
    exit(1);
}

echo "Release verification passed.\n";
