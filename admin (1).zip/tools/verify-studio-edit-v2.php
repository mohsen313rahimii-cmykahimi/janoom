<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$checks=[
 'templates/pages/showcase/index.php'=>['grid-template-columns:repeat(2,minmax(0,1fr))','aspect-ratio:4/3','20260918-showcase-43-v2'],
 'assets/content-detail-v15.js'=>["'/content/new?edit='"],
 'templates/pages/content/detail.php'=>['20260918-studio-edit-v2'],
 'templates/pages/content/new.php'=>['20260918-studio-edit-v2'],
 'assets/content-wizard-v15.js'=>['editContentId','content_edit_get','content_edit_files_commit_v12','ذخیره تغییرات','ویرایش محتوا'],
 'app/Modules/Content/workflow-api.php'=>['content_edit_files_commit_v12','deletedExistingFileIds','replacedPurposes','content_edit_wizard_commit'],
 'app/Modules/Studio/page.php'=>['استودیوی مهدا','مدیریت محتوا','/content/new?edit=','mahda-shell-v3.css','ویرایش مرحله‌ای'],
];
foreach($checks as $file=>$needles){
 $path=$root.'/'.$file;
 if(!is_file($path)){fwrite(STDERR,"Missing file: $file\n");exit(1);} $s=(string)file_get_contents($path);
 foreach($needles as $needle){if(!str_contains($s,$needle)){fwrite(STDERR,"$file missing: $needle\n");exit(1);}}
}
foreach(['assets/content-detail-v15.js','app/Modules/Studio/page.php'] as $file){
 $s=(string)file_get_contents($root.'/'.$file);
 if(str_contains($s,"/studio/?edit=")){fwrite(STDERR,"Old studio edit route remains in $file\n");exit(1);}
}
echo "Showcase 4:3 + mobile studio + wizard edit verification passed.\n";
