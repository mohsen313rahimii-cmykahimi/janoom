<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$root = dirname(__DIR__);
$checks = [
    'mobile token service' => is_file($root . '/app/Modules/Mobile/MobileTokenService.php'),
    'mobile API adapter' => is_file($root . '/app/Modules/Mobile/api.php'),
    'offline sync service' => is_file($root . '/app/Modules/OfflineSync/DraftSyncService.php'),
    'mobile auth migration' => str_contains((string)@file_get_contents($root . '/app/Modules/Mobile/migrations.php'), 'mahda_mobile_tokens'),
    'sync change migration' => str_contains((string)@file_get_contents($root . '/app/Modules/OfflineSync/migrations.php'), 'mahda_sync_changes'),
    'access tokens hashed' => str_contains((string)@file_get_contents($root . '/app/Modules/Mobile/MobileTokenService.php'), 'hash(\'sha256\', $access'),
    'refresh tokens hashed' => str_contains((string)@file_get_contents($root . '/app/Modules/Mobile/MobileTokenService.php'), 'hash(\'sha256\', $refresh'),
    'refresh rotation' => str_contains((string)@file_get_contents($root . '/app/Modules/Mobile/MobileTokenService.php'), 'replaced_by_hash'),
    'offline conflict guard' => str_contains((string)@file_get_contents($root . '/app/Modules/OfflineSync/DraftSyncService.php'), "reason'=>'version_mismatch'"),
    'web draft sync logging' => str_contains((string)@file_get_contents($root . '/app/Modules/Content/workflow-api.php'), "mahda_record_sync_change"),
    'media worker sync logging' => str_contains((string)@file_get_contents($root . '/mahda-api/media-worker.php'), "mahda_record_sync_change"),
];

$routes = (string)@file_get_contents($root . '/api/v1/index.php');
foreach (['/mobile/auth/login','/mobile/auth/refresh','/mobile/auth/logout','/mobile/me','/sync/drafts'] as $route) {
    $checks['route ' . $route] = str_contains($routes, $route);
}

$failed = array_keys(array_filter($checks, static fn(bool $ok): bool => !$ok));
if ($failed) {
    fwrite(STDERR, "Phase 27-28 verification failed:\n - " . implode("\n - ", $failed) . "\n");
    exit(1);
}

fwrite(STDOUT, "Phase 27-28 verification passed.\n");
