<?php
declare(strict_types=1);

return [
    'image_target_bytes' => (int)(getenv('MAHDA_IMAGE_TARGET_BYTES') ?: 200 * 1024),
    'video_output_max_bytes' => (int)(getenv('MAHDA_VIDEO_OUTPUT_MAX_BYTES') ?: 20 * 1024 * 1024),
    'video_input_max_bytes' => (int)(getenv('MAHDA_VIDEO_INPUT_MAX_BYTES') ?: 150 * 1024 * 1024),
    'video_max_duration_seconds' => (int)(getenv('MAHDA_VIDEO_MAX_DURATION_SECONDS') ?: 300),
    'video_max_height' => (int)(getenv('MAHDA_VIDEO_MAX_HEIGHT') ?: 540),
    'video_audio_kbps' => (int)(getenv('MAHDA_VIDEO_AUDIO_KBPS') ?: 64),
    'spawn_media_worker' => in_array(strtolower((string)(getenv('MAHDA_SPAWN_MEDIA_WORKER') ?: '0')), ['1','true','yes','on'], true),
];
