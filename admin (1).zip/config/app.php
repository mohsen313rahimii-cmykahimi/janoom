<?php
declare(strict_types=1);

return [
    'name' => 'mahda',
    'environment' => 'production',
    'timezone' => 'Asia/Tehran',
    'view_path' => dirname(__DIR__) . '/templates',
    'private_path' => dirname(__DIR__, 2) . '/.mahda-private',
];

