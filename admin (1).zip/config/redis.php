<?php
declare(strict_types=1);

$bool = static fn(string $name, bool $default): bool => (($raw = getenv($name)) === false)
    ? $default
    : in_array(strtolower(trim((string)$raw)), ['1','true','yes','on'], true);

return [
    // Disabled by default so the current shared host keeps working unchanged.
    'enabled' => $bool('MAHDA_REDIS_ENABLED', false),
    'scheme' => (string)(getenv('MAHDA_REDIS_SCHEME') ?: 'tcp'),
    'host' => (string)(getenv('MAHDA_REDIS_HOST') ?: '127.0.0.1'),
    'port' => (int)(getenv('MAHDA_REDIS_PORT') ?: 6379),
    'username' => (string)(getenv('MAHDA_REDIS_USERNAME') ?: ''),
    'password' => (string)(getenv('MAHDA_REDIS_PASSWORD') ?: ''),
    'database' => (int)(getenv('MAHDA_REDIS_DATABASE') ?: 0),
    'prefix' => (string)(getenv('MAHDA_REDIS_PREFIX') ?: 'mahda:'),
    'timeout' => (float)(getenv('MAHDA_REDIS_TIMEOUT') ?: 1.5),
    'session_ttl' => (int)(getenv('MAHDA_SESSION_TTL_SECONDS') ?: 43200),
];
