<?php
declare(strict_types=1);

$bool = static fn(string $name, bool $default): bool => (($raw = getenv($name)) === false)
    ? $default
    : in_array(strtolower(trim((string)$raw)), ['1','true','yes','on'], true);

return [
    // `local` is the safe default for the current Netafraz deployment.
    // Switch to `s3` only after credentials/bucket have been provisioned.
    'driver' => strtolower((string)(getenv('MAHDA_STORAGE_DRIVER') ?: 'local')),
    'endpoint' => (string)(getenv('MAHDA_S3_ENDPOINT') ?: ''),
    'bucket' => (string)(getenv('MAHDA_S3_BUCKET') ?: ''),
    'region' => (string)(getenv('MAHDA_S3_REGION') ?: 'us-east-1'),
    'access_key' => (string)(getenv('MAHDA_S3_ACCESS_KEY') ?: ''),
    'secret_key' => (string)(getenv('MAHDA_S3_SECRET_KEY') ?: ''),
    'path_style' => $bool('MAHDA_S3_PATH_STYLE', true),
];
