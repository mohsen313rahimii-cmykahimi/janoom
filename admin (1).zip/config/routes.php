<?php
declare(strict_types=1);

use Mahda\Core\Router;
use Mahda\Core\View;
use Mahda\Modules\Home\HomeController;

$moduleRouteFiles = [
    dirname(__DIR__) . '/app/Modules/Auth/routes.php',
    dirname(__DIR__) . '/app/Modules/Content/routes.php',
    dirname(__DIR__) . '/app/Modules/Library/routes.php',
    dirname(__DIR__) . '/app/Modules/Social/routes.php',
    dirname(__DIR__) . '/app/Modules/ContentChin/routes.php',
    dirname(__DIR__) . '/app/Modules/Atlas/routes.php',
    dirname(__DIR__) . '/app/Modules/Showcase/routes.php',
    dirname(__DIR__) . '/app/Modules/Portal/routes.php',
];

$moduleRegistrars = [];
foreach ($moduleRouteFiles as $routeFile) {
    $registrar = require $routeFile;
    if (!is_callable($registrar)) {
        throw new RuntimeException('Invalid module route registrar: ' . basename(dirname($routeFile)));
    }
    $moduleRegistrars[] = $registrar;
}

return static function (Router $router, View $view) use ($moduleRegistrars): void {
    $home = new HomeController($view);
    $router->get('/', [$home, 'index']);

    foreach ($moduleRegistrars as $registerModule) {
        $registerModule($router, $view);
    }
};
