<?php
declare(strict_types=1);

return [
    // Opaque random tokens. Only SHA-256 hashes are stored server-side.
    'access_ttl_seconds' => 15 * 60,
    'refresh_ttl_seconds' => 30 * 24 * 60 * 60,
    'max_device_label_length' => 120,
];
