<?php
declare(strict_types=1);

// Shared-host fallback: load the protected AI secret file even when this
// config is evaluated outside the normal API kernel bootstrap.
if (class_exists('Mahda\\Core\\Environment')) {
    // Non-hidden filename is used as a shared-host fallback because some\n    // hosting extractors skip dotfiles. Both files are blocked by .htaccess.\n    \Mahda\Core\Environment::loadSecretFile(dirname(__DIR__) . '/mahda-ai.env');\n    \Mahda\Core\Environment::loadSecretFile(dirname(__DIR__) . '/.mahda-ai.env');
}

$bool = static fn(string $name, bool $default): bool => (($raw = getenv($name)) === false)
    ? $default
    : in_array(strtolower(trim((string)$raw)), ['1','true','yes','on'], true);
$int = static fn(string $name, int $default): int => (($raw = getenv($name)) === false || trim((string)$raw) === '') ? $default : (int)$raw;
$float = static fn(string $name, float $default): float => (($raw = getenv($name)) === false || trim((string)$raw) === '') ? $default : (float)$raw;
$text = static fn(string $name, string $default = ''): string => (($raw = getenv($name)) === false) ? $default : trim((string)$raw);

return [
    'enabled' => $bool('AI_SEARCH_ENABLED', false),
    'provider' => $text('AI_PROVIDER', 'seekai'),
    'model' => $text('AI_MODEL', 'glm-5.2'),
    'fallback_model' => $text('AI_MODEL_FALLBACK', ''),
    'base_url' => rtrim($text('AI_BASE_URL', 'https://seekai.cc/v1'), '/'),
    'api_key' => $text('AI_API_KEY', ''),
    'timeout_seconds' => max(2, min(20, $int('AI_SEARCH_TIMEOUT_SECONDS', 8))),
    'connect_timeout_seconds' => max(1, min(8, $int('AI_SEARCH_CONNECT_TIMEOUT_SECONDS', 3))),
    'max_output_tokens' => max(100, min(500, $int('AI_SEARCH_MAX_OUTPUT_TOKENS', 250))),
    'daily_limit' => max(1, min(5, $int('AI_SEARCH_DAILY_LIMIT', 1))),
    'max_results' => max(1, min(12, $int('AI_SEARCH_MAX_RESULTS', 6))),
    'analysis_cache_ttl' => max(60, min(86400, $int('AI_SEARCH_ANALYSIS_CACHE_TTL', 21600))),
    'circuit_failure_threshold' => max(2, min(20, $int('AI_SEARCH_CIRCUIT_FAILURES', 4))),
    'circuit_window_seconds' => max(30, min(1800, $int('AI_SEARCH_CIRCUIT_WINDOW_SECONDS', 300))),
    'circuit_open_seconds' => max(30, min(1800, $int('AI_SEARCH_CIRCUIT_OPEN_SECONDS', 180))),
    'input_cost_per_million' => max(0.0, $float('AI_SEARCH_INPUT_COST_PER_MILLION', 0.0)),
    'output_cost_per_million' => max(0.0, $float('AI_SEARCH_OUTPUT_COST_PER_MILLION', 0.0)),
];
