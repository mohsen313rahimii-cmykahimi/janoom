<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);
$path = parse_url((string)($_SERVER['REQUEST_URI'] ?? '/api/v1/health'), PHP_URL_PATH) ?: '/api/v1/health';
$path = '/' . trim((string)preg_replace('#^/api/v1#', '', $path), '/');
$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));

$routes = [
    'GET /health' => ['action' => 'health'],
    'GET /session' => ['action' => 'session'],
    'POST /auth/login' => ['action' => 'auth_login'],
    'POST /auth/register' => ['action' => 'auth_register'],
    'POST /auth/logout' => ['action' => 'auth_logout'],
    'POST /mobile/auth/login' => ['action' => 'mobile_auth_login'],
    'POST /mobile/auth/register' => ['action' => 'mobile_auth_register'],
    'POST /mobile/auth/refresh' => ['action' => 'mobile_auth_refresh'],
    'POST /mobile/auth/logout' => ['action' => 'mobile_auth_logout'],
    'GET /mobile/me' => ['action' => 'mobile_me'],
    'POST /sync/drafts' => ['action' => 'mobile_sync_drafts_push'],
    'GET /sync/drafts' => ['action' => 'mobile_sync_drafts_pull'],
    'GET /categories' => ['action' => 'categories'],
    'GET /contents' => ['action' => 'contents'],
    'GET /search' => ['action' => 'global_search'],
    'GET /me/contents' => ['action' => 'my_contents'],
    'GET /notifications' => ['action' => 'notifications'],
    'POST /notifications/read' => ['action' => 'notifications_read'],
    'GET /library' => ['action' => 'library'],
    'GET /profile' => ['action' => 'profile'],
];

$key = $method . ' ' . $path;
if (!isset($routes[$key])) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(404);
    echo json_encode(['error' => 'not_found', 'api' => 'v1'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$_GET['action'] = $routes[$key]['action'];
header('X-Mahda-API-Version: 1');
require $root . '/app/Api/Kernel.php';
