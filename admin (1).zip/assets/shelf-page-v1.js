(() => {
  'use strict';
  const API='/mahda-api/index.php';
  const grid=document.getElementById('folderGrid'),meta=document.getElementById('folderMeta'),view=document.getElementById('folderView');
  let csrf='',folders=[],unsorted=0;
  const colors={sage:'#72a878',mint:'#65b99c',sky:'#74aecd',blue:'#6687cf',violet:'#8f78c5',rose:'#c97b8e',amber:'#d7a34a',sand:'#b79b70'};
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fa=n=>Number(n||0).toLocaleString('fa-IR');
  const icon=(n,s=18)=>`<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${n==='plus'?'<path d="M12 5v14M5 12h14"/>':n==='back'?'<path d="M19 12H5m6-6-6 6 6 6"/>':n==='dots'?'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>':'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m3 16 5-5 4 4 3-3 6 6"/>'}</svg>`;
  async function get(action,params={}){const u=new URL(API,location.origin);u.searchParams.set('action',action);Object.entries(params).forEach(([k,v])=>u.searchParams.set(k,String(v)));const r=await fetch(u,{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||action);return d;}
  async function post(action,body,retry=true){if(!csrf){const s=await get('session');csrf=s.csrf||'';}const r=await fetch(`${API}?action=${action}`,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json',Accept:'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body||{})});const d=await r.json().catch(()=>({}));if(r.status===419&&retry){csrf='';return post(action,body,false)}if(!r.ok)throw Error(d.error||action);return d;}
  function color(k){return colors[k]||colors.sage}
  function renderFolders(){
    meta.textContent=`${fa(folders.length)} پوشه خصوصی`;
    const old=unsorted>0?`<div class="shelf-folder virtual" role="button" tabindex="0" data-folder="0" style="--folder:${colors.sand}"><strong>ذخیره‌های قبلی</strong><small>${fa(unsorted)} محتوا</small></div>`:'';
    grid.innerHTML=old+folders.map(f=>`<div class="shelf-folder" role="button" tabindex="0" data-folder="${f.id}" style="--folder:${color(f.color)}"><button class="folder-menu" type="button" data-edit="${f.id}" aria-label="ویرایش">${icon('dots',14)}</button><strong>${esc(f.name)}</strong><small>${fa(f.count)} محتوا</small></div>`).join('')+`<button class="shelf-folder new-folder" id="folderAddCard" type="button"><span>${icon('plus',18)}</span><strong>پوشه جدید</strong></button>`;
    grid.querySelectorAll('[data-folder]').forEach(b=>{b.addEventListener('click',e=>{if(e.target.closest('[data-edit]'))return;openFolder(Number(b.dataset.folder))});b.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openFolder(Number(b.dataset.folder))}})});
    grid.querySelectorAll('[data-edit]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();editFolder(Number(b.dataset.edit))}));
    document.getElementById('folderAddCard')?.addEventListener('click',()=>folderDialog());
  }
  function folderDialog(existing=null){
    const bg=document.createElement('div');bg.className='shelf-dialog-bg';let selected=existing?.color||'sage';
    bg.innerHTML=`<div class="shelf-dialog"><h3>${existing?'ویرایش پوشه':'پوشه جدید'}</h3><p>فقط یک اسم و رنگ انتخاب کن؛ این پوشه کاملاً خصوصی است.</p><input class="shelf-name" maxlength="60" placeholder="مثلاً محرم ۱۴۰۶" value="${esc(existing?.name||'')}"><div class="shelf-colors">${Object.entries(colors).map(([k,v])=>`<button class="shelf-color ${k===selected?'on':''}" type="button" data-color="${k}" style="--folder:${v}" aria-label="${k}"></button>`).join('')}</div><div class="shelf-error" hidden></div><div class="shelf-dialog-actions"><button type="button" class="cancel">انصراف</button>${existing?'<button type="button" class="delete">حذف پوشه</button>':''}<button type="button" class="primary">ذخیره</button></div></div>`;
    document.body.appendChild(bg);const input=bg.querySelector('.shelf-name'),err=bg.querySelector('.shelf-error');
    bg.querySelectorAll('[data-color]').forEach(b=>b.onclick=()=>{selected=b.dataset.color;bg.querySelectorAll('[data-color]').forEach(x=>x.classList.toggle('on',x===b))});
    bg.querySelector('.cancel').onclick=()=>bg.remove();bg.onclick=e=>{if(e.target===bg)bg.remove()};
    bg.querySelector('.primary').onclick=async()=>{const name=input.value.trim();if(!name){err.hidden=false;err.textContent='برای پوشه یک اسم بنویس.';return;}try{if(existing)await post('shelf_folder_update',{id:existing.id,name,color:selected});else await post('shelf_folder_create',{name,color:selected});bg.remove();await load();}catch{err.hidden=false;err.textContent='ذخیره پوشه انجام نشد.'}};
    if(existing)bg.querySelector('.delete').onclick=async()=>{if(!confirm('پوشه حذف شود؟ محتواها از مهدا حذف نمی‌شوند و ذخیره‌ها از بین نمی‌روند.'))return;try{await post('shelf_folder_delete',{id:existing.id});bg.remove();view.hidden=true;await load();}catch{err.hidden=false;err.textContent='حذف پوشه انجام نشد.'}};
    setTimeout(()=>input.focus(),40);
  }
  function editFolder(id){const f=folders.find(x=>x.id===id);if(f)folderDialog(f)}
  async function openFolder(id){
    view.hidden=false;view.innerHTML='<div class="shelf-empty">در حال باز کردن پوشه…</div>';view.scrollIntoView({behavior:'smooth',block:'start'});
    try{const d=await get('shelf_folder',{folder_id:id,limit:100});const items=Array.isArray(d.items)?d.items:[];view.innerHTML=`<div class="shelf-folder-head"><button type="button" id="closeFolder">${icon('back',17)}</button><div><h3>${esc(d.folder?.name||'پوشه')}</h3><p>${fa(items.length)} محتوا در این پوشه</p></div></div><div class="shelf-content-grid">${items.length?items.map(x=>`<article class="shelf-content"><a href="/content/item/${encodeURIComponent(x.id)}">${x.image?`<img src="${esc(x.image)}" alt="" loading="lazy">`:`<span class="shelf-content-placeholder">${icon('image',28)}</span>`}<div class="shelf-content-copy"><strong>${esc(x.title||'بدون عنوان')}</strong><small>${esc(x.categoryLabel||x.publisher||'مهدا')}</small></div></a></article>`).join(''):'<div class="shelf-empty">این پوشه هنوز خالی است.<br>از صفحه هر محتوا روی «قفسه» بزن و این پوشه را انتخاب کن.</div>'}</div>`;document.getElementById('closeFolder').onclick=()=>{view.hidden=true};}
    catch(e){view.innerHTML='<div class="shelf-empty">باز کردن پوشه انجام نشد.</div>'}
  }
  async function load(){try{const s=await get('session');csrf=s.csrf||'';if(!s.user||s.user.guest||!s.user.profile_complete){location.href='/profile?returnTo=%2Fshelf';return;}const d=await get('shelf_bootstrap');folders=Array.isArray(d.folders)?d.folders:[];unsorted=Number(d.unsortedCount||0);renderFolders();}catch(e){grid.innerHTML='<div class="shelf-empty">دریافت قفسه انجام نشد.</div>';meta.textContent='خطای اتصال';}}
  document.getElementById('newFolder')?.addEventListener('click',()=>folderDialog());load();
})();
