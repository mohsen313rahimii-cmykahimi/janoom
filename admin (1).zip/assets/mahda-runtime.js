(()=>{
  'use strict';
  const BUILD='20260916-php-modular-v3';
  window.__MAHDA_BUILD__=BUILD;
  try{document.documentElement.dataset.mahdaBuild=BUILD;}catch(_e){}

  // One-time cleanup of browser caches left by the retired legacy frontend.
  // This does not touch cookies, localStorage drafts, IndexedDB or user data.
  const key='mahda:legacy-cache-cleaned:'+BUILD;
  try{
    if(sessionStorage.getItem(key)!=='1'){
      sessionStorage.setItem(key,'1');
      if('serviceWorker' in navigator){
        navigator.serviceWorker.getRegistrations().then(regs=>Promise.all(regs.map(r=>r.unregister()))).catch(()=>{});
      }
      if('caches' in window){
        caches.keys().then(names=>Promise.all(names.map(n=>caches.delete(n)))).catch(()=>{});
      }
    }
  }catch(_e){}
})();
