(() => {
  'use strict';
  window.MahdaSearch = window.MahdaSearch || {
    endpoint(query) {
      const url = new URL('/mahda-api/index.php', window.location.origin);
      url.searchParams.set('action', 'global_search');
      url.searchParams.set('q', query);
      return url;
    },
  };
})();

