(() => {
  'use strict';
  window.MahdaContentBank = window.MahdaContentBank || {
    buildQuery(params = {}) {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null && String(value) !== '') query.set(key, String(value));
      });
      return query;
    },
  };
})();

