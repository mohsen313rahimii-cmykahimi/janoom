(() => {
  'use strict';
  const el = document.getElementById('showcase-state');
  if (!el) return;
  let state;
  try { state=JSON.parse(el.textContent); } catch { return; }
  const api='/mahda-api/index.php';
  const fa=n=>Number(n||0).toLocaleString('fa-IR');
  const login=()=>location.assign('/profile?returnTo='+encodeURIComponent(location.pathname));
  let toastTimer;
  function toast(text) {
    const box=document.getElementById('toast');
    box.textContent=text; box.classList.add('show');
    clearTimeout(toastTimer); toastTimer=setTimeout(()=>box.classList.remove('show'),2600);
  }
  async function session() {
    const response=await fetch(api+'?action=session',{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}});
    if(!response.ok) throw Error('session_unavailable');
    const data=await response.json();
    state.csrf=data.csrf||'';
    state.authenticated=!!data.user&&!data.user.guest;
    state.complete=!!data.user?.profile_complete;
  }
  async function post(action,body,retry=true) {
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),20000);
    let response,data;
    try {
      response=await fetch(api+'?action='+action,{method:'POST',credentials:'same-origin',cache:'no-store',signal:controller.signal,
        headers:{'Content-Type':'application/json',Accept:'application/json','X-CSRF-Token':state.csrf},body:JSON.stringify(body)});
      data=await response.json();
    } finally { clearTimeout(timeout); }
    if(response.status===419&&data.error==='csrf_failed'&&retry) {
      await session();
      if(!state.authenticated||!state.complete) { login(); throw Error('auth_required'); }
      return post(action,body,false);
    }
    if(!response.ok) {
      if(response.status===401||['auth_required','profile_incomplete','profile_completion_required'].includes(data.error)) login();
      throw Error(data.error||'request_failed');
    }
    if(data.csrf)state.csrf=data.csrf;
    return data;
  }
  function gated() { if(!state.authenticated||!state.complete) { login(); return true; } return false; }
  async function interact(button) {
    if(button.disabled||gated())return;
    const contentId=Number(button.dataset.id),kind=button.dataset.kind;
    if(!Number.isSafeInteger(contentId)||contentId<1||!['like','executed','bookmark'].includes(kind))return;
    if(kind==='bookmark'&&window.MahdaShelf){window.MahdaShelf.open(contentId,{onSaved:(data)=>{button.classList.toggle('active',!!data.saved);button.setAttribute('aria-pressed',String(!!data.saved));let count=button.querySelector('.count');if(Number(data.count)>0){if(!count){count=document.createElement('span');count.className='count';button.appendChild(count);}count.textContent=fa(data.count);}else count?.remove();toast(data.saved?'در قفسه ذخیره شد':'از قفسه برداشته شد');}});return;}
    button.disabled=true; button.setAttribute('aria-busy','true');
    try {
      const data=await post('interaction',{contentId,kind,active:!button.classList.contains('active')});
      button.classList.toggle('active',!!data.active);button.setAttribute('aria-pressed',String(!!data.active));
      let count=button.querySelector('.count');
      if(Number(data.count)>0) {
        if(!count){count=document.createElement('span');count.className='count';button.appendChild(count);}
        count.textContent=fa(data.count);
      } else count?.remove();
    } catch { toast('این عمل انجام نشد؛ دوباره تلاش کنید.'); }
    finally { button.disabled=false;button.removeAttribute('aria-busy'); }
  }
  async function follow(button) {
    if(button.disabled||gated())return;
    button.disabled=true; button.setAttribute('aria-busy','true');
    try {
      const data=await post('follow',{profileId:state.profileId,active:!state.following});
      state.following=!!data.following;
      button.classList.toggle('on',state.following);button.setAttribute('aria-pressed',String(state.following));
      button.textContent=state.following?'دنبال می‌کنید':'دنبال کردن';
      document.getElementById('followerCount').textContent=fa(data.count);
    } catch { toast('دنبال‌کردن انجام نشد؛ دوباره تلاش کنید.'); }
    finally { button.disabled=false;button.removeAttribute('aria-busy'); }
  }
  async function share(id) {
    const url=location.origin+'/content/item/'+encodeURIComponent(id);
    try {
      if(navigator.share){await navigator.share({title:'مهدا',text:'این محتوا را در مهدا ببین',url});return;}
      await navigator.clipboard.writeText(url);toast('لینک محتوا کپی شد');
    } catch(e) { if(e.name!=='AbortError')toast('اشتراک‌گذاری انجام نشد'); }
  }
  document.addEventListener('click',event=>{
    const button=event.target.closest('button');if(!button||button.disabled)return;
    if(button.hasAttribute('data-reload')){location.reload();return;}
    if(button.dataset.go){location.assign(button.dataset.go);return;}
    if(button.dataset.tab){
      document.querySelectorAll('.tab').forEach(tab=>{const selected=tab===button;tab.classList.toggle('active',selected);tab.setAttribute('aria-selected',String(selected));});
      document.getElementById('tabContent').hidden=button.dataset.tab!=='content';
      document.getElementById('tabAbout').hidden=button.dataset.tab!=='about';return;
    }
    if(button.id==='followBtn'){follow(button);return;}
    if(button.classList.contains('interaction')){interact(button);return;}
    if(button.dataset.kind==='comment'){location.assign('/content/item/'+encodeURIComponent(button.dataset.id)+'#comments');return;}
    if(button.dataset.kind==='share'){share(button.dataset.id);return;}
    if(button.dataset.menuId){
      const id=Number(button.dataset.profileId);
      if(id>0&&confirm('برای دیدن صفحه منتشرکننده، تایید را بزنید.\nبرای دیدن خود محتوا، لغو را بزنید.'))location.assign('/showcase/profile/'+id);
      else location.assign('/content/item/'+encodeURIComponent(button.dataset.menuId));
    }
  });
  // Revalidate personalized markup when restored from the browser back-forward cache.
  window.addEventListener('pageshow',event=>{if(event.persisted)location.reload();});
})();
