(() => {
  'use strict';
  if(window.MahdaShelf)return;
  const API='/mahda-api/index.php';let csrf='';
  const colors={sage:'#72a878',mint:'#65b99c',sky:'#74aecd',blue:'#6687cf',violet:'#8f78c5',rose:'#c97b8e',amber:'#d7a34a',sand:'#b79b70'};
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fa=n=>Number(n||0).toLocaleString('fa-IR');
  async function get(action,params={}){const u=new URL(API,location.origin);u.searchParams.set('action',action);Object.entries(params).forEach(([k,v])=>u.searchParams.set(k,String(v)));const r=await fetch(u,{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||action);return d;}
  async function post(action,body,retry=true){if(!csrf){const s=await get('session');csrf=s.csrf||'';}const r=await fetch(`${API}?action=${action}`,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json',Accept:'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body||{})});const d=await r.json().catch(()=>({}));if(r.status===419&&retry){csrf='';return post(action,body,false)}if(!r.ok)throw Error(d.error||action);return d;}
  function login(){location.href='/profile?returnTo='+encodeURIComponent(location.pathname+location.search)}
  async function open(contentId,opts={}){
    if(!Number.isInteger(Number(contentId))||Number(contentId)<1)return;
    let data;try{data=await get('shelf_content_state',{content_id:Number(contentId)});}catch(e){if(['auth_required','profile_incomplete','profile_completion_required'].includes(e.message)){login();return;}opts.onError?.(e);return;}
    let folders=Array.isArray(data.folders)?data.folders:[],selected=new Set(folders.filter(f=>f.selected).map(f=>Number(f.id))),creating=false;
    const bg=document.createElement('div');bg.className='shelf-picker-bg';
    function render(){
      const picked=folders.filter(f=>selected.has(Number(f.id)));
      bg.innerHTML=`<div class="shelf-picker"><h3>افزودن به قفسه</h3><p>یک یا چند پوشه را انتخاب کن. قفسه تو خصوصی است و فقط خودت آن را می‌بینی.</p><div class="shelf-picker-folders">${folders.map(f=>`<button type="button" class="shelf-folder ${selected.has(Number(f.id))?'selected':''}" data-pick="${f.id}" style="--folder:${colors[f.color]||colors.sage}"><strong>${esc(f.name)}</strong><small>${fa(f.count)} محتوا</small></button>`).join('')}${folders.length?'':'<div class="shelf-empty">هنوز پوشه‌ای نداری؛ همین پایین یکی بساز.</div>'}</div><div class="shelf-selected-line">${picked.length?'انتخاب شده: '+picked.map(f=>esc(f.name)).join('، '):data.saved?'این محتوا قبلاً ذخیره شده؛ برای مرتب‌شدن یک پوشه انتخاب کن.':'هنوز پوشه‌ای انتخاب نشده.'}</div><button type="button" class="shelf-create-toggle">+ ساخت پوشه جدید</button><div class="shelf-create-inline" ${creating?'':'hidden'}><input class="shelf-name" maxlength="60" placeholder="نام پوشه"><div class="shelf-colors">${Object.entries(colors).map(([k,v],i)=>`<button class="shelf-color ${i===0?'on':''}" type="button" data-newcolor="${k}" style="--folder:${v}"></button>`).join('')}</div><button type="button" class="shelf-create-toggle" data-create>ساخت و انتخاب پوشه</button></div><div class="shelf-error" hidden></div><div class="shelf-picker-actions"><button type="button" class="cancel">بستن</button><button type="button" class="primary">ذخیره تغییرات</button></div></div>`;
      bg.querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>{const id=Number(b.dataset.pick);selected.has(id)?selected.delete(id):selected.add(id);render()});
      bg.querySelector('.shelf-create-toggle').onclick=()=>{creating=true;render();setTimeout(()=>bg.querySelector('.shelf-name')?.focus(),20)};
      let newColor='sage';bg.querySelectorAll('[data-newcolor]').forEach(b=>b.onclick=()=>{newColor=b.dataset.newcolor;bg.querySelectorAll('[data-newcolor]').forEach(x=>x.classList.toggle('on',x===b))});
      const create=bg.querySelector('[data-create]');if(create)create.onclick=async()=>{const input=bg.querySelector('.shelf-name'),name=input.value.trim(),err=bg.querySelector('.shelf-error');if(!name){err.hidden=false;err.textContent='نام پوشه را بنویس.';return;}try{const d=await post('shelf_folder_create',{name,color:newColor});folders.push({...d.folder,selected:true});selected.add(Number(d.folder.id));creating=false;render();}catch{err.hidden=false;err.textContent='ساخت پوشه انجام نشد.'}};
      bg.querySelector('.cancel').onclick=()=>bg.remove();bg.querySelector('.primary').onclick=async()=>{const btn=bg.querySelector('.primary'),err=bg.querySelector('.shelf-error');btn.disabled=true;btn.textContent='در حال ذخیره…';try{const d=await post('shelf_content_set',{contentId:Number(contentId),folderIds:[...selected]});bg.remove();opts.onSaved?.(d);}catch(e){btn.disabled=false;btn.textContent='ذخیره تغییرات';err.hidden=false;err.textContent='ذخیره در قفسه انجام نشد.'}};
    }
    render();document.body.appendChild(bg);bg.addEventListener('click',e=>{if(e.target===bg)bg.remove()});
  }
  window.MahdaShelf={open};
})();
