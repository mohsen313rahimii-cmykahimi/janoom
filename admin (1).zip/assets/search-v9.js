(() => {
  const API = '/mahda-api/index.php';
  const q = document.getElementById('q');
  const root = document.getElementById('root');
  let timer = 0;
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c] || c));
  const fa = (n) => Number(n || 0).toLocaleString('fa-IR');
  const userSvg = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg>';
  async function get(action, params = {}) {
    const u = new URL(API, location.origin); u.searchParams.set('action', action);
    Object.entries(params).forEach(([k,v]) => u.searchParams.set(k,v));
    const r = await fetch(u, {credentials:'same-origin', cache:'no-store', headers:{Accept:'application/json'}});
    const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || action); return d;
  }
  function emptyStart() {
    root.innerHTML = '<section class="panel suggest"><h2>دنبال چه چیزی هستید؟</h2><p>یک عبارت بنویسید یا از پیشنهادها شروع کنید.</p><div class="chips" id="chips"><button class="chip">بازی</button><button class="chip">همکاری</button><button class="chip">محرم</button><button class="chip">قصه</button><button class="chip">قم</button><button class="chip">مهربانی</button></div></section>';
    bindChips();
  }
  function section(title, count, html) {
    return count ? `<section class="result-section"><div class="section-title"><div><h2>${title}</h2></div><b>${fa(count)}</b></div>${html}</section>` : '';
  }
  function render(d) {
    if (!d.total) {
      root.innerHTML = `<div class="empty panel"><div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg><div>برای «${esc(d.query)}» چیزی پیدا نشد.</div></div></div>`;
      return;
    }
    let out = `<div class="summary"><span>نتایج «${esc(d.query)}»</span><b>${fa(d.total)} مورد</b></div>`;
    const cs = d.contents || [];
    out += section('محتواها', cs.length, `<div class="content-list">${cs.map((x) => `<article class="content-card" style="--c:${esc(x.categoryColor || '#159658')}"><a class="content-cover" href="/content/item/${x.id}">${x.image ? `<img src="${esc(x.image)}" alt="">` : '<span class="blank"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="m21 15-5-5L5 20"/></svg></span>'}${x.categoryLabel ? `<span class="cat">${esc(x.categoryLabel)}</span>` : ''}</a><h3>${esc(x.title)}</h3>${x.publisher ? `<p>${esc(x.publisher)}</p>` : ''}</article>`).join('')}</div>`);
    const ps = d.profiles || [];
    out += section('مربی‌ها و هیئت‌ها', ps.length, `<div class="profiles">${ps.map((x) => `<a class="profile-card" href="/showcase/profile/${x.id}"><span class="p-avatar">${x.avatarUrl ? `<img src="${esc(x.avatarUrl)}" alt="">` : userSvg}</span><span class="p-info"><strong>${esc(x.name)}${x.verified ? '<span class="verified">✓</span>' : ''}</strong><small>${x.role === 'heiat' ? 'هیئت' : 'مربی'}${x.city ? ' · ' + esc(x.city) : ''}</small></span><span class="p-stats">${fa(x.contentCount)} محتوا<br>${fa(x.followers)} دنبال‌کننده</span></a>`).join('')}</div>`);
    const cities = d.cities || [];
    out += section('شهرها', cities.length, `<div class="place-grid">${cities.map((x) => `<a class="place" href="/atlas/?cityId=${x.id}&type=all"><strong>${esc(x.name)}</strong><small>${esc(x.province_name || '')}</small></a>`).join('')}</div>`);
    const taxes = [...(d.topics || []).map((x) => ({...x,t:'موضوع'})), ...(d.goals || []).map((x) => ({...x,t:'هدف تربیتی'})), ...(d.occasions || []).map((x) => ({...x,t:'مناسبت'}))];
    out += section('موضوع‌ها و مناسبت‌ها', taxes.length, `<div class="tax-wrap">${taxes.map((x) => `<button class="tax-row" data-q="${esc(x.label)}">${esc(x.label)} · ${x.t}</button>`).join('')}</div>`);
    root.innerHTML = out;
    root.querySelectorAll('.tax-row').forEach((b) => b.addEventListener('click', () => { q.value = b.dataset.q; search(q.value); }));
  }
  async function search(value) {
    const v = value.trim();
    history.replaceState(null, '', v ? `/search?q=${encodeURIComponent(v)}` : '/search');
    if (!v) { emptyStart(); return; }
    root.innerHTML = '<div class="loading-wrap"><div><div class="spinner"></div><div>در حال جستجو…</div></div></div>';
    try { render(await get('global_search', {q:v, limit:12})); }
    catch { root.innerHTML = '<div class="empty panel">جستجو انجام نشد؛ دوباره تلاش کنید.</div>'; }
  }
  function bindChips() {
    document.querySelectorAll('.chip').forEach((b) => b.addEventListener('click', () => { q.value = b.textContent.trim(); search(q.value); }));
  }
  document.getElementById('form').addEventListener('submit', (e) => { e.preventDefault(); clearTimeout(timer); search(q.value); });
  q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => search(q.value), 330); });
  document.getElementById('clear').addEventListener('click', () => { q.value = ''; q.focus(); search(''); });
  bindChips();
  const initial = new URLSearchParams(location.search).get('q') || '';
  if (initial) { q.value = initial; search(initial); }
  get('session').then((s) => {
    if (s.user?.avatar_url) document.getElementById('headAvatar').innerHTML = `<img src="${esc(s.user.avatar_url)}" alt="">`;
    if (!s.user?.guest) get('notifications', {limit:1}).then((n) => {
      if (n.unread > 0) { const d = document.getElementById('notifDot'); d.textContent = n.unread > 99 ? '۹۹+' : fa(n.unread); d.classList.add('show'); }
    }).catch(() => {});
  }).catch(() => {});
})();
