(() => {
  const API = '/mahda-api/index.php';
  const AI_API = '/api/v1/search/ai';
  const q = document.getElementById('q');
  const root = document.getElementById('root');
  const aiBtn = document.getElementById('aiSearchBtn');
  const aiQuota = document.getElementById('aiQuota');
  const aiHint = document.getElementById('aiHint');
  let timer = 0, csrf = '', session = null, quotaState = null;
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c] || c));
  const fa = (n) => Number(n || 0).toLocaleString('fa-IR');
  const svg = (d, size=18) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const icons = {
    search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/>',
    image:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m21 15-5-5L5 20"/>',
    bookmark:'<path d="M6 3h12v18l-6-4-6 4z"/>',
    heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
    sparkle:'<path d="m12 3 1.4 4.1L17.5 8.5l-4.1 1.4L12 14l-1.4-4.1-4.1-1.4 4.1-1.4z"/><path d="m18.5 14 .7 2.1 2.1.7-2.1.7-.7 2.1-.7-2.1-2.1-.7 2.1-.7z"/>',
    arrow:'<path d="m9 18 6-6-6-6"/>'
  };
  async function get(action, params = {}) {
    const u = new URL(API, location.origin); u.searchParams.set('action', action);
    Object.entries(params).forEach(([k,v]) => u.searchParams.set(k,v));
    const r = await fetch(u, {credentials:'same-origin', cache:'no-store', headers:{Accept:'application/json'}});
    const d = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(d.error || action), {status:r.status,data:d}); return d;
  }
  async function postLegacy(action, body) {
    if (!csrf) { const s = await get('session'); csrf = s.csrf || ''; session = s.user || session; }
    const r = await fetch(`${API}?action=${encodeURIComponent(action)}`, {method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body||{})});
    const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || action); return d;
  }
  async function quota() {
    try {
      const r = await fetch(`${AI_API}/quota`, {credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}});
      const d = await r.json().catch(() => ({}));
      if (r.status === 401) { quotaState = {guest:true,allowed:false}; renderQuota(); return; }
      if (!r.ok) throw new Error(d.error || 'quota');
      quotaState = d; renderQuota();
    } catch { quotaState = {allowed:false,unavailable:true}; renderQuota(); }
  }
  function renderQuota() {
    if (!aiBtn || !aiQuota) return;
    if (quotaState?.guest) { aiQuota.textContent = 'نیاز به ورود'; aiBtn.disabled = false; aiHint.textContent = 'جستجوی عادی برای همه باز است.'; return; }
    if (quotaState?.unavailable) { aiQuota.textContent = 'خطای اتصال سایت'; aiBtn.disabled = true; aiHint.textContent = 'وضعیت جستجوی هوشمند از سرور دریافت نشد.'; return; }
    if (!quotaState?.enabled) { aiQuota.textContent = 'تنظیمات AI خاموش است'; aiBtn.disabled = true; aiHint.textContent = 'جستجوی معمولی همچنان فعال است.'; return; }
    if (!quotaState?.configured) { aiQuota.textContent = 'کلید AI تنظیم نشده'; aiBtn.disabled = true; aiHint.textContent = 'کلید SeekAI روی سرور پیدا نشد.'; return; }
    if (quotaState?.transport === 'missing') { aiQuota.textContent = 'cURL هاست فعال نیست'; aiBtn.disabled = true; aiHint.textContent = 'برای اتصال به SeekAI باید cURL در هاست فعال باشد.'; return; }
    if (!quotaState.allowed) { aiQuota.textContent = 'سهمیه امروز استفاده شده'; aiBtn.disabled = true; aiHint.textContent = 'فردا دوباره می‌تونی از جستجوی هوشمند استفاده کنی.'; return; }
    aiQuota.textContent = `${fa(quotaState.remaining)} جستجو امروز`;
    aiBtn.disabled = false; aiHint.textContent = 'فقط با زدن این دکمه از هوش مصنوعی استفاده می‌شود.';
  }
  function emptyStart() {
    root.innerHTML = '<section class="panel suggest"><h2>دنبال چه چیزی هستید؟</h2><p>یک عبارت بنویسید یا از پیشنهادها شروع کنید.</p><div class="chips" id="chips"><button class="chip">بازی</button><button class="chip">همکاری</button><button class="chip">محرم</button><button class="chip">قصه</button><button class="chip">قم</button><button class="chip">مهربانی</button></div></section>';
    bindChips();
  }
  function section(title, count, html) { return count ? `<section class="result-section"><div class="section-title"><div><h2>${title}</h2></div><b>${fa(count)}</b></div>${html}</section>` : ''; }
  function contentCard(x, smart=false) {
    return `<article class="content-card${smart?' smart-card':''}" style="--c:${esc(x.categoryColor || '#159658')}">
      <a class="content-cover" href="/content/item/${encodeURIComponent(x.id)}">${x.image ? `<img src="${esc(x.image)}" alt="" loading="lazy">` : `<span class="blank">${svg(icons.image,40)}</span>`}${x.categoryLabel ? `<span class="cat">${esc(x.categoryLabel)}</span>` : ''}</a>
      <h3>${esc(x.title)}</h3>${x.publisher ? `<p>${esc(x.publisher)}</p>` : ''}
      ${smart ? `<div class="card-actions"><button data-interaction="bookmark" data-id="${esc(x.id)}" title="افزودن به قفسه">${svg(icons.bookmark,15)} ذخیره</button><button data-interaction="like" data-id="${esc(x.id)}" title="پسندیدن">${svg(icons.heart,15)} پسندیدم</button><a href="/content/item/${encodeURIComponent(x.id)}">مشاهده ${svg(icons.arrow,14)}</a></div>` : ''}
    </article>`;
  }
  function bindCardActions() {
    root.querySelectorAll('[data-interaction]').forEach((b) => b.addEventListener('click', async () => {
      if (!session || session.guest) { location.href = '/profile?returnTo=' + encodeURIComponent(location.pathname + location.search); return; }
      b.disabled = true;
      try { await postLegacy('interaction', {contentId:Number(b.dataset.id),kind:b.dataset.interaction,active:true}); b.classList.add('done'); b.textContent = b.dataset.interaction === 'bookmark' ? 'ذخیره شد' : 'پسندیده شد'; }
      catch { b.disabled = false; }
    }));
  }
  function render(d) {
    if (!d.total) { root.innerHTML = `<div class="empty panel"><div>${svg(icons.search,58)}<div>برای «${esc(d.query)}» چیزی پیدا نشد.</div></div></div>`; return; }
    let out = `<div class="summary"><span>نتایج «${esc(d.query)}»</span><b>${fa(d.total)} مورد</b></div>`;
    const cs = d.contents || []; out += section('محتواها', cs.length, `<div class="content-list">${cs.map((x) => contentCard(x,false)).join('')}</div>`);
    const ps = d.profiles || []; out += section('مربی‌ها و هیئت‌ها', ps.length, `<div class="profiles">${ps.map((x) => `<a class="profile-card" href="/showcase/profile/${x.id}"><span class="p-avatar">${x.avatarUrl ? `<img src="${esc(x.avatarUrl)}" alt="">` : ''}</span><span class="p-info"><strong>${esc(x.name)}${x.verified ? '<span class="verified">✓</span>' : ''}</strong><small>${x.role === 'heiat' ? 'هیئت' : 'مربی'}${x.city ? ' · ' + esc(x.city) : ''}</small></span><span class="p-stats">${fa(x.contentCount)} محتوا<br>${fa(x.followers)} دنبال‌کننده</span></a>`).join('')}</div>`);
    const cities = d.cities || []; out += section('شهرها', cities.length, `<div class="place-grid">${cities.map((x) => `<a class="place" href="/atlas/?cityId=${x.id}&type=all"><strong>${esc(x.name)}</strong><small>${esc(x.province_name || '')}</small></a>`).join('')}</div>`);
    const taxes = [...(d.topics || []).map((x) => ({...x,t:'موضوع'})), ...(d.goals || []).map((x) => ({...x,t:'هدف تربیتی'})), ...(d.occasions || []).map((x) => ({...x,t:'مناسبت'}))];
    out += section('موضوع‌ها و مناسبت‌ها', taxes.length, `<div class="tax-wrap">${taxes.map((x) => `<button class="tax-row" data-q="${esc(x.label)}">${esc(x.label)} · ${x.t}</button>`).join('')}</div>`);
    root.innerHTML = out; root.querySelectorAll('.tax-row').forEach((b) => b.addEventListener('click', () => { q.value = b.dataset.q; search(q.value); }));
  }
  async function search(value) {
    const v = value.trim(); history.replaceState(null, '', v ? `/search?q=${encodeURIComponent(v)}` : '/search');
    if (!v) { emptyStart(); return; }
    root.innerHTML = '<div class="loading-wrap"><div><div class="spinner"></div><div>در حال جستجو…</div></div></div>';
    try { render(await get('global_search', {q:v, limit:12})); } catch { root.innerHTML = '<div class="empty panel">جستجو انجام نشد؛ دوباره تلاش کنید.</div>'; }
  }
  function interpretedText(i={}) {
    const parts=[]; if(i.category)parts.push(i.category); if(i.occasion)parts.push(i.occasion); if(i.age)parts.push(i.age==='4-6'?'۴ تا ۶ سال':'۷ تا ۱۰ سال'); if(i.equipment==='none')parts.push('بدون وسیله'); if(i.activity_level)parts.push({low:'کم‌تحرک',medium:'تحرک متوسط',high:'پرتحرک'}[i.activity_level]||''); return parts.filter(Boolean).join(' · ');
  }
  function renderClarification(data) {
    const c=data.clarification||{}; const chips=c.chips||[];
    root.innerHTML = `<section class="panel ai-clarify"><div class="ai-title">${svg(icons.sparkle,20)} <strong>یک سؤال کوتاه</strong></div><p>${esc(c.message||'کمی دقیق‌تر بگو چه می‌خواهی.')}</p><div class="clarify-chips">${chips.map(x=>`<button data-answer="${esc(x)}">${esc(x)}</button>`).join('')}</div><small>این مرحله از سهمیه هوشمندت کم نمی‌کند.</small></section>`;
    root.querySelectorAll('[data-answer]').forEach(b=>b.addEventListener('click',()=>{const ans=b.dataset.answer||'';q.value=(q.value.trim()+' '+ans).trim();smartSearch();}));
  }
  function renderAiResults(data, meta={}) {
    const items=data.items||[]; const near=data.match_type==='nearest'; const summary=interpretedText(data.interpreted_as||{});
    let html=`<section class="ai-result-head"><div class="ai-title">${svg(icons.sparkle,20)}<strong>جستجوی هوشمند</strong></div><h2>${summary?esc(summary):'برای درخواست شما'}</h2>${near?'<p class="near-note">مورد کاملاً منطبق پیدا نشد؛ این‌ها نزدیک‌ترین پیشنهادهای مهدا هستند.</p>':'<p>نتیجه‌ها فقط از محتوای تأییدشده مهدا هستند.</p>'}</section>`;
    html += items.length ? `<div class="content-list ai-content-list">${items.map(x=>contentCard(x,true)).join('')}</div>` : '<div class="empty panel">برای این درخواست، محتوای تأییدشده‌ای پیدا نشد.</div>';
    root.innerHTML=html; bindCardActions(); if(typeof meta.daily_remaining==='number'){quotaState={...(quotaState||{}),allowed:meta.daily_remaining>0,remaining:meta.daily_remaining,enabled:true,configured:true};renderQuota();}
  }
  async function smartSearch() {
    const value=q.value.trim(); if(!value){q.focus();return;}
    if(quotaState?.guest){root.innerHTML='<section class="panel ai-login"><h2>جستجوی هوشمند برای حساب مهداست</h2><p>برای استفاده از جستجوی هوشمند وارد حساب شوید. جستجوی معمولی همچنان بدون محدودیت در دسترس است.</p><a href="/profile?returnTo=/search">ورود به حساب</a></section>';return;}
    if(aiBtn.disabled)return;
    aiBtn.disabled=true; aiBtn.classList.add('loading'); root.innerHTML='<div class="loading-wrap"><div><div class="spinner"></div><div>مهدا دارد درخواستت را می‌فهمد…</div></div></div>';
    try{
      if(!csrf){const s=await get('session');csrf=s.csrf||'';session=s.user||session;}
      const r=await fetch(AI_API,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({query:value})});
      const d=await r.json().catch(()=>({}));
      if(r.status===401){quotaState={guest:true,allowed:false};renderQuota();throw Object.assign(new Error('auth_required'),{data:d});}
      if(!r.ok)throw Object.assign(new Error(d.error||'ai_search'),{data:d,status:r.status});
      if(d.data?.kind==='clarification')renderClarification(d.data);else renderAiResults(d.data||{},d.meta||{});
    }catch(e){root.innerHTML=`<section class="panel ai-error"><h2>جستجوی هوشمند انجام نشد</h2><p>${esc(e.data?.message||'جستجوی هوشمند فعلاً در دسترس نیست؛ می‌تونی از جستجوی معمولی استفاده کنی.')}</p><button id="normalFallback">جستجوی معمولی</button></section>`;document.getElementById('normalFallback')?.addEventListener('click',()=>search(q.value));if(e.status===429)quota();}
    finally{aiBtn.classList.remove('loading');renderQuota();}
  }
  function bindChips(){document.querySelectorAll('.chip').forEach((b)=>b.addEventListener('click',()=>{q.value=b.textContent.trim();search(q.value);}));}
  document.getElementById('form').addEventListener('submit',(e)=>{e.preventDefault();clearTimeout(timer);search(q.value);});
  q.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>search(q.value),330);});
  document.getElementById('clear').addEventListener('click',()=>{q.value='';q.focus();search('');});
  aiBtn?.addEventListener('click',smartSearch); bindChips();
  const initial=new URLSearchParams(location.search).get('q')||''; if(initial){q.value=initial;search(initial);}
  get('session').then((s)=>{csrf=s.csrf||'';session=s.user||null;if(s.user?.avatar_url)document.getElementById('headAvatar').innerHTML=`<img src="${esc(s.user.avatar_url)}" alt="">`;if(!s.user?.guest)get('notifications',{limit:1}).then((n)=>{if(n.unread>0){const d=document.getElementById('notifDot');d.textContent=n.unread>99?'۹۹+':fa(n.unread);d.classList.add('show');}}).catch(()=>{});quota();}).catch(()=>quota());
})();
