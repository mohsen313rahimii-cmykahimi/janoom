(() => {
  const API = '/mahda-api/index.php';
  let csrf = '';
  let kind = 'bookmark';
  let session = null;
  const grid = document.getElementById('grid');
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c] || c));
  const fa = (n) => Number(n || 0).toLocaleString('fa-IR');
  const icons = {
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    bookmark: '<path d="M6 3h12v18l-6-4-6 4z"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9" r="1.5"/><path d="m21 15-5-5L5 20"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>'
  };
  const icon = (name, size = 19) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[name] || icons.bookmark}</svg>`;
  async function get(action, params = {}) {
    const u = new URL(API, location.origin);
    u.searchParams.set('action', action);
    Object.entries(params).forEach(([k, v]) => u.searchParams.set(k, v));
    const r = await fetch(u, {credentials:'same-origin', cache:'no-store', headers:{Accept:'application/json'}});
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || action);
    return d;
  }
  async function post(action, body, retry = true) {
    if (!csrf) { const s = await get('session'); csrf = s.csrf || ''; session = s.user || session; }
    const r = await fetch(`${API}?action=${encodeURIComponent(action)}`, {
      method:'POST', credentials:'same-origin', cache:'no-store', headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':csrf}, body:JSON.stringify(body||{})
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) {
      if (r.status === 419 && d.error === 'csrf_failed' && retry) {
        csrf = d.csrf || ''; const s = await get('session'); csrf = s.csrf || csrf; session = s.user || session; return post(action, body, false);
      }
      throw new Error(d.error || action);
    }
    if (d.csrf) csrf = d.csrf;
    return d;
  }
  function toast(text) {
    const e = document.getElementById('toast');
    e.textContent = text; e.classList.add('show'); setTimeout(() => e.classList.remove('show'), 2200);
  }
  async function loadNotif() {
    try {
      const d = await get('notifications', {limit:1});
      const dot = document.getElementById('notifDot');
      if (d.unread > 0) { dot.textContent = d.unread > 99 ? '۹۹+' : fa(d.unread); dot.classList.add('show'); }
    } catch {}
  }
  function render(items) {
    if (!items.length) {
      const text = kind === 'bookmark' ? 'هنوز محتوایی ذخیره نکرده‌ای.' : kind === 'executed' ? 'هنوز محتوایی را «انجام دادم» نزده‌ای.' : 'هنوز محتوایی را نپسندیده‌ای.';
      grid.innerHTML = `<div class="empty panel"><div>${icon(kind,54)}<div style="margin-top:9px">${text}</div></div></div>`;
      return;
    }
    grid.innerHTML = items.map((x) => {
      const c = esc(x.categoryColor || '#159658');
      const amount = kind === 'bookmark' ? fa(x.bookmarkCount) : kind === 'executed' ? fa(x.executedCount) : fa(x.likeCount);
      return `<article class="card" style="--c:${c}">
        <a class="cover" href="/content/item/${encodeURIComponent(x.id)}">
          ${x.image ? `<img src="${esc(x.image)}" alt="">` : `<span class="placeholder">${icon('image',44)}</span>`}
          ${x.categoryLabel ? `<span class="badge">${esc(x.categoryLabel)}</span>` : ''}
        </a>
        <div class="body"><h3>${esc(x.title)}</h3>${x.publisher ? `<small>${esc(x.publisher)}</small>` : ''}
          <div class="meta"><span>${icon(kind,14)} ${amount}</span><button class="remove" data-id="${x.id}" aria-label="حذف از این بخش">${icon('x',15)}</button></div>
        </div></article>`;
    }).join('');
    grid.querySelectorAll('.remove').forEach((b) => b.addEventListener('click', () => remove(Number(b.dataset.id))));
  }
  async function load() {
    grid.innerHTML = '<div class="empty"><div><div class="spinner"></div>در حال دریافت…</div></div>';
    try {
      const d = await get('library', {kind, limit:100});
      ['bookmark','executed','like'].forEach((k) => document.getElementById(`count-${k}`).textContent = fa(d.counts?.[k] || 0));
      render(d.items || []);
    } catch (e) {
      if (e.message === 'auth_required' || e.message === 'profile_incomplete') location.href = '/profile?returnTo=/library';
      else grid.innerHTML = '<div class="empty panel">دریافت کتابخانه انجام نشد.</div>';
    }
  }
  async function remove(id) {
    try { await post('interaction', {contentId:id, kind, active:false}); toast('از این بخش برداشته شد'); load(); }
    catch { toast('انجام نشد'); }
  }
  async function init() {
    try {
      const s = await get('session'); csrf = s.csrf || ''; session = s.user;
      if (!session || session.guest || !session.profile_complete) {
        grid.innerHTML = '<div class="empty panel login-card"><div><h2>کتابخانه برای حساب توست</h2><p>برای دیدن ذخیره‌ها و تجربه‌های انجام‌شده وارد حساب مهدا شو.</p><button id="loginBtn">ورود به حساب</button></div></div>';
        document.getElementById('loginBtn')?.addEventListener('click', () => location.href = '/profile?returnTo=/library');
        return;
      }
      loadNotif(); load();
    } catch { grid.innerHTML = '<div class="empty">اتصال به حساب مهدا برقرار نشد.</div>'; }
  }
  document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => {
    kind = t.dataset.kind;
    document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('active', x === t));
    load();
  }));
  init();
})();
