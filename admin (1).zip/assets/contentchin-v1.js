(function () {
  'use strict';

  const API = '/mahda-api/index.php';
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  const isNew = path === '/contentchin/new';
  const isView = path.indexOf('/contentchin/view/') === 0;
  const isHome = path === '/contentchin';
  let csrf = '';
  let boot = null;
  let currentPlan = null;

  const iconPaths = {
    flag: '<path d="M5 21V4"/><path d="M5 5c5-3 9 3 14 0v10c-5 3-9-3-14 0"/>',
    sparkles: '<path d="m12 3-1.5 3.6L7 8l3.5 1.4L12 13l1.5-3.6L17 8l-3.5-1.4Z"/><path d="m19 14-.8 2-2 .8 2 .8L19 20l.8-2.4 2-.8-2-.8Z"/>',
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H11V4H6.5A2.5 2.5 0 0 0 4 6.5Z"/><path d="M20 19.5a2.5 2.5 0 0 0-2.5-2.5H13V4h4.5A2.5 2.5 0 0 1 20 6.5Z"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3.5 20a5.5 5.5 0 0 1 11 0"/><path d="M16 5.5a3 3 0 0 1 0 5.8M17 14.5a5.2 5.2 0 0 1 3.5 5"/>',
    gift: '<rect x="3" y="9" width="18" height="12" rx="2"/><path d="M12 9v12M3 13h18M12 9H8.7a2.7 2.7 0 1 1 2.2-4.3L12 6.5M12 9h3.3a2.7 2.7 0 1 0-2.2-4.3L12 6.5"/>',
    map: '<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Z"/><path d="M9 3v15M15 6v15"/>',
    wand: '<path d="m15 4 5 5"/><path d="m4 20 10-10"/><path d="m6 3 .7 2.3L9 6l-2.3.7L6 9l-.7-2.3L3 6l2.3-.7Z"/><path d="m18 14 .6 2 2 .6-2 .7-.6 2-.7-2-2-.7 2-.6Z"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    usersSmall: '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.3"/><path d="M3.5 20a5.5 5.5 0 0 1 11 0M15 15a4.5 4.5 0 0 1 5 5"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    arrow: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    alert: '<path d="M12 3 2.8 20h18.4Z"/><path d="M12 9v5M12 17h.01"/>',
  };

  function icon(name, size) {
    return '<svg viewBox="0 0 24 24" width="' + (size || 21) + '" height="' + (size || 21) + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (iconPaths[name] || iconPaths.sparkles) + '</svg>';
  }

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char];
    });
  }

  function faDigits(value) {
    return String(value == null ? '' : value).replace(/\d/g, function (digit) { return '۰۱۲۳۴۵۶۷۸۹'[digit]; });
  }

  function typeById(id) {
    return (boot && Array.isArray(boot.planTypes) ? boot.planTypes : []).find(function (item) { return String(item.id) === String(id); }) || null;
  }

  function typeLabel(id) {
    const type = typeById(id);
    return type ? type.label : 'برنامه مهدا';
  }

  function showToast(message) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(function () { toast.classList.remove('show'); }, 2600);
  }

  function navigateBack() {
    const button = document.querySelector('.chin-back');
    const fallback = button && button.dataset.fallback ? button.dataset.fallback : '/';
    const ref = document.referrer || '';
    try {
      const sameOrigin = ref && new URL(ref).origin === location.origin;
      if (sameOrigin && history.length > 1) { history.back(); return; }
    } catch (_) {}
    location.href = fallback;
  }

  function setupBack() {
    document.querySelectorAll('.chin-back').forEach(function (button) { button.addEventListener('click', navigateBack); });
  }

  async function request(action, options) {
    const opts = options || {};
    const url = API + '?action=' + encodeURIComponent(action) + (opts.query || '');
    const headers = Object.assign({ 'Accept': 'application/json' }, opts.headers || {});
    const response = await fetch(url, {
      method: opts.method || 'GET',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: headers,
      body: opts.body,
    });
    let payload = null;
    try { payload = await response.json(); } catch (_) { payload = {}; }
    if (!response.ok) {
      const error = new Error(String(payload.error || 'request_failed'));
      error.status = response.status;
      error.payload = payload;
      throw error;
    }
    return payload;
  }

  async function post(action, body) {
    return request(action, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(body || {}),
    });
  }

  async function loadBootstrap() {
    const payload = await request('contentchin_bootstrap_v1');
    boot = payload;
    csrf = String(payload.csrf || '');
    return payload;
  }

  function errorText(error) {
    const code = error && error.message ? error.message : '';
    const messages = {
      auth_required: 'برای ساخت برنامه، ابتدا وارد حساب مهدا شو.',
      profile_incomplete: 'برای ساخت برنامه، اطلاعات حساب را کامل کن.',
      csrf_failed: 'نشست مهدا تازه شده است؛ دوباره تلاش کن.',
      plan_conflict: 'این پیش‌نویس در جای دیگری تغییر کرده است؛ نسخه تازه را باز کن.',
      invalid_plan_type: 'نوع برنامه را انتخاب کن.',
      invalid_title: 'عنوان برنامه را کوتاه و روشن بنویس.',
      plan_title_required: 'برای انتشار، یک عنوان برای برنامه بنویس.',
      plan_item_required: 'برای انتشار، دست‌کم یک محتوای بانک را به برنامه اضافه کن.',
      content_not_available: 'این محتوا دیگر در بانک عمومی در دسترس نیست.',
      plan_not_editable: 'این برنامه منتشر شده است؛ برای ویرایش دوباره آن را به پیش‌نویس برگردان.',
      invalid_plan_order: 'مرتب‌سازی برنامه معتبر نیست؛ صفحه را تازه کن و دوباره تلاش کن.',
    };
    return messages[code] || 'اتصال به مهدا برقرار نشد؛ دوباره تلاش کن.';
  }

  function authRedirect(error, returnTo) {
    if (!error) return false;
    if (error.message === 'auth_required' || error.message === 'profile_incomplete') {
      location.replace('/profile?returnTo=' + encodeURIComponent(returnTo || location.pathname));
      return true;
    }
    return false;
  }

  function renderDashboard(data) {
    const grid = document.getElementById('templateGrid');
    const drafts = document.getElementById('draftList');
    const cta = document.querySelector('.chin-hero .chin-primary');
    const canCreate = !!data.canCreate;
    if (cta && !canCreate) {
      cta.href = '/profile?returnTo=' + encodeURIComponent('/contentchin/new');
      cta.textContent = 'ورود برای ساخت برنامه ';
      cta.insertAdjacentHTML('beforeend', icon('arrow', 16));
    }
    const templates = Array.isArray(data.templates) ? data.templates : [];
    if (!templates.length) {
      grid.innerHTML = '<div class="chin-empty" style="grid-column:1/-1"><strong>هنوز مسیر آماده‌ای ثبت نشده است</strong><span>می‌توانی یک برنامه آزاد را از صفر شروع کنی.</span></div>';
    } else {
      grid.innerHTML = templates.map(function (template) {
        const type = typeById(template.planType);
        const color = type && type.color ? type.color : '#24925b';
        return '<button class="chin-template-card" type="button" data-template="' + esc(template.slug) + '" style="--template-color:' + esc(color) + '">' +
          '<span class="chin-template-top"><span class="chin-template-icon">' + icon(type && type.icon ? type.icon : 'sparkles', 19) + '</span><span class="chin-template-label">شروع سریع</span></span>' +
          '<strong>' + esc(template.title) + '</strong><small>' + esc(template.description) + '</small></button>';
      }).join('');
      grid.querySelectorAll('[data-template]').forEach(function (button) {
        button.addEventListener('click', function () { location.href = '/contentchin/new?template=' + encodeURIComponent(button.dataset.template); });
      });
    }

    const list = Array.isArray(data.drafts) ? data.drafts : [];
    if (!data.authenticated) {
      drafts.innerHTML = '<div class="chin-empty"><strong>پیش‌نویس‌ها برای حساب تو نگه‌داری می‌شوند</strong><span>برای شروع ساخت برنامه، وارد حساب مهدا شو.</span><br><a class="chin-secondary" style="display:inline-flex;align-items:center;margin-top:9px" href="/profile?returnTo=%2Fcontentchin%2Fnew">ورود به حساب</a></div>';
      return;
    }
    if (!list.length) {
      drafts.innerHTML = '<div class="chin-empty"><strong>هنوز پیش‌نویسی نداری</strong><span>یک مسیر را انتخاب کن تا برنامه‌ات را قدم‌به‌قدم بسازیم.</span></div>';
      return;
    }
    drafts.innerHTML = '<div class="chin-draft-list">' + list.map(function (plan) {
      const title = String(plan.title || '').trim() || 'برنامه بدون عنوان';
      return '<button type="button" class="chin-draft-card" data-plan-id="' + esc(plan.id) + '"><span class="chin-draft-icon">' + icon('sparkles', 18) + '</span><span class="chin-draft-body"><strong>' + esc(title) + '</strong><small>' + esc(typeLabel(plan.planType)) + ' · مرحله ' + faDigits(plan.currentStep || 1) + ' از ۴</small></span><span class="chin-draft-arrow">' + icon('chevron', 17) + '</span></button>';
    }).join('') + '</div>';
    drafts.querySelectorAll('[data-plan-id]').forEach(function (button) {
      button.addEventListener('click', function () { location.href = '/contentchin/view/' + encodeURIComponent(button.dataset.planId); });
    });
  }

  function dashboardError(error) {
    const grid = document.getElementById('templateGrid');
    const drafts = document.getElementById('draftList');
    const html = '<div class="chin-state chin-error" style="grid-column:1/-1"><div>' + icon('alert', 24) + '<strong>خطا در دریافت مسیرها</strong><br><span>' + esc(errorText(error)) + '</span><br><button type="button" class="chin-retry" id="chinRetry">تلاش دوباره</button></div></div>';
    if (grid) grid.innerHTML = html;
    if (drafts) drafts.innerHTML = '<div class="chin-state chin-error"><div>خطا در دریافت پیش‌نویس‌ها<br><button type="button" class="chin-retry" id="chinRetryDraft">تلاش دوباره</button></div></div>';
    document.querySelectorAll('#chinRetry,#chinRetryDraft').forEach(function (button) { button.addEventListener('click', function () { location.reload(); }); });
  }

  function templateFromQuery(data) {
    const slug = new URLSearchParams(location.search).get('template');
    if (!slug) return null;
    return (Array.isArray(data.templates) ? data.templates : []).find(function (item) { return String(item.slug) === slug; }) || null;
  }

  function renderNewForm(data, initialTemplate) {
    const root = document.getElementById('contentChinForm');
    if (!root) return;
    const state = { planType: initialTemplate ? initialTemplate.planType : '', title: '', occasionId: '', ageGroup: '', suggestedDuration: '' };
    const types = Array.isArray(data.planTypes) ? data.planTypes : [];
    const occasions = Array.isArray(data.occasions) ? data.occasions : [];
    const occasionOptions = occasions.map(function (item) { return '<option value="' + esc(item.id) + '">' + esc(item.label) + '</option>'; }).join('');

    root.innerHTML = '<div class="chin-form-title"><span class="chin-heading-icon">' + icon('sparkles', 20) + '</span><div><h2>قدم اول؛ شکل برنامه را انتخاب کن</h2><p>این اطلاعات فقط برای شروع پیش‌نویس ذخیره می‌شود.</p></div></div>' +
      '<label class="chin-label" for="chinTitle">عنوان برنامه <span style="color:#9aa79d;font-weight:500">(اختیاری)</span></label><input class="chin-input" id="chinTitle" maxlength="180" placeholder="مثلاً برنامه کامل موکب محرم" autocomplete="off">' +
      '<span class="chin-label">من می‌خواهم بسازم</span><div class="chin-choice-grid" id="chinTypeChoices">' + types.map(function (type) { return '<button class="chin-choice" type="button" data-type="' + esc(type.id) + '" style="--choice-color:' + esc(type.color || '#24925b') + '"><span class="chin-choice-icon">' + icon(type.icon || 'sparkles', 19) + '</span><strong>' + esc(type.label) + '</strong><small>' + esc(type.description || '') + '</small></button>'; }).join('') + '</div>' +
      '<label class="chin-label" for="chinOccasion">مناسبت <span style="color:#9aa79d;font-weight:500">(اختیاری)</span></label><div class="chin-select-wrap"><select class="chin-input chin-select" id="chinOccasion"><option value="">بدون مناسبت مشخص</option>' + occasionOptions + '</select></div>' +
      '<span class="chin-label">گروه سنی <span style="color:#9aa79d;font-weight:500">(اختیاری)</span></span><div class="chin-choice-grid" id="chinAgeChoices"><button class="chin-choice" type="button" data-age="4-6" style="--choice-color:#4d9b91"><span class="chin-choice-icon">' + icon('usersSmall', 18) + '</span><strong>۴ تا ۶ سال</strong></button><button class="chin-choice" type="button" data-age="7-10" style="--choice-color:#4b83c8"><span class="chin-choice-icon">' + icon('usersSmall', 18) + '</span><strong>۷ تا ۱۰ سال</strong></button></div>' +
      '<span class="chin-label">مدت پیشنهادی برنامه <span style="color:#9aa79d;font-weight:500">(اختیاری)</span></span><div class="chin-choice-grid" id="chinDurationChoices"><button class="chin-choice" type="button" data-duration="30" style="--choice-color:#d68a2a"><span class="chin-choice-icon">' + icon('clock', 18) + '</span><strong>۳۰ دقیقه</strong></button><button class="chin-choice" type="button" data-duration="60" style="--choice-color:#2f9b5b"><span class="chin-choice-icon">' + icon('clock', 18) + '</span><strong>۶۰ دقیقه</strong></button><button class="chin-choice" type="button" data-duration="90" style="--choice-color:#7d66c4"><span class="chin-choice-icon">' + icon('clock', 18) + '</span><strong>۹۰ دقیقه</strong></button></div>' +
      '<p class="chin-helper">بعد از ذخیره، همین‌جا محتواهای بانک را به مسیر اضافه و مرتب می‌کنی. هیچ محتوایی بدون انتخاب تو وارد برنامه نمی‌شود.</p><div class="chin-form-actions"><button class="chin-secondary" type="button" id="chinCancel">بازگشت</button><button class="chin-primary" type="button" id="chinStart">ساخت پیش‌نویس ' + icon('arrow', 16) + '</button></div>';

    const titleInput = document.getElementById('chinTitle');
    const occasionInput = document.getElementById('chinOccasion');
    function mark(selector, attribute, value) {
      root.querySelectorAll(selector).forEach(function (button) { button.classList.toggle('selected', String(button.getAttribute(attribute)) === String(value)); });
    }
    root.querySelectorAll('[data-type]').forEach(function (button) { button.addEventListener('click', function () { state.planType = button.dataset.type; mark('[data-type]', 'data-type', state.planType); }); });
    root.querySelectorAll('[data-age]').forEach(function (button) { button.addEventListener('click', function () { state.ageGroup = state.ageGroup === button.dataset.age ? '' : button.dataset.age; mark('[data-age]', 'data-age', state.ageGroup); }); });
    root.querySelectorAll('[data-duration]').forEach(function (button) { button.addEventListener('click', function () { state.suggestedDuration = state.suggestedDuration === button.dataset.duration ? '' : button.dataset.duration; mark('[data-duration]', 'data-duration', state.suggestedDuration); }); });
    titleInput.addEventListener('input', function () { state.title = titleInput.value; });
    occasionInput.addEventListener('change', function () { state.occasionId = occasionInput.value; });
    if (state.planType) mark('[data-type]', 'data-type', state.planType);

    document.getElementById('chinCancel').addEventListener('click', navigateBack);
    document.getElementById('chinStart').addEventListener('click', async function () {
      const button = document.getElementById('chinStart');
      if (!state.planType) { showToast('اول نوع برنامه را انتخاب کن.'); return; }
      button.disabled = true;
      button.style.opacity = '.7';
      try {
        const keyName = 'mahda:contentchin:client-key:' + String(data.user && data.user.id ? data.user.id : 'session');
        let clientKey = '';
        try { clientKey = localStorage.getItem(keyName) || ''; } catch (_) {}
        if (!clientKey) {
          clientKey = 'cc_' + (window.crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now() + '_' + Math.random().toString(36).slice(2));
          try { localStorage.setItem(keyName, clientKey); } catch (_) {}
        }
        const result = await post('contentchin_plan_start_v1', { clientKey: clientKey, title: state.title, planType: state.planType, occasionId: state.occasionId, ageGroup: state.ageGroup, suggestedDuration: state.suggestedDuration });
        currentPlan = result.plan;
        try { localStorage.removeItem(keyName); } catch (_) {}
        renderCreatedPlan(root, currentPlan);
      } catch (error) {
        if (authRedirect(error, '/contentchin/new')) return;
        button.disabled = false;
        button.style.opacity = '';
        showToast(errorText(error));
      }
    });
  }

  function renderCreatedPlan(root, plan) {
    const type = typeById(plan.planType);
    root.innerHTML = '<div class="chin-created"><span class="chin-created-icon">' + icon('check', 26) + '</span><h2>پیش‌نویس ذخیره شد</h2><p>' + esc(plan.title ? '«' + plan.title + '»' : 'برنامه بدون عنوان') + '<br><span>' + esc(type ? type.label : 'برنامه مهدا') + '</span> آماده است؛ حالا می‌توانی محتواهای بانک را به آن اضافه و مرتب کنی.</p><a class="chin-primary" href="/contentchin/view/' + encodeURIComponent(plan.id) + '">دیدن پیش‌نویس ' + icon('arrow', 16) + '</a><button class="chin-secondary" type="button" id="chinSaveAgain" style="margin:9px auto 0">ذخیره تغییرات</button></div><div class="chin-note">این برنامه هنوز منتشر نشده و فقط در حساب تو به‌صورت پیش‌نویس نگه‌داری می‌شود.</div>';
    const save = document.getElementById('chinSaveAgain');
    save.addEventListener('click', async function () {
      save.disabled = true;
      try {
        const result = await post('contentchin_plan_save_v1', { planId: plan.id, version: plan.version, plan: { title: plan.title, planType: plan.planType, occasionId: plan.occasionId, ageGroup: plan.ageGroup, suggestedDuration: plan.suggestedDuration, currentStep: plan.currentStep } });
        currentPlan = result.plan;
        plan = result.plan;
        save.textContent = 'ذخیره شد ✓';
      } catch (error) {
        if (authRedirect(error, '/contentchin/new')) return;
        showToast(errorText(error));
        save.disabled = false;
      }
    });
  }

  function planItems(plan) {
    return Array.isArray(plan && plan.items) ? plan.items : [];
  }

  function planItemCard(item, index, editable) {
    const image = item.image ? '<img class="chin-plan-thumb" src="' + esc(item.image) + '" alt="">' : '<span class="chin-plan-thumb empty">' + icon('book', 20) + '</span>';
    const note = String(item.note || '').trim();
    const controls = editable ? '<div class="chin-plan-controls">' +
      '<button type="button" data-move="up" data-item-id="' + esc(item.planItemId) + '" aria-label="بالاتر"' + (index === 0 ? ' disabled' : '') + '>↑</button>' +
      '<button type="button" data-move="down" data-item-id="' + esc(item.planItemId) + '" aria-label="پایین‌تر">↓</button>' +
      '<button type="button" data-note-item="' + esc(item.planItemId) + '">یادداشت</button>' +
      '<button type="button" class="danger" data-remove-item="' + esc(item.planItemId) + '">حذف</button>' +
      '</div>' : '';
    return '<article class="chin-plan-item" data-plan-item="' + esc(item.planItemId) + '">' + image +
      '<div class="chin-plan-item-copy"><span class="chin-plan-order">' + faDigits(index + 1) + '</span><strong>' + esc(item.title || 'محتوای بدون عنوان') + '</strong>' +
      '<small>' + esc(item.categoryLabel || 'محتوای مهدا') + (item.duration ? ' · ' + esc(item.duration) : '') + '</small>' +
      (note ? '<p>' + esc(note) + '</p>' : '') + '<a href="/content/item/' + encodeURIComponent(item.id) + '" target="_blank" rel="noopener">مشاهده محتوا</a></div>' + controls + '</article>';
  }

  function renderView(plan) {
    currentPlan = plan;
    const root = document.getElementById('planView');
    if (!root) return;
    const type = typeById(plan.planType);
    const meta = [];
    if (plan.ageGroup) meta.push('<span>' + icon('usersSmall', 14) + (plan.ageGroup === '4-6' ? '۴ تا ۶ سال' : '۷ تا ۱۰ سال') + '</span>');
    if (plan.suggestedDuration) meta.push('<span>' + icon('clock', 14) + faDigits(plan.suggestedDuration) + ' دقیقه</span>');
    const occasion = (boot.occasions || []).find(function (item) { return String(item.id) === String(plan.occasionId); });
    if (occasion) meta.push('<span>' + icon('calendar', 14) + esc(occasion.label) + '</span>');
    const editable = String(plan.status || 'draft') === 'draft';
    const items = planItems(plan);
    const totalDuration = items.reduce(function (sum, item) { return sum + (Number(item.durationMinutes) || 0); }, 0);
    const status = editable ? '<span class="chin-plan-status draft">پیش‌نویس</span>' : '<span class="chin-plan-status published">منتشر شده</span>';
    const list = items.length ? items.map(function (item, index) { return planItemCard(item, index, editable); }).join('') : '<div class="chin-empty"><strong>مسیر برنامه هنوز خالی است</strong><span>از بانک محتوا جست‌وجو کن و آیتم‌های دلخواهت را به ترتیب اضافه کن.</span></div>';
    const builder = editable ? '<section class="chin-builder"><div class="chin-builder-head"><div><h2>افزودن از بانک محتوا</h2><p>عنوان، موضوع یا نام ناشر را جست‌وجو کن.</p></div></div><div class="chin-search-row"><input class="chin-input" id="chinContentQuery" maxlength="120" placeholder="مثلاً بازی گروهی یا قصه محرم"><button class="chin-primary" type="button" id="chinContentSearch">جست‌وجو</button></div><div id="chinContentResults" class="chin-content-results"><div class="chin-note">برای دیدن پیشنهادها، یک عبارت جست‌وجو کن یا بدون نوشتن چیزی «جست‌وجو» را بزن.</div></div></section>' : '';
    const action = editable ? '<button class="chin-primary" type="button" id="chinPublishPlan">انتشار برنامه ' + icon('check',16) + '</button>' : '<button class="chin-secondary" type="button" id="chinReopenPlan">بازگردانی به پیش‌نویس</button>';
    root.innerHTML = '<div class="chin-plan-head"><div><span class="chin-view-kicker">برنامه تربیتی</span><h1>' + esc(plan.title || 'برنامه بدون عنوان') + '</h1><p class="chin-plan-type">' + esc(type ? type.label : 'برنامه مهدا') + '</p></div>' + status + '</div>' +
      '<div class="chin-view-meta">' + meta.join('') + (items.length ? '<span>' + faDigits(items.length) + ' محتوا</span>' : '') + (totalDuration ? '<span>' + faDigits(totalDuration) + ' دقیقه محتوای ثبت‌شده</span>' : '') + '</div>' +
      '<section class="chin-view-list"><div class="chin-builder-head"><div><h2>مسیر برنامه</h2><p>ترتیب اجرا را با فلش‌ها تغییر بده و برای هر بخش یادداشت اجرایی بنویس.</p></div></div><div class="chin-plan-items">' + list + '</div></section>' + builder +
      '<div class="chin-publish-actions">' + action + '<a class="chin-secondary" href="/contentchin">بازگشت به محتواچین</a></div>';
    wirePlanBuilder(plan);
  }

  async function savePlanAction(action, body) {
    const result = await post(action, body);
    currentPlan = result.plan;
    renderView(currentPlan);
    return currentPlan;
  }

  function wirePlanBuilder(plan) {
    const editable = String(plan.status || 'draft') === 'draft';
    const items = planItems(plan);
    if (editable) {
      document.querySelectorAll('[data-remove-item]').forEach(function (button) {
        button.addEventListener('click', async function () {
          if (!confirm('این محتوا از مسیر برنامه حذف شود؟')) return;
          button.disabled = true;
          try { await savePlanAction('contentchin_plan_item_remove_v2', { planId: plan.id, itemId: Number(button.dataset.removeItem) }); showToast('محتوا از برنامه حذف شد.'); }
          catch (error) { button.disabled = false; showToast(errorText(error)); }
        });
      });
      document.querySelectorAll('[data-note-item]').forEach(function (button) {
        button.addEventListener('click', async function () {
          const item = items.find(function (entry) { return String(entry.planItemId) === String(button.dataset.noteItem); });
          if (!item) return;
          const value = prompt('یادداشت اجرایی این بخش را بنویس:', String(item.note || ''));
          if (value === null) return;
          button.disabled = true;
          try { await savePlanAction('contentchin_plan_item_note_v2', { planId: plan.id, itemId: Number(button.dataset.noteItem), note: value }); showToast('یادداشت ذخیره شد.'); }
          catch (error) { button.disabled = false; showToast(errorText(error)); }
        });
      });
      document.querySelectorAll('[data-move]').forEach(function (button) {
        button.addEventListener('click', async function () {
          const ids = items.map(function (entry) { return Number(entry.planItemId); });
          const itemId = Number(button.dataset.itemId); const index = ids.indexOf(itemId); if (index < 0) return;
          const target = button.dataset.move === 'up' ? index - 1 : index + 1; if (target < 0 || target >= ids.length) return;
          const temp = ids[index]; ids[index] = ids[target]; ids[target] = temp; button.disabled = true;
          try { await savePlanAction('contentchin_plan_item_reorder_v2', { planId: plan.id, itemIds: ids }); }
          catch (error) { button.disabled = false; showToast(errorText(error)); }
        });
      });
      const searchButton = document.getElementById('chinContentSearch');
      const queryInput = document.getElementById('chinContentQuery');
      if (searchButton && queryInput) {
        searchButton.addEventListener('click', function () { searchBank(plan, queryInput.value); });
        queryInput.addEventListener('keydown', function (event) { if (event.key === 'Enter') { event.preventDefault(); searchBank(plan, queryInput.value); } });
      }
      const publish = document.getElementById('chinPublishPlan');
      if (publish) publish.addEventListener('click', async function () {
        publish.disabled = true;
        try { await savePlanAction('contentchin_plan_publish_v2', { planId: plan.id }); showToast('برنامه منتشر شد.'); }
        catch (error) { publish.disabled = false; showToast(errorText(error)); }
      });
    } else {
      const reopen = document.getElementById('chinReopenPlan');
      if (reopen) reopen.addEventListener('click', async function () {
        reopen.disabled = true;
        try { await savePlanAction('contentchin_plan_reopen_v2', { planId: plan.id }); showToast('برنامه دوباره به پیش‌نویس برگشت.'); }
        catch (error) { reopen.disabled = false; showToast(errorText(error)); }
      });
    }
  }

  async function searchBank(plan, query) {
    const results = document.getElementById('chinContentResults');
    const button = document.getElementById('chinContentSearch');
    if (!results || !button) return;
    button.disabled = true;
    results.innerHTML = '<div class="chin-state"><div><div class="chin-spinner"></div>در حال جست‌وجوی بانک محتوا…</div></div>';
    try {
      const payload = await request('contentchin_content_search_v2', { query: '&q=' + encodeURIComponent(String(query || '').trim()) + '&limit=24' });
      const currentIds = new Set(planItems(currentPlan).map(function (item) { return String(item.id); }));
      const found = Array.isArray(payload.items) ? payload.items : [];
      if (!found.length) { results.innerHTML = '<div class="chin-empty"><strong>موردی پیدا نشد</strong><span>عبارت دیگری امتحان کن.</span></div>'; return; }
      results.innerHTML = found.map(function (item) {
        const added = currentIds.has(String(item.id));
        const image = item.image ? '<img src="' + esc(item.image) + '" alt="">' : '<span class="chin-result-art">' + icon('book',20) + '</span>';
        return '<article class="chin-result-card">' + image + '<div><strong>' + esc(item.title || 'محتوای بدون عنوان') + '</strong><small>' + esc(item.categoryLabel || '') + (item.duration ? ' · ' + esc(item.duration) : '') + '</small><span>' + esc(item.publisher || '') + '</span></div><button type="button" data-add-content="' + esc(item.id) + '"' + (added ? ' disabled' : '') + '>' + (added ? 'اضافه شده' : 'افزودن +') + '</button></article>';
      }).join('');
      results.querySelectorAll('[data-add-content]').forEach(function (addButton) {
        addButton.addEventListener('click', async function () {
          addButton.disabled = true;
          try { await savePlanAction('contentchin_plan_item_add_v2', { planId: plan.id, contentId: Number(addButton.dataset.addContent) }); showToast('محتوا به برنامه اضافه شد.'); }
          catch (error) { addButton.disabled = false; showToast(errorText(error)); }
        });
      });
    } catch (error) {
      results.innerHTML = '<div class="chin-state chin-error"><div>' + icon('alert',22) + '<strong>جست‌وجو انجام نشد</strong><br><span>' + esc(errorText(error)) + '</span></div></div>';
    } finally { button.disabled = false; }
  }

  async function initHome() {
    try {
      const data = await loadBootstrap();
      renderDashboard(data);
    } catch (error) {
      dashboardError(error);
    }
  }

  async function initNew() {
    try {
      const data = await loadBootstrap();
      if (!data.authenticated || !data.canCreate) {
        location.replace('/profile?returnTo=' + encodeURIComponent('/contentchin/new'));
        return;
      }
      renderNewForm(data, templateFromQuery(data));
    } catch (error) {
      if (authRedirect(error, '/contentchin/new')) return;
      const root = document.getElementById('contentChinForm');
      if (root) root.innerHTML = '<div class="chin-state chin-error"><div>' + icon('alert', 24) + '<strong>خطا در آماده‌سازی ساخت برنامه</strong><br><span>' + esc(errorText(error)) + '</span><br><button class="chin-retry" type="button" onclick="location.reload()">تلاش دوباره</button></div></div>';
    }
  }

  async function initView() {
    const match = path.match(/^\/contentchin\/view\/(\d+)$/);
    const id = match ? match[1] : '';
    if (!id) return;
    try {
      const data = await loadBootstrap();
      const result = await request('contentchin_plan_get_v1', { query: '&id=' + encodeURIComponent(id) });
      currentPlan = result.plan;
      renderView(currentPlan);
    } catch (error) {
      if (authRedirect(error, location.pathname)) return;
      const root = document.getElementById('planView');
      if (root) root.innerHTML = '<div class="chin-state chin-error"><div>' + icon('alert', 24) + '<strong>این برنامه در دسترس نیست</strong><br><span>' + esc(errorText(error)) + '</span><br><button class="chin-retry" type="button" onclick="history.back()">بازگشت</button></div></div>';
    }
  }

  setupBack();
  if (isHome) initHome();
  else if (isNew) initNew();
  else if (isView) initView();
})();
