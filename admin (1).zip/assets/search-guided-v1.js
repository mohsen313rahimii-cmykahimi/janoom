(() => {
  'use strict';

  const API = '/mahda-api/index.php';
  const STORAGE_KEY = 'mahda_guided_search_v1';
  const root = document.getElementById('guidedSearchRoot');
  const summary = document.getElementById('guidedSummary');
  const progressFill = document.getElementById('guidedProgressFill');
  const progressText = document.getElementById('guidedProgressText');

  const steps = [
    { id: 'category', title: 'دنبال چه نوع محتوایی هستی؟', subtitle: 'از دسته‌ای شروع کن که به برنامه‌ات نزدیک‌تره.' },
    { id: 'age', title: 'برای چه گروه سنی؟', subtitle: 'مهدا فقط محتواهای مناسب این بازه را جلوتر می‌آورد.' },
    { id: 'occasion', title: 'مناسبت برات مهمه؟', subtitle: 'می‌تونی همه مناسبت‌ها را ببینی یا یک مناسبت مشخص انتخاب کنی.' },
    { id: 'goals', title: 'چه هدفی برات مهم‌تره؟', subtitle: 'یک یا چند هدف تربیتی انتخاب کن؛ اگر مهم نیست، ردش کن.' },
    { id: 'equipment', title: 'درباره وسیله چطور؟', subtitle: 'اگر وسیله در دسترس نداری، مهدا گزینه‌های بدون وسیله را ترجیح می‌دهد.' },
    { id: 'duration', title: 'چقدر زمان برای اجرا داری؟', subtitle: 'زمان تقریبی را بگو تا پیشنهادها واقع‌بینانه‌تر شوند.' },
    { id: 'participants', title: 'تقریباً چند نفر شرکت می‌کنند؟', subtitle: 'تعداد نفرات کمک می‌کند محتوای اجرایی مناسب‌تری پیدا شود.' },
    { id: 'space', title: 'کجا می‌خوای اجراش کنی؟', subtitle: 'فضای اجرا آخرین فیلتر ماست؛ بعد مهدا پیشنهادها را می‌چیند.' },
  ];

  const defaultState = () => ({
    step: 0,
    category: '',
    age: '',
    occasionMode: '',
    occasionId: 0,
    goalIds: [],
    equipment: '',
    duration: '',
    participants: '',
    space: '',
    occasionQuery: '',
    goalQuery: '',
  });

  let data = { categories: [], goals: [], occasions: [], ages: [], durations: [], participants: [], spaces: [] };
  let state = restore();
  let advancing = 0;

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
  const fa = (n) => Number(n || 0).toLocaleString('fa-IR');

  function restore() {
    try {
      const raw = JSON.parse(sessionStorage.getItem(STORAGE_KEY) || 'null');
      return raw && typeof raw === 'object' ? { ...defaultState(), ...raw } : defaultState();
    } catch { return defaultState(); }
  }

  function persist() {
    const copy = { ...state };
    delete copy.occasionQuery;
    delete copy.goalQuery;
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(copy));
  }

  async function get(action, params = {}) {
    const url = new URL(API, location.origin);
    url.searchParams.set('action', action);
    Object.entries(params).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        if (value.length) url.searchParams.set(key, value.join(','));
      } else if (value !== '' && value !== null && value !== undefined) {
        url.searchParams.set(key, String(value));
      }
    });
    const response = await fetch(url, { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || action);
    return payload;
  }

  function icon(name, size = 24) {
    const attrs = `viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"`;
    const paths = {
      search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/>',
      puzzle: '<path d="M8 3h3a2 2 0 1 1 4 0h3v5a2 2 0 1 1 0 4v5h-5a2 2 0 1 1-4 0H4v-5a2 2 0 1 1 0-4V3z"/>',
      gamepad: '<path d="M6 8h12a4 4 0 0 1 3.7 5.5l-1.1 2.8a2.5 2.5 0 0 1-4 1l-1.1-1H8.5l-1.1 1a2.5 2.5 0 0 1-4-1l-1.1-2.8A4 4 0 0 1 6 8Z"/><path d="M7 12h4M9 10v4M16 12h.01M18 14h.01"/>',
      book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H11v16H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M20 5.5A2.5 2.5 0 0 0 17.5 3H13v16h4.5a2.5 2.5 0 0 1 2.5 2.5z"/>',
      scissors: '<circle cx="6" cy="7" r="3"/><circle cx="6" cy="17" r="3"/><path d="m8.7 8.3 11.3 6.2M8.7 15.7 20 9.5"/>',
      film: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 5v14M17 5v14M3 9h4M17 9h4M3 15h4M17 15h4"/>',
      flag: '<path d="M5 21V4M5 5h11l-2 4 2 4H5"/>',
      palette: '<path d="M12 3a9 9 0 1 0 0 18h1.5a2.5 2.5 0 0 0 0-5H12a2 2 0 0 1 0-4h3a6 6 0 0 0-3-9Z"/><circle cx="7.5" cy="10" r=".8"/><circle cx="9.5" cy="6.5" r=".8"/>',
      sparkles: '<path d="m12 3 1.2 3.2L16.5 7.5l-3.3 1.3L12 12l-1.2-3.2-3.3-1.3 3.3-1.3zM18 14l.8 2.2L21 17l-2.2.8L18 20l-.8-2.2L15 17l2.2-.8z"/>',
      flask: '<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 18l-5-9V3"/><path d="M7.5 15h9"/>',
      sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
      calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
      target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
      backpack: '<path d="M8 8V6a4 4 0 0 1 8 0v2"/><rect x="5" y="8" width="14" height="13" rx="3"/><path d="M8 13h8M9 16h6"/>',
      clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
      home: '<path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/>',
      tree: '<path d="M12 22v-7M8 18h8"/><path d="M12 2 7 9h3l-4 6h12l-4-6h3z"/>',
      check: '<path d="m5 12 4 4L19 6"/>',
      chevron: '<path d="m15 18-6-6 6-6"/>',
      edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4z"/>',
      shelf: '<path d="M4 5h6l2 2h8v12H4z"/><path d="M4 9h16"/>',
      wand: '<path d="m15 4 5 5L8 21l-5-5zM13 6l5 5M6 4V2M5 3H3M20 18v4M18 20h4"/>',
    };
    return `<svg ${attrs}>${paths[name] || paths.sparkles}</svg>`;
  }

  function categoryIcon(item) {
    const aliases = { 'book-open':'book', 'theater':'sparkles', 'scroll':'book', 'clipboard':'book', 'newspaper':'book', 'utensils':'sparkles' };
    const known = ['puzzle','gamepad','book','scissors','film','flag','palette','sparkles','flask','sun'];
    const key = aliases[item.icon] || item.icon;
    return icon(known.includes(key) ? key : 'sparkles', 29);
  }

  function selectionLabel(stepId) {
    if (stepId === 'category') return data.categories.find(x => x.id === state.category)?.label || '';
    if (stepId === 'age') return data.ages.find(x => x.id === state.age)?.label || '';
    if (stepId === 'occasion') {
      if (state.occasionMode === 'all') return 'همه مناسبت‌ها';
      return data.occasions.find(x => Number(x.id) === Number(state.occasionId))?.label || '';
    }
    if (stepId === 'goals') {
      if (!state.goalIds.length) return 'هدف مهم نیست';
      const labels = state.goalIds.map(id => data.goals.find(x => Number(x.id) === Number(id))?.label).filter(Boolean);
      return labels.length > 1 ? `${labels[0]} +${fa(labels.length - 1)}` : (labels[0] || '');
    }
    if (stepId === 'equipment') return state.equipment === 'none' ? 'بدون وسیله' : state.equipment === 'any' ? 'وسیله مهم نیست' : '';
    if (stepId === 'duration') return data.durations.find(x => x.id === state.duration)?.label || '';
    if (stepId === 'participants') return data.participants.find(x => x.id === state.participants)?.label || '';
    if (stepId === 'space') return data.spaces.find(x => x.id === state.space)?.label || '';
    return '';
  }

  function updateSummary() {
    const max = Math.min(state.step, steps.length);
    const chips = [];
    for (let i = 0; i < max; i++) {
      const label = selectionLabel(steps[i].id);
      if (label) chips.push(`<button type="button" class="gs-summary-chip" data-edit-step="${i}"><span>${esc(label)}</span>${icon('edit', 13)}</button>`);
    }
    summary.innerHTML = chips.length
      ? `<div class="gs-summary-head"><span>${icon('wand', 15)} انتخاب‌های تو</span><small>برای تغییر، روی هرکدام بزن</small></div><div class="gs-summary-chips">${chips.join('')}</div>`
      : `<div class="gs-summary-empty">${icon('sparkles', 17)} قدم‌به‌قدم جلو می‌ریم؛ فقط چند انتخاب کوتاه.</div>`;
    summary.querySelectorAll('[data-edit-step]').forEach(btn => btn.addEventListener('click', () => {
      state.step = Number(btn.dataset.editStep);
      persist();
      render();
    }));

    const current = Math.min(state.step, steps.length);
    const percent = steps.length ? (current / steps.length) * 100 : 0;
    progressFill.style.width = `${percent}%`;
    progressText.textContent = state.step >= steps.length ? 'پیشنهادهای مهدا' : `${fa(state.step + 1)} از ${fa(steps.length)}`;
  }

  function optionCard({ value, title, subtitle = '', iconName = 'sparkles', selected = false, color = '#159658', extraClass = '' }) {
    return `<button type="button" class="gs-option ${selected ? 'is-selected' : ''} ${extraClass}" data-value="${esc(value)}" style="--option:${esc(color)}">
      <span class="gs-option-art">${icon(iconName, 28)}<i></i></span>
      <span class="gs-option-copy"><strong>${esc(title)}</strong>${subtitle ? `<small>${esc(subtitle)}</small>` : ''}</span>
      <span class="gs-option-check">${icon('check', 14)}</span>
    </button>`;
  }

  function stageShell(content, options = {}) {
    const step = steps[state.step];
    const backDisabled = state.step === 0;
    return `<section class="gs-stage gs-enter">
      <div class="gs-stage-top">
        <div class="gs-step-orb">${icon(options.heroIcon || (step.id === 'occasion' ? 'calendar' : 'sparkles'), 26)}</div>
        <div><span class="gs-eyebrow">جستجوی محتوا</span><h1>${esc(step.title)}</h1><p>${esc(step.subtitle)}</p></div>
      </div>
      <div class="gs-stage-body">${content}</div>
      <div class="gs-actions">
        <button type="button" class="gs-btn gs-btn-ghost" data-prev ${backDisabled ? 'disabled' : ''}>${icon('chevron', 17)} مرحله قبل</button>
        ${options.next === false ? '' : `<button type="button" class="gs-btn gs-btn-primary" data-next ${options.nextDisabled ? 'disabled' : ''}>${options.nextLabel || 'ادامه'} ${icon('chevron', 17)}</button>`}
      </div>
    </section>`;
  }

  function renderCategory() {
    const cards = data.categories.map((item, index) => `<button type="button" class="gs-category ${state.category === item.id ? 'is-selected' : ''}" data-category="${esc(item.id)}" style="--cat:${esc(item.color || '#159658')};--delay:${index * 24}ms">
      <span class="gs-category-art">${categoryIcon(item)}</span>
      <span><strong>${esc(item.label)}</strong><small>${esc(item.description || 'محتوای این دسته')}</small></span>
      <i>${icon('check', 13)}</i>
    </button>`).join('');
    return stageShell(`<div class="gs-category-grid">${cards}</div>`, { heroIcon: 'puzzle', nextDisabled: !state.category });
  }

  function renderAge() {
    const cards = data.ages.map((item, index) => optionCard({
      value: item.id, title: item.label,
      subtitle: item.id === '4-6' ? 'پیش‌دبستان و سال‌های آغازین' : item.id === '7-10' ? 'دبستان و فعالیت‌های گروهی' : 'سن برایت محدودیت ندارد',
      iconName: item.id === 'any' ? 'sparkles' : 'users', selected: state.age === item.id,
      color: item.id === 'any' ? '#6d8e74' : index === 0 ? '#e0a43d' : '#4c91a8'
    })).join('');
    return stageShell(`<div class="gs-option-grid gs-option-grid-3">${cards}</div>`, { heroIcon: 'users', nextDisabled: !state.age });
  }

  function renderOccasion() {
    const compact = state.occasionMode === 'specific';
    const modeCards = `<div class="gs-mode-grid ${compact ? 'is-compact' : ''}">
      ${optionCard({ value: 'all', title: 'همه مناسبت‌ها', subtitle: 'مناسبت برایم محدودیت نیست', iconName: 'sun', selected: state.occasionMode === 'all', color: '#77a86f' })}
      ${optionCard({ value: 'specific', title: 'انتخاب مناسبت', subtitle: 'مثلاً محرم، غدیر یا نیمه شعبان', iconName: 'calendar', selected: state.occasionMode === 'specific', color: '#b77a50' })}
    </div>`;
    let chooser = '';
    if (compact) {
      const query = state.occasionQuery.trim();
      const items = data.occasions.filter(item => !query || `${item.label} ${item.description || ''}`.includes(query)).slice(0, query ? 40 : 18);
      chooser = `<div class="gs-reveal">
        <label class="gs-filter-input">${icon('search', 18)}<input id="occasionFilter" value="${esc(state.occasionQuery)}" placeholder="نام مناسبت را بنویس…" autocomplete="off"></label>
        <div class="gs-mini-grid">${items.map(item => `<button type="button" class="gs-mini ${Number(state.occasionId) === Number(item.id) ? 'is-selected' : ''}" data-occasion="${item.id}"><span>${esc(item.label)}</span><i>${icon('check', 12)}</i></button>`).join('') || '<div class="gs-no-option">مناسبتی با این عبارت پیدا نشد.</div>'}</div>
      </div>`;
    }
    return stageShell(modeCards + chooser, { heroIcon: 'calendar', nextDisabled: !state.occasionMode || (state.occasionMode === 'specific' && !state.occasionId) });
  }

  function renderGoals() {
    const query = state.goalQuery.trim();
    const visible = data.goals.filter(item => !query || `${item.label} ${item.description || ''}`.includes(query)).slice(0, query ? 60 : 20);
    const selectedLabels = state.goalIds.map(id => data.goals.find(g => Number(g.id) === Number(id))).filter(Boolean);
    const selected = selectedLabels.length ? `<div class="gs-picked"><span>انتخاب‌شده:</span>${selectedLabels.map(item => `<button type="button" data-remove-goal="${item.id}">${esc(item.label)} ×</button>`).join('')}</div>` : '';
    return stageShell(`<label class="gs-filter-input">${icon('search', 18)}<input id="goalFilter" value="${esc(state.goalQuery)}" placeholder="مثلاً همکاری، مهربانی، مسئولیت…" autocomplete="off"></label>
      ${selected}
      <div class="gs-goal-grid">${visible.map(item => `<button type="button" class="gs-goal ${state.goalIds.includes(Number(item.id)) ? 'is-selected' : ''}" data-goal="${item.id}"><span class="gs-goal-mark">${icon('target', 18)}</span><span><strong>${esc(item.label)}</strong>${item.description ? `<small>${esc(item.description)}</small>` : ''}</span><i>${icon('check', 12)}</i></button>`).join('')}</div>
      <button type="button" class="gs-skip-line" data-goals-any>${state.goalIds.length ? 'پاک کردن هدف‌ها' : 'هدف خاصی مهم نیست'}</button>`,
      { heroIcon: 'target', nextLabel: 'ادامه با این هدف‌ها' });
  }

  function renderEquipment() {
    const cards = [
      optionCard({ value: 'none', title: 'بدون وسیله', subtitle: 'چیزی برای آماده‌سازی لازم نباشد', iconName: 'backpack', selected: state.equipment === 'none', color: '#4c9b74' }),
      optionCard({ value: 'any', title: 'وسیله مهم نیست', subtitle: 'اگر لازم بود، وسایل ساده هم مشکلی نیست', iconName: 'sparkles', selected: state.equipment === 'any', color: '#6886a3' }),
    ].join('');
    return stageShell(`<div class="gs-option-grid gs-option-grid-2">${cards}</div>`, { heroIcon: 'backpack', nextDisabled: !state.equipment });
  }

  function renderDuration() {
    const cards = data.durations.map((item, i) => optionCard({ value: item.id, title: item.label, subtitle: ['خیلی سریع و جمع‌وجور','برای یک بخش کوتاه برنامه','برای فعالیت اصلی جلسه','برای برنامه مفصل یا کارگاهی','هر زمانی مناسب است'][i] || '', iconName: 'clock', selected: state.duration === item.id, color: i === 4 ? '#718579' : '#53917c' })).join('');
    return stageShell(`<div class="gs-option-grid gs-option-grid-2 gs-option-compact">${cards}</div>`, { heroIcon: 'clock', nextDisabled: !state.duration });
  }

  function renderParticipants() {
    const cards = data.participants.map((item, i) => optionCard({ value: item.id, title: item.label, subtitle: i === 0 ? 'فردی' : i === 1 ? 'گروه خیلی کوچک' : i === 2 ? 'گروه متوسط' : i === 3 ? 'جمع بزرگ' : 'تعداد محدودیت ندارد', iconName: 'users', selected: state.participants === item.id, color: i === 4 ? '#718579' : '#6f8fb0' })).join('');
    return stageShell(`<div class="gs-option-grid gs-option-grid-2 gs-option-compact">${cards}</div>`, { heroIcon: 'users', nextDisabled: !state.participants });
  }

  function renderSpace() {
    const cards = data.spaces.map((item, i) => optionCard({ value: item.id, title: item.label, subtitle: i === 0 ? 'کلاس، حسینیه یا سالن' : i === 1 ? 'حیاط، پارک یا فضای بیرونی' : 'هر فضایی قابل قبول است', iconName: i === 0 ? 'home' : i === 1 ? 'tree' : 'sparkles', selected: state.space === item.id, color: i === 0 ? '#7d7bb2' : i === 1 ? '#559567' : '#718579' })).join('');
    return stageShell(`<div class="gs-option-grid gs-option-grid-3">${cards}</div><div class="gs-final-note">${icon('wand', 20)} بعد از این انتخاب، مهدا از بین محتواهای تأییدشده بهترین گزینه‌ها را برایت می‌چیند.</div>`, { heroIcon: 'home', nextDisabled: !state.space, nextLabel: 'پیشنهادهای مهدا' });
  }

  function renderLoadingResults() {
    root.innerHTML = `<section class="gs-result-loading gs-enter"><div class="gs-loader-orbit"><span></span><i></i>${icon('wand', 30)}</div><h2>مهدا داره بهترین‌ها رو پیدا می‌کنه…</h2><p>انتخاب‌هات رو با محتوای تأییدشده بانک مهدا تطبیق می‌دیم.</p></section>`;
    updateSummary();
  }

  function resultCard(item, index) {
    const reasons = (item.matchReasons || []).map(reason => `<span>${esc(reason)}</span>`).join('');
    const meta = [item.duration, item.audienceSize].filter(Boolean).slice(0,2).map(v => `<small>${esc(v)}</small>`).join('');
    return `<article class="gs-result-card" style="--delay:${index * 55}ms">
      <a class="gs-result-cover" href="/content/${encodeURIComponent(item.id)}" style="--cat:${esc(item.categoryColor || '#159658')}">
        ${item.image ? `<img src="${esc(item.image)}" alt="" loading="lazy">` : `<span class="gs-result-placeholder">${icon(item.categoryIcon || 'sparkles', 36)}</span>`}
        <b>${esc(item.categoryLabel || 'محتوا')}</b>
      </a>
      <div class="gs-result-body"><h3>${esc(item.title || '')}</h3><p>${esc(item.publisher || item.author || '')}</p>
        ${reasons ? `<div class="gs-reasons">${reasons}</div>` : ''}
        <div class="gs-result-meta">${meta}<span>${item.isExactMatch ? 'تطابق دقیق' : 'پیشنهاد نزدیک'}</span></div>
        <div class="gs-result-actions"><a href="/content/${encodeURIComponent(item.id)}">مشاهده</a><button type="button" data-shelf-content="${esc(item.id)}">${icon('shelf', 16)} قفسه</button></div>
      </div>
    </article>`;
  }

  function renderResults(payload) {
    const items = Array.isArray(payload.items) ? payload.items : [];
    const nearest = payload.matchType === 'nearest';
    root.innerHTML = `<section class="gs-results gs-enter">
      <div class="gs-results-hero"><div class="gs-results-icon">${icon('wand', 27)}</div><div><span>پیشنهاد مهدا</span><h1>${items.length ? 'این‌ها به انتخاب‌های تو نزدیک‌ترند' : 'فعلاً مورد مناسبی پیدا نشد'}</h1><p>${nearest ? 'مورد کاملاً منطبق کم بود؛ نزدیک‌ترین گزینه‌های تأییدشده مهدا را آوردیم.' : items.length ? 'از بین محتوای واقعی و تأییدشده بانک مهدا.' : 'یکی از انتخاب‌های بالا را تغییر بده تا دوباره بگردیم.'}</p></div></div>
      ${items.length ? `<div class="gs-results-grid">${items.map(resultCard).join('')}</div>` : `<div class="gs-zero">${icon('search', 40)}<strong>نتیجه‌ای نداریم</strong><span>مثلاً زمان، هدف یا تعداد نفرات را کمی بازتر انتخاب کن.</span></div>`}
      <div class="gs-result-footer"><button type="button" class="gs-btn gs-btn-ghost" data-edit-last>${icon('edit', 16)} تغییر انتخاب‌ها</button><button type="button" class="gs-btn gs-btn-primary" data-restart>${icon('sparkles', 16)} جستجوی تازه</button></div>
    </section>`;
    updateSummary();
    root.querySelector('[data-edit-last]')?.addEventListener('click', () => { state.step = steps.length - 1; persist(); render(); });
    root.querySelector('[data-restart]')?.addEventListener('click', reset);
    root.querySelectorAll('[data-shelf-content]').forEach(button => button.addEventListener('click', () => {
      if (window.MahdaShelf) window.MahdaShelf.open(Number(button.dataset.shelfContent));
    }));
  }

  async function loadResults() {
    renderLoadingResults();
    try {
      const payload = await get('guided_search', {
        category: state.category || 'any', age: state.age || 'any', occasionId: state.occasionId || 0,
        goalIds: state.goalIds, equipment: state.equipment || 'any', duration: state.duration || 'any',
        participants: state.participants || 'any', space: state.space || 'any'
      });
      renderResults(payload);
    } catch {
      root.innerHTML = `<section class="gs-zero panel">${icon('search', 40)}<strong>جستجو انجام نشد</strong><span>اتصال را بررسی کن و دوباره تلاش کن.</span><button type="button" class="gs-btn gs-btn-primary" data-retry>تلاش دوباره</button></section>`;
      root.querySelector('[data-retry]')?.addEventListener('click', loadResults);
    }
  }

  function advanceSoon() {
    clearTimeout(advancing);
    advancing = setTimeout(() => next(), 210);
  }

  function next() {
    if (state.step >= steps.length - 1) {
      state.step = steps.length;
      persist();
      loadResults();
      return;
    }
    state.step += 1;
    persist();
    render();
  }

  function previous() {
    if (state.step <= 0) return;
    state.step -= 1;
    persist();
    render();
  }

  function reset() {
    state = defaultState();
    persist();
    render();
  }

  function bindStep() {
    root.querySelector('[data-prev]')?.addEventListener('click', previous);
    root.querySelector('[data-next]')?.addEventListener('click', next);

    root.querySelectorAll('[data-category]').forEach(btn => btn.addEventListener('click', () => { state.category = btn.dataset.category; persist(); render(); advanceSoon(); }));
    root.querySelectorAll('.gs-option[data-value]').forEach(btn => btn.addEventListener('click', () => {
      const value = btn.dataset.value;
      const id = steps[state.step]?.id;
      if (id === 'age') state.age = value;
      else if (id === 'occasion') {
        state.occasionMode = value;
        if (value === 'all') { state.occasionId = 0; persist(); render(); advanceSoon(); return; }
      } else if (id === 'equipment') state.equipment = value;
      else if (id === 'duration') state.duration = value;
      else if (id === 'participants') state.participants = value;
      else if (id === 'space') state.space = value;
      persist(); render();
      if (id !== 'occasion') advanceSoon();
    }));

    root.querySelectorAll('[data-occasion]').forEach(btn => btn.addEventListener('click', () => { state.occasionId = Number(btn.dataset.occasion); persist(); render(); advanceSoon(); }));
    const occasionFilter = root.querySelector('#occasionFilter');
    if (occasionFilter) occasionFilter.addEventListener('input', () => { const pos = occasionFilter.selectionStart; state.occasionQuery = occasionFilter.value; render(); const nextInput = root.querySelector('#occasionFilter'); if (nextInput) { nextInput.focus(); try { nextInput.setSelectionRange(pos, pos); } catch {} } });

    root.querySelectorAll('[data-goal]').forEach(btn => btn.addEventListener('click', () => {
      const id = Number(btn.dataset.goal);
      state.goalIds = state.goalIds.includes(id) ? state.goalIds.filter(x => x !== id) : [...state.goalIds, id].slice(0, 5);
      persist(); render();
    }));
    root.querySelectorAll('[data-remove-goal]').forEach(btn => btn.addEventListener('click', () => { state.goalIds = state.goalIds.filter(x => x !== Number(btn.dataset.removeGoal)); persist(); render(); }));
    root.querySelector('[data-goals-any]')?.addEventListener('click', () => { state.goalIds = []; persist(); render(); });
    const goalFilter = root.querySelector('#goalFilter');
    if (goalFilter) goalFilter.addEventListener('input', () => { const pos = goalFilter.selectionStart; state.goalQuery = goalFilter.value; render(); const nextInput = root.querySelector('#goalFilter'); if (nextInput) { nextInput.focus(); try { nextInput.setSelectionRange(pos, pos); } catch {} } });
  }

  function render() {
    clearTimeout(advancing);
    updateSummary();
    if (state.step >= steps.length) { loadResults(); return; }
    const id = steps[state.step].id;
    root.innerHTML = id === 'category' ? renderCategory()
      : id === 'age' ? renderAge()
      : id === 'occasion' ? renderOccasion()
      : id === 'goals' ? renderGoals()
      : id === 'equipment' ? renderEquipment()
      : id === 'duration' ? renderDuration()
      : id === 'participants' ? renderParticipants()
      : renderSpace();
    bindStep();
  }

  async function init() {
    root.innerHTML = `<section class="gs-start-loading"><div class="gs-loader-orbit"><span></span><i></i>${icon('search', 29)}</div><strong>آماده‌کردن جستجوی مهدا…</strong></section>`;
    try {
      data = await get('guided_search_bootstrap');
      // Old/incomplete saved states should never trap the user beyond the flow.
      state.step = Math.max(0, Math.min(steps.length, Number(state.step) || 0));
      render();
    } catch {
      root.innerHTML = `<section class="gs-zero panel">${icon('search', 40)}<strong>جستجو آماده نشد</strong><span>صفحه را یک بار دوباره باز کن.</span><button type="button" class="gs-btn gs-btn-primary" onclick="location.reload()">تلاش دوباره</button></section>`;
    }

    get('session').then((session) => {
      if (session.user?.avatar_url) document.getElementById('headAvatar').innerHTML = `<img src="${esc(session.user.avatar_url)}" alt="">`;
      if (!session.user?.guest) get('notifications', { limit: 1 }).then((n) => {
        if (n.unread > 0) { const dot = document.getElementById('notifDot'); dot.textContent = n.unread > 99 ? '۹۹+' : fa(n.unread); dot.classList.add('show'); }
      }).catch(() => {});
    }).catch(() => {});
  }

  init();
})();
