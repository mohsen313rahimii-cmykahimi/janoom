(function(){
  'use strict';

  const API='/mahda-api/index.php';
  const path=decodeURIComponent(location.pathname);
  const match=path.match(/^\/content\/item\/(\d+)\/?$/);
  const routeId=new URLSearchParams(location.search).get('route_id');
  const contentId=match?match[1]:(/^\d+$/.test(routeId||'')?routeId:'');
  const main=document.getElementById('detailMain');
  const actionBar=document.getElementById('actionBar');
  const addBtn=document.getElementById('addBtn');
  let item=null;
  let csrf='';
  let interaction={authenticated:false,active:[],counts:null,loaded:false,error:false};

  class ApiError extends Error{
    constructor(message,status=0,payload={}){super(message||'request_failed');this.status=status;this.payload=payload||{};}
  }

  const PATHS={
    gamepad:'<path d="M8 8h8a5 5 0 0 1 4.7 6.7l-1.1 3a2.8 2.8 0 0 1-4.8.8L13.7 17h-3.4l-1.1 1.5a2.8 2.8 0 0 1-4.8-.8l-1.1-3A5 5 0 0 1 8 8Z"/><path d="M7 12v4M5 14h4"/><circle cx="16.5" cy="12.5" r=".8" fill="currentColor" stroke="none"/><circle cx="18.5" cy="14.5" r=".8" fill="currentColor" stroke="none"/>',
    puzzle:'<path d="M19 13h-2.2a2 2 0 1 0 0 4H19v3H5v-3h2.2a2 2 0 1 0 0-4H5V5h4V3.8a2 2 0 1 1 4 0V5h6v4h1.2a2 2 0 1 1 0 4Z"/>',
    book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H11V4H6.5A2.5 2.5 0 0 0 4 6.5Z"/><path d="M20 19.5a2.5 2.5 0 0 0-2.5-2.5H13V4h4.5A2.5 2.5 0 0 1 20 6.5Z"/>',
    masks:'<path d="M4 6c3-2 6-2 9 0v6c0 3-2 5-4.5 6C6 17 4 15 4 12Z"/><path d="M11 7c3-2 6-2 9 0v6c0 3-2 5-4.5 6a7 7 0 0 1-4-3"/><path d="M6.5 9.5h.01M10.5 9.5h.01M14 10h.01M18 10h.01"/><path d="M6.7 13c1.2 1 2.4 1 3.6 0M14 14c1-1 2-1 3 0"/>',
    film:'<path d="M3 6h18v14H3z"/><path d="M7 6V3M12 6V3M17 6V3"/><path d="m10 10 5 3-5 3z"/>',
    flask:'<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.7 3h10.6A2 2 0 0 0 19 18l-5-9V3"/><path d="M7.5 16h9"/>',
    scissors:'<circle cx="6" cy="7" r="3"/><circle cx="6" cy="17" r="3"/><path d="m8.7 8.4 11.3 6.1M8.7 15.6 20 9.5"/>',
    clipboard:'<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4.5V3h6v1.5M9 9h6M9 13h6M9 17h4"/>',
    flag:'<path d="M5 21V4"/><path d="M5 5c5-3 9 3 14 0v10c-5 3-9-3-14 0"/>',
    palette:'<path d="M12 3a9 9 0 1 0 0 18h1.4a2 2 0 0 0 1.7-3c-.7-1.2.1-2.7 1.5-2.7H18a3 3 0 0 0 3-3C21 7.2 17 3 12 3Z"/><circle cx="7.5" cy="11" r="1"/><circle cx="9.5" cy="7.5" r="1"/><circle cx="14" cy="7.5" r="1"/><circle cx="16.5" cy="11" r="1"/>',
    scroll:'<path d="M6 3h12v15a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3h12"/><path d="M6 3a3 3 0 0 0-3 3v1h3M9 8h6M9 12h6"/>',
    newspaper:'<path d="M4 4h14v16H6a2 2 0 0 1-2-2Z"/><path d="M18 8h2v10a2 2 0 0 1-2 2M8 8h6M8 12h6M8 16h3"/>',
    sparkles:'<path d="m12 3-1.4 3.6L7 8l3.6 1.4L12 13l1.4-3.6L17 8l-3.6-1.4Z"/><path d="m18 14-.9 2.1L15 17l2.1.9L18 20l.9-2.1L21 17l-2.1-.9Z"/>',
    sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.41M17.66 6.34l1.41-1.41"/>',
    utensils:'<path d="M5 3v7M8 3v7M5 7h3M6.5 10v11M16 3v18M16 3c3 2 3 7 0 9"/>',
    grid:'<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>'
  };
  const CATEGORY_ICON_KEY={game:'gamepad',activity:'puzzle',story:'book',theater:'masks',animation:'film',experiment:'flask',craft:'scissors',worksheet:'clipboard',heiat_lesson:'flag',painting:'palette',pardeh_khani:'scroll',magazine:'newspaper',pedagogical:'sparkles',ambiance:'sun',catering:'utensils'};
  const ICON_ALIASES={game:'gamepad',activity:'puzzle',story:'book',theater:'masks',animation:'film',experiment:'flask',craft:'scissors',worksheet:'clipboard',heiat_lesson:'flag',painting:'palette',pardeh_khani:'scroll',magazine:'newspaper',pedagogical:'sparkles',ambiance:'sun',catering:'utensils'};

  const icon=(name,size=20)=>{const m={
    heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z"/>',
    check:'<circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/>',
    users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    sprout:'<path d="M12 22V11"/><path d="M7 12c-3 0-5-2-5-5 4 0 7 2 7 5"/><path d="M17 10c3 0 5-2 5-5-4 0-7 2-7 5"/>',
    package:'<path d="m12 3 8 4-8 4-8-4Z"/><path d="M4 7v10l8 4 8-4V7M12 11v10"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    message:'<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/>',
    user:'<path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/>',
    download:'<path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 21h14"/>',
    bookmark:'<path d="M6 3h12v18l-6-4-6 4z"/>'
  };return '<svg viewBox="0 0 24 24" width="'+size+'" height="'+size+'" aria-hidden="true">'+(m[name]||'')+'</svg>'};

  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const fa=n=>Number(n||0).toLocaleString('fa-IR');
  const categoryIcon=(x,size=22)=>{
    const raw=String((x&&x.categoryIcon)||'').trim();
    const key=(PATHS[raw]&&raw)||ICON_ALIASES[raw]||CATEGORY_ICON_KEY[String((x&&x.category)||'')]||'grid';
    return '<svg viewBox="0 0 24 24" width="'+size+'" height="'+size+'" aria-hidden="true">'+PATHS[key]+'</svg>';
  };

  async function get(url){
    let r;
    try{r=await fetch(url,{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}})}catch(e){throw new ApiError('network_error',0)}
    const j=await r.json().catch(()=>({}));
    if(!r.ok)throw new ApiError(j.error||'request_failed',r.status,j);
    return j;
  }

  async function post(action,payload,retry=true){
    if(!csrf){const s=await get(API+'?action=session');csrf=s.csrf||'';}
    let r;
    try{r=await fetch(API+'?action='+encodeURIComponent(action),{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(payload||{})})}catch(e){throw new ApiError('network_error',0)}
    const j=await r.json().catch(()=>({}));
    if(!r.ok){
      if(r.status===419&&j.error==='csrf_failed'&&retry){csrf=j.csrf||'';const s=await get(API+'?action=session');csrf=s.csrf||csrf;return post(action,payload,false);}
      throw new ApiError(j.error||'request_failed',r.status,j);
    }
    if(j.csrf)csrf=j.csrf;
    return j;
  }

  function tags(values){
    const clean=(Array.isArray(values)?values:[]).map(v=>String(v||'').trim()).filter(Boolean);
    return clean.length?'<div class="tag-list">'+clean.map(v=>'<span class="tag">'+esc(v)+'</span>').join('')+'</div>':'';
  }

  function accordion(title,tone,ico,body='',extra=''){
    if((body===null||body===undefined||body==='')&&!extra)return'';
    return '<div class="accordion" style="--tone:'+tone+'"><button class="accordion-head" type="button" aria-expanded="false"><span class="accordion-icon">'+icon(ico,19)+'</span><strong>'+esc(title)+'</strong><svg class="chev" viewBox="0 0 24 24" width="18" height="18"><path d="m6 9 6 6 6-6"/></svg></button><div class="accordion-body">'+(body!==null&&body!==undefined&&body!==''?'<div>'+esc(body)+'</div>':'')+extra+'</div></div>';
  }

  const sizeText=n=>{n=Number(n||0);if(!Number.isFinite(n)||n<0)return'';if(n<1024)return fa(n)+' بایت';if(n<1048576)return (n/1024).toFixed(1).replace('.', '٫')+' KB';return (n/1048576).toFixed(1).replace('.', '٫')+' MB'};
  function mediaBlock(f){
    if(!f||!f.url)return'';
    const mime=String(f.mime||'');
    const name=String(f.name||'فایل');
    const meta='<div class="file-meta"><span class="file-name">'+esc(name)+'</span>'+(f.size?'<span class="file-size">'+esc(sizeText(f.size))+'</span>':'')+'</div>';
    const dl='<a class="file-link" href="'+esc(f.url)+'" download>'+icon('download',16)+'<span>دریافت فایل</span></a>';
    if(mime.startsWith('video/'))return '<div class="media-entry"><video controls playsinline preload="metadata" src="'+esc(f.url)+'"></video>'+meta+dl+'</div>';
    if(mime.startsWith('audio/'))return '<div class="media-entry"><audio controls preload="metadata" src="'+esc(f.url)+'"></audio>'+meta+dl+'</div>';
    if(mime.startsWith('image/'))return '<div class="media-entry"><img class="attached-image" src="'+esc(f.url)+'" alt="'+esc(name)+'" loading="lazy">'+meta+dl+'</div>';
    return '<div class="media-entry file-only">'+meta+dl+'</div>';
  }

  function formatValue(v){if(v===true)return'بله';if(v===false)return'خیر';if(Array.isArray(v))return v.map(x=>String(x)).filter(Boolean).join('، ');return String(v??'').trim();}
  function mainTextTitle(category){return ({story:'متن قصه',theater:'متن نمایشنامه',pedagogical:'متن محتوای تربیتی',heiat_lesson:'متن طرح درس',magazine:'متن ویژه‌نامه',activity:'شرح فعالیت',experiment:'شرح آزمایش',craft:'راهنمای کاردستی',worksheet:'متن کاربرگ',pardeh_khani:'متن پرده‌خوانی',painting:'راهنمای فعالیت',ambiance:'شرح فضاسازی',catering:'شرح پذیرایی',game:'شرح بازی',animation:'توضیحات محتوای ویدیویی'})[category]||'متن اصلی';}

  function buildAccordions(x){
    let out='';
    if(String(x.mainText||'').trim())out+=accordion(mainTextTitle(x.category),'#6d5bd2','bookmark',String(x.mainText).trim());
    if((x.goals||[]).length)out+=accordion('اهداف تربیتی','#0b9b55','sprout','',tags(x.goals));

    const specs=[];
    if(x.category==='game'){
      if(x.activityLevel)specs.push('میزان تحرک: '+x.activityLevel);
      if(x.gameStyle)specs.push('شیوه بازی: '+x.gameStyle);
    }
    if(x.category==='theater'){
      if(x.theaterActorsCount)specs.push('تعداد بازیگران: '+x.theaterActorsCount);
      if(x.theaterNeedCostume!==null&&x.theaterNeedCostume!==undefined)specs.push('نیاز به لباس: '+formatValue(x.theaterNeedCostume));
      if(x.theaterNeedStage!==null&&x.theaterNeedStage!==undefined)specs.push('نیاز به دکور: '+formatValue(x.theaterNeedStage));
    }
    if(x.category==='experiment'){
      if(x.experimentDifficulty)specs.push('سطح دشواری: '+x.experimentDifficulty);
      if(x.experimentNeedSupervision!==null&&x.experimentNeedSupervision!==undefined)specs.push('نیاز به نظارت بزرگسال: '+formatValue(x.experimentNeedSupervision));
    }
    (x.customFieldDetails||[]).forEach(f=>{const value=formatValue(f.value);if(value!=='')specs.push(String(f.label||'')+': '+value);});
    if(specs.length)out+=accordion('مشخصات اختصاصی','#3c92d4','bookmark',specs.join('\n'));

    if(x.isToolFree===true)out+=accordion('وسایل لازم','#ff850d','package','بدون وسیله');
    else if((x.requiredTools||[]).length)out+=accordion('وسایل لازم','#ff850d','package','',tags(x.requiredTools));

    const occ=[];
    if(x.generalOccasion===true)occ.push('عمومی؛ قابل استفاده در همه ایام');
    (x.occasions||[]).forEach(v=>{if(v)occ.push(v)});
    if(occ.length)out+=accordion('مناسبت‌ها','#08a552','calendar','',tags(occ));

    if(x.mainFile)out+=accordion('فایل اصلی','#1677ec','download','',mediaBlock(x.mainFile));

    let execution='';
    if(String(x.executionText||'').trim())execution+='<div class="execution-text">'+esc(String(x.executionText).trim())+'</div>';
    if(x.executionVideo)execution+=mediaBlock(x.executionVideo);
    if(x.executionAudio)execution+=mediaBlock(x.executionAudio);
    if(execution)out+=accordion('توضیح اجرا','#7a61c9','bookmark','',execution);

    if((x.attachments||[]).length)out+=accordion('فایل‌های همراه','#1677ec','download','',(x.attachments||[]).map(mediaBlock).join(''));
    return out;
  }

  function fact(cls,ico,text){
    if(text===null||text===undefined||String(text).trim()==='')return'';
    return '<div class="fact '+cls+'">'+(cls==='category'?categoryIcon(item,21):icon(ico,20))+'<strong>'+esc(text)+'</strong></div>';
  }

  function publicNotice(x){
    if(x.isPublic!==false)return'';
    const status=x.reviewStatus==='pending'?'این محتوا هنوز عمومی نیست و در وضعیت بررسی قرار دارد.':'این محتوا هنوز برای عموم منتشر نشده است.';
    return '<div class="private-content-banner">'+icon('bookmark',17)+'<span>'+esc(status)+'</span></div>';
  }

  function render(){
    const x=item;
    document.documentElement.style.setProperty('--cat',x.categoryColor||'#159658');
    document.getElementById('headTitle').textContent=x.title;
    document.getElementById('headIcon').innerHTML=categoryIcon(x,17);
    document.title=x.title+' | مهدا';

    const image=x.image?'<img src="'+esc(x.image)+'" alt="'+esc(x.title||'')+'">':'<div class="cover-empty">'+categoryIcon(x,70)+'</div>';
    const age=(x.ages||[]).map(a=>a==='4-6'?'۴ تا ۶ سال':a==='7-10'?'۷ تا ۱۰ سال':a).filter(Boolean).join(' و ');
    const goal=(x.goals||[])[0]||'';
    const avatar=x.publisherAvatar?'<img src="'+esc(x.publisherAvatar)+'" alt="">':icon('user',20);
    const seal=x.hasMahdaSeal===true?'<span class="seal">✓ تأیید مهدا</span>':'';
    const edit=x.canEdit?'<button type="button" class="owner-edit" id="editContentBtn">'+(x.requiresReviewOnEdit?'ویرایش و ارسال مجدد':'ویرایش محتوا')+'</button>':'';
    const publisherName=String(x.publisher||x.author||'').trim();
    const publisher=publisherName?'<div class="publisher"><div class="publisher-main"><span class="publisher-avatar">'+avatar+'</span><div class="publisher-meta"><small>منتشرکننده</small><strong>'+esc(publisherName)+'</strong>'+seal+'</div></div><div class="publisher-actions">'+(x.profileId?'<button class="publisher-link" type="button" id="publisherBtn">دیدن ویترین <span>‹</span></button>':'')+edit+'</div></div>':'';
    const coverActions=x.isPublic===false?'':'<div class="cover-actions"><button type="button" class="cover-pill" id="likeBtn">'+icon('heart',16)+'<span id="likeLabel">پسندیدم</span></button><button type="button" class="cover-pill" id="executedBtn">'+icon('check',16)+'<span id="execLabel">اجرا کردم</span></button></div>';
    const facts=fact('category','',x.categoryLabel)+fact('age','users',age)+fact('time','clock',x.duration)+fact('goal','sprout',goal)+(x.category==='game'?fact('people','users',x.audienceSize):'');
    const comments=x.isPublic===false?'':'<section class="comments"><div class="comments-head"><div class="comments-title"><span class="bubble">'+icon('message',18)+'</span><div><h2>نظرات</h2><p id="commentsSubtitle">در حال دریافت دیدگاه‌ها…</p></div></div></div><form class="comment-form" id="commentForm"><span class="user-ico">'+icon('user',17)+'</span><input id="commentInput" maxlength="2000" placeholder="دیدگاه یا تجربه‌تان را بنویسید…"><button id="commentSubmit" type="submit">ارسال</button></form><div class="comment-list" id="commentList"></div><button type="button" class="report-link" id="reportContentBtn">گزارش این محتوا</button></section>';

    main.innerHTML=publicNotice(x)+'<section class="hero-card"><div class="content-title-line"><span>'+categoryIcon(x,18)+'</span><span class="body-title">'+esc(x.title||'')+'</span></div><div class="cover-wrap">'+image+coverActions+'</div>'+publisher+'</section>'+(facts?'<section class="facts">'+facts+'</section>':'')+'<section class="accordions">'+buildAccordions(x)+'</section><div class="notice" id="notice"></div>'+comments;

    actionBar.hidden=x.isPublic===false;
    if(addBtn){addBtn.disabled=true;addBtn.setAttribute('aria-disabled','true');addBtn.title='محتواچین هنوز در نسخه جدید فعال نشده است';}
    bind();
    if(x.isPublic!==false){loadComments();refreshInteraction();}
  }

  function notice(text){const n=document.getElementById('notice');if(!n)return;n.innerHTML='<span>'+icon('message',15)+'</span><span>'+esc(text)+'</span>';n.classList.add('show');setTimeout(()=>n.classList.remove('show'),4000);}

  async function refreshInteraction(){
    try{
      const d=await get(API+'?action=interaction_state&content_id='+contentId);
      interaction={authenticated:!!d.authenticated,active:Array.isArray(d.active)?d.active:[],counts:d.counts&&typeof d.counts==='object'?d.counts:null,loaded:true,error:false};
    }catch(e){interaction={authenticated:false,active:[],counts:null,loaded:false,error:true};}
    setInteractionUI();
  }

  function setInteractionUI(){
    const like=document.getElementById('likeBtn'),exec=document.getElementById('executedBtn'),book=document.getElementById('bookmarkBtn');
    const active=interaction.active||[];
    const counts=interaction.counts;
    if(like){like.classList.toggle('active',active.includes('like'));const label=document.getElementById('likeLabel');if(label)label.textContent='پسندیدم'+(counts&&Number.isFinite(Number(counts.like))?' '+fa(counts.like):'');}
    if(exec){exec.classList.toggle('active',active.includes('executed'));const label=document.getElementById('execLabel');if(label)label.textContent=(active.includes('executed')?'اجرا شد':'اجرا کردم')+(counts&&Number(counts.executed)>0?' '+fa(counts.executed):'');}
    if(book){book.classList.toggle('saved',active.includes('bookmark'));const label=book.querySelector('span');if(label)label.textContent=active.includes('bookmark')?'در قفسه':'افزودن به قفسه';}
  }

  async function toggle(kind){
    const active=!(interaction.active||[]).includes(kind);
    try{
      const res=await post('interaction',{contentId:Number(contentId),kind,active});
      interaction.active=active?[...new Set([...(interaction.active||[]),kind])]:(interaction.active||[]).filter(k=>k!==kind);
      interaction.counts=interaction.counts||{like:0,executed:0,bookmark:0};
      interaction.counts[kind]=Number(res.count||0);
      interaction.loaded=true;interaction.error=false;
      setInteractionUI();
    }catch(e){
      if(e.message==='auth_required'||e.message==='profile_incomplete')return requireLogin('برای ثبت این مورد ابتدا وارد حساب مهدا شوید.');
      notice('ثبت انجام نشد؛ دوباره تلاش کنید.');
    }
  }

  function requireLogin(message){notice(message);setTimeout(()=>location.href='/profile?returnTo='+encodeURIComponent(location.pathname+location.search),850);}

  function bind(){
    document.querySelectorAll('.accordion-head').forEach(btn=>btn.addEventListener('click',()=>{const box=btn.parentElement;const open=!box.classList.contains('open');box.classList.toggle('open',open);btn.setAttribute('aria-expanded',open?'true':'false');}));
    document.getElementById('likeBtn')?.addEventListener('click',()=>toggle('like'));
    document.getElementById('executedBtn')?.addEventListener('click',()=>toggle('executed'));
    document.getElementById('bookmarkBtn')?.addEventListener('click',()=>{if(!window.MahdaShelf){notice('قفسه آماده نشد؛ صفحه را دوباره باز کنید.');return;}window.MahdaShelf.open(Number(contentId),{onSaved:(d)=>{interaction.active=d.saved?[...new Set([...(interaction.active||[]),'bookmark'])]:(interaction.active||[]).filter(k=>k!=='bookmark');interaction.counts=interaction.counts||{like:0,executed:0,bookmark:0};interaction.counts.bookmark=Number(d.count||0);setInteractionUI();notice(d.saved?'در قفسه ذخیره شد.':'از قفسه برداشته شد.');},onError:(e)=>{if(['auth_required','profile_incomplete'].includes(e?.message))requireLogin('برای استفاده از قفسه وارد حساب مهدا شوید.');else notice('باز کردن قفسه انجام نشد.');}});});
    document.getElementById('publisherBtn')?.addEventListener('click',()=>location.href='/showcase/profile/'+encodeURIComponent(item.profileId));
    document.getElementById('editContentBtn')?.addEventListener('click',()=>location.href='/content/new?edit='+encodeURIComponent(contentId));
    document.getElementById('shareBtn')?.addEventListener('click',share);
    document.getElementById('reportContentBtn')?.addEventListener('click',()=>openReport('content',Number(contentId)));
    const input=document.getElementById('commentInput'),submit=document.getElementById('commentSubmit');
    input?.addEventListener('input',()=>submit?.classList.toggle('ready',!!input.value.trim()));
    document.getElementById('commentForm')?.addEventListener('submit',sendComment);
  }

  async function share(){
    const publisher=String(item.publisher||item.author||'').trim();
    const data={title:item.title,text:item.title+(publisher?'؛ منتشرشده توسط '+publisher:''),url:location.href};
    try{if(navigator.share)await navigator.share(data);else{await navigator.clipboard.writeText(data.text+'\n'+data.url);notice('لینک محتوا کپی شد.');}}catch(e){}
  }

  async function loadComments(){
    const list=document.getElementById('commentList'),subtitle=document.getElementById('commentsSubtitle');
    if(!list||!subtitle)return;
    subtitle.textContent='در حال دریافت دیدگاه‌ها…';
    try{
      const d=await get(API+'?action=comments&content_id='+contentId);
      const arr=Array.isArray(d.items)?d.items:[];
      subtitle.textContent=arr.length?fa(arr.length)+' تجربه و دیدگاه':'هنوز دیدگاهی ثبت نشده است';
      list.innerHTML=arr.length?arr.map(c=>'<article class="comment"><span class="comment-avatar">'+(c.avatarUrl?'<img src="'+esc(c.avatarUrl)+'" alt="">':icon('user',16))+'</span><div class="comment-body"><strong>'+esc(c.name||'')+'</strong><p>'+esc(c.text||'')+'</p><span class="comment-actions"><button type="button" class="report-comment" data-comment="'+esc(c.id)+'">گزارش</button></span></div></article>').join(''):'<div class="empty-comments">هنوز نظری برای این محتوا ثبت نشده است.</div>';
      list.querySelectorAll('.report-comment').forEach(b=>b.addEventListener('click',()=>openReport('comment',Number(b.dataset.comment))));
    }catch(e){subtitle.textContent='خطا در دریافت دیدگاه‌ها';list.innerHTML='<div class="empty-comments error">دریافت نظرات انجام نشد. <button type="button" id="retryComments">تلاش دوباره</button></div>';document.getElementById('retryComments')?.addEventListener('click',loadComments);}
  }

  async function sendComment(ev){
    ev.preventDefault();
    const input=document.getElementById('commentInput');
    const body=(input?.value||'').trim();
    if(!body)return;
    try{await post('comment_create',{contentId:Number(contentId),body});input.value='';document.getElementById('commentSubmit')?.classList.remove('ready');await loadComments();}
    catch(e){if(e.message==='auth_required'||e.message==='profile_incomplete')return requireLogin('برای ثبت نظر ابتدا وارد حساب مهدا شوید.');if(e.message==='comment_too_fast')notice('چند ثانیه صبر کنید و دوباره ارسال کنید.');else notice('ارسال نظر انجام نشد.');}
  }

  function openReport(type,id){
    let o=document.getElementById('reportOverlay');
    if(!o){
      o=document.createElement('div');o.id='reportOverlay';o.className='report-overlay';
      o.innerHTML='<div class="report-box"><h3>گزارش به مهدا</h3><p>دلیل گزارش را انتخاب کنید. گزارش برای تیم بررسی مهدا ارسال می‌شود.</p><div class="report-reasons"><button data-r="inappropriate">محتوای نامناسب</button><button data-r="wrong_info">اطلاعات نادرست</button><button data-r="wrong_category">دسته‌بندی اشتباه</button><button data-r="broken_file">فایل خراب</button><button data-r="copyright">حقوق نشر</button><button data-r="ethical">مغایرت تربیتی</button><button data-r="other">سایر</button></div><textarea class="report-note" placeholder="توضیح تکمیلی (اختیاری)"></textarea><div class="report-actions"><button type="button" class="cancel">انصراف</button><button type="button" class="send">ارسال گزارش</button></div></div>';
      document.body.appendChild(o);o.querySelector('.cancel').onclick=()=>o.classList.remove('open');o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('open')});
    }
    o.dataset.type=type;o.dataset.id=String(id);o.dataset.reason='';o.querySelectorAll('[data-r]').forEach(b=>{b.classList.remove('on');b.onclick=()=>{o.dataset.reason=b.dataset.r;o.querySelectorAll('[data-r]').forEach(x=>x.classList.toggle('on',x===b));}});o.querySelector('.report-note').value='';o.querySelector('.send').onclick=sendReport;o.classList.add('open');
  }

  async function sendReport(){
    const o=document.getElementById('reportOverlay'),reason=o?.dataset.reason||'';
    if(!reason){notice('ابتدا دلیل گزارش را انتخاب کنید.');return;}
    try{await post('report_create',{targetType:o.dataset.type,targetId:Number(o.dataset.id),reason,note:o.querySelector('.report-note').value.trim()});o.classList.remove('open');notice('گزارش برای بررسی مهدا ارسال شد.');}
    catch(e){if(e.message==='auth_required'||e.message==='profile_incomplete'){o.classList.remove('open');return requireLogin('برای گزارش ابتدا وارد حساب مهدا شوید.');}if(e.message==='report_already_open'){o.classList.remove('open');notice('این مورد قبلاً گزارش شده و در حال بررسی است.');}else notice('ارسال گزارش انجام نشد.');}
  }

  function showLoadError(error){
    actionBar.hidden=true;
    if(error instanceof ApiError&&error.status===404){main.innerHTML='<div class="error-state"><div class="error-card">این محتوا وجود ندارد یا برای شما قابل مشاهده نیست.<br><button id="backBank">بازگشت به بانک محتوا</button></div></div>';document.getElementById('backBank')?.addEventListener('click',()=>location.href='/content');return;}
    main.innerHTML='<div class="error-state"><div class="error-card">دریافت محتوا از سرور انجام نشد.<br><button id="retryContent">تلاش دوباره</button></div></div>';document.getElementById('retryContent')?.addEventListener('click',loadContent);
  }

  async function loadContent(){
    main.innerHTML='<div class="loading">در حال دریافت محتوا…</div>';
    actionBar.hidden=true;
    try{const d=await get(API+'?action=content_detail&id='+contentId);if(!d.item)throw new ApiError('content_not_found',404);if(!String(d.item.title||'').trim())throw new ApiError('invalid_content_payload',502);item=d.item;render();}catch(e){showLoadError(e);}
  }

  async function init(){
    if(!contentId){showLoadError(new ApiError('content_not_found',404));return;}
    try{const session=await get(API+'?action=session');csrf=session.csrf||'';}catch(e){csrf='';}
    await loadContent();
  }

  init();
})();
