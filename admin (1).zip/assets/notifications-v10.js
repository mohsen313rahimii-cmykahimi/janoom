(() => {
  const API = '/mahda-api/index.php';
  let csrf = '';
  let items = [];
  const list = document.getElementById('list');
  const summary = document.getElementById('summary');
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c] || c));
  const fa = (n) => Number(n || 0).toLocaleString('fa-IR');
  const userSvg = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg>';
  async function get(action, params = {}) {
    const u = new URL(API, location.origin); u.searchParams.set('action', action); Object.entries(params).forEach(([k,v]) => u.searchParams.set(k,v));
    const r = await fetch(u, {credentials:'same-origin', cache:'no-store', headers:{Accept:'application/json'}}); const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || action); return d;
  }
  async function post(action, body = {}, retry = true) {
    if (!csrf) { const s = await get('session'); csrf = s.csrf || ''; }
    const r = await fetch(`${API}?action=${encodeURIComponent(action)}`, {method:'POST', credentials:'same-origin', cache:'no-store', headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':csrf}, body:JSON.stringify(body||{})});
    const d = await r.json().catch(() => ({}));
    if (!r.ok) {
      if (r.status === 419 && d.error === 'csrf_failed' && retry) { csrf = d.csrf || ''; const s = await get('session'); csrf = s.csrf || csrf; return post(action, body, false); }
      throw new Error(d.error || action);
    }
    if (d.csrf) csrf = d.csrf;
    return d;
  }
  function ago(v) {
    const t = Date.parse(String(v).replace(' ', 'T')); if (!t) return '';
    const m = Math.max(0, Math.floor((Date.now() - t) / 60000)); if (m < 1) return 'همین الان'; if (m < 60) return `${fa(m)} دقیقه پیش`;
    const h = Math.floor(m / 60); if (h < 24) return `${fa(h)} ساعت پیش`; return `${fa(Math.floor(h / 24))} روز پیش`;
  }
  function text(n) {
    const actor = n.actorName ? esc(n.actorName) : '';
    const title = n.contentTitle ? `«${esc(n.contentTitle)}»` : '';
    switch (n.kind) {
      case 'like': return ['پسند جدید', actor && title ? `${actor} محتوای ${title} را پسندید.` : actor ? `${actor} یکی از محتواهای تو را پسندید.` : title ? `محتوای ${title} پسندیده شد.` : 'یک پسند جدید برای محتوای تو ثبت شد.'];
      case 'executed': return ['یک تجربه تازه', actor && title ? `${actor} اعلام کرد محتوای ${title} را اجرا کرده است.` : actor ? `${actor} اجرای یکی از محتواهای تو را ثبت کرد.` : title ? `اجرای محتوای ${title} ثبت شد.` : 'یک اجرای تازه برای محتوای تو ثبت شد.'];
      case 'comment': return ['دیدگاه جدید', actor && title ? `${actor} برای ${title} دیدگاه گذاشت.` : actor ? `${actor} برای یکی از محتواهای تو دیدگاه گذاشت.` : title ? `برای ${title} دیدگاه تازه‌ای ثبت شد.` : 'یک دیدگاه تازه برای محتوای تو ثبت شد.'];
      case 'follow': return ['دنبال‌کننده جدید', actor ? `${actor} ویترین شما را دنبال کرد.` : 'ویترین شما دنبال‌کننده تازه‌ای دارد.'];
      case 'review_approved': return ['محتوا تأیید شد', title ? `محتوای ${title} با مهر مهدا تأیید شد.` : 'یکی از محتواهای ارسالی تأیید شد.'];
      case 'review_revision': return ['نیاز به اصلاح', title ? `برای محتوای ${title} اصلاحاتی درخواست شده است.` : 'برای یکی از محتواهای ارسالی اصلاحاتی درخواست شده است.'];
      case 'review_rejected': return ['نتیجه بررسی محتوا', title ? `محتوای ${title} تأیید نشد.` : 'یکی از محتواهای ارسالی تأیید نشد.'];
      default: return ['اعلان مهدا', n.reviewNote ? esc(n.reviewNote) : actor ? `${actor} با ویترین شما تعامل داشت.` : 'یک تعامل تازه در حساب شما ثبت شد.'];
    }
  }
  function target(n) { if (n.contentId) return `/content/item/${n.contentId}`; if (n.profileId) return `/showcase/profile/${n.profileId}`; if (n.actorProfileId) return `/showcase/profile/${n.actorProfileId}`; return '/showcase'; }
  function render(unread) {
    summary.textContent = items.length ? `${fa(items.length)} اعلان · ${fa(unread)} خوانده‌نشده` : 'اعلانی نداری';
    document.getElementById('markAll').style.display = unread ? '' : 'none';
    if (!items.length) { list.innerHTML = '<div class="empty panel"><div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M18 8a6 6 0 10-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg><div>فعلاً اعلان تازه‌ای نداری.</div></div></div>'; return; }
    list.innerHTML = items.map((n) => {
      const [title, body] = text(n);
      return `<article class="item ${!n.read ? 'unread' : ''}" data-id="${n.id}" data-href="${target(n)}"><span class="avatar">${n.actorAvatar ? `<img src="${esc(n.actorAvatar)}" alt="">` : userSvg}</span><span class="copy"><strong>${title}</strong><p>${body}</p><time>${ago(n.createdAt)}</time></span><span class="chev"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m15 18-6-6 6-6"/></svg></span></article>`;
    }).join('');
    list.querySelectorAll('.item').forEach((el) => el.addEventListener('click', () => openNotif(el)));
  }
  async function openNotif(el) { try { await post('notifications_read', {id:Number(el.dataset.id)}); } catch {} location.href = el.dataset.href; }
  async function load() {
    try {
      const s = await get('session'); csrf = s.csrf || '';
      if (s.user?.avatar_url) document.getElementById('headAvatar').innerHTML = `<img src="${esc(s.user.avatar_url)}" alt="">`;
      if (!s.user || s.user.guest || !s.user.profile_complete) {
        list.innerHTML = '<section class="panel login"><h2>اعلان‌ها برای حساب توست</h2><p>برای دیدن تعامل‌های ویترین، نظرها و نتیجه بررسی محتوا وارد حساب مهدا شو.</p><button id="loginBtn">ورود به حساب</button></section>';
        summary.textContent = ''; document.getElementById('markAll').style.display = 'none'; document.getElementById('loginBtn')?.addEventListener('click', () => location.href = '/profile?returnTo=/notifications'); return;
      }
      const d = await get('notifications', {limit:100}); items = d.items || []; render(d.unread || 0);
    } catch { list.innerHTML = '<div class="empty panel">دریافت اعلان‌ها انجام نشد.</div>'; }
  }
  document.getElementById('markAll').addEventListener('click', async () => { try { await post('notifications_read', {}); items.forEach((x) => x.read = true); render(0); } catch {} });
  load();
})();
