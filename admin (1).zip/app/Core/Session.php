<?php
declare(strict_types=1);

namespace Mahda\Core;

use Mahda\Core\Redis\RedisClient;
use Mahda\Core\Redis\RedisSessionHandler;

final class Session
{
    private static bool $handlerConfigured = false;

    public function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        @ini_set('session.use_strict_mode', '1');
        @ini_set('session.use_only_cookies', '1');
        @ini_set('session.cookie_httponly', '1');
        @ini_set('session.cookie_samesite', 'Lax');
        $this->configureHandler();
        session_name('mahda_app');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $this->isHttps(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);

        if (!session_start()) {
            throw new \RuntimeException('session_start_failed');
        }
    }

    public function get(string $key, mixed $default = null): mixed
    {
        $this->start();
        return $_SESSION[$key] ?? $default;
    }

    public function set(string $key, mixed $value): void
    {
        $this->start();
        $_SESSION[$key] = $value;
    }

    public function forget(string ...$keys): void
    {
        $this->start();
        foreach ($keys as $key) {
            unset($_SESSION[$key]);
        }
    }

    /** @return array<string, mixed> */
    public function all(): array
    {
        $this->start();
        return $_SESSION;
    }

    public function regenerate(bool $deleteOld = true): void
    {
        $this->start();
        session_regenerate_id($deleteOld);
    }

    public function clearAndDestroy(): void
    {
        $this->start();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => (string)($params['path'] ?? '/'),
                'domain' => (string)($params['domain'] ?? ''),
                'secure' => (bool)($params['secure'] ?? false),
                'httponly' => (bool)($params['httponly'] ?? true),
                'samesite' => (string)($params['samesite'] ?? 'Lax'),
            ]);
        }
        session_destroy();
    }

    private function configureHandler(): void
    {
        if (self::$handlerConfigured) return;
        self::$handlerConfigured = true;
        $path = dirname(__DIR__, 2) . '/config/redis.php';
        if (!is_file($path)) return;
        $config = require $path;
        if (!is_array($config)) return;
        try {
            $private = Database::privateConfig();
            if (isset($private['redis']) && is_array($private['redis'])) {
                $config = array_replace($config, $private['redis']);
            }
        } catch (\Throwable $ignored) {}
        if (empty($config['enabled'])) return;
        $redis = RedisClient::fromConfig($config);
        if (!$redis) return; // Safe fallback to PHP's native file sessions.
        $ttl = max(300, (int)($config['session_ttl'] ?? 43200));
        @ini_set('session.gc_maxlifetime', (string)$ttl);
        session_set_save_handler(new RedisSessionHandler($redis, $ttl), true);
    }

    private function isHttps(): bool
    {
        if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
            return true;
        }
        $forwarded = strtolower(trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0] ?? ''));
        return $forwarded === 'https' || strtolower((string)($_SERVER['HTTP_X_FORWARDED_SSL'] ?? '')) === 'on';
    }
}

