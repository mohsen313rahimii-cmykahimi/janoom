<?php
declare(strict_types=1);

namespace Mahda\Core\Ai;

interface AiProviderInterface
{
    /**
     * @param list<array{role:string,content:string}> $messages
     * @return array{data:array<string,mixed>,input_tokens:int,output_tokens:int,total_tokens:int,latency_ms:int,request_id:?string,model:string}
     */
    public function structuredJson(array $messages): array;
}
