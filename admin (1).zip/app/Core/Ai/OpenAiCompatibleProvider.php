<?php
declare(strict_types=1);

namespace Mahda\Core\Ai;

use RuntimeException;

final class OpenAiCompatibleProvider implements AiProviderInterface
{
    public function __construct(
        private string $baseUrl,
        private string $apiKey,
        private string $model,
        private string $fallbackModel = '',
        private int $timeoutSeconds = 8,
        private int $connectTimeoutSeconds = 3,
        private int $maxOutputTokens = 250,
    ) {
        $this->baseUrl = rtrim($this->baseUrl, '/');
    }

    public function structuredJson(array $messages): array
    {
        if ($this->apiKey === '') {
            throw new RuntimeException('ai_not_configured');
        }
        if (!function_exists('curl_init')) {
            throw new RuntimeException('ai_transport_unavailable');
        }

        $payload = [
            'model' => $this->model,
            'messages' => $messages,
            'temperature' => 0,
            'max_tokens' => $this->maxOutputTokens,
            'stream' => false,
        ];

        $started = microtime(true);
        $requestId = null;
        $rawBody = '';
        $status = 0;
        $attempts = 0;

        do {
            $attempts++;
            $ch = curl_init($this->baseUrl . '/chat/completions');
            if ($ch === false) {
                throw new RuntimeException('ai_transport_unavailable');
            }
            $headers = [];
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => $this->connectTimeoutSeconds,
                CURLOPT_TIMEOUT => $this->timeoutSeconds,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $this->apiKey,
                    'Content-Type: application/json',
                    'Accept: application/json',
                ],
                CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                CURLOPT_HEADERFUNCTION => static function ($curl, string $line) use (&$headers, &$requestId): int {
                    $length = strlen($line);
                    $parts = explode(':', $line, 2);
                    if (count($parts) === 2) {
                        $name = strtolower(trim($parts[0]));
                        $value = trim($parts[1]);
                        $headers[$name] = $value;
                        if (in_array($name, ['x-request-id','request-id','x-trace-id'], true)) {
                            $requestId = substr($value, 0, 190);
                        }
                    }
                    return $length;
                },
            ]);
            $response = curl_exec($ch);
            $curlError = curl_error($ch);
            $curlErrno = curl_errno($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            curl_close($ch);
            $rawBody = is_string($response) ? $response : '';

            if ($response === false || $curlError !== '') {
                if ($attempts < 2 && str_contains(strtolower($curlError), 'timed out') === false) {
                    usleep(120000);
                    continue;
                }
                if ($curlErrno === 6) throw new RuntimeException('ai_dns_error');
                if ($curlErrno === 7) throw new RuntimeException('ai_connect_error');
                if (in_array($curlErrno, [35,51,58,60,77,83,90], true)) throw new RuntimeException('ai_ssl_error');
                throw new RuntimeException(str_contains(strtolower($curlError), 'timed out') ? 'ai_timeout' : 'ai_transport_error');
            }
            if (in_array($status, [502,503,504], true) && $attempts < 2) {
                usleep(150000);
                continue;
            }
            break;
        } while ($attempts < 2);

        if ($status === 400 && $this->fallbackModel !== '' && $this->fallbackModel !== $this->model && preg_match('/model|not.?found|unknown/i', $rawBody) === 1) {
            $payload['model'] = $this->fallbackModel;
            $ch = curl_init($this->baseUrl . '/chat/completions');
            if ($ch !== false) {
                curl_setopt_array($ch, [
                    CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CONNECTTIMEOUT => $this->connectTimeoutSeconds, CURLOPT_TIMEOUT => $this->timeoutSeconds,
                    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $this->apiKey,'Content-Type: application/json','Accept: application/json'],
                    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                ]);
                $response = curl_exec($ch); $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
                $rawBody = is_string($response) ? $response : '';
            }
        }
        $latency = (int)round((microtime(true) - $started) * 1000);
        if ($status === 401 || $status === 403) {
            throw new RuntimeException('ai_auth_error');
        }
        if ($status === 429) {
            throw new RuntimeException('ai_provider_rate_limited');
        }
        if ($status < 200 || $status >= 300) {
            throw new RuntimeException($status >= 500 ? 'ai_provider_unavailable' : 'ai_provider_error');
        }

        $decoded = json_decode($rawBody, true);
        if (!is_array($decoded)) {
            throw new RuntimeException('ai_invalid_response');
        }
        $message = $decoded['choices'][0]['message'] ?? [];
        $content = is_array($message) ? (string)($message['content'] ?? '') : '';
        if (trim($content) === '' && is_array($message)) {
            $content = (string)($message['reasoning_content'] ?? ($message['reasoning'] ?? ''));
        }
        $json = $this->extractJsonObject($content);
        $structured = json_decode($json, true);
        if (!is_array($structured)) {
            throw new RuntimeException('ai_invalid_json');
        }
        $usage = is_array($decoded['usage'] ?? null) ? $decoded['usage'] : [];
        $input = max(0, (int)($usage['prompt_tokens'] ?? ($usage['input_tokens'] ?? 0)));
        $output = max(0, (int)($usage['completion_tokens'] ?? ($usage['output_tokens'] ?? 0)));
        $total = max($input + $output, (int)($usage['total_tokens'] ?? 0));

        return [
            'data' => $structured,
            'input_tokens' => $input,
            'output_tokens' => $output,
            'total_tokens' => $total,
            'latency_ms' => $latency,
            'request_id' => $requestId,
            'model' => (string)($payload['model'] ?? $this->model),
        ];
    }

    private function extractJsonObject(string $content): string
    {
        $content = trim($content);
        if (str_starts_with($content, '```')) {
            $content = preg_replace('/^```(?:json)?\s*/i', '', $content) ?? $content;
            $content = preg_replace('/\s*```$/', '', $content) ?? $content;
        }
        $start = strpos($content, '{');
        $end = strrpos($content, '}');
        if ($start === false || $end === false || $end < $start) {
            throw new RuntimeException('ai_invalid_json');
        }
        return substr($content, $start, $end - $start + 1);
    }
}
