<?php
declare(strict_types=1);

namespace Mahda\Core\Ai;

use RuntimeException;

final class AiProviderFactory
{
    /** @param array<string,mixed> $config */
    public static function make(array $config): AiProviderInterface
    {
        $provider = strtolower(trim((string)($config['provider'] ?? '')));
        if (!in_array($provider, ['seekai','openai-compatible','openai_compatible'], true)) {
            throw new RuntimeException('ai_provider_unsupported');
        }
        return new OpenAiCompatibleProvider(
            (string)($config['base_url'] ?? ''),
            (string)($config['api_key'] ?? ''),
            (string)($config['model'] ?? ''),
            (string)($config['fallback_model'] ?? ''),
            (int)($config['timeout_seconds'] ?? 8),
            (int)($config['connect_timeout_seconds'] ?? 3),
            (int)($config['max_output_tokens'] ?? 250),
        );
    }
}
