<?php
declare(strict_types=1);

namespace Mahda\Core\Storage;

use RuntimeException;

final class LocalPrivateStorage implements StorageInterface
{
    public function __construct(private string $directory, private array $fallbackDirectories = []) {}

    public function path(string $key): ?string
    {
        $safe = $this->safeKey($key);
        if ($safe === null) return null;
        foreach (array_merge([$this->directory], $this->fallbackDirectories) as $dir) {
            $candidate = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . $safe;
            if (is_file($candidate)) return $candidate;
        }
        return null;
    }

    public function exists(string $key): bool
    {
        return $this->path($key) !== null;
    }

    public function delete(string $key): void
    {
        $safe = $this->safeKey($key);
        if ($safe === null) return;
        foreach (array_merge([$this->directory], $this->fallbackDirectories) as $dir) {
            $candidate = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . $safe;
            if (is_file($candidate)) @unlink($candidate);
        }
    }

    public function ensureReady(): void
    {
        if (!is_dir($this->directory) && !mkdir($this->directory, 0750, true) && !is_dir($this->directory)) {
            throw new RuntimeException('storage_unavailable');
        }
        if (!is_writable($this->directory)) throw new RuntimeException('storage_unavailable');
    }

    public function directory(): string
    {
        return $this->directory;
    }

    public function putFile(string $key, string $localPath): void
    {
        $safe = $this->safeKey($key);
        if ($safe === null || !is_file($localPath)) throw new RuntimeException('storage_unavailable');
        $this->ensureReady();
        $target = rtrim($this->directory, '/\\') . DIRECTORY_SEPARATOR . $safe;
        if (realpath($localPath) === realpath($target)) return;
        if (!@copy($localPath, $target)) throw new RuntimeException('storage_unavailable');
        @chmod($target, 0640);
    }

    public function isRemote(): bool
    {
        return false;
    }

    private function safeKey(string $key): ?string
    {
        $key = trim($key);
        if ($key === '' || basename($key) !== $key || $key === '.' || $key === '..') return null;
        return $key;
    }
}
