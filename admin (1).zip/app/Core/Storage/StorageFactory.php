<?php
declare(strict_types=1);

namespace Mahda\Core\Storage;

use RuntimeException;

final class StorageFactory
{
    private function __construct() {}

    public static function make(array $config, string $localDirectory, array $fallbackDirectories = []): StorageInterface
    {
        $driver = strtolower(trim((string)($config['driver'] ?? 'local')));
        if ($driver === '' || $driver === 'local') {
            return new LocalPrivateStorage($localDirectory, $fallbackDirectories);
        }
        if (in_array($driver, ['s3','object','object_storage'], true)) {
            return new S3CompatibleStorage($config, $localDirectory);
        }
        throw new RuntimeException('storage_driver_not_supported');
    }
}
