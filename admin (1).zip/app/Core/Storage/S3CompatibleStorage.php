<?php
declare(strict_types=1);

namespace Mahda\Core\Storage;

use RuntimeException;

/**
 * Minimal S3-compatible private object-storage adapter.
 *
 * It intentionally uses only cURL + AWS Signature V4 so the project does not
 * need an SDK/Composer dependency on the current shared-hosting deployment.
 * Finished media is uploaded to S3; reads are cached into the local staging
 * directory so legacy PHP streaming and FFmpeg can continue working during the
 * migration period.
 */
final class S3CompatibleStorage implements StorageInterface
{
    private string $endpoint;
    private string $bucket;
    private string $region;
    private string $accessKey;
    private string $secretKey;
    private string $directory;
    private bool $pathStyle;

    public function __construct(array $config, string $directory)
    {
        $this->endpoint = rtrim((string)($config['endpoint'] ?? ''), '/');
        $this->bucket = trim((string)($config['bucket'] ?? ''));
        $this->region = trim((string)($config['region'] ?? 'us-east-1')) ?: 'us-east-1';
        $this->accessKey = trim((string)($config['access_key'] ?? ''));
        $this->secretKey = (string)($config['secret_key'] ?? '');
        $this->pathStyle = (bool)($config['path_style'] ?? true);
        $this->directory = rtrim($directory, '/\\');

        if ($this->endpoint === '' || $this->bucket === '' || $this->accessKey === '' || $this->secretKey === '') {
            throw new RuntimeException('storage_invalid_config');
        }
        $scheme = strtolower((string)(parse_url($this->endpoint, PHP_URL_SCHEME) ?? ''));
        if (!in_array($scheme, ['https','http'], true)) throw new RuntimeException('storage_invalid_config');
        if (!function_exists('curl_init')) throw new RuntimeException('storage_curl_unavailable');
    }

    public function ensureReady(): void
    {
        if (!is_dir($this->directory) && !mkdir($this->directory, 0750, true) && !is_dir($this->directory)) {
            throw new RuntimeException('storage_unavailable');
        }
        if (!is_writable($this->directory)) throw new RuntimeException('storage_unavailable');
    }

    public function directory(): string
    {
        return $this->directory;
    }

    public function isRemote(): bool
    {
        return true;
    }

    public function path(string $key): ?string
    {
        $key = $this->safeKey($key);
        if ($key === null) return null;
        $this->ensureReady();
        $local = $this->localPath($key);
        if (is_file($local)) return $local;

        $tmp = $local . '.download-' . bin2hex(random_bytes(6));
        try {
            $this->request('GET', $key, '', $tmp);
            if (!is_file($tmp)) return null;
            @chmod($tmp, 0640);
            if (!@rename($tmp, $local)) { @unlink($tmp); return null; }
            return $local;
        } catch (RuntimeException $e) {
            @unlink($tmp);
            if ($e->getMessage() === 'storage_object_not_found') return null;
            return null;
        }
    }

    public function exists(string $key): bool
    {
        $key = $this->safeKey($key);
        if ($key === null) return false;
        if (is_file($this->localPath($key))) return true;
        try {
            $this->request('HEAD', $key);
            return true;
        } catch (RuntimeException $e) {
            return false;
        }
    }

    public function delete(string $key): void
    {
        $key = $this->safeKey($key);
        if ($key === null) return;
        $local = $this->localPath($key);
        if (is_file($local)) @unlink($local);
        try { $this->request('DELETE', $key); } catch (RuntimeException $ignored) {}
    }

    public function putFile(string $key, string $localPath): void
    {
        $key = $this->safeKey($key);
        if ($key === null || !is_file($localPath) || !is_readable($localPath)) throw new RuntimeException('storage_unavailable');
        $this->ensureReady();
        $this->request('PUT', $key, $localPath);

        // Keep one local cached copy for FFmpeg/current PHP streaming. If the
        // source lives elsewhere, copy it into the staging cache after upload.
        $cache = $this->localPath($key);
        if (realpath($localPath) !== realpath($cache)) {
            if (!@copy($localPath, $cache)) throw new RuntimeException('storage_cache_failed');
            @chmod($cache, 0640);
        }
    }

    private function localPath(string $key): string
    {
        return $this->directory . DIRECTORY_SEPARATOR . $key;
    }

    private function safeKey(string $key): ?string
    {
        $key = trim($key);
        if ($key === '' || basename($key) !== $key || $key === '.' || $key === '..') return null;
        return $key;
    }

    /**
     * @return array{url:string,host:string,uri:string}
     */
    private function target(string $key): array
    {
        $parts = parse_url($this->endpoint);
        if (!is_array($parts) || empty($parts['host'])) throw new RuntimeException('storage_invalid_config');
        $scheme = (string)($parts['scheme'] ?? 'https');
        $host = (string)$parts['host'];
        if (isset($parts['port'])) $host .= ':' . (int)$parts['port'];
        $basePath = '/' . trim((string)($parts['path'] ?? ''), '/');
        if ($basePath === '/') $basePath = '';
        $encodedKey = implode('/', array_map('rawurlencode', explode('/', $key)));

        if ($this->pathStyle) {
            $uri = $basePath . '/' . rawurlencode($this->bucket) . '/' . $encodedKey;
        } else {
            $host = rawurlencode($this->bucket) . '.' . $host;
            $uri = $basePath . '/' . $encodedKey;
        }
        if ($uri === '') $uri = '/';
        return ['url'=>$scheme.'://'.$host.$uri,'host'=>$host,'uri'=>$uri];
    }

    private function request(string $method, string $key, string $bodyFile = '', string $downloadFile = ''): void
    {
        $target = $this->target($key);
        $payloadHash = $bodyFile !== '' ? hash_file('sha256', $bodyFile) : hash('sha256', '');
        if (!is_string($payloadHash) || $payloadHash === '') throw new RuntimeException('storage_unavailable');
        $now = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $amzDate = $now->format('Ymd\\THis\\Z');
        $date = $now->format('Ymd');
        $canonicalHeaders = 'host:' . strtolower($target['host']) . "\n" .
            'x-amz-content-sha256:' . $payloadHash . "\n" .
            'x-amz-date:' . $amzDate . "\n";
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
        $canonicalRequest = $method . "\n" . $target['uri'] . "\n\n" . $canonicalHeaders . "\n" . $signedHeaders . "\n" . $payloadHash;
        $scope = $date . '/' . $this->region . '/s3/aws4_request';
        $stringToSign = "AWS4-HMAC-SHA256\n" . $amzDate . "\n" . $scope . "\n" . hash('sha256', $canonicalRequest);
        $kDate = hash_hmac('sha256', $date, 'AWS4' . $this->secretKey, true);
        $kRegion = hash_hmac('sha256', $this->region, $kDate, true);
        $kService = hash_hmac('sha256', 's3', $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);
        $authorization = 'AWS4-HMAC-SHA256 Credential=' . $this->accessKey . '/' . $scope . ', SignedHeaders=' . $signedHeaders . ', Signature=' . $signature;

        $headers = [
            'Host: ' . $target['host'],
            'x-amz-content-sha256: ' . $payloadHash,
            'x-amz-date: ' . $amzDate,
            'Authorization: ' . $authorization,
        ];
        $ch = curl_init($target['url']);
        if ($ch === false) throw new RuntimeException('storage_unavailable');
        $out = null;
        $in = null;
        try {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            curl_setopt($ch, CURLOPT_TIMEOUT, $method === 'PUT' || $method === 'GET' ? 120 : 15);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
            curl_setopt($ch, CURLOPT_HEADER, false);
            if ($method === 'HEAD') curl_setopt($ch, CURLOPT_NOBODY, true);
            elseif ($method === 'PUT') {
                $in = fopen($bodyFile, 'rb');
                if ($in === false) throw new RuntimeException('storage_unavailable');
                curl_setopt($ch, CURLOPT_UPLOAD, true);
                curl_setopt($ch, CURLOPT_INFILE, $in);
                curl_setopt($ch, CURLOPT_INFILESIZE, (int)filesize($bodyFile));
            } elseif ($method === 'GET' && $downloadFile !== '') {
                $out = fopen($downloadFile, 'wb');
                if ($out === false) throw new RuntimeException('storage_unavailable');
                curl_setopt($ch, CURLOPT_FILE, $out);
            } else {
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            }
            $result = curl_exec($ch);
            if ($result === false) throw new RuntimeException('storage_request_failed');
            $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            if ($status === 404) throw new RuntimeException('storage_object_not_found');
            if ($status < 200 || $status >= 300) throw new RuntimeException('storage_request_failed');
        } finally {
            if (is_resource($in)) fclose($in);
            if (is_resource($out)) fclose($out);
            curl_close($ch);
        }
    }
}
