<?php
declare(strict_types=1);

namespace Mahda\Core\Storage;

interface StorageInterface
{
    /**
     * Returns a local readable path. Remote drivers may transparently cache the
     * object before returning the path.
     */
    public function path(string $key): ?string;

    public function exists(string $key): bool;
    public function delete(string $key): void;
    public function ensureReady(): void;

    /** Local staging directory used by image/video processors. */
    public function directory(): string;

    /**
     * Persist a finished local file under the given storage key. Local storage
     * keeps the file in-place; remote storage uploads it to the object store.
     */
    public function putFile(string $key, string $localPath): void;

    public function isRemote(): bool;
}
