<?php
declare(strict_types=1);

namespace Mahda\Core;

use PDO;

final class MigrationRunner
{
    /** @param iterable<callable(PDO): void> $migrations */
    public function run(PDO $connection, iterable $migrations): void
    {
        foreach ($migrations as $migration) {
            if (!is_callable($migration)) {
                throw new \InvalidArgumentException('Invalid migration.');
            }
            $migration($connection);
        }
    }
}

