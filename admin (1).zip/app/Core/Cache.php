<?php
declare(strict_types=1);

namespace Mahda\Core;

use Mahda\Core\Redis\RedisClient;

/** Small optional Redis cache facade; safe no-op when Redis is unavailable. */
final class Cache
{
    public function __construct(private ?RedisClient $redis) {}

    public function get(string $key, mixed $default = null): mixed
    {
        if (!$this->redis) return $default;
        $raw = $this->redis->get('cache:' . $key);
        if ($raw === null) return $default;
        $value = json_decode($raw, true);
        return json_last_error() === JSON_ERROR_NONE ? $value : $default;
    }

    public function set(string $key, mixed $value, int $ttl = 300): bool
    {
        if (!$this->redis) return false;
        $raw = json_encode($value, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        return is_string($raw) && $this->redis->setEx('cache:' . $key, max(1,$ttl), $raw);
    }

    public function forget(string $key): void
    {
        if ($this->redis) $this->redis->delete('cache:' . $key);
    }
}
