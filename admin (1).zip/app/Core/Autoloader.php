<?php
declare(strict_types=1);

namespace Mahda\Core;

final class Autoloader
{
    private function __construct()
    {
    }

    public static function register(string $baseDir): void
    {
        $baseDir = rtrim($baseDir, '/\\');

        spl_autoload_register(static function (string $class) use ($baseDir): void {
            $prefix = 'Mahda\\';
            if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
                return;
            }

            $relative = substr($class, strlen($prefix));
            if ($relative === '' || str_contains($relative, '..')) {
                return;
            }

            $file = $baseDir . '/' . str_replace('\\', '/', $relative) . '.php';
            if (is_file($file)) {
                require_once $file;
            }
        });
    }
}

