<?php
declare(strict_types=1);

namespace Mahda\Core;

use PDO;

final class Database
{
    private static ?PDO $connection = null;

    /** @var array<string, mixed>|null */
    private static ?array $privateConfig = null;

    private function __construct()
    {
    }

    /** @return array<string, mixed> */
    public static function privateConfig(?string $path = null): array
    {
        if (self::$privateConfig !== null && $path === null) {
            return self::$privateConfig;
        }

        $configuredPath = getenv('MAHDA_PRIVATE_CONFIG');
        $configuredDir = getenv('MAHDA_PRIVATE_PATH');
        $projectRoot = dirname(__DIR__, 2);
        $candidates = $path !== null ? [$path] : array_values(array_filter([
            $configuredPath !== false && trim((string)$configuredPath) !== '' ? (string)$configuredPath : null,
            $configuredDir !== false && trim((string)$configuredDir) !== '' ? rtrim((string)$configuredDir, '/\\') . '/config.php' : null,
            dirname($projectRoot) . '/.mahda-private/config.php',
            // Backward-compatible fallback for deployments that already placed
            // the private directory under the document root and protected it.
            $projectRoot . '/.mahda-private/config.php',
        ]));
        $file = null;
        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                $file = $candidate;
                break;
            }
        }
        if ($file === null) {
            throw new \RuntimeException('not_installed');
        }

        $config = require $file;
        if (!is_array($config) || !isset($config['dsn'], $config['user'], $config['password'])) {
            throw new \RuntimeException('invalid_config');
        }

        if ($path === null) {
            self::$privateConfig = $config;
        }

        return $config;
    }

    public static function connection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        $config = self::privateConfig();
        self::$connection = new PDO((string)$config['dsn'], (string)$config['user'], (string)$config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        return self::$connection;
    }

    public static function reset(): void
    {
        self::$connection = null;
        self::$privateConfig = null;
    }
}

