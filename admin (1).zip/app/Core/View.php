<?php
declare(strict_types=1);

namespace Mahda\Core;

final class View
{
    private string $basePath;

    public function __construct(string $basePath)
    {
        $resolved = realpath($basePath);
        if ($resolved === false || !is_dir($resolved)) {
            throw new \RuntimeException('Template directory not found.');
        }
        $this->basePath = $resolved;
    }

    /** @param array<string, mixed> $data */
    public function render(string $template, array $data = []): string
    {
        if ($template === '' || str_contains($template, '..') || str_contains($template, "\0")) {
            throw new \InvalidArgumentException('Invalid template name.');
        }

        $file = realpath($this->basePath . '/' . ltrim($template, '/') . '.php');
        if ($file === false || !str_starts_with($file, $this->basePath . DIRECTORY_SEPARATOR) || !is_file($file)) {
            throw new \RuntimeException('Template not found.');
        }

        extract($data, EXTR_SKIP);
        ob_start();
        try {
            require $file;
            return (string)ob_get_clean();
        } catch (\Throwable $error) {
            ob_end_clean();
            throw $error;
        }
    }
}

