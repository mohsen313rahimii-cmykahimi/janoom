<?php
declare(strict_types=1);

namespace Mahda\Core;

final class Request
{
    /** @var array<string, mixed> */
    private array $server;

    /** @var array<string, string> */
    private array $routeParams = [];

    /** @param array<string, mixed>|null $server */
    public function __construct(?array $server = null)
    {
        $this->server = $server ?? $_SERVER;
    }

    public function method(): string
    {
        return strtoupper((string)($this->server['REQUEST_METHOD'] ?? 'GET'));
    }

    public function path(): string
    {
        $raw = (string)($this->server['REQUEST_URI'] ?? '/');
        $path = parse_url($raw, PHP_URL_PATH);
        $path = is_string($path) && $path !== '' ? $path : '/';
        $path = '/' . ltrim($path, '/');
        $path = preg_replace('#/{2,}#', '/', $path) ?? $path;

        if ($path !== '/') {
            $path = rtrim($path, '/');
        }

        return $path === '' ? '/' : $path;
    }

    public function query(string $key, mixed $default = null): mixed
    {
        return $_GET[$key] ?? $default;
    }

    /** @param array<string, string> $params */
    public function setRouteParams(array $params): void
    {
        $this->routeParams = $params;
    }

    public function route(string $key, mixed $default = null): mixed
    {
        return $this->routeParams[$key] ?? $default;
    }
}
