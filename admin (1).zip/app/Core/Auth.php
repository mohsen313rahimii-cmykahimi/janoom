<?php
declare(strict_types=1);

namespace Mahda\Core;

use Mahda\Modules\Auth\AuthRepository;

final class Auth
{
    private bool $loaded = false;
    /** @var array<string, mixed>|null */
    private ?array $cachedUser = null;

    public function __construct(private AuthRepository $repository, private Session $session)
    {
    }

    /** @return array<string, mixed>|null */
    public function user(): ?array
    {
        if ($this->loaded) {
            return $this->cachedUser;
        }
        $this->loaded = true;
        $userId = (int)$this->session->get('user_id', 0);
        $profileId = (int)$this->session->get('profile_id', 0);
        if ($userId < 1 || $profileId < 1 || (bool)$this->session->get('guest', false)) {
            return null;
        }

        $row = $this->repository->findByIds($userId, $profileId);
        if ($row === null) {
            $this->forgetIdentity();
            return null;
        }

        $this->session->set('display_name', (string)$row['display_name']);
        $this->session->set('role', (string)$row['role']);
        $this->cachedUser = $this->repository->toPayload($row);
        return $this->cachedUser;
    }

    /** @return array<string, mixed> */
    public function guest(): array
    {
        $this->session->forget('user_id', 'profile_id', 'phone', 'display_name', 'role');
        $this->session->set('guest', true);
        return $this->repository->guestPayload();
    }

    /** @return array<string, mixed> */
    public function requireMember(): array
    {
        $user = $this->user();
        if ($user === null) {
            throw new \RuntimeException('auth_required');
        }
        return $user;
    }

    public function establish(array $row, string $phone = ''): array
    {
        $this->session->regenerate(true);
        $this->session->set('user_id', (int)$row['id']);
        $this->session->set('profile_id', (int)$row['profile_id']);
        if ($phone !== '') {
            $this->session->set('phone', $phone);
        }
        $this->session->set('display_name', (string)$row['display_name']);
        $this->session->set('role', (string)$row['role']);
        $this->session->set('guest', false);
        $this->cachedUser = $this->repository->toPayload(array_merge($row, ['phone' => $phone, 'guest' => false]));
        $this->loaded = true;
        return $this->cachedUser;
    }

    /** @return array<string, mixed> */
    public function logout(): array
    {
        $this->session->clearAndDestroy();
        $this->loaded = false;
        $this->cachedUser = null;
        $this->session->start();
        $this->session->regenerate(true);
        return $this->guest();
    }

    private function forgetIdentity(): void
    {
        $this->session->forget('user_id', 'profile_id', 'phone', 'display_name', 'role', 'guest');
        $this->cachedUser = null;
    }
}

