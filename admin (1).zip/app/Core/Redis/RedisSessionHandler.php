<?php
declare(strict_types=1);

namespace Mahda\Core\Redis;

final class RedisSessionHandler implements \SessionHandlerInterface
{
    private ?string $lockKey = null;
    private ?string $lockToken = null;

    public function __construct(private RedisClient $redis, private int $ttl = 43200) {}

    public function open(string $path, string $name): bool { return true; }
    public function close(): bool { $this->unlock(); return true; }

    public function read(string $id): string|false
    {
        $this->lockKey = 'session-lock:' . $id;
        $this->lockToken = bin2hex(random_bytes(16));
        $deadline = microtime(true) + 2.0;
        while (!$this->redis->acquireLock($this->lockKey, $this->lockToken, 10)) {
            if (microtime(true) >= $deadline) { $this->lockKey = $this->lockToken = null; break; }
            usleep(20000);
        }
        return $this->redis->get('session:' . $id) ?? '';
    }

    public function write(string $id, string $data): bool
    {
        return $this->redis->setEx('session:' . $id, $this->ttl, $data);
    }

    public function destroy(string $id): bool
    {
        $this->redis->delete('session:' . $id);
        $this->unlock();
        return true;
    }

    public function gc(int $max_lifetime): int|false { return 0; }

    private function unlock(): void
    {
        if ($this->lockKey !== null && $this->lockToken !== null) {
            $this->redis->releaseLock($this->lockKey, $this->lockToken);
        }
        $this->lockKey = $this->lockToken = null;
    }
}
