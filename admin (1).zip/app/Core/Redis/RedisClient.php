<?php
declare(strict_types=1);

namespace Mahda\Core\Redis;

use RuntimeException;

/** Optional ext-redis connection. Returns null when Redis is not configured. */
final class RedisClient
{
    private \Redis $redis;

    private function __construct(\Redis $redis)
    {
        $this->redis = $redis;
    }

    public static function fromConfig(array $config): ?self
    {
        $enabled = (bool)($config['enabled'] ?? false);
        if (!$enabled) return null;
        if (!class_exists('Redis')) return null;

        $host = trim((string)($config['host'] ?? '127.0.0.1'));
        $port = max(1, (int)($config['port'] ?? 6379));
        $timeout = max(0.2, (float)($config['timeout'] ?? 1.5));
        $scheme = strtolower((string)($config['scheme'] ?? 'tcp'));
        if ($scheme === 'tls' && !str_starts_with($host, 'tls://')) $host = 'tls://' . $host;

        try {
            $redis = new \Redis();
            if (!$redis->connect($host, $port, $timeout)) return null;
            $password = (string)($config['password'] ?? '');
            $username = (string)($config['username'] ?? '');
            if ($password !== '') {
                $auth = $username !== '' ? [$username, $password] : $password;
                if (!$redis->auth($auth)) return null;
            }
            $database = max(0, (int)($config['database'] ?? 0));
            if ($database > 0 && !$redis->select($database)) return null;
            $prefix = (string)($config['prefix'] ?? 'mahda:');
            if ($prefix !== '') $redis->setOption(\Redis::OPT_PREFIX, $prefix);
            return new self($redis);
        } catch (\Throwable $e) {
            return null;
        }
    }

    public function get(string $key): ?string
    {
        try { $value = $this->redis->get($key); return is_string($value) ? $value : null; }
        catch (\Throwable $e) { return null; }
    }

    public function setEx(string $key, int $ttl, string $value): bool
    {
        try { return (bool)$this->redis->setex($key, max(1,$ttl), $value); }
        catch (\Throwable $e) { return false; }
    }

    public function delete(string $key): void
    {
        try { $this->redis->del($key); } catch (\Throwable $e) {}
    }

    /** Atomic fixed-window increment; returns the current count or null on failure. */
    public function incrementWindow(string $key, int $ttl): ?int
    {
        try {
            $count = (int)$this->redis->incr($key);
            if ($count === 1) $this->redis->expire($key, max(1,$ttl));
            return $count;
        } catch (\Throwable $e) {
            return null;
        }
    }

    public function acquireLock(string $key, string $token, int $ttl): bool
    {
        try { return $this->redis->set($key, $token, ['nx', 'ex'=>max(1,$ttl)]) === true; }
        catch (\Throwable $e) { return false; }
    }

    public function releaseLock(string $key, string $token): void
    {
        $script = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end";
        try { $this->redis->eval($script, [$key, $token], 1); } catch (\Throwable $e) {}
    }
}
