<?php
declare(strict_types=1);

namespace Mahda\Core;

final class Config
{
    private function __construct()
    {
    }

    public static function fromFile(string $path): array
    {
        if (!is_file($path)) {
            throw new \RuntimeException('Configuration file not found.');
        }

        $config = require $path;
        if (!is_array($config)) {
            throw new \RuntimeException('Configuration must return an array.');
        }

        return $config;
    }
}

