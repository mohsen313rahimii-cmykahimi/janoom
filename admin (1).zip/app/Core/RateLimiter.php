<?php
declare(strict_types=1);

namespace Mahda\Core;

use PDO;
use Mahda\Core\Redis\RedisClient;

/**
 * Small fixed-window limiter suitable for the current single-database deployment.
 * The interface is deliberately isolated so Redis can replace this implementation later.
 */
final class RateLimiter
{
    public function __construct(private PDO $db, private ?RedisClient $redis = null) {}

    public function hit(string $bucket, int $limit, int $windowSeconds): bool
    {
        $bucket = hash('sha256', $bucket);
        $limit = max(1, $limit);
        $windowSeconds = max(1, $windowSeconds);
        $now = time();
        $windowStart = $now - ($now % $windowSeconds);

        if ($this->redis) {
            $count = $this->redis->incrementWindow('rate:' . $bucket . ':' . $windowStart, $windowSeconds + 2);
            if ($count !== null) return $count <= $limit;
            // Redis outage must not disable protection; fall back to the DB.
        }

        $windowAt = date('Y-m-d H:i:s', $windowStart);

        $expiryAt = date('Y-m-d H:i:s', $windowStart + $windowSeconds + 1);
        $sql = "INSERT INTO mahda_rate_limits(bucket_key,window_started,hits,expires_at)
                VALUES(?,?,1,?)
                ON DUPLICATE KEY UPDATE hits=hits+1, expires_at=VALUES(expires_at)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$bucket, $windowAt, $expiryAt]);

        $read = $this->db->prepare('SELECT hits FROM mahda_rate_limits WHERE bucket_key=? AND window_started=? LIMIT 1');
        $read->execute([$bucket, $windowAt]);
        return (int)$read->fetchColumn() <= $limit;
    }

    public function cleanup(): void
    {
        $this->db->exec('DELETE FROM mahda_rate_limits WHERE expires_at < NOW()');
    }
}
