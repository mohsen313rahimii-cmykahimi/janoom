<?php
declare(strict_types=1);

namespace Mahda\Core;

final class Router
{
    /** @var array<string, array<string, callable>> */
    private array $staticRoutes = [];

    /** @var array<string, list<array{pattern:string,handler:callable}>> */
    private array $dynamicRoutes = [];

    public function add(string $method, string $path, callable $handler): void
    {
        $method = strtoupper($method);
        $path = self::normalizePath($path);
        if (!str_contains($path, '{')) {
            $this->staticRoutes[$method][$path] = $handler;
            return;
        }

        // preg_quote escapes braces; restore named placeholders before compiling.
        $quoted = preg_quote($path, '#');
        $pattern = preg_replace_callback('/\\\{([A-Za-z_][A-Za-z0-9_]*)\\\}/', static function (array $m): string {
            return '(?P<' . $m[1] . '>[1-9][0-9]*)';
        }, $quoted) ?? $quoted;
        $this->dynamicRoutes[$method][] = ['pattern' => '#^' . $pattern . '$#', 'handler' => $handler];
    }

    public function get(string $path, callable $handler): void
    {
        $this->add('GET', $path, $handler);
    }

    public function post(string $path, callable $handler): void
    {
        $this->add('POST', $path, $handler);
    }

    public function dispatch(Request $request): mixed
    {
        $method = $request->method();
        $path = self::normalizePath($request->path());
        $handler = $this->staticRoutes[$method][$path] ?? null;
        if ($handler !== null) {
            return $handler($request);
        }

        foreach ($this->dynamicRoutes[$method] ?? [] as $route) {
            if (preg_match($route['pattern'], $path, $matches) !== 1) {
                continue;
            }
            $params = [];
            foreach ($matches as $key => $value) {
                if (is_string($key)) {
                    $params[$key] = $value;
                }
            }
            $request->setRouteParams($params);
            return ($route['handler'])($request);
        }

        return null;
    }

    private static function normalizePath(string $path): string
    {
        $path = '/' . ltrim($path, '/');
        $path = preg_replace('#/{2,}#', '/', $path) ?? $path;
        return $path === '/' ? '/' : rtrim($path, '/');
    }
}
