<?php
declare(strict_types=1);

namespace Mahda\Core;

final class App
{
    public function __construct(
        private Request $request,
        private Response $response,
        private Router $router,
    ) {
    }

    public function handleWebRequest(): void
    {
        $result = $this->router->dispatch($this->request);
        if ($result === null) {
            $this->response->sendHtml('<!doctype html><meta charset="utf-8"><title>مهدا</title><h1>صفحه پیدا نشد</h1>', 404);
            return;
        }

        $this->response->sendHtml((string)$result);
    }
}

