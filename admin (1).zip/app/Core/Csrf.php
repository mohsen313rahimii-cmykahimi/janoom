<?php
declare(strict_types=1);

namespace Mahda\Core;

final class Csrf
{
    public function __construct(private Session $session)
    {
    }

    public function token(): string
    {
        // Keep the same session key as the legacy API during the modular
        // migration.  Both clients can therefore share one CSRF token.
        $token = (string)$this->session->get('csrf', $this->session->get('_csrf', ''));
        if ($token === '') {
            $token = bin2hex(random_bytes(32));
            $this->session->set('csrf', $token);
        }
        $this->session->set('_csrf', $token);
        return $token;
    }

    public function validate(?string $token): bool
    {
        $expected = $this->token();
        return is_string($token) && $token !== '' && hash_equals($expected, $token);
    }

    public function rotate(): string
    {
        $token = bin2hex(random_bytes(32));
        $this->session->set('csrf', $token);
        $this->session->set('_csrf', $token);
        return $token;
    }
}
