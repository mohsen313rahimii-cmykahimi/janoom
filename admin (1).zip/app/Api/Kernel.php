<?php
declare(strict_types=1);

ini_set('display_errors', '0');

$root = dirname(__DIR__, 2);
require_once $root . '/mahda-api/bootstrap.php';
require_once $root . '/app/Modules/Content/registration-contract.php';
require_once $root . '/app/Modules/ContentChin/api.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

try {
    $db = mahda_db();
    // Production migrations belong to deploy/CLI, never the hot request path.
    // Temporary opt-in exists only to ease one legacy deployment transition.
    if (in_array(strtolower((string)(getenv('MAHDA_ALLOW_REQUEST_MIGRATIONS') ?: '0')), ['1','true','yes','on'], true)) {
        mahda_run_all_migrations($db);
    }

    $action = (string)($_GET['action'] ?? 'health');

    require_once $root . '/app/Core/Autoloader.php';
    \Mahda\Core\Autoloader::register($root . '/app');

    require_once $root . '/app/Modules/Mobile/api.php';
    require_once $root . '/app/Modules/OfflineSync/api.php';
    require_once $root . '/app/Modules/Auth/api.php';
    require_once $root . '/app/Modules/System/api.php';
    require_once $root . '/app/Modules/Profile/api.php';
    require_once $root . '/app/Modules/Home/api.php';
    require_once $root . '/app/Modules/Atlas/api.php';
    require_once $root . '/app/Modules/Content/api.php';
    require_once $root . '/app/Modules/Content/workflow-api.php';
    require_once $root . '/app/Modules/Social/api.php';
    require_once $root . '/app/Modules/Showcase/api.php';
    require_once $root . '/app/Modules/Media/api.php';
    require_once $root . '/app/Modules/Admin/api.php';

    $dispatchers = [
        'mahda_mobile_module_dispatch',
        'mahda_offline_sync_module_dispatch',
        'mahda_auth_module_dispatch',
        'mahda_system_module_dispatch',
        'mahda_profile_module_dispatch',
        'mahda_home_module_dispatch',
        'mahda_atlas_module_dispatch',
        'mahda_content_module_dispatch',
        'mahda_content_workflow_dispatch',
        'mahda_social_module_dispatch',
        'mahda_showcase_module_dispatch',
        'mahda_contentchin_dispatch',
        'mahda_media_module_dispatch',
        'mahda_admin_module_dispatch',
    ];

    foreach ($dispatchers as $dispatch) {
        if ($dispatch($db, $action)) {
            exit;
        }
    }

    mahda_json(['error' => 'not_found'], 404);
} catch (RuntimeException $error) {
    if ($error->getMessage() === 'not_installed') {
        mahda_json(['status' => 'not_installed'], 503);
    }
    $safe = in_array($error->getMessage(), ['file_too_large','invalid_file','file_type_not_allowed','storage_unavailable','image_compression_failed','media_processing_unavailable','rate_limited'], true)
        ? $error->getMessage()
        : 'request_failed';
    mahda_json(['error' => $safe], 422);
} catch (Throwable $error) {
    try {
        if (isset($db) && $db instanceof PDO) {
            mahda_log_system_error($db, $action ?? null, $error);
        }
    } catch (Throwable $ignored) {
    }
    mahda_json(['error' => 'server_error'], 500);
}
