<?php
declare(strict_types=1);

namespace Mahda\Modules\Mobile;

use Mahda\Modules\Auth\AuthRepository;
use PDO;
use RuntimeException;

final class MobileTokenService
{
    /** @var array<string,mixed> */
    private array $config;

    public function __construct(private PDO $db, private AuthRepository $users)
    {
        $path = dirname(__DIR__, 3) . '/config/mobile_auth.php';
        $config = is_file($path) ? require $path : [];
        $this->config = is_array($config) ? $config : [];
    }

    /** @return array{accessToken:string,refreshToken:string,tokenType:string,expiresIn:int,refreshExpiresIn:int} */
    public function issueForUser(array $row, string $deviceLabel = ''): array
    {
        $family = bin2hex(random_bytes(16));
        return $this->issuePair((int)$row['id'], (int)$row['profile_id'], $family, $deviceLabel);
    }

    /** @return array<string,mixed> */
    public function authenticateBearer(?string $header = null): array
    {
        $raw = $this->extractBearer($header);
        if ($raw === null || !str_starts_with($raw, 'mda1a_')) {
            throw new RuntimeException('mobile_auth_required');
        }
        $hash = hash('sha256', $raw);
        $stmt = $this->db->prepare("SELECT user_id,profile_id,family_key FROM mahda_mobile_tokens WHERE token_hash=? AND token_type='access' AND revoked_at IS NULL AND expires_at>NOW() LIMIT 1");
        $stmt->execute([$hash]);
        $token = $stmt->fetch();
        if (!is_array($token)) throw new RuntimeException('mobile_auth_required');
        $row = $this->users->findByIds((int)$token['user_id'], (int)$token['profile_id']);
        if ($row === null) throw new RuntimeException('mobile_auth_required');
        $user = $this->users->toPayload($row);
        $user['_token_family'] = (string)$token['family_key'];
        return $user;
    }

    /** @return array{tokens:array<string,mixed>,user:array<string,mixed>} */
    public function rotate(string $refreshToken, string $deviceLabel = ''): array
    {
        if (!str_starts_with($refreshToken, 'mda1r_')) throw new RuntimeException('invalid_refresh_token');
        $hash = hash('sha256', $refreshToken);
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare("SELECT *, (expires_at<=NOW()) AS is_expired FROM mahda_mobile_tokens WHERE token_hash=? AND token_type='refresh' LIMIT 1 FOR UPDATE");
            $stmt->execute([$hash]);
            $token = $stmt->fetch();
            if (!is_array($token)) throw new RuntimeException('invalid_refresh_token');

            $family = (string)$token['family_key'];
            if (!empty($token['revoked_at'])) {
                $this->revokeFamilyInsideTransaction($family);
                $this->db->commit();
                throw new RuntimeException('refresh_token_reused');
            }
            if ((int)($token['is_expired'] ?? 0) === 1) {
                $this->db->prepare('UPDATE mahda_mobile_tokens SET revoked_at=COALESCE(revoked_at,NOW()) WHERE id=?')->execute([(int)$token['id']]);
                $this->db->commit();
                throw new RuntimeException('refresh_token_expired');
            }

            $row = $this->users->findByIds((int)$token['user_id'], (int)$token['profile_id']);
            if ($row === null) {
                $this->revokeFamilyInsideTransaction($family);
                $this->db->commit();
                throw new RuntimeException('mobile_auth_required');
            }

            $label = $deviceLabel !== '' ? $deviceLabel : (string)($token['device_label'] ?? '');
            $pair = $this->issuePairInsideTransaction((int)$token['user_id'], (int)$token['profile_id'], $family, $label);
            $newRefreshHash = hash('sha256', (string)$pair['refreshToken']);
            $this->db->prepare('UPDATE mahda_mobile_tokens SET revoked_at=NOW(),replaced_by_hash=?,last_used_at=NOW() WHERE id=? AND revoked_at IS NULL')
                ->execute([$newRefreshHash, (int)$token['id']]);
            $this->db->commit();
            return ['tokens' => $pair, 'user' => $this->users->toPayload($row)];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    public function revokeBearerFamily(?string $header = null): void
    {
        $raw = $this->extractBearer($header);
        if ($raw === null) return;
        $hash = hash('sha256', $raw);
        $stmt = $this->db->prepare("SELECT family_key FROM mahda_mobile_tokens WHERE token_hash=? AND token_type='access' LIMIT 1");
        $stmt->execute([$hash]);
        $family = (string)($stmt->fetchColumn() ?: '');
        if ($family !== '') {
            $this->db->prepare('UPDATE mahda_mobile_tokens SET revoked_at=COALESCE(revoked_at,NOW()) WHERE family_key=?')->execute([$family]);
        }
    }

    public function revokeRefreshToken(string $refreshToken): void
    {
        if ($refreshToken === '') return;
        $hash = hash('sha256', $refreshToken);
        $stmt = $this->db->prepare("SELECT family_key FROM mahda_mobile_tokens WHERE token_hash=? AND token_type='refresh' LIMIT 1");
        $stmt->execute([$hash]);
        $family = (string)($stmt->fetchColumn() ?: '');
        if ($family !== '') {
            $this->db->prepare('UPDATE mahda_mobile_tokens SET revoked_at=COALESCE(revoked_at,NOW()) WHERE family_key=?')->execute([$family]);
        }
    }

    public function cleanupExpired(int $limit = 500): int
    {
        $limit = max(1, min(5000, $limit));
        $stmt = $this->db->prepare("DELETE FROM mahda_mobile_tokens WHERE expires_at<DATE_SUB(NOW(),INTERVAL 7 DAY) LIMIT {$limit}");
        $stmt->execute();
        return $stmt->rowCount();
    }

    /** @return array{accessToken:string,refreshToken:string,tokenType:string,expiresIn:int,refreshExpiresIn:int} */
    private function issuePair(int $userId, int $profileId, string $family, string $deviceLabel): array
    {
        $ownsTransaction = !$this->db->inTransaction();
        if ($ownsTransaction) $this->db->beginTransaction();
        try {
            $pair = $this->issuePairInsideTransaction($userId, $profileId, $family, $deviceLabel);
            if ($ownsTransaction) $this->db->commit();
            return $pair;
        } catch (\Throwable $e) {
            if ($ownsTransaction && $this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    /** @return array{accessToken:string,refreshToken:string,tokenType:string,expiresIn:int,refreshExpiresIn:int} */
    private function issuePairInsideTransaction(int $userId, int $profileId, string $family, string $deviceLabel): array
    {
        $accessTtl = max(300, min(3600, (int)($this->config['access_ttl_seconds'] ?? 900)));
        $refreshTtl = max(86400, min(90 * 86400, (int)($this->config['refresh_ttl_seconds'] ?? 30 * 86400)));
        $maxLabel = max(20, min(190, (int)($this->config['max_device_label_length'] ?? 120)));
        $deviceLabel = trim($deviceLabel);
        if (function_exists('mb_substr')) $deviceLabel = mb_substr($deviceLabel, 0, $maxLabel, 'UTF-8');
        else $deviceLabel = substr($deviceLabel, 0, $maxLabel);
        $deviceLabel = $deviceLabel !== '' ? $deviceLabel : null;

        $access = 'mda1a_' . self::base64url(random_bytes(32));
        $refresh = 'mda1r_' . self::base64url(random_bytes(48));
        $insert = $this->db->prepare('INSERT INTO mahda_mobile_tokens(token_hash,token_type,family_key,user_id,profile_id,device_label,expires_at) VALUES(?,?,?,?,?,?,TIMESTAMPADD(SECOND,?,NOW()))');
        $insert->execute([hash('sha256', $access), 'access', $family, $userId, $profileId, $deviceLabel, $accessTtl]);
        $insert->execute([hash('sha256', $refresh), 'refresh', $family, $userId, $profileId, $deviceLabel, $refreshTtl]);
        return [
            'accessToken' => $access,
            'refreshToken' => $refresh,
            'tokenType' => 'Bearer',
            'expiresIn' => $accessTtl,
            'refreshExpiresIn' => $refreshTtl,
        ];
    }

    private function revokeFamilyInsideTransaction(string $family): void
    {
        $this->db->prepare('UPDATE mahda_mobile_tokens SET revoked_at=COALESCE(revoked_at,NOW()) WHERE family_key=?')->execute([$family]);
    }

    private function extractBearer(?string $header = null): ?string
    {
        $header = $header ?? (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        if (!preg_match('/^Bearer\s+([^\s]+)$/i', trim($header), $m)) return null;
        return (string)$m[1];
    }

    private static function base64url(string $bytes): string
    {
        return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
    }
}
