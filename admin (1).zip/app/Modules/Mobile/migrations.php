<?php
declare(strict_types=1);

function mahda_migrate_mobile_auth_v27(PDO $db): void
{
    if (!mahda_table_exists($db, 'mahda_migrations')) return;
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=27 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) return;

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_mobile_tokens (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        token_hash CHAR(64) NOT NULL,
        token_type VARCHAR(16) NOT NULL,
        family_key CHAR(32) NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        profile_id BIGINT UNSIGNED NOT NULL,
        device_label VARCHAR(120) NULL,
        expires_at DATETIME NOT NULL,
        revoked_at DATETIME NULL,
        replaced_by_hash CHAR(64) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_used_at DATETIME NULL,
        UNIQUE KEY ux_mobile_token_hash(token_hash),
        KEY ix_mobile_token_family(family_key,revoked_at),
        KEY ix_mobile_token_user(user_id,profile_id,token_type,revoked_at,expires_at),
        KEY ix_mobile_token_expiry(expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(27)')->execute();
}
