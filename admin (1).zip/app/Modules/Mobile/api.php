<?php
declare(strict_types=1);

use Mahda\Modules\Auth\AuthRepository;
use Mahda\Modules\Auth\AuthValidator;
use Mahda\Modules\Mobile\MobileTokenService;

function mahda_mobile_module_dispatch(PDO $db, string $action): bool
{
    $actions = ['mobile_auth_login','mobile_auth_register','mobile_auth_refresh','mobile_auth_logout','mobile_me'];
    if (!in_array($action, $actions, true)) return false;

    $allowInsecure = in_array(strtolower((string)(getenv('MAHDA_ALLOW_INSECURE_MOBILE_AUTH') ?: '0')), ['1','true','yes','on'], true);
    if (!$allowInsecure && !mahda_request_is_https()) {
        mahda_json(['error'=>'https_required'], 400);
    }

    $repo = new AuthRepository($db);
    $tokens = new MobileTokenService($db, $repo);
    $validator = new AuthValidator();

    try {
        if ($action === 'mobile_auth_login' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            mahda_enforce_rate_limit($db, 'mobile_auth_login', 12, 300);
            $data = mahda_request_data();
            $email = $validator->email($data['email'] ?? '');
            $password = (string)($data['password'] ?? '');
            if ($password === '') throw new RuntimeException('invalid_credentials');
            $row = $repo->findByEmail($email);
            if ($row === null || !password_verify($password, (string)($row['password_hash'] ?? ''))) {
                throw new RuntimeException('invalid_credentials');
            }
            $user = $repo->toPayload($row);
            $pair = $tokens->issueForUser($row, (string)($data['deviceName'] ?? ''));
            mahda_json(['user'=>$user,'tokens'=>$pair]);
        }

        if ($action === 'mobile_auth_register' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            mahda_enforce_rate_limit($db, 'mobile_auth_register', 6, 600);
            $data = mahda_request_data();
            $email = $validator->email($data['email'] ?? '');
            $displayName = trim((string)($data['displayName'] ?? ($data['name'] ?? '')));
            $password = $validator->password($data['password'] ?? '');
            $role = $validator->role($data['profileRole'] ?? ($data['role'] ?? 'other'));
            $kind = $role === 'heiat' ? 'heiat' : 'personal';
            $profileName = trim((string)($role === 'heiat' ? ($data['organizationName'] ?? '') : $displayName));
            if ($displayName === '' || $profileName === '') throw new RuntimeException('invalid_registration');
            $row = $repo->createRegistration($email, $displayName, $password, $kind, $profileName, $role);
            $pair = $tokens->issueForUser($row, (string)($data['deviceName'] ?? ''));
            mahda_json(['user'=>$repo->toPayload($row),'tokens'=>$pair], 201);
        }

        if ($action === 'mobile_auth_refresh' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            mahda_enforce_rate_limit($db, 'mobile_auth_refresh', 30, 300);
            $data = mahda_request_data();
            $refresh = trim((string)($data['refreshToken'] ?? ''));
            if ($refresh === '') throw new RuntimeException('invalid_refresh_token');
            mahda_json($tokens->rotate($refresh, (string)($data['deviceName'] ?? '')));
        }

        if ($action === 'mobile_auth_logout' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            $data = mahda_request_data();
            $tokens->revokeBearerFamily();
            if (!empty($data['refreshToken'])) $tokens->revokeRefreshToken((string)$data['refreshToken']);
            mahda_json(['ok'=>true]);
        }

        if ($action === 'mobile_me' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            $user = $tokens->authenticateBearer();
            unset($user['_token_family']);
            mahda_json(['user'=>$user]);
        }

        mahda_json(['error'=>'method_not_allowed'], 405);
    } catch (RuntimeException $e) {
        $status = match ($e->getMessage()) {
            'invalid_credentials','mobile_auth_required','invalid_refresh_token','refresh_token_expired','refresh_token_reused' => 401,
            'email_exists' => 409,
            'invalid_email','invalid_password','invalid_role','invalid_registration' => 422,
            default => 500,
        };
        mahda_json(['error'=>$e->getMessage()], $status);
    }

    return true;
}
