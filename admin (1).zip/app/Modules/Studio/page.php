<?php
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
?><!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#f5faf1">
<title>مدیریت محتواهای من | مهدا</title>
<link rel="icon" href="/favicon.svg">
<link rel="stylesheet" href="/assets/mahda-shell-v3.css?v=20260918-studio-mobile-v2">
<style>
@font-face{font-family:Vazirmatn;src:url('/assets/vazirmatn-arabic-wght-normal-Cafbb7Zc.woff2') format('woff2');font-weight:100 900;font-display:swap}
:root{--green:#14915b;--green2:#0f7448;--ink:#20334a;--muted:#748277;--line:#e0e8dc;--paper:#fff;--danger:#b5483d;--amber:#9a741d}
*{box-sizing:border-box}.studio-main{padding:11px 11px 108px!important;background:linear-gradient(180deg,#fbfdf9,#f6faf3)}
.studio-head-action{width:42px;height:42px;border-radius:14px;border:1px solid #dce7d8;background:#eef8eb;color:#168452;display:grid;place-items:center}.studio-head-action svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.studio-hero{position:relative;overflow:hidden;border:1px solid #dce9d8;border-radius:24px;background:linear-gradient(135deg,#f4fbed 0%,#fff 62%);padding:17px 16px;box-shadow:0 10px 28px #3b6f4510}.studio-hero:before,.studio-hero:after{content:"";position:absolute;border-radius:999px;background:#dff2d7;opacity:.75}.studio-hero:before{width:105px;height:105px;left:-38px;top:-45px}.studio-hero:after{width:68px;height:68px;left:32px;bottom:-42px;background:#fff0c7}.studio-hero-row{display:flex;align-items:center;gap:13px;position:relative;z-index:1}.studio-orb{width:58px;height:58px;border-radius:19px;background:linear-gradient(145deg,#27bb73,#14915b);color:#fff;display:grid;place-items:center;box-shadow:0 9px 22px #15915b33;flex:0 0 auto}.studio-orb svg{width:29px;height:29px;fill:none;stroke:currentColor;stroke-width:1.7}.studio-hero h1{font-size:18px;margin:0;color:#184632}.studio-hero p{font-size:10.5px;line-height:1.9;color:#718076;margin:5px 0 0}.quick-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px;position:relative;z-index:1}.quick-link{height:39px;border-radius:13px;border:1px solid #dbe7d6;background:#fff;color:#37604a;display:flex;align-items:center;justify-content:center;gap:7px;font-size:10.5px;font-weight:800}.quick-link.primary{background:#15915b;border-color:#15915b;color:#fff}.quick-link svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:1.9}
.stats-strip{display:grid;grid-template-columns:repeat(5,minmax(74px,1fr));gap:7px;overflow-x:auto;padding:10px 0 2px;scrollbar-width:none}.stats-strip::-webkit-scrollbar{display:none}.stat-card{min-width:74px;border:1px solid #e0e8dc;border-radius:16px;background:#fff;padding:10px 9px;text-align:center;color:#56675d;box-shadow:0 4px 14px #334f3510;cursor:pointer}.stat-card.active{border-color:#9fd0af;background:#eff9ef;color:#137448}.stat-card strong{display:block;font-size:18px;color:#1f4b38}.stat-card span{font-size:8.8px;white-space:nowrap}.stat-card.active strong{color:#117748}
.tools-card{margin-top:10px;border:1px solid #e0e8dc;border-radius:18px;background:#fff;padding:10px}.search-row{display:grid;grid-template-columns:1fr 104px;gap:7px}.studio-input,.studio-select{height:42px;border:1px solid #dce5d8;border-radius:13px;background:#fbfdf9;padding:0 11px;color:#294337;outline:none;font:inherit;font-size:10.5px}.studio-input:focus,.studio-select:focus{border-color:#8ec49d;box-shadow:0 0 0 3px #17915a10}.studio-select{width:100%}.search-box{position:relative}.search-box svg{position:absolute;right:11px;top:12px;width:18px;height:18px;fill:none;stroke:#6f8175;stroke-width:1.8}.search-box .studio-input{width:100%;padding-right:36px}
.status-tabs{display:flex;gap:6px;overflow-x:auto;padding:9px 1px 1px;scrollbar-width:none}.status-tabs::-webkit-scrollbar{display:none}.status-tab{height:31px;border-radius:999px;border:1px solid #e0e8dc;background:#f9fbf7;color:#627268;padding:0 10px;font-size:9px;font-weight:800;white-space:nowrap}.status-tab.active{background:#214c38;border-color:#214c38;color:#fff}
.content-list{display:grid;gap:9px;margin-top:10px}.content-card{border:1px solid #e0e8dc;background:#fff;border-radius:19px;padding:9px;display:grid;grid-template-columns:116px minmax(0,1fr);gap:10px;box-shadow:0 7px 20px #3551370c}.content-cover{width:116px;aspect-ratio:4/3;border-radius:14px;overflow:hidden;background:linear-gradient(145deg,#eaf4e5,#dcebd6);display:grid;place-items:center;color:#178b55;border:0;padding:0;cursor:pointer}.content-cover img{width:100%;height:100%;object-fit:cover;display:block}.content-cover svg{width:31px;height:31px;fill:none;stroke:currentColor;stroke-width:1.7}.content-body{min-width:0}.content-title{display:flex;align-items:flex-start;justify-content:space-between;gap:6px}.content-title h3{font-size:12.5px;line-height:1.65;color:#253f34;margin:0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.status-pill{border-radius:999px;padding:4px 7px;font-size:7.8px;font-weight:900;white-space:nowrap;flex:0 0 auto}.status-pill.pending{background:#fff4cf;color:#87651b}.status-pill.approved{background:#e7f7e7;color:#27713d}.status-pill.revision{background:#fff1c9;color:#8a6718}.status-pill.rejected{background:#ffeded;color:#9a4137}.status-pill.not_requested{background:#edf1ef;color:#68766d}.meta-line{display:flex;flex-wrap:wrap;gap:5px;margin-top:6px}.mini-tag{border-radius:999px;background:#f0f5ed;color:#65746a;padding:3px 6px;font-size:7.8px}.review-note{margin-top:6px;border-radius:10px;background:#fff8e5;border:1px solid #f0dfad;color:#735b20;padding:6px 7px;font-size:8.4px;line-height:1.7}.card-actions{grid-column:1/-1;display:grid;grid-template-columns:1fr 1fr 44px;gap:6px;margin-top:1px}.card-btn{height:34px;border-radius:11px;border:1px solid #dce7d8;background:#f8fbf6;color:#456051;font-size:9px;font-weight:850;display:flex;align-items:center;justify-content:center;gap:5px;cursor:pointer}.card-btn.edit{background:#15915b;border-color:#15915b;color:#fff}.card-btn.delete{color:#a33f37;background:#fff4f2;border-color:#f1d2cd}.card-btn svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:1.9}
.state-box{border:1px solid #e0e8dc;background:#fff;border-radius:20px;padding:28px 16px;text-align:center;color:#75827a;font-size:10.5px;line-height:1.9}.state-box strong{display:block;color:#365142;font-size:12.5px;margin-bottom:4px}.studio-spinner{width:28px;height:28px;border-radius:50%;border:3px solid #dcebd8;border-top-color:#15915b;animation:spin .8s linear infinite;margin:0 auto 8px}@keyframes spin{to{transform:rotate(360deg)}}
.studio-toast{position:absolute;bottom:101px;left:50%;transform:translate(-50%,18px);opacity:0;pointer-events:none;background:#173d31;color:#fff;border-radius:13px;padding:9px 12px;font-size:9.5px;z-index:140;transition:.2s;max-width:86%;text-align:center}.studio-toast.show{opacity:1;transform:translate(-50%,0)}.studio-toast.bad{background:#923f36}
@media(max-width:600px){.content-card{grid-template-columns:108px minmax(0,1fr)}.content-cover{width:108px}.studio-hero{padding:15px 14px}.search-row{grid-template-columns:1fr 96px}}
</style>
</head>
<body>
<div class="page">
  <div class="scene-left" aria-hidden="true"><div class="left-logo-wrap"><img class="left-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt=""><div class="left-slogan">نسل فردا،<br>با مهدا روشن‌تر</div></div><img class="left-child" src="/assets/child-garden-DajGLj7z.webp" alt=""></div>
  <div class="scene-right" aria-hidden="true"><img class="right-simorgh" src="/assets/simorgh-BobLCgG-.webp" alt=""><img class="right-garden" src="/assets/persian-garden-CJRlRJZ1.webp" alt=""></div>
  <section class="app-shell">
    <header class="app-header">
      <div class="head-left"><a class="studio-head-action" href="/showcase/me" aria-label="ویترین من"><svg viewBox="0 0 24 24"><path d="M6 19V5h12v14M9 9h6M9 13h6"/></svg></a></div>
      <div class="head-center"><strong>مدیریت محتوا</strong><small>استودیوی مهدا</small></div>
      <div class="head-right"><a class="studio-head-action" href="/content/new" aria-label="ثبت محتوای جدید"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></a></div>
    </header>
    <main class="app-main studio-main">
      <section class="studio-hero">
        <div class="studio-hero-row"><span class="studio-orb"><svg viewBox="0 0 24 24"><path d="M4 5h16v14H4z"/><path d="M8 9h8M8 13h5"/></svg></span><div><h1>محتواهای من</h1><p>وضعیت بررسی، بازخورد و مدیریت همه محتواها را در یک صفحه ببین.</p></div></div>
        <div class="quick-row"><a class="quick-link primary" href="/content/new"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>ثبت محتوای جدید</a><a class="quick-link" href="/showcase/me"><svg viewBox="0 0 24 24"><path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/></svg>ویترین من</a></div>
      </section>
      <div class="stats-strip" id="stats"></div>
      <section class="tools-card">
        <div class="search-row"><div class="search-box"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input id="q" class="studio-input" placeholder="جستجو در محتواهای من…"></div><select id="sort" class="studio-select"><option value="newest">جدیدترین</option><option value="oldest">قدیمی‌ترین</option><option value="title">عنوان</option></select></div>
        <div class="status-tabs" id="tabs"></div>
      </section>
      <section id="list" class="content-list"><div class="state-box"><div class="studio-spinner"></div><strong>در حال دریافت محتواها…</strong></div></section>
    </main>
    <nav class="bottom-nav" aria-label="منوی اصلی">
      <a class="nav-item" href="/"><svg viewBox="0 0 24 24"><path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/></svg><span>خانه</span></a>
      <a class="nav-item" href="/search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg><span>جستجو</span></a>
      <a class="nav-item nav-showcase" href="/showcase"><span class="showcase-bubble"><svg viewBox="0 0 24 24"><path d="m12 2.8 2.75 5.57 6.15.9-4.45 4.34 1.05 6.12L12 16.84l-5.5 2.89 1.05-6.12L3.1 9.27l6.15-.9z"/></svg></span><span>ویترین</span></a>
      <a class="nav-item" href="/shelf"><svg viewBox="0 0 24 24"><path d="M4 5h6l2 2h8v12H4z"/><path d="M4 9h16"/></svg><span>قفسه</span></a>
      <a class="nav-item active" href="/profile"><svg viewBox="0 0 24 24"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg><span>حساب</span></a>
    </nav>
    <div id="toast" class="studio-toast"></div>
  </section>
</div>
<script>
(()=>{'use strict';
const API='/mahda-api/index.php';let csrf='',currentStatus='all',items=[];
const $=s=>document.querySelector(s),esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const statusLabels={all:'همه',pending:'در انتظار',approved:'تأییدشده',revision:'نیازمند اصلاح',rejected:'ردشده',not_requested:'ارسال‌نشده'};
const ico=(name)=>({edit:'<path d="M4 20h4l10-10-4-4L4 16z"/><path d="m13 7 4 4"/>',eye:'<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/>',trash:'<path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13"/>',image:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="9" r="1.5"/><path d="m21 15-5-5L5 21"/>'}[name]||'');
function svg(name){return '<svg viewBox="0 0 24 24">'+ico(name)+'</svg>'}
function toast(t,bad=false){const el=$('#toast');el.textContent=t;el.className='studio-toast show'+(bad?' bad':'');clearTimeout(el._t);el._t=setTimeout(()=>el.className='studio-toast',3000)}
async function json(action,opts={},params={}){const u=new URL(API,location.origin);u.searchParams.set('action',action);Object.entries(params).forEach(([k,v])=>v!==''&&v!==undefined&&u.searchParams.set(k,String(v)));const r=await fetch(u,{credentials:'same-origin',cache:'no-store',...opts,headers:{Accept:'application/json',...(opts.headers||{})}});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||`HTTP_${r.status}`);return d}
async function session(){const d=await json('session');csrf=d.csrf||'';if(d.user?.guest){location.replace('/profile?returnTo='+encodeURIComponent('/studio/'));throw Error('auth_required')}if(!d.user?.profile_complete){location.replace('/profile?returnTo='+encodeURIComponent('/studio/'));throw Error('profile_incomplete')}return d}
async function post(action,body){if(!csrf)await session();const r=await fetch(API+'?action='+encodeURIComponent(action),{method:'POST',credentials:'same-origin',headers:{Accept:'application/json','Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||`HTTP_${r.status}`);return d}
function fmtDate(v){if(!v)return'';const d=new Date(String(v).replace(' ','T'));return Number.isNaN(d.getTime())?'':d.toLocaleDateString('fa-IR',{month:'short',day:'numeric'})}
function renderStats(stats={}){const order=['all','pending','revision','approved','rejected'];$('#stats').innerHTML=order.map(k=>`<button type="button" class="stat-card ${currentStatus===k?'active':''}" data-stat="${k}"><strong>${Number(stats[k]||0).toLocaleString('fa-IR')}</strong><span>${statusLabels[k]}</span></button>`).join('');document.querySelectorAll('[data-stat]').forEach(b=>b.onclick=()=>{currentStatus=b.dataset.stat;load()})}
function renderTabs(stats={}){const order=['all','pending','revision','approved','rejected'];$('#tabs').innerHTML=order.map(k=>`<button type="button" class="status-tab ${currentStatus===k?'active':''}" data-tab="${k}">${statusLabels[k]} · ${Number(stats[k]||0).toLocaleString('fa-IR')}</button>`).join('');document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{currentStatus=b.dataset.tab;load()})}
function sortedRows(rows){let r=[...rows],s=$('#sort').value;if(s==='oldest')r.reverse();if(s==='title')r.sort((a,b)=>String(a.title).localeCompare(String(b.title),'fa'));return r}
function pill(s){return `<span class="status-pill ${esc(s)}">${esc(statusLabels[s]||s)}</span>`}
function renderList(){const rows=sortedRows(items),box=$('#list');if(!rows.length){box.innerHTML='<div class="state-box"><strong>محتوایی در این بخش نیست</strong>از دکمه «ثبت محتوای جدید» شروع کن.</div>';return}box.innerHTML=rows.map(x=>`<article class="content-card"><button class="content-cover" data-view="${x.id}" aria-label="مشاهده محتوا">${x.image?`<img src="${esc(x.image)}" alt="">`:svg('image')}</button><div class="content-body"><div class="content-title"><h3>${esc(x.title)}</h3>${pill(x.reviewStatus||'pending')}</div><div class="meta-line"><span class="mini-tag">${esc(x.categoryLabel||x.category||'محتوا')}</span>${x.publisher?`<span class="mini-tag">${esc(x.publisher)}</span>`:''}${x.createdAt?`<span class="mini-tag">${esc(fmtDate(x.createdAt))}</span>`:''}</div>${x.reviewNote?`<div class="review-note"><b>${x.lastDecision==='reject'?'دلیل رد':'یادداشت بررسی'}:</b> ${esc(x.reviewNote)}</div>`:''}</div><div class="card-actions"><button class="card-btn edit" data-edit="${x.id}">${svg('edit')}ویرایش مرحله‌ای</button><button class="card-btn" data-view="${x.id}">${svg('eye')}مشاهده</button><button class="card-btn delete" data-delete="${x.id}" aria-label="حذف">${svg('trash')}</button></div></article>`).join('');document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>location.href='/content/item/'+encodeURIComponent(b.dataset.view));document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>location.href='/content/new?edit='+encodeURIComponent(b.dataset.edit));document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>removeContent(Number(b.dataset.delete)))}
async function load(){const box=$('#list');box.innerHTML='<div class="state-box"><div class="studio-spinner"></div><strong>در حال دریافت محتواها…</strong></div>';try{const d=await json('my_contents',{}, {status:currentStatus,q:$('#q').value.trim(),limit:200});items=d.items||[];renderStats(d.stats||{});renderTabs(d.stats||{});renderList()}catch(e){box.innerHTML='<div class="state-box"><strong>دریافت محتواها انجام نشد</strong>'+esc(e.message)+'</div>'}}
async function removeContent(id){const x=items.find(v=>Number(v.id)===id);if(!confirm(`محتوای «${x?.title||''}» حذف شود؟ این کار قابل بازگشت نیست.`))return;try{await post('content_delete',{contentId:id});toast('محتوا حذف شد.');load()}catch(e){toast('حذف انجام نشد.',true)}}
$('#q').addEventListener('input',()=>{clearTimeout($('#q')._t);$('#q')._t=setTimeout(load,350)});$('#sort').onchange=renderList;
(async()=>{const oldEdit=Number(new URLSearchParams(location.search).get('edit')||0);if(oldEdit>0){location.replace('/content/new?edit='+encodeURIComponent(oldEdit));return}try{await session();await load()}catch(e){if(!['auth_required','profile_incomplete'].includes(e.message))$('#list').innerHTML='<div class="state-box"><strong>صفحه آماده نشد</strong>'+esc(e.message)+'</div>'}})();
})();
</script>
</body></html>
