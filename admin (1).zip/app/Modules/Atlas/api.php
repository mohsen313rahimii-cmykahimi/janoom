<?php
declare(strict_types=1);

/** API actions owned by the Atlas module. */
function mahda_atlas_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['atlas_public_summary', 'atlas_public_cities', 'atlas_public_profiles', 'atlas_geo'], true)) {
        return false;
    }

        if ($action === 'atlas_public_summary' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $sql = "SELECT pr.id,pr.name,pr.slug,pr.latitude,pr.longitude,
                COALESCE(x.mentor_count,0) AS mentor_count,COALESCE(x.heiat_count,0) AS heiat_count
                FROM mahda_provinces pr
                LEFT JOIN (
                    SELECT COALESCE(p.province_id,c.province_id) AS province_id,
                        SUM(CASE WHEN p.profile_role='mentor' THEN 1 ELSE 0 END) AS mentor_count,
                        SUM(CASE WHEN p.profile_role='heiat' THEN 1 ELSE 0 END) AS heiat_count
                    FROM mahda_profiles p
                    JOIN mahda_users u ON u.id=p.owner_id AND u.is_active=1
                    LEFT JOIN mahda_cities c ON c.id=p.city_id
                    WHERE p.atlas_visible=1 AND p.profile_role IN ('mentor','heiat') AND p.name<>''
                      AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local'
                    GROUP BY COALESCE(p.province_id,c.province_id)
                ) x ON x.province_id=pr.id
                ORDER BY pr.id";
            $items=[];
            foreach($db->query($sql)->fetchAll() as $row){
                $mentor=(int)$row['mentor_count'];$heiat=(int)$row['heiat_count'];
                $items[]=['id'=>(int)$row['id'],'name'=>(string)$row['name'],'slug'=>(string)$row['slug'],
                    'latitude'=>$row['latitude']!==null?(float)$row['latitude']:null,'longitude'=>$row['longitude']!==null?(float)$row['longitude']:null,
                    'mentorCount'=>$mentor,'heiatCount'=>$heiat,'totalCount'=>$mentor+$heiat];
            }
            mahda_json(['items'=>$items,'total'=>array_sum(array_column($items,'totalCount')),'generatedAt'=>date(DATE_ATOM)]);
        }

        if ($action === 'atlas_public_cities' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $provinceId=max(0,(int)($_GET['provinceId']??($_GET['province_id']??0)));
            if($provinceId<1) mahda_json(['error'=>'invalid_province'],422);
            $check=$db->prepare('SELECT id,name FROM mahda_provinces WHERE id=? LIMIT 1');$check->execute([$provinceId]);$province=$check->fetch();
            if(!$province) mahda_json(['error'=>'province_not_found'],404);
            $sql="SELECT c.id,c.name,c.slug,c.latitude,c.longitude,
                (SELECT COUNT(*) FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id
                    WHERE u.is_active=1 AND p.atlas_visible=1 AND p.profile_role='mentor' AND p.name<>''
                      AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local'
                      AND (p.city_id=c.id OR (p.city_id IS NULL AND p.city=c.name))) AS mentor_count,
                (SELECT COUNT(*) FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id
                    WHERE u.is_active=1 AND p.atlas_visible=1 AND p.profile_role='heiat' AND p.name<>''
                      AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local'
                      AND (p.city_id=c.id OR (p.city_id IS NULL AND p.city=c.name))) AS heiat_count
                FROM mahda_cities c WHERE c.province_id=? ORDER BY c.name";
            $st=$db->prepare($sql);$st->execute([$provinceId]);$items=[];
            foreach($st->fetchAll() as $row){$mentor=(int)$row['mentor_count'];$heiat=(int)$row['heiat_count'];$items[]=['id'=>(int)$row['id'],'name'=>(string)$row['name'],'slug'=>(string)$row['slug'],'latitude'=>$row['latitude']!==null?(float)$row['latitude']:null,'longitude'=>$row['longitude']!==null?(float)$row['longitude']:null,'mentorCount'=>$mentor,'heiatCount'=>$heiat,'totalCount'=>$mentor+$heiat];}
            mahda_json(['province'=>['id'=>(int)$province['id'],'name'=>(string)$province['name']],'items'=>$items,'cityCount'=>count($items)]);
        }

        if ($action === 'atlas_public_profiles' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $cityId=max(0,(int)($_GET['cityId']??($_GET['city_id']??0)));$type=mahda_string($_GET['type']??'all',20);
            if($cityId<1) mahda_json(['error'=>'invalid_city'],422);
            if(!in_array($type,['all','mentor','heiat'],true))$type='all';
            $citySt=$db->prepare('SELECT c.id,c.name,c.province_id,p.name AS province_name FROM mahda_cities c JOIN mahda_provinces p ON p.id=c.province_id WHERE c.id=? LIMIT 1');$citySt->execute([$cityId]);$city=$citySt->fetch();
            if(!$city) mahda_json(['error'=>'city_not_found'],404);
            $where=["(p.city_id=? OR (p.city_id IS NULL AND p.city=?))","p.atlas_visible=1","p.profile_role IN ('mentor','heiat')","u.is_active=1","p.name<>''","u.email NOT LIKE 'guest-%@mahda.local'","u.email NOT LIKE 'test-phone-%@mahda.local'"];$params=[$cityId,(string)$city['name']];
            if($type!=='all'){$where[]='p.profile_role=?';$params[]=$type;}
            $attributedContentSql=mahda_attributed_content_sql('c');
            $sql="SELECT p.id,p.slug,p.name,p.bio,p.kind,p.profile_role,p.is_verified,p.city,p.profile_data_json,
                (SELECT COUNT(*) FROM mahda_contents c WHERE c.profile_id=p.id AND {$attributedContentSql} AND c.archived_at IS NULL AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved'))) AS content_count,
                (SELECT COUNT(*) FROM mahda_follows f WHERE f.profile_id=p.id) AS follower_count
                FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE ".implode(' AND ',$where)." ORDER BY p.is_verified DESC,content_count DESC,p.name LIMIT 120";
            $st=$db->prepare($sql);$st->execute($params);$rows=$st->fetchAll();$items=[];$badgeMap=[];
            $profileIds=array_values(array_filter(array_map(static fn($r)=>(int)($r['id']??0),$rows)));
            if($profileIds && mahda_table_exists($db,'mahda_profile_badges') && mahda_table_exists($db,'mahda_badges')){
                $ph=implode(',',array_fill(0,count($profileIds),'?'));
                $bst=$db->prepare("SELECT pb.profile_id,b.id,b.title,b.slug,b.icon,b.color FROM mahda_profile_badges pb JOIN mahda_badges b ON b.id=pb.badge_id WHERE pb.profile_id IN ({$ph}) AND b.is_active=1 ORDER BY b.sort_order,b.id");
                $bst->execute($profileIds);
                foreach($bst->fetchAll() as $br){$badgeMap[(int)$br['profile_id']][]=['id'=>(int)$br['id'],'title'=>(string)$br['title'],'slug'=>(string)$br['slug'],'icon'=>(string)($br['icon']??''),'color'=>(string)($br['color']??'#2f9a48')];}
            }
            foreach($rows as $row){$pid=(int)$row['id'];$items[]=['id'=>$pid,'slug'=>(string)$row['slug'],'name'=>(string)$row['name'],'bio'=>(string)($row['bio']??''),'role'=>(string)$row['profile_role'],'verified'=>(bool)$row['is_verified'],'city'=>(string)($row['city']??''),'contentCount'=>(int)$row['content_count'],'followerCount'=>(int)$row['follower_count'],'avatarUrl'=>mahda_profile_avatar_url_db($db,$pid,(string)($row['profile_data_json']??''),(string)($row['kind']??'personal')),'badges'=>$badgeMap[$pid]??[]];}
            mahda_json(['city'=>['id'=>(int)$city['id'],'name'=>(string)$city['name'],'provinceId'=>(int)$city['province_id'],'provinceName'=>(string)$city['province_name']],'items'=>$items]);
        }

        if ($action === 'atlas_geo' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $private=mahda_private_path();if(!is_dir($private))@mkdir($private,0770,true);
            $cache=$private.'/iran-provinces.min.geojson';$maxAge=30*24*3600;$raw='';
            if(is_file($cache) && filesize($cache)>10000 && (time()-filemtime($cache))<$maxAge){$raw=(string)file_get_contents($cache);}
            if($raw===''){
                $urls=[
                    'https://raw.githubusercontent.com/hosseinhabibi2004/iran-geojson/refs/heads/master/data/provinces/provinces.min.geojson',
                    'https://cdn.jsdelivr.net/gh/hosseinhabibi2004/iran-geojson@master/data/provinces/provinces.min.geojson'
                ];
                foreach($urls as $url){
                    $candidate='';
                    if(function_exists('curl_init')){$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_TIMEOUT=>12,CURLOPT_USERAGENT=>'MahdaAtlas/1.0']);$response=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);if(is_string($response)&&$code>=200&&$code<300)$candidate=$response;}
                    if($candidate==='' && filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN)){$context=stream_context_create(['http'=>['timeout'=>12,'user_agent'=>'MahdaAtlas/1.0']]);$response=@file_get_contents($url,false,$context);if(is_string($response))$candidate=$response;}
                    $decoded=json_decode($candidate,true);
                    if(is_array($decoded)&&($decoded['type']??'')==='FeatureCollection'&&count($decoded['features']??[])>=31){$raw=$candidate;@file_put_contents($cache,$raw,LOCK_EX);break;}
                }
            }
            if($raw==='') mahda_json(['error'=>'atlas_geometry_unavailable'],503);
            header('Content-Type: application/geo+json; charset=utf-8');header('Cache-Control: public, max-age=86400, stale-while-revalidate=604800');echo $raw;exit;
        }

    mahda_json(['error' => 'method_not_allowed'], 405);
}
