<?php
declare(strict_types=1);
namespace Mahda\Modules\Atlas;
use Mahda\Core\Router;
use Mahda\Core\View;
return static function (Router $router, View $view): void {
    $controller = new AtlasController($view);
    $router->get('/atlas', [$controller, 'index']);
};
