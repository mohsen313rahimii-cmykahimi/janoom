<?php
declare(strict_types=1);
namespace Mahda\Modules\Atlas;
use Mahda\Core\Request;
use Mahda\Core\View;
final class AtlasController
{
    public function __construct(private View $view) {}
    public function index(Request $request): string { return $this->view->render('pages/atlas/index'); }
}
