<?php
// Read payloads preserved from this release's PHP API; no API dispatch or HTTP loopback.
if (!defined('MAHDA_SHOWCASE_PAGE')) { http_response_code(404); exit; }
function sc_session(PDO $db): array {
        $user = mahda_current_user($db, true);
        if (!$user['guest'] && (int)$user['profile_id'] > 0) {
            $profileStmt = $db->prepare('SELECT id,kind,name,city,profile_data_json FROM mahda_profiles WHERE id=? LIMIT 1');
            $profileStmt->execute([(int)$user['profile_id']]);
            $sessionProfile = $profileStmt->fetch();
            $user['profile_kind'] = (string)($sessionProfile['kind'] ?? 'personal');
            $user['profile_name'] = (string)($sessionProfile['name'] ?? '');
            $user['city'] = (string)($sessionProfile['city'] ?? '');
            $user['profile_data'] = is_array(json_decode((string)($sessionProfile['profile_data_json'] ?? ''), true)) ? json_decode((string)($sessionProfile['profile_data_json'] ?? ''), true) : [];
            $user['avatar_url'] = mahda_profile_avatar_url_db($db, (int)($sessionProfile['id'] ?? 0), (string)($sessionProfile['profile_data_json'] ?? ''), (string)($sessionProfile['kind'] ?? 'personal'));
            $user['profile_complete'] = mahda_profile_complete($user['profile_data'], $user['profile_kind'], (string)$user['display_name'], (string)$user['profile_name'], (string)$user['city']);
            $user['profile_data'] = mahda_profile_public_data($user['profile_data']);
        } else {
            $user['profile_kind'] = null;
            $user['profile_name'] = '';
            $user['city'] = '';
            $user['profile_data'] = [];
            $user['avatar_url'] = '';
            $user['profile_complete'] = false;
        }
        return $user;
}
function sc_profile(PDO $db, int $profileId): array {
    $stmt = $db->prepare("SELECT p.id,p.owner_id,p.slug,p.name,p.kind,p.bio,p.city,p.profile_role,p.is_verified,p.profile_data_json,u.display_name FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE p.id=? AND p.name<>'' AND u.is_active=1 AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local' LIMIT 1");
    $stmt->execute([$profileId]);
    $profile=$stmt->fetch();
    if (!$profile) { throw new RuntimeException('profile_not_found'); }

        $profile['id'] = (int)$profile['id'];
        $ownerId = (int)$profile['owner_id'];
        unset($profile['owner_id']);
        $profile['verified'] = (bool)($profile['is_verified'] ?? false);
        $profile['role'] = (string)($profile['profile_role'] ?? (($profile['kind'] ?? '') === 'heiat' ? 'heiat' : 'mentor'));
        $publicData = json_decode((string)($profile['profile_data_json'] ?? ''), true); if (!is_array($publicData)) $publicData = [];
        $profile['specialties'] = [];
        if (is_array($publicData['specialties'] ?? null)) { foreach (array_slice($publicData['specialties'],0,12) as $value) { $value=mahda_string($value,80); if($value!=='')$profile['specialties'][]=$value; } }
        $profile['ages'] = is_array($publicData['ages'] ?? null) ? array_values(array_intersect(['4-6','7-10'], $publicData['ages'])) : [];
        $profile['avatarUrl'] = mahda_profile_avatar_url_db($db, (int)$profile['id'], (string)($profile['profile_data_json'] ?? ''), (string)($profile['kind'] ?? 'personal'));
        $profile['badges'] = mahda_profile_badges_public($db, (int)$profile['id']);
        unset($profile['profile_data_json'],$profile['profile_role'],$profile['is_verified']);
        $followers = $db->prepare('SELECT COUNT(*) FROM mahda_follows WHERE profile_id=?'); $followers->execute([$profile['id']]);
        $following = $db->prepare('SELECT COUNT(*) FROM mahda_follows WHERE user_id=?'); $following->execute([$ownerId]);
        $profileAttribution=mahda_attributed_content_sql('c');
        $contentCount = $db->prepare("SELECT COUNT(*) FROM mahda_contents c WHERE c.profile_id=? AND {$profileAttribution} AND (c.archived_at IS NULL AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved')))"); $contentCount->execute([$profile['id']]);
        $viewer = mahda_current_user($db, true);
        $viewerId = empty($viewer['guest']) ? (int)$viewer['id'] : 0;
        return ['profile'=>$profile,'followers'=>(int)$followers->fetchColumn(),'following'=>(int)$following->fetchColumn(),'contentCount'=>(int)$contentCount->fetchColumn(),'isOwn'=>$viewerId > 0 && $viewerId === $ownerId];
}
function sc_feed(PDO $db, int $limit = 30, int $offset = 0): array {
        $sql = "SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color
            FROM mahda_contents c
            JOIN mahda_profiles p ON p.id=c.profile_id
            JOIN mahda_users owner ON owner.id=c.author_id
            JOIN mahda_categories cat ON cat.id=c.category_id
            WHERE p.name<>'' AND owner.is_active=1
              AND owner.email NOT LIKE 'guest-%@mahda.local'
              AND owner.email NOT LIKE 'test-phone-%@mahda.local'
              AND c.archived_at IS NULL
              AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved'))
            ORDER BY c.created_at DESC,c.id DESC LIMIT ? OFFSET ?";
        $stmt=$db->prepare($sql);$stmt->bindValue(1,$limit,PDO::PARAM_INT);$stmt->bindValue(2,$offset,PDO::PARAM_INT);$stmt->execute();
        $items=mahda_items($db,$stmt->fetchAll());
        return ['items'=>$items,'limit'=>$limit,'offset'=>$offset,'hasMore'=>count($items)===$limit];
}