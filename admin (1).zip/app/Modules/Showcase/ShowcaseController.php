<?php
declare(strict_types=1);
namespace Mahda\Modules\Showcase;
use Mahda\Core\Request;
final class ShowcaseController
{
    public function index(Request $request): string
    {
        ob_start();
        try {
            require __DIR__ . '/entry.php';
            return (string)ob_get_clean();
        } catch (\Throwable $error) {
            ob_end_clean();
            throw $error;
        }
    }
}
