<?php
declare(strict_types=1);
namespace Mahda\Modules\Showcase;
use Mahda\Core\Router;
use Mahda\Core\View;
return static function (Router $router, View $view): void {
    $controller = new ShowcaseController();
    $router->get('/showcase', [$controller, 'index']);
    $router->get('/showcase/me', [$controller, 'index']);
    $router->get('/showcase/profile/{id}', [$controller, 'index']);
};
