<?php
declare(strict_types=1);

/** API actions owned by the Showcase module. */
function mahda_showcase_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['showcase_feed'], true)) {
        return false;
    }

        if ($action === 'showcase_feed' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $limit = max(1, min(80, (int)($_GET['limit'] ?? 30)));
            $offset = max(0, min(10000, (int)($_GET['offset'] ?? 0)));
            $sql = "SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color
                FROM mahda_contents c
                JOIN mahda_profiles p ON p.id=c.profile_id
                JOIN mahda_users owner ON owner.id=c.author_id
                JOIN mahda_categories cat ON cat.id=c.category_id
                WHERE p.name<>'' AND owner.is_active=1
                  AND owner.email NOT LIKE 'guest-%@mahda.local'
                  AND owner.email NOT LIKE 'test-phone-%@mahda.local'
                  AND c.archived_at IS NULL
                  AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved'))
                ORDER BY c.created_at DESC,c.id DESC LIMIT ? OFFSET ?";
            $stmt=$db->prepare($sql);$stmt->bindValue(1,$limit,PDO::PARAM_INT);$stmt->bindValue(2,$offset,PDO::PARAM_INT);$stmt->execute();
            $items=mahda_items($db,$stmt->fetchAll());
            mahda_json(['items'=>$items,'limit'=>$limit,'offset'=>$offset,'hasMore'=>count($items)===$limit]);
        }

    mahda_json(['error' => 'method_not_allowed'], 405);
}
