<?php
declare(strict_types=1);
ini_set('display_errors', '0');
define('MAHDA_SHOWCASE_PAGE', true);
require __DIR__ . '/views.php';

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
header('X-Mahda-Showcase: php-v1');
$path = rtrim((string)parse_url($_SERVER['REQUEST_URI'] ?? '/showcase', PHP_URL_PATH), '/');
$route = sc_route($path);
$vm = ['mode'=>$route['mode'], 'title'=>'ویترین', 'user'=>null, 'csrf'=>'', 'items'=>[],
    'profile'=>null, 'following'=>false, 'active'=>[], 'unread'=>0, 'error'=>null];

try {
    if ($route['mode'] === 'missing') { throw new RuntimeException('profile_not_found'); }
    require_once dirname(__DIR__, 3) . '/mahda-api/bootstrap.php';
    require_once __DIR__ . '/read-contracts.php';
    require_once __DIR__ . '/repository.php';
    $db = mahda_db();
    // Uses the already installed schema. Rendering never runs installers or migrations.
    $vm['user'] = sc_session($db);
    $vm['csrf'] = mahda_csrf();
    if ($route['mode'] === 'me' && (!empty($vm['user']['guest']) || empty($vm['user']['profile_complete']))) {
        header('Location: /profile?returnTo=' . rawurlencode('/showcase/me'), true, 302);
        exit;
    }
    if ($route['mode'] === 'feed') {
        $vm['items'] = sc_feed($db)['items'];
        $vm['active'] = sc_active_interactions($db, $vm['items'], (int)($vm['user']['id'] ?? 0));
    } else {
        $id = $route['mode'] === 'me' ? (int)$vm['user']['profile_id'] : $route['id'];
        $vm['profile'] = sc_profile($db, $id);
        $vm['title'] = $vm['profile']['profile']['name'];
        $vm['items'] = sc_profile_items($db, $id);
        if (!$vm['profile']['isOwn'] && empty($vm['user']['guest'])) {
            $st=$db->prepare('SELECT 1 FROM mahda_follows WHERE user_id=? AND profile_id=?');
            $st->execute([(int)$vm['user']['id'], $id]);
            $vm['following']=(bool)$st->fetchColumn();
        }
    }
    if (empty($vm['user']['guest'])) {
        // A notification count failure must not take the whole showcase down.
        try {
            $st=$db->prepare('SELECT COUNT(*) FROM mahda_notifications WHERE recipient_user_id=? AND is_read=0');
            $st->execute([(int)$vm['user']['id']]);
            $vm['unread']=(int)$st->fetchColumn();
        } catch (Throwable $ignored) { $vm['unread']=0; }
    }
} catch (Throwable $e) {
    $missing=$e->getMessage()==='profile_not_found';
    http_response_code($missing ? 404 : 503);
    $vm['items']=[];
    $vm['profile']=null;
    $vm['error']=$missing ? 'این ویترین در دسترس نیست.' : 'دریافت ویترین انجام نشد. لطفاً دوباره تلاش کنید.';
    // Never expose SQL, credentials or configuration paths to the visitor.
    if (!$missing) error_log('Mahda showcase PHP: ' . get_class($e) . ' code=' . $e->getCode());
}
if (session_status() === PHP_SESSION_ACTIVE) { session_write_close(); }
ob_start();
try {
    require dirname(__DIR__, 3) . '/templates/pages/showcase/index.php';
    ob_end_flush();
} catch (Throwable $e) {
    ob_end_clean();
    http_response_code(500);
    echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><p>نمایش ویترین انجام نشد.</p><a href="/showcase">تلاش دوباره</a></html>';
    error_log('Mahda showcase render: ' . get_class($e));
}
