<?php
declare(strict_types=1);
if (!defined('MAHDA_SHOWCASE_PAGE')) { http_response_code(404); exit; }

function sc_profile_items(PDO $db, int $profileId): array
{
    $attribution = mahda_attributed_content_sql('c');
    $sql = "SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color
        FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id
        JOIN mahda_users owner ON owner.id=c.author_id JOIN mahda_categories cat ON cat.id=c.category_id
        WHERE p.name<>'' AND owner.is_active=1 AND owner.email NOT LIKE 'guest-%@mahda.local'
        AND owner.email NOT LIKE 'test-phone-%@mahda.local' AND c.archived_at IS NULL
        AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved'))
        AND {$attribution} AND c.profile_id=? ORDER BY c.created_at DESC,c.id DESC LIMIT 100";
    $st=$db->prepare($sql);
    $st->execute([$profileId]);
    return mahda_items($db, $st->fetchAll());
}

function sc_active_interactions(PDO $db, array $items, int $userId): array
{
    if ($userId < 1 || !$items) return [];
    $ids=array_map(static fn(array $x): int => (int)$x['id'], $items);
    $marks=implode(',', array_fill(0,count($ids),'?'));
    $st=$db->prepare("SELECT content_id,kind FROM mahda_interactions WHERE user_id=? AND content_id IN ({$marks})");
    $st->execute(array_merge([$userId],$ids));
    $result=[];
    foreach($st->fetchAll() as $row) $result[(int)$row['content_id']][]=(string)$row['kind'];
    return $result;
}
