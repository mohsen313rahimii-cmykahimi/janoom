<?php
declare(strict_types=1);
if (!defined('MAHDA_SHOWCASE_PAGE')) { http_response_code(404); exit; }

function sc_e($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function sc_fa($value): string { return strtr((string)$value, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']); }
function sc_color($value): string { return preg_match('/^#[a-f0-9]{3}(?:[a-f0-9]{3})?$/i',(string)$value) ? (string)$value : '#159658'; }
function sc_url($value): string {
    $url=trim((string)$value);
    if ($url==='' || preg_match('/[\x00-\x20\x7f\\\\]/',$url)) return '';
    if (str_starts_with($url,'/') && !str_starts_with($url,'//')) return $url;
    return preg_match('#^https?://[^/]+#i',$url) ? $url : '';
}
function sc_icon(string $name, int $size=22): string {
    static $paths;
    $paths ??= require __DIR__.'/icons.php';
    return '<svg aria-hidden="true" viewBox="0 0 24 24" width="'.$size.'" height="'.$size.'" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'.($paths[$name]??$paths['user']).'</svg>';
}
function sc_route(string $path): array {
    if (in_array($path,['/showcase','/showcase/index.php','/showcase/index.html'],true)) return ['mode'=>'feed','id'=>0];
    if ($path==='/showcase/me') return ['mode'=>'me','id'=>0];
    if (preg_match('#^/showcase/profile/([1-9][0-9]{0,17})$#D',$path,$m)) return ['mode'=>'profile','id'=>(int)$m[1]];
    return ['mode'=>'missing','id'=>0];
}
function sc_age(array $ages): string { return implode('، ',array_map(static fn($a)=>['4-6'=>'۴ تا ۶ سال','7-10'=>'۷ تا ۱۰ سال'][$a]??(string)$a,$ages)); }
function sc_role(array $profile): string { return ['heiat'=>'هیئت','mentor'=>'مربی','family'=>'خانواده'][$profile['role']??'']??'خادم فرهنگی'; }
function sc_relative($input): string {
    if (!$input) return '';
    try { $date=new DateTimeImmutable((string)$input); } catch (Throwable $e) { return ''; }
    $seconds=max(0,time()-$date->getTimestamp());
    if ($seconds<60) return 'همین حالا';
    if ($seconds<3600) return sc_fa(intdiv($seconds,60)).' دقیقه پیش';
    if ($seconds<86400) return sc_fa(intdiv($seconds,3600)).' ساعت پیش';
    $days=intdiv($seconds,86400);
    if ($days<30) return sc_fa($days).' روز پیش';
    if (class_exists('IntlDateFormatter')) {
        $formatter=new IntlDateFormatter('fa_IR@calendar=persian',IntlDateFormatter::NONE,IntlDateFormatter::NONE,date_default_timezone_get(),IntlDateFormatter::TRADITIONAL,'d MMMM');
        return (string)$formatter->format($date);
    }
    return sc_fa($days).' روز پیش';
}
function sc_client_state(array $v): array {
    return ['csrf'=>$v['csrf'], 'authenticated'=>!empty($v['user'])&&empty($v['user']['guest']),
        'complete'=>!empty($v['user']['profile_complete']), 'profileId'=>(int)($v['profile']['profile']['id']??0),
        'following'=>$v['following']];
}
function sc_header(array $v): void {
    $feed=$v['mode']==='feed'; $logged=!empty($v['user'])&&empty($v['user']['guest']);
    $sub=$feed?'شبکه اجتماعی مربیان':($v['profile']?'ویترین '.sc_role($v['profile']['profile']):'پروفایل مهدا');
    $avatar=sc_url($v['user']['avatar_url']??'');
    ?>
    <div class="head-left"><a class="logo-button" href="/"><img src="/assets/mahda-logo-aUAXJ1di.webp" alt="مهدا"></a></div>
    <div class="head-center"><strong><?= sc_e($v['title']) ?></strong><small id="headSub"><?= sc_e($sub) ?></small></div>
    <div class="head-right">
    <?php if ($feed): ?>
      <?php if ($logged): ?><button class="head-button" data-go="/content/new" aria-label="افزودن"><?= sc_icon('plus',24) ?></button><button class="head-button has-badge" id="showcaseBell" data-go="/notifications" aria-label="اعلان‌ها"><?= sc_icon('bell',20) ?><span class="notif-dot<?= $v['unread']>0?' show':'' ?>" id="showcaseNotifDot"><?= $v['unread']>0?sc_fa($v['unread']>99?'99+':$v['unread']):'' ?></span></button><?php endif ?>
      <a class="head-button round account-thumb" href="<?= $logged?'/showcase/me':'/profile?returnTo=%2Fshowcase' ?>" id="headAccount" aria-label="ویترین من"><?= $avatar?'<img src="'.sc_e($avatar).'" alt="">':sc_icon('user',21) ?></a>
    <?php else: ?><a class="head-button" href="/showcase" aria-label="بازگشت"><?= sc_icon('back',24) ?></a><?php endif ?>
    </div>
    <?php
}
function sc_main(array $v): void {
    if ($v['error']) {
        ?><div class="error-card" role="alert"><?= sc_e($v['error']) ?><br><button data-reload>تلاش دوباره</button><br><a href="/showcase">بازگشت به ویترین</a></div><?php
    } elseif ($v['mode']==='feed') {
        ?><div class="feed" id="feed"><?php
        if (!$v['items']) { ?><div class="empty-state panel">هنوز محتوایی در ویترین منتشر نشده است.</div><?php }
        foreach ($v['items'] as $item) sc_feed_card($item,$v['active'][(int)$item['id']]??[]);
        ?></div><?php
    } else { sc_profile_view($v); }
}
function sc_feed_card(array $x,array $active): void {
    $id=(int)$x['id']; $profileId=(int)($x['profileId']??0);
    $ownerAttrs=$profileId>0?'href="/showcase/profile/'.$profileId.'"':'aria-disabled="true"';
    $text=trim((string)($x['description']?:($x['mainText']??'')));
    $summary=function_exists('mb_substr')?mb_substr($text,0,90,'UTF-8'):implode('',array_slice(preg_split('//u',$text,-1,PREG_SPLIT_NO_EMPTY)?:[],0,90));
    $title=$x['title']?:'بدون عنوان'; $category=$x['categoryLabel']??'';
    $image=sc_url($x['image']??''); $avatar=sc_url($x['publisherAvatar']??'');
    $chips=[];
    if ($age=sc_age($x['ages']??[])) $chips[]=['age','people',$age];
    if (!empty($x['duration'])) $chips[]=['time','clock',$x['duration']];
    $players=!empty($x['playersMin'])?sc_fa($x['playersMin']).(!empty($x['playersMax'])&&$x['playersMax']!==$x['playersMin']?' تا '.sc_fa($x['playersMax']):'').' نفر':($x['audienceSize']??'');
    if ($players) $chips[]=['players','people',$players];
    if (!empty($x['goals'][0])) $chips[]=['goal','target',$x['goals'][0]];
    ?>
    <article class="feed-card" data-id="<?= $id ?>">
      <header class="feed-head"><a class="feed-avatar" <?= $ownerAttrs ?>><?= $avatar?'<img src="'.sc_e($avatar).'" alt="" loading="lazy" decoding="async">':sc_icon('user',19) ?></a><a class="feed-owner" <?= $ownerAttrs ?>><strong><?= sc_e($x['publisher']??'') ?></strong><small><?= sc_e(sc_relative($x['createdAt']??'')) ?></small></a><button class="menu-btn" type="button" data-menu-id="<?= $id ?>" data-profile-id="<?= $profileId ?>" aria-label="بیشتر"><?= sc_icon('menu',18) ?></button></header>
      <a href="/content/item/<?= $id ?>" class="feed-cover"><?php if ($image): ?><img src="<?= sc_e($image) ?>" alt="<?= sc_e($title) ?>" loading="lazy" decoding="async"><?php else: ?><div class="feed-cover-empty"><?= sc_e($summary?:'این محتوا هنوز فایل یا متن نمایشی ندارد.') ?></div><?php endif ?></a>
      <div class="feed-title-wrap"><div class="feed-title-row"><h2 class="feed-title"><?= sc_e($title) ?></h2><?php if ($category): ?><span class="category-chip" style="--chip:<?= sc_color($x['categoryColor']??'') ?>"><?= sc_e($category) ?></span><?php endif ?></div><?php if ($summary): ?><p class="summary"><?= sc_e($summary) ?></p><?php endif ?></div>
      <?php if ($chips): ?><div class="meta-grid"><?php foreach($chips as [$class,$icon,$label]): ?><span class="meta-chip <?= $class ?>"><?= sc_icon($icon,13) ?><?= sc_e($label) ?></span><?php endforeach ?></div><?php endif ?>
      <div class="actions"><?php
      foreach ([['bookmark','bookmark','قفسه','bookmarkCount'],['executed','check','اجرا کردم','executedCount'],['share','share','اشتراک',null],['comment','comment','نظر','commentCount'],['like','heart','پسند','likeCount']] as [$kind,$icon,$label,$countKey]):
      $isInteraction=in_array($kind,['bookmark','executed','like'],true); $count=$countKey?(int)($x[$countKey]??0):0;
      ?><button class="action-btn <?= $isInteraction?'interaction ':'' ?><?= $kind ?><?= in_array($kind,$active,true)?' active':'' ?>" type="button" data-kind="<?= $kind ?>" data-id="<?= $id ?>"<?= $isInteraction?' aria-pressed="'.(in_array($kind,$active,true)?'true':'false').'"':'' ?>><?= sc_icon($icon,16) ?><span><?= $label ?></span><?php if ($count>0): ?><span class="count"><?= sc_fa($count) ?></span><?php endif ?></button><?php endforeach ?></div>
    </article>
    <?php
}
function sc_profile_view(array $v): void {
    $p=$v['profile']; $x=$p['profile']; $role=sc_role($x); $avatar=sc_url($x['avatarUrl']??'');
    ?>
    <section class="profile-hero"><div class="profile-top"><div class="profile-avatar"><?= $avatar?'<img src="'.sc_e($avatar).'" alt="'.sc_e($x['name']).'">':sc_icon('user',48) ?></div><div class="profile-info">
    <div class="profile-name-row"><strong class="profile-name"><?= sc_e($x['name']) ?></strong><?php if (!empty($x['verified'])): ?><span class="verified">✓</span><?php endif ?></div>
    <div class="profile-role">ویترین <?= sc_e($role) ?> مهدا<?= !empty($x['city'])?' · '.sc_e($x['city']):'' ?></div>
    <div class="stats"><div class="stat"><b><?= sc_fa($p['contentCount']) ?></b><span>محتوا</span></div><div class="stat"><b><?= sc_fa($p['following']) ?></b><span>دنبال می‌کند</span></div><div class="stat"><b id="followerCount"><?= sc_fa($p['followers']) ?></b><span>دنبال‌کننده‌ها</span></div></div>
    <?php if (!empty($x['badges'])): ?><div class="badge-row"><?php foreach($x['badges'] as $badge): ?><span class="badge-chip" style="--bc:<?= sc_color($badge['color']??'') ?>"><?= sc_e($badge['title']) ?></span><?php endforeach ?></div><?php endif ?>
    <div class="follow-row"><?php if ($p['isOwn']): ?><button class="edit-btn" data-go="/profile"><?= sc_icon('edit',15) ?> ویرایش پروفایل</button><?php else: ?><button id="followBtn" class="follow-btn<?= $v['following']?' on':'' ?>" aria-pressed="<?= $v['following']?'true':'false' ?>"><?= $v['following']?'دنبال می‌کنید':'دنبال کردن' ?></button><?php endif ?></div></div></div></section>
    <div class="tabs" role="tablist"><button class="tab active" id="contentTab" role="tab" aria-selected="true" aria-controls="tabContent" data-tab="content">محتواها</button><button class="tab" id="aboutTab" role="tab" aria-selected="false" aria-controls="tabAbout" data-tab="about">درباره <?= sc_e($role) ?></button></div>
    <section id="tabContent" role="tabpanel" aria-labelledby="contentTab"><div class="showcase-grid"><?php if (!$v['items']): ?><div class="empty-state" style="grid-column:1/-1">هنوز محتوایی در این ویترین منتشر نشده است.</div><?php endif ?>
    <?php foreach ($v['items'] as $i): $image=sc_url($i['image']??''); ?><button class="tile" style="--c:<?= sc_color($i['categoryColor']??'') ?>" data-go="/content/item/<?= (int)$i['id'] ?>"><?php if($image): ?><img src="<?= sc_e($image) ?>" alt="" loading="lazy" decoding="async"><?php endif ?><span class="tile-shade"></span><strong><?= sc_e($i['title']) ?></strong><span class="tile-badge"><?= sc_e($i['categoryLabel']??'') ?></span></button><?php endforeach ?></div></section>
    <section id="tabAbout" class="about" role="tabpanel" aria-labelledby="aboutTab" hidden><div class="about-card"><h2><?= sc_e($x['name']) ?></h2><?php if(!empty($x['bio'])): ?><p><?= sc_e($x['bio']) ?></p><?php endif ?><div class="about-list"><div class="about-item"><small>نوع ویترین</small><b><?= sc_e($role) ?></b></div>
    <?php if(!empty($x['city'])): ?><div class="about-item"><small>شهر</small><b><?= sc_e($x['city']) ?></b></div><?php endif ?>
    <?php if(!empty($x['ages'])): ?><div class="about-item"><small>گروه سنی فعالیت</small><b><?= sc_e(sc_age($x['ages'])) ?></b></div><?php endif ?>
    <?php if(!empty($x['specialties'])): ?><div class="about-item"><small>حوزه فعالیت</small><b><?= sc_e(implode('، ',$x['specialties'])) ?></b></div><?php endif ?></div></div></section>
    <?php
}
