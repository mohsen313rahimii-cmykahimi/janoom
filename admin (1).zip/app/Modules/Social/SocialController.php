<?php
declare(strict_types=1);
namespace Mahda\Modules\Social;
use Mahda\Core\Request;
use Mahda\Core\View;
final class SocialController
{
    public function __construct(private View $view) {}
    public function notifications(Request $request): string { return $this->view->render('pages/social/notifications'); }
}
