<?php
declare(strict_types=1);
namespace Mahda\Modules\Social;
use Mahda\Core\Router;
use Mahda\Core\View;
return static function (Router $router, View $view): void {
    $controller = new SocialController($view);
    $router->get('/notifications', [$controller, 'notifications']);
};
