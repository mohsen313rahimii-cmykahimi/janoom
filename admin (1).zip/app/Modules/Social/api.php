<?php
declare(strict_types=1);

/**
 * Shelf v1 is intentionally initialized only when a shelf endpoint is used.
 * This keeps ordinary requests migration-free while making the small patch
 * deployable on shared hosting without a terminal step.
 */
function mahda_shelf_ensure_schema(PDO $db): void
{
    static $ready = false;
    if ($ready) { return; }
    try {
        $check = $db->prepare("SELECT setting_value FROM mahda_settings WHERE setting_key='schema:shelf:v1' LIMIT 1");
        $check->execute();
        if ((string)$check->fetchColumn() === '1') { $ready = true; return; }
    } catch (Throwable $e) {
        // Continue to idempotent CREATE TABLE statements below.
    }
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_shelf_folders (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(60) NOT NULL,
        color_key VARCHAR(20) NOT NULL DEFAULT 'sage',
        sort_order INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY ix_shelf_folders_user(user_id,sort_order,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_shelf_items (
        folder_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        content_id BIGINT UNSIGNED NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(folder_id,content_id),
        KEY ix_shelf_items_user_content(user_id,content_id),
        KEY ix_shelf_items_user_folder(user_id,folder_id,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    try {
        $db->prepare("INSERT INTO mahda_settings(setting_key,setting_value) VALUES('schema:shelf:v1','1') ON DUPLICATE KEY UPDATE setting_value='1'")->execute();
    } catch (Throwable $e) {}
    $ready = true;
}

function mahda_shelf_colors(): array
{
    return ['sage','mint','sky','blue','violet','rose','amber','sand'];
}

function mahda_shelf_folders(PDO $db, int $userId, ?int $contentId = null): array
{
    $sql = "SELECT f.id,f.name,f.color_key,f.sort_order,COUNT(si.content_id) AS item_count";
    if ($contentId !== null) { $sql .= ",MAX(CASE WHEN si.content_id=".(int)$contentId." THEN 1 ELSE 0 END) AS selected"; }
    $sql .= " FROM mahda_shelf_folders f LEFT JOIN mahda_shelf_items si ON si.folder_id=f.id AND si.user_id=f.user_id WHERE f.user_id=? GROUP BY f.id,f.name,f.color_key,f.sort_order ORDER BY f.sort_order ASC,f.id ASC";
    $st=$db->prepare($sql);$st->execute([$userId]);$out=[];
    foreach($st->fetchAll() as $r){$row=['id'=>(int)$r['id'],'name'=>(string)$r['name'],'color'=>(string)$r['color_key'],'count'=>(int)$r['item_count']];if($contentId!==null)$row['selected']=!empty($r['selected']);$out[]=$row;}
    return $out;
}

function mahda_shelf_unsorted_count(PDO $db, int $userId): int
{
    $st=$db->prepare("SELECT COUNT(*) FROM mahda_interactions i JOIN mahda_contents c ON c.id=i.content_id WHERE i.user_id=? AND i.kind='bookmark' AND c.archived_at IS NULL AND NOT EXISTS (SELECT 1 FROM mahda_shelf_items si WHERE si.user_id=i.user_id AND si.content_id=i.content_id)");
    $st->execute([$userId]);return (int)$st->fetchColumn();
}

/** API actions owned by the Social module. */
function mahda_social_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['report_create', 'interaction_state', 'interaction', 'comments', 'comment_create', 'follow_state', 'follow', 'library', 'shelf_bootstrap', 'shelf_folder', 'shelf_content_state', 'shelf_folder_create', 'shelf_folder_update', 'shelf_folder_delete', 'shelf_content_set', 'notifications', 'notifications_read'], true)) {
        return false;
    }

        if ($action === 'report_create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_member($db);$type=mahda_string($data['targetType']??'',24);$target=max(0,(int)($data['targetId']??0));$reason=mahda_string($data['reason']??'',40);$note=mahda_string($data['note']??'',2000);$allowed=['inappropriate','wrong_info','wrong_category','broken_file','copyright','ethical','other'];if(!in_array($type,['content','comment'],true)||$target<1||!in_array($reason,$allowed,true))mahda_json(['error'=>'invalid_report'],422);
            $table=$type==='content'?'mahda_contents':'mahda_comments';$check=$db->prepare("SELECT id FROM {$table} WHERE id=? LIMIT 1");$check->execute([$target]);if(!$check->fetchColumn())mahda_json(['error'=>'target_not_found'],404);
            $dup=$db->prepare("SELECT id FROM mahda_reports WHERE reporter_user_id=? AND target_type=? AND target_id=? AND status IN ('new','in_progress') LIMIT 1");$dup->execute([(int)$user['id'],$type,$target]);if($dup->fetchColumn())mahda_json(['error'=>'report_already_open'],409);
            $db->prepare('INSERT INTO mahda_reports(reporter_user_id,target_type,target_id,reason_key,note) VALUES(?,?,?,?,?)')->execute([(int)$user['id'],$type,$target,$reason,$note!==''?$note:null]);$id=(int)$db->lastInsertId();mahda_admin_notify($db,'report_new','گزارش جدید','یک گزارش جدید برای بررسی ثبت شد.','report',$id,'report:new:'.$id);mahda_json(['ok'=>true,'id'=>$id],201);
        }

        if ($action === 'interaction_state' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $contentId = max(0, (int)($_GET['content_id'] ?? 0));
            if ($contentId < 1 || !mahda_public_content_exists($db, $contentId)) { mahda_json(['authenticated'=>false,'counts'=>['like'=>0,'executed'=>0,'bookmark'=>0],'active'=>[]]); }
            $counts = [];
            $stmt = $db->prepare('SELECT kind,COUNT(*) AS total FROM mahda_interactions WHERE content_id=? GROUP BY kind'); $stmt->execute([$contentId]);
            foreach ($stmt->fetchAll() as $row) { $counts[(string)$row['kind']] = (int)$row['total']; }
            $viewer = mahda_current_user($db, true); $userId = empty($viewer['guest']) ? (int)$viewer['id'] : 0;
            $active = [];
            if ($userId > 0) { $mine = $db->prepare('SELECT kind FROM mahda_interactions WHERE user_id=? AND content_id=?'); $mine->execute([$userId,$contentId]); $active = array_column($mine->fetchAll(), 'kind'); }
            mahda_json(['authenticated'=>$userId > 0,'counts'=>['like'=>$counts['like']??0,'executed'=>$counts['executed']??0,'bookmark'=>$counts['bookmark']??0],'active'=>$active]);
        }

        if ($action === 'interaction' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data(); mahda_require_csrf($data); $user = mahda_require_complete_member($db);
            $contentId = max(0, (int)($data['contentId'] ?? 0));
            $kind = mahda_string($data['kind'] ?? '', 20); $active = filter_var($data['active'] ?? true, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($contentId < 1 || !in_array($kind, ['like','executed','bookmark'], true) || $active === null) { mahda_json(['error'=>'invalid_interaction'], 422); }
            if ($kind === 'bookmark') { mahda_shelf_ensure_schema($db); }
            $exists = $db->prepare("SELECT c.id,c.author_id,c.profile_id FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_users owner ON owner.id=c.author_id WHERE c.id=? AND p.name<>'' AND owner.is_active=1 AND owner.email NOT LIKE 'guest-%@mahda.local' AND owner.email NOT LIKE 'test-phone-%@mahda.local' AND (c.archived_at IS NULL AND (c.visibility='showcase' OR (c.archived_at IS NULL AND c.visibility<>'hidden' AND c.review_status='approved'))) LIMIT 1"); $exists->execute([$contentId]); $ownedContent = $exists->fetch(); if (!$ownedContent) { mahda_json(['error'=>'content_not_found'], 404); }
            if ($active) {
                $write = $db->prepare('INSERT IGNORE INTO mahda_interactions(user_id,content_id,kind) VALUES(?,?,?)');
                $write->execute([(int)$user['id'],$contentId,$kind]);
                if ($write->rowCount() > 0 && in_array($kind, ['like','executed'], true)) { mahda_notify($db,(int)$ownedContent['author_id'],(int)$user['id'],$kind,$contentId,(int)$ownedContent['profile_id']); }
            } else {
                $db->prepare('DELETE FROM mahda_interactions WHERE user_id=? AND content_id=? AND kind=?')->execute([(int)$user['id'],$contentId,$kind]);
                if ($kind === 'bookmark') { $db->prepare('DELETE FROM mahda_shelf_items WHERE user_id=? AND content_id=?')->execute([(int)$user['id'],$contentId]); }
                if (in_array($kind, ['like','executed'], true)) { $db->prepare('DELETE FROM mahda_notifications WHERE recipient_user_id=? AND actor_user_id=? AND content_id=? AND kind=? AND is_read=0')->execute([(int)$ownedContent['author_id'],(int)$user['id'],$contentId,$kind]); }
            }
            $count = $db->prepare('SELECT COUNT(*) FROM mahda_interactions WHERE content_id=? AND kind=?'); $count->execute([$contentId,$kind]);
            mahda_json(['kind'=>$kind,'active'=>(bool)$active,'count'=>(int)$count->fetchColumn()]);
        }

        if ($action === 'comments' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $contentId = max(0, (int)($_GET['content_id'] ?? 0));
            if ($contentId < 1 || !mahda_public_content_exists($db, $contentId)) { mahda_json(['items'=>[]]); }
            $stmt = $db->prepare("SELECT c.id,c.body,c.created_at,u.display_name,
                (SELECT p.id FROM mahda_profiles p WHERE p.owner_id=u.id ORDER BY (p.kind='personal') DESC,p.id LIMIT 1) AS profile_id,
                (SELECT p.kind FROM mahda_profiles p WHERE p.owner_id=u.id ORDER BY (p.kind='personal') DESC,p.id LIMIT 1) AS profile_kind,
                (SELECT p.profile_data_json FROM mahda_profiles p WHERE p.owner_id=u.id ORDER BY (p.kind='personal') DESC,p.id LIMIT 1) AS profile_data_json
                FROM mahda_comments c JOIN mahda_users u ON u.id=c.user_id WHERE c.content_id=? AND c.status='published' AND COALESCE(c.is_hidden,0)=0 ORDER BY c.created_at DESC,c.id DESC LIMIT 100");
            $stmt->execute([$contentId]); $items = [];
            foreach ($stmt->fetchAll() as $row) { $items[] = ['id'=>(string)$row['id'],'name'=>(string)$row['display_name'],'text'=>(string)$row['body'],'liked'=>false,'createdAt'=>(string)$row['created_at'],'profileId'=>(int)($row['profile_id']??0),'avatarUrl'=>mahda_profile_avatar_url_db($db,(int)($row['profile_id']??0),(string)($row['profile_data_json']??''),(string)($row['profile_kind']??'personal'))]; }
            mahda_json(['items'=>$items]);
        }

        if ($action === 'comment_create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data(); mahda_require_csrf($data); $user = mahda_require_complete_member($db);
            $contentId = max(0, (int)($data['contentId'] ?? 0)); $body = mahda_string($data['body'] ?? '', 2000);
            if ($contentId < 1 || $body === '') { mahda_json(['error'=>'comment_required'], 422); }
            $exists = $db->prepare("SELECT c.id,c.author_id,c.profile_id FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_users owner ON owner.id=c.author_id WHERE c.id=? AND p.name<>'' AND owner.is_active=1 AND owner.email NOT LIKE 'guest-%@mahda.local' AND owner.email NOT LIKE 'test-phone-%@mahda.local' AND (c.archived_at IS NULL AND (c.visibility='showcase' OR (c.archived_at IS NULL AND c.visibility<>'hidden' AND c.review_status='approved'))) LIMIT 1"); $exists->execute([$contentId]); $ownedContent = $exists->fetch(); if (!$ownedContent) { mahda_json(['error'=>'content_not_found'], 404); }
            $recentComment = $db->prepare("SELECT body FROM mahda_comments WHERE user_id=? AND content_id=? AND created_at >= DATE_SUB(NOW(), INTERVAL 8 SECOND) ORDER BY id DESC LIMIT 1");
            $recentComment->execute([(int)$user['id'],$contentId]);
            $recentBody = $recentComment->fetchColumn();
            if ($recentBody !== false) { mahda_json(['error'=>'comment_too_fast'], 429); }
            $db->prepare("INSERT INTO mahda_comments(user_id,content_id,body,status) VALUES(?,?,?,'published')")->execute([(int)$user['id'],$contentId,$body]);
            $commentId = (string)$db->lastInsertId();
            mahda_notify($db,(int)$ownedContent['author_id'],(int)$user['id'],'comment',$contentId,(int)$ownedContent['profile_id']);
            mahda_json(['comment'=>['id'=>$commentId,'name'=>(string)$user['display_name'],'text'=>$body,'liked'=>false]]); 
        }

        if ($action === 'follow_state' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $profileId = max(0, (int)($_GET['profile_id'] ?? 0));
            if ($profileId < 1) { mahda_json(['authenticated'=>false,'following'=>false,'count'=>0]); }
            $profileExists = $db->prepare("SELECT 1 FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE p.id=? AND p.name<>'' AND u.is_active=1 AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local' LIMIT 1"); $profileExists->execute([$profileId]);
            if (!$profileExists->fetchColumn()) { mahda_json(['authenticated'=>false,'following'=>false,'count'=>0]); }
            $count = $db->prepare('SELECT COUNT(*) FROM mahda_follows WHERE profile_id=?'); $count->execute([$profileId]);
            $viewer = mahda_current_user($db, true); $userId = empty($viewer['guest']) ? (int)$viewer['id'] : 0;
            $following = false;
            if ($userId > 0) { $mine = $db->prepare('SELECT 1 FROM mahda_follows WHERE user_id=? AND profile_id=?'); $mine->execute([$userId,$profileId]); $following = (bool)$mine->fetchColumn(); }
            mahda_json(['authenticated'=>$userId > 0,'following'=>$following,'count'=>(int)$count->fetchColumn()]);
        }

        if ($action === 'follow' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data(); mahda_require_csrf($data); $user = mahda_require_complete_member($db);
            $profileId = max(0, (int)($data['profileId'] ?? 0)); $active = filter_var($data['active'] ?? true, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($profileId < 1 || $active === null) { mahda_json(['error'=>'invalid_follow'], 422); }
            $exists = $db->prepare("SELECT p.id,p.owner_id FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE p.id=? AND p.name<>'' AND u.is_active=1 AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local' LIMIT 1"); $exists->execute([$profileId]); $followProfile = $exists->fetch(); if (!$followProfile) { mahda_json(['error'=>'profile_not_found'], 404); }
            if ((int)$followProfile['owner_id'] === (int)$user['id']) { mahda_json(['error'=>'cannot_follow_self'], 422); }
            if ($active) {
                $write = $db->prepare('INSERT IGNORE INTO mahda_follows(user_id,profile_id) VALUES(?,?)'); $write->execute([(int)$user['id'],$profileId]);
                if ($write->rowCount() > 0) { mahda_notify($db,(int)$followProfile['owner_id'],(int)$user['id'],'follow',null,$profileId); }
            } else {
                $db->prepare('DELETE FROM mahda_follows WHERE user_id=? AND profile_id=?')->execute([(int)$user['id'],$profileId]);
                $db->prepare("DELETE FROM mahda_notifications WHERE recipient_user_id=? AND actor_user_id=? AND profile_id=? AND kind='follow' AND is_read=0")->execute([(int)$followProfile['owner_id'],(int)$user['id'],$profileId]);
            }
            $count = $db->prepare('SELECT COUNT(*) FROM mahda_follows WHERE profile_id=?'); $count->execute([$profileId]);
            mahda_json(['following'=>(bool)$active,'count'=>(int)$count->fetchColumn()]);
        }

        if ($action === 'library' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $user = mahda_require_complete_member($db);
            $limit = max(1, min(100, (int)($_GET['limit'] ?? 100)));
            $kind = mahda_string($_GET['kind'] ?? 'bookmark', 20);
            if (!in_array($kind, ['bookmark','executed','like'], true)) { $kind='bookmark'; }
            $stmt = $db->prepare("SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color
                FROM mahda_contents c
                JOIN mahda_interactions i ON i.content_id=c.id AND i.user_id=? AND i.kind=?
                JOIN mahda_profiles p ON p.id=c.profile_id
                JOIN mahda_users owner ON owner.id=c.author_id
                JOIN mahda_categories cat ON cat.id=c.category_id
                WHERE p.name<>'' AND owner.is_active=1 AND owner.email NOT LIKE 'guest-%@mahda.local' AND owner.email NOT LIKE 'test-phone-%@mahda.local'
                  AND c.archived_at IS NULL AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved'))
                ORDER BY i.created_at DESC,c.id DESC LIMIT ?");
            $stmt->bindValue(1, (int)$user['id'], PDO::PARAM_INT);
            $stmt->bindValue(2, $kind, PDO::PARAM_STR);
            $stmt->bindValue(3, $limit, PDO::PARAM_INT);
            $stmt->execute();
            $items = mahda_items($db, $stmt->fetchAll());
            $counts=[];
            $countSt=$db->prepare("SELECT i.kind,COUNT(*) total
                FROM mahda_interactions i
                JOIN mahda_contents c ON c.id=i.content_id
                JOIN mahda_profiles p ON p.id=c.profile_id
                JOIN mahda_users owner ON owner.id=c.author_id
                WHERE i.user_id=? AND i.kind IN ('bookmark','executed','like')
                  AND p.name<>'' AND owner.is_active=1 AND owner.email NOT LIKE 'guest-%@mahda.local' AND owner.email NOT LIKE 'test-phone-%@mahda.local'
                  AND c.archived_at IS NULL AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved'))
                GROUP BY i.kind");
            $countSt->execute([(int)$user['id']]);
            foreach($countSt->fetchAll() as $r){$counts[(string)$r['kind']]=(int)$r['total'];}
            mahda_json(['items'=>$items,'kind'=>$kind,'counts'=>['bookmark'=>$counts['bookmark']??0,'executed'=>$counts['executed']??0,'like'=>$counts['like']??0],'limit'=>$limit]);
        }


        if (str_starts_with($action, 'shelf_')) {
            mahda_shelf_ensure_schema($db);
        }

        if ($action === 'shelf_bootstrap' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $user=mahda_require_complete_member($db);$uid=(int)$user['id'];
            mahda_json(['folders'=>mahda_shelf_folders($db,$uid),'unsortedCount'=>mahda_shelf_unsorted_count($db,$uid),'colors'=>mahda_shelf_colors()]);
        }

        if ($action === 'shelf_content_state' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $user=mahda_require_complete_member($db);$uid=(int)$user['id'];$contentId=max(0,(int)($_GET['content_id']??0));
            if($contentId<1||!mahda_public_content_exists($db,$contentId)){mahda_json(['error'=>'content_not_found'],404);}
            $book=$db->prepare("SELECT 1 FROM mahda_interactions WHERE user_id=? AND content_id=? AND kind='bookmark' LIMIT 1");$book->execute([$uid,$contentId]);
            mahda_json(['folders'=>mahda_shelf_folders($db,$uid,$contentId),'saved'=>(bool)$book->fetchColumn(),'colors'=>mahda_shelf_colors()]);
        }

        if ($action === 'shelf_folder_create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_complete_member($db);$uid=(int)$user['id'];
            $name=trim(mahda_string($data['name']??'',60));$color=mahda_string($data['color']??'sage',20);
            if($name===''||!in_array($color,mahda_shelf_colors(),true)){mahda_json(['error'=>'invalid_folder'],422);}
            $sort=$db->prepare('SELECT COALESCE(MAX(sort_order),0)+1 FROM mahda_shelf_folders WHERE user_id=?');$sort->execute([$uid]);$order=(int)$sort->fetchColumn();
            $st=$db->prepare('INSERT INTO mahda_shelf_folders(user_id,name,color_key,sort_order) VALUES(?,?,?,?)');$st->execute([$uid,$name,$color,$order]);
            mahda_json(['folder'=>['id'=>(int)$db->lastInsertId(),'name'=>$name,'color'=>$color,'count'=>0]],201);
        }

        if ($action === 'shelf_folder_update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_complete_member($db);$uid=(int)$user['id'];$id=max(0,(int)($data['id']??0));
            $name=trim(mahda_string($data['name']??'',60));$color=mahda_string($data['color']??'sage',20);
            if($id<1||$name===''||!in_array($color,mahda_shelf_colors(),true)){mahda_json(['error'=>'invalid_folder'],422);}
            $st=$db->prepare('UPDATE mahda_shelf_folders SET name=?,color_key=? WHERE id=? AND user_id=?');$st->execute([$name,$color,$id,$uid]);if(!$st->rowCount()){ $chk=$db->prepare('SELECT 1 FROM mahda_shelf_folders WHERE id=? AND user_id=?');$chk->execute([$id,$uid]);if(!$chk->fetchColumn())mahda_json(['error'=>'folder_not_found'],404); }
            mahda_json(['ok'=>true,'folder'=>['id'=>$id,'name'=>$name,'color'=>$color]]);
        }

        if ($action === 'shelf_folder_delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_complete_member($db);$uid=(int)$user['id'];$id=max(0,(int)($data['id']??0));
            if($id<1)mahda_json(['error'=>'invalid_folder'],422);$db->beginTransaction();
            try{$chk=$db->prepare('SELECT 1 FROM mahda_shelf_folders WHERE id=? AND user_id=? FOR UPDATE');$chk->execute([$id,$uid]);if(!$chk->fetchColumn()){ $db->rollBack();mahda_json(['error'=>'folder_not_found'],404); }$db->prepare('DELETE FROM mahda_shelf_items WHERE folder_id=? AND user_id=?')->execute([$id,$uid]);$db->prepare('DELETE FROM mahda_shelf_folders WHERE id=? AND user_id=?')->execute([$id,$uid]);$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
            mahda_json(['ok'=>true]);
        }

        if ($action === 'shelf_content_set' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_complete_member($db);$uid=(int)$user['id'];$contentId=max(0,(int)($data['contentId']??0));
            if($contentId<1||!mahda_public_content_exists($db,$contentId)){mahda_json(['error'=>'content_not_found'],404);}
            $raw=is_array($data['folderIds']??null)?$data['folderIds']:[];$ids=[];foreach($raw as $v){$n=(int)$v;if($n>0)$ids[$n]=$n;}$ids=array_values($ids);
            if($ids){$marks=implode(',',array_fill(0,count($ids),'?'));$params=array_merge([$uid],$ids);$chk=$db->prepare("SELECT id FROM mahda_shelf_folders WHERE user_id=? AND id IN ($marks)");$chk->execute($params);$owned=array_map('intval',array_column($chk->fetchAll(),'id'));sort($owned);$expected=$ids;sort($expected);if($owned!==$expected)mahda_json(['error'=>'folder_not_found'],404);}
            $db->beginTransaction();try{$db->prepare('DELETE FROM mahda_shelf_items WHERE user_id=? AND content_id=?')->execute([$uid,$contentId]);if($ids){$ins=$db->prepare('INSERT INTO mahda_shelf_items(folder_id,user_id,content_id) VALUES(?,?,?)');foreach($ids as $fid)$ins->execute([$fid,$uid,$contentId]);$db->prepare("INSERT IGNORE INTO mahda_interactions(user_id,content_id,kind) VALUES(?,?,'bookmark')")->execute([$uid,$contentId]);}else{$db->prepare("DELETE FROM mahda_interactions WHERE user_id=? AND content_id=? AND kind='bookmark'")->execute([$uid,$contentId]);}$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
            $count=$db->prepare("SELECT COUNT(*) FROM mahda_interactions WHERE content_id=? AND kind='bookmark'");$count->execute([$contentId]);mahda_json(['ok'=>true,'saved'=>(bool)$ids,'folderIds'=>$ids,'count'=>(int)$count->fetchColumn()]);
        }

        if ($action === 'shelf_folder' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $user=mahda_require_complete_member($db);$uid=(int)$user['id'];$folderId=max(0,(int)($_GET['folder_id']??0));$limit=max(1,min(100,(int)($_GET['limit']??100)));$folder=null;
            $select="SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color FROM mahda_contents c ";
            if($folderId>0){$fst=$db->prepare('SELECT id,name,color_key FROM mahda_shelf_folders WHERE id=? AND user_id=? LIMIT 1');$fst->execute([$folderId,$uid]);$f=$fst->fetch();if(!$f)mahda_json(['error'=>'folder_not_found'],404);$folder=['id'=>(int)$f['id'],'name'=>(string)$f['name'],'color'=>(string)$f['color_key']];$select.="JOIN mahda_shelf_items si ON si.content_id=c.id AND si.user_id=? AND si.folder_id=? ";$params=[$uid,$folderId];$order='si.created_at';}
            else{$folder=['id'=>0,'name'=>'ذخیره‌های قبلی','color'=>'sand'];$select.="JOIN mahda_interactions i ON i.content_id=c.id AND i.user_id=? AND i.kind='bookmark' ";$params=[$uid];$order='i.created_at';}
            $select.="JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_users owner ON owner.id=c.author_id JOIN mahda_categories cat ON cat.id=c.category_id WHERE p.name<>'' AND owner.is_active=1 AND owner.email NOT LIKE 'guest-%@mahda.local' AND owner.email NOT LIKE 'test-phone-%@mahda.local' AND c.archived_at IS NULL AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved')) ";
            if($folderId===0)$select.="AND NOT EXISTS (SELECT 1 FROM mahda_shelf_items sx WHERE sx.user_id=? AND sx.content_id=c.id) ";
            $select.="ORDER BY $order DESC,c.id DESC LIMIT ?";$st=$db->prepare($select);$i=1;foreach($params as $v)$st->bindValue($i++,$v,PDO::PARAM_INT);if($folderId===0)$st->bindValue($i++,$uid,PDO::PARAM_INT);$st->bindValue($i,$limit,PDO::PARAM_INT);$st->execute();
            mahda_json(['folder'=>$folder,'items'=>mahda_items($db,$st->fetchAll())]);
        }

        if ($action === 'notifications' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $user = mahda_require_complete_member($db);
            $limit = max(1, min(200, (int)($_GET['limit'] ?? 100)));
            $stmt = $db->prepare("SELECT n.id,n.kind,n.meta_json,n.is_read,n.created_at,
                COALESCE(NULLIF(ap.name,''),NULLIF(u.display_name,'')) AS actor_name,
                c.id AS live_content_id,c.title AS content_title,p.id AS live_profile_id,p.slug AS profile_slug,p.name AS profile_name,
                ap.id actor_profile_id,ap.kind actor_profile_kind,ap.profile_data_json actor_profile_data
                FROM mahda_notifications n JOIN mahda_users u ON u.id=n.actor_user_id
                LEFT JOIN mahda_contents c ON c.id=n.content_id AND c.archived_at IS NULL
                LEFT JOIN mahda_profiles p ON p.id=n.profile_id AND p.name<>''
                LEFT JOIN mahda_profiles ap ON ap.id=(SELECT ap2.id FROM mahda_profiles ap2 WHERE ap2.owner_id=u.id AND ap2.name<>'' ORDER BY (ap2.kind='personal') DESC,ap2.id LIMIT 1)
                WHERE n.recipient_user_id=? ORDER BY n.created_at DESC,n.id DESC LIMIT ?");
            $stmt->bindValue(1,(int)$user['id'],PDO::PARAM_INT); $stmt->bindValue(2,$limit,PDO::PARAM_INT); $stmt->execute();
            $items = [];
            foreach ($stmt->fetchAll() as $row) {
                $meta = json_decode((string)($row['meta_json'] ?? ''), true); if (!is_array($meta)) { $meta = []; }
                $apId=(int)($row['actor_profile_id']??0);
                $items[] = ['id'=>(string)$row['id'],'kind'=>(string)$row['kind'],'actorName'=>$row['actor_name']===null?'':(string)$row['actor_name'],'actorProfileId'=>$apId?:null,'actorAvatar'=>$apId>0?mahda_profile_avatar_url_db($db,$apId,(string)($row['actor_profile_data']??''),(string)($row['actor_profile_kind']??'personal')):'','contentId'=>$row['live_content_id'] === null ? null : (string)$row['live_content_id'],'contentTitle'=>$row['content_title'],'profileId'=>$row['live_profile_id'] === null ? null : (int)$row['live_profile_id'],'profileSlug'=>$row['profile_slug'],'profileName'=>$row['profile_name'],'reviewNote'=>isset($meta['note']) ? mahda_string($meta['note'], 800) : '','read'=>(bool)$row['is_read'],'createdAt'=>(string)$row['created_at']];
            }
            $unread = $db->prepare('SELECT COUNT(*) FROM mahda_notifications WHERE recipient_user_id=? AND is_read=0'); $unread->execute([(int)$user['id']]);
            mahda_json(['items'=>$items,'unread'=>(int)$unread->fetchColumn()]);
        }

        if ($action === 'notifications_read' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data(); mahda_require_csrf($data); $user = mahda_require_complete_member($db);
            $notificationId = max(0,(int)($data['id'] ?? 0));
            if ($notificationId > 0) { $db->prepare('UPDATE mahda_notifications SET is_read=1 WHERE id=? AND recipient_user_id=?')->execute([$notificationId,(int)$user['id']]); }
            else { $db->prepare('UPDATE mahda_notifications SET is_read=1 WHERE recipient_user_id=?')->execute([(int)$user['id']]); }
            $unread = $db->prepare('SELECT COUNT(*) FROM mahda_notifications WHERE recipient_user_id=? AND is_read=0'); $unread->execute([(int)$user['id']]);
            mahda_json(['ok'=>true,'unread'=>(int)$unread->fetchColumn()]);
        }

    mahda_json(['error' => 'method_not_allowed'], 405);
}
