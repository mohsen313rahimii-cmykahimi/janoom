<?php
declare(strict_types=1);
namespace Mahda\Modules\Library;
use Mahda\Core\Request;
use Mahda\Core\View;
final class LibraryController
{
    public function __construct(private View $view) {}
    public function index(Request $request): string { return $this->view->render('pages/library/index'); }
    public function shelf(Request $request): string { return $this->view->render('pages/library/shelf'); }
}
