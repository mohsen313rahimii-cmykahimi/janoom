<?php
declare(strict_types=1);
namespace Mahda\Modules\Library;
use Mahda\Core\Router;
use Mahda\Core\View;
return static function (Router $router, View $view): void {
    $controller = new LibraryController($view);
    $router->get('/library', [$controller, 'index']);
    $router->get('/shelf', [$controller, 'shelf']);
};
