<?php
declare(strict_types=1);

namespace Mahda\Modules\Auth;

use PDO;

final class AuthRepository
{
    public function __construct(private PDO $db)
    {
    }

    /** @return array{id:int,province_id:int,name:string}|null */
    public function resolveCity(string $city): ?array
    {
        $city = trim($city);
        if ($city === '') return null;
        $stmt = $this->db->prepare('SELECT id,province_id,name FROM mahda_cities WHERE name=? LIMIT 1');
        $stmt->execute([$city]);
        $row = $stmt->fetch();
        if (!is_array($row)) return null;
        return ['id'=>(int)$row['id'],'province_id'=>(int)$row['province_id'],'name'=>(string)$row['name']];
    }

    /** @return array<string, mixed>|null */
    public function findByIds(int $userId, int $profileId): ?array
    {
        $stmt = $this->db->prepare($this->baseSelect() . ' WHERE u.id=? AND p.id=? AND p.owner_id=u.id AND u.is_active=1 LIMIT 1');
        $stmt->execute([$userId, $profileId]);
        $row = $stmt->fetch();
        return is_array($row) ? $row : null;
    }

    /** @return array<string, mixed>|null */
    public function findByPhone(string $phone): ?array
    {
        $identity = 'phone-' . $phone . '@mahda.local';
        $legacy = 'test-phone-' . $phone . '@mahda.local';
        $stmt = $this->db->prepare($this->baseSelect() . ' WHERE u.email IN (?,?) AND u.is_active=1 ORDER BY (u.email=?) DESC,(p.kind=\'personal\') DESC,p.id LIMIT 1');
        $stmt->execute([$identity, $legacy, $identity]);
        $row = $stmt->fetch();
        return is_array($row) ? $row : null;
    }

    /** @return array<string, mixed>|null */
    public function findByEmail(string $email): ?array
    {
        $stmt = $this->db->prepare($this->baseSelect(true) . ' WHERE LOWER(u.email)=LOWER(?) AND u.is_active=1 ORDER BY (p.kind=\'personal\') DESC,p.id LIMIT 1');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        return is_array($row) ? $row : null;
    }

    /**
     * Password login accepts the public email identity and, for staff, the
     * optional admin username. Keeping this lookup here avoids duplicating
     * authentication SQL in controllers and lets the login page stay simple.
     *
     * @return array<string, mixed>|null
     */
    public function findByLoginIdentifier(string $identifier): ?array
    {
        $stmt = $this->db->prepare(
            $this->baseSelect(true)
            . ' WHERE (LOWER(u.email)=LOWER(?) OR (u.admin_username IS NOT NULL AND LOWER(u.admin_username)=LOWER(?)))'
            . ' AND u.is_active=1 ORDER BY (LOWER(u.email)=LOWER(?)) DESC,(p.kind=\'personal\') DESC,p.id LIMIT 1'
        );
        $stmt->execute([$identifier, $identifier, $identifier]);
        $row = $stmt->fetch();
        return is_array($row) ? $row : null;
    }

    /** @return array<string, mixed>|null */
    public function createPhoneUser(string $phone): ?array
    {
        $identity = 'phone-' . $phone . '@mahda.local';
        $this->db->beginTransaction();
        try {
            $this->db->prepare("INSERT INTO mahda_users(email,display_name,password_hash,role) VALUES(?,?,?,'member')")
                ->execute([$identity, '', password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT)]);
            $userId = (int)$this->db->lastInsertId();
            $slug = 'm-' . $userId . '-' . substr(hash('sha256', $identity), 0, 12);
            $this->db->prepare("INSERT INTO mahda_profiles(owner_id,slug,name,kind,profile_data_json) VALUES(?,?,?,'personal',?)")
                ->execute([$userId, $slug, '', '{}']);
            $profileId = (int)$this->db->lastInsertId();
            $this->db->commit();
            return $this->findByIds($userId, $profileId);
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            // A concurrent request may win the unique identity insert; in
            // that one case, reuse the account it created. Other database
            // failures must remain visible to the caller.
            if ($error instanceof \PDOException && (string)($error->errorInfo[0] ?? '') === '23000') {
                return $this->findByPhone($phone);
            }
            throw $error;
        }
    }

    /** @return array<string, mixed> */
    public function createRegistration(
        string $email,
        string $displayName,
        string $password,
        string $kind,
        string $profileName,
        string $role,
        array $profileData = [],
        string $city = '',
        string $bio = ''
    ): array
    {
        $cityRow = $city !== '' ? $this->resolveCity($city) : null;
        if ($city !== '' && $cityRow === null) {
            throw new \RuntimeException('invalid_city');
        }
        $canonicalCity = $cityRow ? (string)$cityRow['name'] : '';
        $this->db->beginTransaction();
        try {
            $this->db->prepare("INSERT INTO mahda_users(email,display_name,password_hash,role) VALUES(?,?,?,'member')")
                ->execute([$email, $displayName, password_hash($password, PASSWORD_DEFAULT)]);
            $userId = (int)$this->db->lastInsertId();
            $slug = ($kind === 'heiat' ? 'h-' : 'm-') . $userId . '-' . substr(hash('sha256', $email), 0, 12);
            $profileData['profileRole'] = $role;
            if (!isset($profileData['primaryRole'])) {
                $profileData['primaryRole'] = $role === 'heiat' ? 'heiat' : ($role === 'mentor' ? 'mentor' : 'other');
            }
            if ($role === 'family') {
                $profileData['role'] = 'family';
            } elseif ($role === 'khadem') {
                $profileData['role'] = 'cultural_servant';
            } elseif ($role === 'other') {
                $profileData['role'] = 'other';
            }
            if ($role === 'heiat') {
                $profileData['heiatName'] = $profileName;
            }
            $profileData['profileComplete'] = $this->profileComplete($profileData, $kind, $displayName, $profileName, $canonicalCity);
            $encoded = json_encode($profileData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $atlasVisible = in_array($role, ['mentor','heiat'], true) ? 1 : 0;
            $this->db->prepare('INSERT INTO mahda_profiles(owner_id,slug,name,kind,bio,city,city_id,province_id,profile_data_json,profile_role,atlas_visible) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
                ->execute([
                    $userId, $slug, $profileName, $kind, $bio !== '' ? $bio : null,
                    $canonicalCity !== '' ? $canonicalCity : null,
                    $cityRow ? (int)$cityRow['id'] : null,
                    $cityRow ? (int)$cityRow['province_id'] : null,
                    $encoded ?: '{}', $role, $atlasVisible
                ]);
            $profileId = (int)$this->db->lastInsertId();
            $this->db->commit();
            return $this->findByIds($userId, $profileId) ?? throw new \RuntimeException('registration_failed');
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            if ($error instanceof \PDOException && (string)($error->errorInfo[0] ?? '') === '23000') {
                throw new \RuntimeException('email_exists');
            }
            throw $error;
        }
    }

    /** @return array<string, mixed> */
    public function guestPayload(): array
    {
        return [
            'id' => 0,
            'profile_id' => 0,
            'phone' => '',
            'display_name' => '',
            'role' => 'guest',
            'guest' => true,
            'profile_kind' => null,
            'profile_name' => '',
            'city' => '',
            'profile_data' => [],
            'avatar_url' => '',
            'profile_complete' => false,
            'created_at' => null,
        ];
    }

    /** @return array<string, mixed> */
    public function toPayload(array $row): array
    {
        $profileData = json_decode((string)($row['profile_data_json'] ?? ''), true);
        $profileData = is_array($profileData) ? $profileData : [];
        unset($profileData['avatarDataUrl'], $profileData['heiatLogoDataUrl']);
        if (function_exists('mahda_profile_public_data')) {
            $profileData = mahda_profile_public_data($profileData);
        }
        $kind = (string)($row['profile_kind'] ?? 'personal');
        $profileName = (string)($row['profile_name'] ?? '');
        $displayName = (string)($row['display_name'] ?? '');
        $city = (string)($row['city'] ?? '');
        $phone = (string)($row['phone'] ?? '');
        if ($phone === '' && preg_match('/^(?:test-)?phone-(98\d+)@mahda\.local$/', (string)($row['email'] ?? ''), $phoneMatch) === 1) {
            $phone = $phoneMatch[1];
        }
        return [
            'id' => (int)$row['id'],
            'profile_id' => (int)($row['profile_id'] ?? 0),
            'phone' => $phone,
            'display_name' => $displayName,
            'role' => (string)($row['role'] ?? 'member'),
            'guest' => false,
            'profile_kind' => $kind,
            'profile_name' => $profileName,
            'city' => $city,
            'profile_data' => $profileData,
            'avatar_url' => (int)($row['profile_id'] ?? 0) > 0 ? '/mahda-api/index.php?action=profile_avatar&id=' . (int)$row['profile_id'] : '',
            'profile_complete' => $this->profileComplete($profileData, $kind, $displayName, $profileName, $city),
            'created_at' => isset($row['created_at']) ? (string)$row['created_at'] : null,
        ];
    }

    private function baseSelect(bool $withPassword = false): string
    {
        return 'SELECT u.id,u.display_name,u.role,u.created_at,u.email'
            . ($withPassword ? ',u.password_hash' : '')
            . ',p.id AS profile_id,p.kind AS profile_kind,p.name AS profile_name,p.city,p.profile_data_json,p.profile_role FROM mahda_users u JOIN mahda_profiles p ON p.owner_id=u.id';
    }

    private function profileComplete(array $data, string $kind, string $displayName, string $profileName, string $city): bool
    {
        $primary = (string)($data['primaryRole'] ?? ($data['profileRole'] ?? ($kind === 'heiat' ? 'heiat' : 'other')));
        $identity = trim($displayName) !== '' && trim($profileName) !== '' && trim($city) !== '';
        if ($primary === 'mentor') {
            return $identity && trim((string)($data['firstName'] ?? '')) !== '' && trim((string)($data['lastName'] ?? '')) !== ''
                && !empty($data['specialties']) && !empty($data['ages']);
        }
        if ($primary === 'heiat' || $kind === 'heiat') {
            return $identity && trim((string)($data['heiatName'] ?? $profileName)) !== '' && !empty($data['ages']);
        }
        return $identity && in_array((string)($data['role'] ?? ''), ['other', 'family', 'cultural_servant'], true);
    }
}
