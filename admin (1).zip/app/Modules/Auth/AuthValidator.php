<?php
declare(strict_types=1);

namespace Mahda\Modules\Auth;

use Mahda\Core\Database;

final class AuthValidator
{
    public function normalizePhone(mixed $value): string
    {
        $text = strtr((string)$value, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ]);
        $phone = preg_replace('/\D+/', '', $text) ?? '';
        if (str_starts_with($phone, '0098')) {
            $phone = substr($phone, 2);
        }
        if (str_starts_with($phone, '09')) {
            $phone = '98' . substr($phone, 1);
        } elseif (!str_starts_with($phone, '98') && strlen($phone) === 10 && str_starts_with($phone, '9')) {
            $phone = '98' . $phone;
        }
        return $phone;
    }

    public function phone(mixed $value): string
    {
        $phone = $this->normalizePhone($value);
        if (!preg_match('/^989\d{9}$/', $phone)) {
            throw new \RuntimeException('invalid_phone');
        }
        return $phone;
    }

    public function email(mixed $value): string
    {
        $email = strtolower(trim((string)$value));
        if ($email === '' || strlen($email) > 190 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            throw new \RuntimeException('invalid_email');
        }
        return $email;
    }

    public function password(mixed $value): string
    {
        $password = (string)$value;
        if (strlen($password) < 12 || strlen($password) > 72) {
            throw new \RuntimeException('invalid_password');
        }
        return $password;
    }

    public function role(mixed $value): string
    {
        $role = trim((string)$value);
        if (!in_array($role, ['mentor', 'heiat', 'family', 'khadem', 'other'], true)) {
            throw new \RuntimeException('invalid_role');
        }
        return $role;
    }

    public function phoneMode(): string
    {
        $config = Database::privateConfig();
        $enabled = getenv('MAHDA_TEST_PHONE_AUTH');
        $enabled = $enabled === false
            ? (bool)($config['test_phone_auth'] ?? false)
            : in_array(strtolower(trim((string)$enabled)), ['1', 'true', 'yes', 'on'], true);
        // Test mode is usable only when a server-side code is configured.
        return $enabled && $this->testCode() !== '' ? 'test' : 'disabled';
    }

    public function testCode(): string
    {
        $config = Database::privateConfig();
        $raw = getenv('MAHDA_TEST_PHONE_AUTH_CODE');
        $raw = $raw === false ? (string)($config['test_phone_auth_code'] ?? '') : (string)$raw;
        return $this->normalizeOtp($raw);
    }

    public function assertTestCode(mixed $value): void
    {
        $expected = $this->testCode();
        $provided = $this->normalizeOtp($value);
        if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
            throw new \RuntimeException('invalid_otp');
        }
    }

    private function normalizeOtp(mixed $value): string
    {
        $text = strtr((string)$value, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ]);
        $code = preg_replace('/\D+/', '', $text) ?? '';
        return preg_match('/^\d{6,12}$/', $code) ? $code : '';
    }
}
