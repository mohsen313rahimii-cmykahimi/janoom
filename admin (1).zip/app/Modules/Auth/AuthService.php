<?php
declare(strict_types=1);

namespace Mahda\Modules\Auth;

use Mahda\Core\Auth;
use Mahda\Core\Csrf;

final class AuthService
{
    public function __construct(
        private AuthRepository $repository,
        private Auth $auth,
        private Csrf $csrf,
        private AuthValidator $validator,
    ) {
    }

    /** @return array<string, mixed> */
    public function sessionPayload(): array
    {
        $user = $this->auth->user() ?? $this->auth->guest();
        return [
            'csrf' => $this->csrf->token(),
            'user' => $user,
            'auth' => ['phoneMode' => $this->validator->phoneMode()],
        ];
    }

    /** @return array{isNew:bool,user:array<string,mixed>} */
    public function startByPhone(mixed $phoneInput, mixed $otpInput = null): array
    {
        $phone = $this->validator->phone($phoneInput);
        if ($this->validator->phoneMode() !== 'test') {
            throw new \RuntimeException('phone_auth_not_configured');
        }
        $this->validator->assertTestCode($otpInput);
        $row = $this->repository->findByPhone($phone);
        $isNew = $row === null;
        if ($row === null) {
            $row = $this->repository->createPhoneUser($phone);
        }
        if ($row === null) {
            throw new \RuntimeException('account_create_failed');
        }
        $user = $this->auth->establish($row, $phone);
        $this->csrf->rotate();
        return ['isNew' => $isNew, 'user' => $user];
    }

    /** @return array<string, mixed> */
    public function loginByPassword(mixed $identifierInput, mixed $passwordInput): array
    {
        $identifier = trim((string)$identifierInput);
        $password = (string)$passwordInput;
        if ($identifier === '' || strlen($identifier) > 190 || $password === '') {
            throw new \RuntimeException('invalid_credentials');
        }
        $row = $this->repository->findByLoginIdentifier($identifier);
        if ($row === null || !password_verify($password, (string)($row['password_hash'] ?? ''))) {
            throw new \RuntimeException('invalid_credentials');
        }
        $user = $this->auth->establish($row);
        $this->csrf->rotate();
        return ['user' => $user];
    }

    /** Backward-compatible alias used by older callers. */
    public function loginByEmail(mixed $emailInput, mixed $passwordInput): array
    {
        return $this->loginByPassword($emailInput, $passwordInput);
    }

    /** @return array<string, mixed> */
    public function register(array $data): array
    {
        $email = $this->validator->email($data['email'] ?? '');
        $displayName = trim((string)($data['displayName'] ?? ($data['name'] ?? '')));
        $password = $this->validator->password($data['password'] ?? '');
        $role = $this->validator->role($data['profileRole'] ?? ($data['role'] ?? 'other'));
        $kind = $role === 'heiat' ? 'heiat' : 'personal';
        $profileName = trim((string)($role === 'heiat' ? ($data['organizationName'] ?? ($data['profileName'] ?? '')) : ($data['profileName'] ?? $displayName)));
        $city = trim((string)($data['city'] ?? ''));
        $bio = trim((string)($data['bio'] ?? ''));
        if ($displayName === '' || $profileName === '' || $city === '' || strlen($displayName) > 120 || strlen($profileName) > 190) {
            throw new \RuntimeException('invalid_registration');
        }
        if ($this->repository->resolveCity($city) === null) {
            throw new \RuntimeException('invalid_city');
        }

        $agesRaw = is_array($data['ages'] ?? null) ? $data['ages'] : [];
        $ages = array_values(array_unique(array_filter(array_map('strval', $agesRaw), static fn(string $v): bool => in_array($v, ['4-6','7-10'], true))));
        $specialtiesRaw = $data['specialties'] ?? [];
        if (is_string($specialtiesRaw)) {
            $specialtiesRaw = preg_split('/[،,]/u', $specialtiesRaw) ?: [];
        }
        $specialties = [];
        if (is_array($specialtiesRaw)) {
            foreach ($specialtiesRaw as $value) {
                $value = trim((string)$value);
                if ($value !== '' && strlen($value) <= 120) $specialties[] = $value;
                if (count($specialties) >= 12) break;
            }
        }

        $profileData = ['profileRole'=>$role];
        if ($role === 'mentor') {
            $firstName = trim((string)($data['firstName'] ?? ''));
            $lastName = trim((string)($data['lastName'] ?? ''));
            if ($firstName === '' || $lastName === '' || !$ages || !$specialties) {
                throw new \RuntimeException('invalid_registration');
            }
            $profileData += [
                'primaryRole'=>'mentor', 'firstName'=>$firstName, 'lastName'=>$lastName,
                'specialties'=>$specialties, 'ages'=>$ages,
            ];
        } elseif ($role === 'heiat') {
            if (!$ages) throw new \RuntimeException('invalid_registration');
            $profileData += ['primaryRole'=>'heiat','heiatName'=>$profileName,'ages'=>$ages];
        } else {
            $profileData += [
                'primaryRole'=>'other',
                'role'=>$role === 'family' ? 'family' : ($role === 'khadem' ? 'cultural_servant' : 'other'),
            ];
        }
        if ($bio !== '') $profileData['intro'] = function_exists('mb_substr') ? mb_substr($bio, 0, 2000, 'UTF-8') : substr($bio, 0, 2000);

        $row = $this->repository->createRegistration(
            $email, $displayName, $password, $kind, $profileName, $role,
            $profileData, $city, $bio
        );
        $user = $this->auth->establish($row);
        $this->csrf->rotate();
        return ['user' => $user];
    }

    /** @return array<string, mixed> */
    public function logout(): array
    {
        $user = $this->auth->logout();
        $this->csrf->rotate();
        return ['csrf' => $this->csrf->token(), 'user' => $user];
    }
}
