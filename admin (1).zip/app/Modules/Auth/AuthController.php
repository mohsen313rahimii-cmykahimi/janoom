<?php
declare(strict_types=1);

namespace Mahda\Modules\Auth;

use Mahda\Core\Request;
use Mahda\Core\View;

final class AuthController
{
    public function __construct(private View $view)
    {
    }

    public function account(Request $request): string
    {
        return $this->view->render('pages/auth/login');
    }
}

