<?php
declare(strict_types=1);

use Mahda\Core\Auth;
use Mahda\Core\Csrf;
use Mahda\Core\Session;
use Mahda\Modules\Auth\AuthRepository;
use Mahda\Modules\Auth\AuthService;
use Mahda\Modules\Auth\AuthValidator;

/**
 * Transitional adapter: these actions use the new Auth module while the
 * legacy API entrypoint remains available for actions not migrated yet.
 */
function mahda_auth_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['session', 'auth_phone', 'auth_login', 'auth_register', 'auth_logout'], true)) {
        return false;
    }

    $session = new Session();
    $csrf = new Csrf($session);
    $repository = new AuthRepository($db);
    $auth = new Auth($repository, $session);
    $service = new AuthService($repository, $auth, $csrf, new AuthValidator());

    try {
        if (in_array($action, ['auth_login','auth_phone','auth_register'], true)) {
            mahda_enforce_rate_limit($db, $action, $action === 'auth_login' ? 12 : 8, 300);
        }
        if ($action === 'session' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            mahda_json($service->sessionPayload());
        }

        $data = function_exists('mahda_request_data') ? mahda_request_data() : [];
        $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($data['csrf'] ?? ($data['_csrf'] ?? '')));
        if (!$csrf->validate($token)) {
            mahda_json(['error' => 'csrf_failed', 'csrf' => $csrf->token()], 419);
        }

        if ($action === 'auth_phone' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            $result = $service->startByPhone($data['phone'] ?? '', $data['otp'] ?? ($data['code'] ?? '')); 
            mahda_json(['isNew' => $result['isNew'], 'csrf' => $csrf->token(), 'user' => $result['user']]);
        }
        if ($action === 'auth_login' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            $identifier = $data['identifier'] ?? ($data['email'] ?? ($data['username'] ?? ''));
            $result = $service->loginByPassword($identifier, $data['password'] ?? '');
            mahda_json(['csrf' => $csrf->token(), 'user' => $result['user']]);
        }
        if ($action === 'auth_register' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            $result = $service->register($data);
            mahda_json(['csrf' => $csrf->token(), 'user' => $result['user']], 201);
        }
        if ($action === 'auth_logout' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            mahda_json($service->logout());
        }
        mahda_json(['error' => 'method_not_allowed'], 405);
    } catch (\RuntimeException $error) {
        $status = match ($error->getMessage()) {
            'auth_required', 'invalid_credentials', 'invalid_otp' => 401,
            'email_exists' => 409,
            'phone_auth_not_configured' => 503,
            'invalid_phone', 'invalid_email', 'invalid_password', 'invalid_role', 'invalid_registration', 'invalid_city' => 422,
            default => 500,
        };
        mahda_json(['error' => $error->getMessage()], $status);
    }

    return true;
}
