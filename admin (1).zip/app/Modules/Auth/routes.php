<?php
declare(strict_types=1);

namespace Mahda\Modules\Auth;

use Mahda\Core\Router;
use Mahda\Core\View;

return static function (Router $router, View $view): void {
    $controller = new AuthController($view);
    $router->get('/profile', [$controller, 'account']);
};

