<?php
declare(strict_types=1);

namespace Mahda\Modules\AiSearch;

use PDO;

final class AiSearchRepository
{
    public function __construct(private PDO $db, private PersianNormalizer $normalizer) {}

    /** @param array<string,mixed> $intent @return list<array<string,mixed>> */
    public function candidates(array $intent, int $limit = 160): array
    {
        $limit = max(20,min(250,$limit));
        $where = [
            "p.name<>''",
            'owner.is_active=1',
            "owner.email NOT LIKE 'guest-%@mahda.local'",
            "owner.email NOT LIKE 'test-phone-%@mahda.local'",
            'c.archived_at IS NULL',
            "c.visibility='showcase'",
            "c.review_status='approved'",
            'cat.is_active=1',
            'COALESCE(cat.show_in_bank,1)=1',
        ];
        $params = [];
        $signals = [];

        $categoryId = trim((string)($intent['category_id'] ?? ''));
        if ($categoryId !== '') {
            $signals[] = 'c.category_id=?';
            $params[] = $categoryId;
        }
        $occasionId = (int)($intent['occasion_id'] ?? 0);
        if ($occasionId > 0) {
            $signals[] = 'EXISTS (SELECT 1 FROM mahda_content_occasions xco WHERE xco.content_id=c.id AND xco.occasion_id=?)';
            $params[] = $occasionId;
        }
        $goalIds = array_values(array_filter(array_map('intval', is_array($intent['goal_ids'] ?? null) ? $intent['goal_ids'] : []), static fn(int $v): bool => $v > 0));
        if ($goalIds) {
            $ph = implode(',',array_fill(0,count($goalIds),'?'));
            $signals[] = "EXISTS (SELECT 1 FROM mahda_content_goals xcg WHERE xcg.content_id=c.id AND xcg.goal_id IN ({$ph}))";
            array_push($params,...$goalIds);
        }
        $keywords = array_slice(array_values(array_filter(array_map('strval', is_array($intent['keywords'] ?? null) ? $intent['keywords'] : []))),0,6);
        foreach ($keywords as $keyword) {
            $keyword = $this->normalizer->normalize($keyword);
            if ($keyword === '') continue;
            $signals[] = '(c.title LIKE ? OR c.body LIKE ? OR c.execution_text LIKE ? OR cat.label LIKE ?)';
            $term = '%' . $keyword . '%';
            array_push($params,$term,$term,$term,$term);
        }
        if ($signals) {
            $where[] = '(' . implode(' OR ', $signals) . ')';
        }

        $sql = 'SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color '
            . 'FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_users owner ON owner.id=c.author_id JOIN mahda_categories cat ON cat.id=c.category_id '
            . 'WHERE ' . implode(' AND ', $where) . ' ORDER BY c.created_at DESC,c.id DESC LIMIT ' . $limit;
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        if (!$rows) return [];

        $ids = array_values(array_map(static fn(array $r): int => (int)$r['id'],$rows));
        $placeholders = implode(',',array_fill(0,count($ids),'?'));
        $occasionMap = $goalMap = [];

        $s = $this->db->prepare("SELECT co.content_id,co.occasion_id,o.label FROM mahda_content_occasions co JOIN mahda_occasions o ON o.id=co.occasion_id WHERE co.content_id IN ({$placeholders})");
        $s->execute($ids);
        foreach ($s->fetchAll() as $r) {
            $occasionMap[(int)$r['content_id']]['ids'][] = (int)$r['occasion_id'];
            $occasionMap[(int)$r['content_id']]['labels'][] = (string)$r['label'];
        }
        $s = $this->db->prepare("SELECT cg.content_id,cg.goal_id,g.label FROM mahda_content_goals cg JOIN mahda_goals g ON g.id=cg.goal_id WHERE cg.content_id IN ({$placeholders})");
        $s->execute($ids);
        foreach ($s->fetchAll() as $r) {
            $goalMap[(int)$r['content_id']]['ids'][] = (int)$r['goal_id'];
            $goalMap[(int)$r['content_id']]['labels'][] = (string)$r['label'];
        }

        foreach ($rows as &$row) {
            $id = (int)$row['id'];
            $row['_occasion_ids'] = $occasionMap[$id]['ids'] ?? [];
            $row['_occasion_labels'] = $occasionMap[$id]['labels'] ?? [];
            $row['_goal_ids'] = $goalMap[$id]['ids'] ?? [];
            $row['_goal_labels'] = $goalMap[$id]['labels'] ?? [];
            $row['_search_text'] = $this->normalizer->normalize(implode(' ', [
                (string)($row['title'] ?? ''),(string)($row['body'] ?? ''),(string)($row['execution_text'] ?? ''),
                (string)($row['category_label'] ?? ''),implode(' ', $row['_occasion_labels']),implode(' ', $row['_goal_labels']),
            ]));
        }
        unset($row);
        return $rows;
    }
}
