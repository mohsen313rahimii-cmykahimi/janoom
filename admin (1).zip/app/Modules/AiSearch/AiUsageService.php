<?php
declare(strict_types=1);

namespace Mahda\Modules\AiSearch;

use Mahda\Core\Redis\RedisClient;
use RuntimeException;

final class AiUsageService
{
    public function __construct(
        private AiUsageRepository $repository,
        private ?RedisClient $redis,
        private int $dailyLimit,
        private float $inputCostPerMillion = 0.0,
        private float $outputCostPerMillion = 0.0,
    ) {}

    /** @return array{allowed:bool,remaining:int,resets_at:string} */
    public function quota(int $userId): array
    {
        $date = date('Y-m-d');
        $used = $this->repository->countForDay($userId, $date);
        $remaining = max(0, $this->dailyLimit - $used);
        return ['allowed'=>$remaining > 0,'remaining'=>$remaining,'resets_at'=>$this->resetAt()];
    }

    /** @return array{id:int,slot:int} */
    public function reserve(int $userId, int $profileId, string $provider, string $model, string $query): array
    {
        $date = date('Y-m-d');
        $record = $this->repository->reserve($userId, $profileId, $date, $this->dailyLimit, [
            'provider'=>$provider,
            'model'=>$model,
            'query_hash'=>hash('sha256',$query),
            'query_text'=>$this->truncate($query, 1000),
        ]);
        if (!$record) throw new RuntimeException('ai_daily_limit_reached');
        $this->redis?->setEx('ai-search:daily:' . $userId . ':' . $date, $this->secondsToReset(), (string)$record['slot']);
        return $record;
    }

    /** @param array<string,mixed> $providerMetrics */
    public function complete(int $usageId, array $providerMetrics, int $resultCount): void
    {
        $input = max(0,(int)($providerMetrics['input_tokens'] ?? 0));
        $output = max(0,(int)($providerMetrics['output_tokens'] ?? 0));
        $cost = null;
        if ($this->inputCostPerMillion > 0 || $this->outputCostPerMillion > 0) {
            $cost = ($input / 1000000) * $this->inputCostPerMillion + ($output / 1000000) * $this->outputCostPerMillion;
        }
        $this->repository->complete($usageId, [
            'model'=>(string)($providerMetrics['model'] ?? ''),
            'input_tokens'=>$input,
            'output_tokens'=>$output,
            'total_tokens'=>max($input+$output,(int)($providerMetrics['total_tokens'] ?? 0)),
            'estimated_cost'=>$cost,
            'latency_ms'=>(int)($providerMetrics['latency_ms'] ?? 0),
            'request_id'=>$providerMetrics['request_id'] ?? null,
            'result_count'=>$resultCount,
        ]);
    }

    public function fail(int $usageId, string $errorCode, int $latencyMs = 0): void
    {
        $this->repository->fail($usageId,$errorCode,$latencyMs);
    }

    private function secondsToReset(): int
    {
        return max(60, strtotime('tomorrow') - time() + 5);
    }

    private function resetAt(): string
    {
        return date(DATE_ATOM, strtotime('tomorrow'));
    }

    private function truncate(string $value, int $max): string
    {
        return function_exists('mb_substr') ? mb_substr($value,0,$max,'UTF-8') : substr($value,0,$max);
    }
}
