<?php
declare(strict_types=1);

namespace Mahda\Modules\AiSearch;

use PDO;
use RuntimeException;

final class AiSearchService
{
    public function __construct(
        private PDO $db,
        private QueryIntentService $intentService,
        private AiSearchRepository $repository,
        private SearchRankingService $ranking,
        private AiUsageService $usage,
        private TaxonomyRepository $taxonomy,
        private AiCircuitBreaker $circuit,
        private array $config,
    ) {}

    /** @return array<string,mixed> */
    public function search(array $user,string $query): array
    {
        if (!(bool)($this->config['enabled']??false)) throw new RuntimeException('ai_search_disabled');
        if (trim((string)($this->config['api_key']??''))==='') throw new RuntimeException('ai_not_configured');
        $query=trim($query); if($query==='') throw new RuntimeException('ai_query_required');
        if((function_exists('mb_strlen')?mb_strlen($query,'UTF-8'):strlen($query))>500) throw new RuntimeException('ai_query_too_long');

        $clarification=$this->intentService->clarification($query);
        if($clarification){
            return ['kind'=>'clarification','query'=>$query,'clarification'=>$clarification,'meta'=>['daily_remaining'=>$this->usage->quota((int)$user['id'])['remaining']]];
        }
        if($this->circuit->isOpen()) throw new RuntimeException('ai_circuit_open');

        $reserved=null;
        $providerStarted=microtime(true);
        try{
            $analysis=$this->intentService->analyze($query,function() use($user,$query,&$reserved):void{
                $reserved=$this->usage->reserve((int)$user['id'],(int)($user['profile_id']??0),(string)($this->config['provider']??''),(string)($this->config['model']??''),$query);
            });
            $intent=$analysis['intent'];
            $intent=$this->applyProfilePreferences((int)($user['profile_id']??0),$intent);
            $candidates=$this->repository->candidates($intent);
            $ranked=$this->ranking->rank($intent,$candidates,(int)($this->config['max_results']??6));
            $rows=$ranked['rows'];
            $items=function_exists('mahda_items')?\mahda_items($this->db,$rows):[];
            if($reserved){$this->usage->complete((int)$reserved['id'],$analysis['provider'],count($items));}
            $this->circuit->success();
            $quota=$this->usage->quota((int)$user['id']);
            return [
                'kind'=>'results','query'=>$query,'interpreted_as'=>$this->interpreted($intent),
                'match_type'=>$ranked['match_type'],'items'=>$items,
                'meta'=>['limit'=>(int)($this->config['max_results']??6),'daily_remaining'=>$quota['remaining'],'cache_hit'=>(bool)$analysis['cache_hit']],
            ];
        }catch(\Throwable $e){
            if($reserved){$this->usage->fail((int)$reserved['id'],$e->getMessage(),(int)round((microtime(true)-$providerStarted)*1000));}
            if(str_starts_with($e->getMessage(),'ai_')&&!in_array($e->getMessage(),['ai_daily_limit_reached','ai_query_required','ai_query_too_long'],true))$this->circuit->failure();
            throw $e;
        }
    }

    /** @return array<string,mixed> */
    public function quota(array $user): array
    {
        $q=$this->usage->quota((int)$user['id']);
        return array_merge($q,['enabled'=>(bool)($this->config['enabled']??false),'configured'=>trim((string)($this->config['api_key']??''))!=='']);
    }

    /** @param array<string,mixed> $intent @return array<string,mixed> */
    private function applyProfilePreferences(int $profileId,array $intent): array
    {
        if($profileId<1||!empty($intent['age_group'])||$intent['age_min']!==null||$intent['age_max']!==null)return $intent;
        $stmt=$this->db->prepare('SELECT profile_data_json FROM mahda_profiles WHERE id=? LIMIT 1');$stmt->execute([$profileId]);
        $data=json_decode((string)($stmt->fetchColumn()?:''),true); if(!is_array($data))return $intent;
        $ages=is_array($data['ages']??null)?$data['ages']:[];
        foreach($ages as $age){$v=strtr((string)$age,['۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','۱۰'=>'10']); if(str_contains($v,'4')&&str_contains($v,'6')){$intent['age_group']='4-6';break;} if(str_contains($v,'7')&&str_contains($v,'10')){$intent['age_group']='7-10';break;}}
        return $intent;
    }

    /** @param array<string,mixed> $intent @return array<string,mixed> */
    private function interpreted(array $intent): array
    {
        $catMap=[];foreach($this->taxonomy->categories() as $x)$catMap[$x['id']]=$x['label'];
        $occMap=[];foreach($this->taxonomy->occasions() as $x)$occMap[$x['id']]=$x['label'];
        $goalMap=[];foreach($this->taxonomy->goals() as $x)$goalMap[$x['id']]=$x['label'];
        return [
            'normalized_query'=>$intent['normalized_query']??'',
            'category'=>isset($intent['category_id'])?($catMap[$intent['category_id']]??null):null,
            'occasion'=>isset($intent['occasion_id'])?($occMap[(int)$intent['occasion_id']]??null):null,
            'goals'=>array_values(array_filter(array_map(fn($id)=>$goalMap[(int)$id]??null,$intent['goal_ids']??[]))),
            'age'=>$intent['age_group']??null,'equipment'=>$intent['equipment']??null,'activity_level'=>$intent['activity_level']??null,'space'=>$intent['space']??null,
            'keywords'=>$intent['keywords']??[],
        ];
    }
}
