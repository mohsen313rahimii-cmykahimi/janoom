<?php
declare(strict_types=1);

namespace Mahda\Modules\AiSearch;

use PDO;
use PDOException;

final class AiUsageRepository
{
    public function __construct(private PDO $db) {}

    public function countForDay(int $userId, string $date): int
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM mahda_ai_search_usages WHERE user_id=? AND usage_date=? AND status IN ('processing','success')");
        $stmt->execute([$userId, $date]);
        return (int)$stmt->fetchColumn();
    }

    /** @return array{id:int,slot:int}|null */
    public function reserve(int $userId, int $profileId, string $date, int $limit, array $meta): ?array
    {
        $limit = max(1, min(5, $limit));
        $sql = "INSERT INTO mahda_ai_search_usages
            (user_id,profile_id,usage_date,usage_slot,provider,model,query_hash,query_text,status,created_at)
            VALUES(?,?,?,?,?,?,?,?, 'processing', NOW())";
        $stmt = $this->db->prepare($sql);
        for ($slot = 1; $slot <= $limit; $slot++) {
            try {
                $stmt->execute([
                    $userId,
                    $profileId > 0 ? $profileId : null,
                    $date,
                    $slot,
                    (string)($meta['provider'] ?? ''),
                    (string)($meta['model'] ?? ''),
                    (string)($meta['query_hash'] ?? ''),
                    (string)($meta['query_text'] ?? ''),
                ]);
                return ['id'=>(int)$this->db->lastInsertId(),'slot'=>$slot];
            } catch (PDOException $e) {
                if ((string)($e->errorInfo[0] ?? '') !== '23000') throw $e;
            }
        }
        return null;
    }

    /** @param array<string,mixed> $metrics */
    public function complete(int $id, array $metrics): void
    {
        $stmt = $this->db->prepare("UPDATE mahda_ai_search_usages SET
            model=COALESCE(NULLIF(?,''),model),input_tokens=?,output_tokens=?,total_tokens=?,estimated_cost=?,latency_ms=?,result_count=?,status='success',error_code=NULL,request_id=?,completed_at=NOW()
            WHERE id=?");
        $stmt->execute([
            (string)($metrics['model'] ?? ''),
            max(0,(int)($metrics['input_tokens'] ?? 0)),
            max(0,(int)($metrics['output_tokens'] ?? 0)),
            max(0,(int)($metrics['total_tokens'] ?? 0)),
            $metrics['estimated_cost'] ?? null,
            max(0,(int)($metrics['latency_ms'] ?? 0)),
            max(0,(int)($metrics['result_count'] ?? 0)),
            ($metrics['request_id'] ?? null) ?: null,
            $id,
        ]);
    }

    public function fail(int $id, string $errorCode, int $latencyMs = 0): void
    {
        $stmt = $this->db->prepare("UPDATE mahda_ai_search_usages SET usage_slot=-id,status='failed',error_code=?,latency_ms=?,completed_at=NOW() WHERE id=?");
        $stmt->execute([substr($errorCode,0,80),max(0,$latencyMs),$id]);
    }
}
