<?php
declare(strict_types=1);

function mahda_migrate_ai_search_v29(PDO $db): void
{
    if (!function_exists('mahda_table_exists') || !mahda_table_exists($db,'mahda_migrations')) return;
    $exists=$db->prepare('SELECT 1 FROM mahda_migrations WHERE version=29 LIMIT 1');
    $exists->execute(); if($exists->fetchColumn()) return;
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_ai_search_usages (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        profile_id BIGINT UNSIGNED NULL,
        usage_date DATE NOT NULL,
        usage_slot TINYINT UNSIGNED NOT NULL DEFAULT 1,
        provider VARCHAR(40) NOT NULL,
        model VARCHAR(120) NOT NULL,
        query_hash CHAR(64) NOT NULL,
        query_text VARCHAR(1000) NULL,
        input_tokens INT UNSIGNED NOT NULL DEFAULT 0,
        output_tokens INT UNSIGNED NOT NULL DEFAULT 0,
        total_tokens INT UNSIGNED NOT NULL DEFAULT 0,
        estimated_cost DECIMAL(14,8) NULL,
        latency_ms INT UNSIGNED NOT NULL DEFAULT 0,
        result_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        status VARCHAR(24) NOT NULL DEFAULT 'processing',
        error_code VARCHAR(80) NULL,
        request_id VARCHAR(190) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        completed_at DATETIME NULL,
        UNIQUE KEY ux_ai_usage_daily_slot(user_id,usage_date,usage_slot),
        KEY ix_ai_usage_created(created_at),
        KEY ix_ai_usage_status(status,created_at),
        KEY ix_ai_usage_query_hash(query_hash,created_at),
        KEY ix_ai_usage_profile(profile_id,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(29)')->execute();
}


function mahda_migrate_ai_search_v30(PDO $db): void
{
    if (!function_exists('mahda_table_exists') || !mahda_table_exists($db,'mahda_ai_search_usages')) return;
    if (!mahda_table_exists($db,'mahda_migrations')) return;
    $exists=$db->prepare('SELECT 1 FROM mahda_migrations WHERE version=30 LIMIT 1');
    $exists->execute(); if($exists->fetchColumn()) return;
    // Failed provider calls must not permanently occupy the user's daily slot.
    $db->exec('ALTER TABLE mahda_ai_search_usages MODIFY usage_slot INT NOT NULL DEFAULT 1');
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(30)')->execute();
}
