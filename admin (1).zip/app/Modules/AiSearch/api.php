<?php
declare(strict_types=1);

use Mahda\Core\Ai\AiProviderFactory;
use Mahda\Modules\AiSearch\AiCircuitBreaker;
use Mahda\Modules\AiSearch\AiSearchRepository;
use Mahda\Modules\AiSearch\AiSearchService;
use Mahda\Modules\AiSearch\AiUsageRepository;
use Mahda\Modules\AiSearch\AiUsageService;
use Mahda\Modules\AiSearch\PersianNormalizer;
use Mahda\Modules\AiSearch\QueryIntentService;
use Mahda\Modules\AiSearch\SearchRankingService;
use Mahda\Modules\AiSearch\TaxonomyRepository;

function mahda_ai_search_module_dispatch(PDO $db,string $action): bool
{
    if(!in_array($action,['ai_search','ai_search_quota'],true))return false;
    // Shared-host self-healing install: users without CLI/Terminal should not
    // see the feature as disabled just because migration 29 has not run yet.
    // The migration is idempotent and returns immediately after first success.
    mahda_migrate_ai_search_v29($db);
    mahda_migrate_ai_search_v30($db);
    $user=mahda_current_user($db,true);
    if(!empty($user['guest']))mahda_json(['error'=>'auth_required','message'=>'برای استفاده از جستجوی هوشمند وارد حساب شوید.'],401);
    $config=mahda_ai_search_config();
    $normalizer=new PersianNormalizer();
    $taxonomy=new TaxonomyRepository($db);
    $redis=mahda_redis_client();
    $usage=new AiUsageService(new AiUsageRepository($db),$redis,(int)($config['daily_limit']??1),(float)($config['input_cost_per_million']??0),(float)($config['output_cost_per_million']??0));

    if($action==='ai_search_quota'&&($_SERVER['REQUEST_METHOD']??'GET')==='GET'){
        $quota=$usage->quota((int)$user['id']);
        $enabled=(bool)($config['enabled']??false);
        $configured=trim((string)($config['api_key']??''))!=='';
        mahda_json(array_merge($quota,[
            'enabled'=>$enabled,
            'configured'=>$configured,
            'transport'=>function_exists('curl_init')?'curl':'missing',
            'model'=>(string)($config['model']??''),
            'status'=>($enabled&&$configured&&function_exists('curl_init'))?'ready':'configuration_required'
        ]));
    }
    if($action==='ai_search'&&($_SERVER['REQUEST_METHOD']??'')==='POST'){
        $data=mahda_request_data(); mahda_require_csrf($data);
        $query=mahda_string($data['query']??'',500);
        try{
            $provider=AiProviderFactory::make($config);
            $intent=new QueryIntentService($provider,$taxonomy,$normalizer,$redis,(int)($config['analysis_cache_ttl']??21600));
            $circuit=new AiCircuitBreaker($redis,(int)($config['circuit_failure_threshold']??4),(int)($config['circuit_window_seconds']??300),(int)($config['circuit_open_seconds']??180));
            $service=new AiSearchService($db,$intent,new AiSearchRepository($db,$normalizer),new SearchRankingService($normalizer),$usage,$taxonomy,$circuit,$config);
            $result=$service->search($user,$query);
            if(($result['kind']??'')==='clarification')mahda_json(['success'=>true,'data'=>$result,'meta'=>['daily_remaining'=>$result['meta']['daily_remaining']??null]],200);
            mahda_json(['success'=>true,'data'=>['query'=>$result['query'],'interpreted_as'=>$result['interpreted_as'],'match_type'=>$result['match_type'],'items'=>$result['items']], 'meta'=>$result['meta']]);
        }catch(RuntimeException $e){
            $code=$e->getMessage();
            $status=match($code){'ai_daily_limit_reached'=>429,'ai_query_required','ai_query_too_long'=>422,'ai_search_disabled','ai_not_configured'=>503,'ai_circuit_open','ai_timeout','ai_provider_unavailable','ai_provider_rate_limited','ai_transport_error','ai_transport_unavailable','ai_dns_error','ai_connect_error','ai_ssl_error','ai_auth_error','ai_invalid_response','ai_invalid_json','ai_provider_error'=>503,default=>500};
            $messages=[
                'ai_daily_limit_reached'=>'جستجوی هوشمند امروزت استفاده شده؛ فردا دوباره می‌تونی استفاده کنی.',
                'ai_auth_error'=>'کلید SeekAI پذیرفته نشد. کلید API باید بررسی یا تعویض شود.',
                'ai_dns_error'=>'هاست مهدا نمی‌تواند آدرس seekai.cc را پیدا کند. دسترسی خروجی/DNS هاست باید فعال باشد.',
                'ai_connect_error'=>'هاست مهدا نتوانست به SeekAI وصل شود. اتصال خروجی HTTPS هاست باید بررسی شود.',
                'ai_ssl_error'=>'اتصال امن HTTPS از هاست به SeekAI برقرار نشد. تنظیمات SSL/cURL هاست باید بررسی شود.',
                'ai_timeout'=>'ارتباط با SeekAI بیش از حد طول کشید. چند لحظه بعد دوباره تلاش کنید.',
                'ai_provider_rate_limited'=>'SeekAI فعلاً محدودیت درخواست اعمال کرده است. کمی بعد دوباره تلاش کنید.',
                'ai_transport_unavailable'=>'افزونه cURL روی هاست فعال نیست و برای اتصال به SeekAI لازم است.',
                'ai_invalid_json'=>'پاسخ مدل قابل پردازش نبود. دوباره تلاش کنید.',
                'ai_provider_error'=>'SeekAI درخواست را نپذیرفت. مدل یا تنظیمات Provider باید بررسی شود.',
            ];
            mahda_json(['error'=>$code,'message'=>$messages[$code]??'جستجوی هوشمند فعلاً در دسترس نیست؛ می‌تونی از جستجوی معمولی استفاده کنی.'],$status);
        }
    }
    mahda_json(['error'=>'method_not_allowed'],405);
    return true;
}
