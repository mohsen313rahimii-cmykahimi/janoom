<?php
declare(strict_types=1);

namespace Mahda\Modules\AiSearch;

final class SearchRankingService
{
    public function __construct(private PersianNormalizer $normalizer) {}

    /**
     * @param array<string,mixed> $intent
     * @param list<array<string,mixed>> $candidates
     * @return array{match_type:string,rows:list<array<string,mixed>>}
     */
    public function rank(array $intent, array $candidates, int $limit): array
    {
        $scored = [];
        foreach ($candidates as $row) {
            $score = $this->score($intent,$row);
            $exact = $this->isExact($intent,$row);
            $primary = $this->primaryMatchCount($intent,$row);
            $scored[] = ['row'=>$row,'score'=>$score,'exact'=>$exact,'primary'=>$primary];
        }
        $exact = array_values(array_filter($scored, static fn(array $x): bool => $x['exact']));
        $pool = $exact ?: $scored;

        // If we need nearest results and a primary intent exists, do not drift to unrelated content.
        if (!$exact && ((string)($intent['category_id'] ?? '') !== '' || (int)($intent['occasion_id'] ?? 0) > 0)) {
            $primaryPool = array_values(array_filter($pool, static fn(array $x): bool => $x['primary'] > 0));
            if ($primaryPool) $pool = $primaryPool;
        }
        usort($pool, static function(array $a,array $b): int {
            if ($a['score'] !== $b['score']) return $b['score'] <=> $a['score'];
            return (int)$b['row']['id'] <=> (int)$a['row']['id'];
        });
        $rows = array_map(static fn(array $x): array => $x['row'], array_slice($pool,0,max(1,$limit)));
        return ['match_type'=>$exact ? 'exact' : 'nearest','rows'=>$rows];
    }

    /** @param array<string,mixed> $intent @param array<string,mixed> $row */
    private function score(array $intent,array $row): int
    {
        $score = 0;
        $category = (string)($intent['category_id'] ?? '');
        if ($category !== '') $score += ((string)$row['category_id'] === $category) ? 32 : -8;
        $occasion = (int)($intent['occasion_id'] ?? 0);
        if ($occasion > 0) $score += in_array($occasion,$row['_occasion_ids'] ?? [],true) ? 36 : -12;
        $goals = array_values(array_filter(array_map('intval',is_array($intent['goal_ids'] ?? null)?$intent['goal_ids']:[])));
        if ($goals) {
            $matches = count(array_intersect($goals,$row['_goal_ids'] ?? []));
            $score += $matches > 0 ? min(24,12 + $matches * 6) : -5;
        }
        $age = (string)($intent['age_group'] ?? '');
        if ($age === '4-6') $score += (int)$row['age_4_6'] === 1 ? 20 : -9;
        elseif ($age === '7-10') $score += (int)$row['age_7_10'] === 1 ? 20 : -9;
        $equipment = (string)($intent['equipment'] ?? '');
        if ($equipment === 'none') $score += (int)$row['tool_free'] === 1 ? 12 : -7;
        $activity = (string)($intent['activity_level'] ?? '');
        if ($activity !== '') $score += (string)($row['activity_level'] ?? '') === $activity ? 8 : -3;
        $space = (string)($intent['space'] ?? '');
        if ($space === 'indoor') $score += (int)$row['indoor'] === 1 ? 6 : -2;
        elseif ($space === 'outdoor') $score += (int)$row['outdoor'] === 1 ? 6 : -2;
        $text = (string)($row['_search_text'] ?? '');
        $kwPoints = 0;
        foreach (array_slice(is_array($intent['keywords'] ?? null)?$intent['keywords']:[],0,6) as $keyword) {
            $keyword = $this->normalizer->normalize((string)$keyword);
            if ($keyword !== '' && str_contains($text,$keyword)) $kwPoints += 4;
        }
        $score += min(20,$kwPoints);
        return $score;
    }

    /** @param array<string,mixed> $intent @param array<string,mixed> $row */
    private function isExact(array $intent,array $row): bool
    {
        $category=(string)($intent['category_id']??''); if($category!==''&&(string)$row['category_id']!==$category)return false;
        $occasion=(int)($intent['occasion_id']??0); if($occasion>0&&!in_array($occasion,$row['_occasion_ids']??[],true))return false;
        $goals=array_values(array_filter(array_map('intval',is_array($intent['goal_ids']??null)?$intent['goal_ids']:[]))); if($goals&&!array_intersect($goals,$row['_goal_ids']??[]))return false;
        $age=(string)($intent['age_group']??''); if($age==='4-6'&&(int)$row['age_4_6']!==1)return false; if($age==='7-10'&&(int)$row['age_7_10']!==1)return false;
        if((string)($intent['equipment']??'')==='none'&&(int)$row['tool_free']!==1)return false;
        $activity=(string)($intent['activity_level']??''); if($activity!==''&&(string)($row['activity_level']??'')!==$activity)return false;
        $space=(string)($intent['space']??''); if($space==='indoor'&&(int)$row['indoor']!==1)return false; if($space==='outdoor'&&(int)$row['outdoor']!==1)return false;
        return true;
    }

    /** @param array<string,mixed> $intent @param array<string,mixed> $row */
    private function primaryMatchCount(array $intent,array $row): int
    {
        $n=0;
        $category=(string)($intent['category_id']??''); if($category!==''&&(string)$row['category_id']===$category)$n++;
        $occasion=(int)($intent['occasion_id']??0); if($occasion>0&&in_array($occasion,$row['_occasion_ids']??[],true))$n++;
        return $n;
    }
}
