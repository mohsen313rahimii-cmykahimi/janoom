<?php
declare(strict_types=1);

namespace Mahda\Modules\AiSearch;

use Mahda\Core\Redis\RedisClient;

final class AiCircuitBreaker
{
    public function __construct(
        private ?RedisClient $redis,
        private int $threshold,
        private int $windowSeconds,
        private int $openSeconds,
    ) {}

    public function isOpen(): bool
    {
        return $this->redis?->get('ai-search:circuit:open') === '1';
    }

    public function success(): void
    {
        if (!$this->redis) return;
        $this->redis->delete('ai-search:circuit:open');
        $this->redis->delete('ai-search:circuit:failures');
    }

    public function failure(): void
    {
        if (!$this->redis) return;
        $count = $this->redis->incrementWindow('ai-search:circuit:failures', $this->windowSeconds);
        if ($count !== null && $count >= $this->threshold) {
            $this->redis->setEx('ai-search:circuit:open', $this->openSeconds, '1');
        }
    }
}
