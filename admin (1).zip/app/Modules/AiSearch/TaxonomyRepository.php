<?php
declare(strict_types=1);

namespace Mahda\Modules\AiSearch;

use PDO;

final class TaxonomyRepository
{
    public function __construct(private PDO $db) {}

    /** @return list<array{id:string,label:string}> */
    public function categories(): array
    {
        $stmt = $this->db->query("SELECT id,label FROM mahda_categories WHERE is_active=1 AND COALESCE(show_in_bank,1)=1 ORDER BY sort_order,id");
        return array_map(static fn(array $r): array => ['id'=>(string)$r['id'],'label'=>(string)$r['label']], $stmt->fetchAll());
    }

    /** @return list<array{id:int,label:string,aliases:list<string>}> */
    public function occasions(): array
    {
        $stmt = $this->db->query("SELECT id,label,aliases_json FROM mahda_occasions WHERE is_active=1 ORDER BY sort_order,id");
        $out = [];
        foreach ($stmt->fetchAll() as $row) {
            $aliases = json_decode((string)($row['aliases_json'] ?? ''), true);
            $out[] = ['id'=>(int)$row['id'],'label'=>(string)$row['label'],'aliases'=>is_array($aliases)?array_values(array_filter(array_map('strval',$aliases))):[]];
        }
        return $out;
    }

    /** @return list<array{id:int,label:string}> */
    public function goals(): array
    {
        $stmt = $this->db->query("SELECT id,label FROM mahda_goals WHERE is_active=1 ORDER BY sort_order,id");
        return array_map(static fn(array $r): array => ['id'=>(int)$r['id'],'label'=>(string)$r['label']], $stmt->fetchAll());
    }

    /** @return array<string,mixed> */
    public function compactPromptData(): array
    {
        return [
            'categories'=>$this->categories(),
            'occasions'=>array_map(static fn(array $r): array => ['id'=>$r['id'],'label'=>$r['label']], $this->occasions()),
            'goals'=>$this->goals(),
        ];
    }

    public function versionHash(): string
    {
        return substr(hash('sha256', json_encode($this->compactPromptData(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: ''), 0, 16);
    }
}
