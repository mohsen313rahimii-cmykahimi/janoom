<?php
declare(strict_types=1);

function mahda_ai_search_config(): array
{
    static $config;
    if(is_array($config??null))return $config;
    $path=dirname(__DIR__,3).'/config/ai.php';
    $config=is_file($path)?require $path:['enabled'=>false];
    return is_array($config)?$config:['enabled'=>false];
}
