<?php
declare(strict_types=1);

namespace Mahda\Modules\AiSearch;

final class PersianNormalizer
{
    public function normalize(string $value): string
    {
        $value = trim($value);
        $value = strtr($value, [
            'ي'=>'ی','ى'=>'ی','ئ'=>'ی','ك'=>'ک','ة'=>'ه','ۀ'=>'ه',
            'ؤ'=>'و','إ'=>'ا','أ'=>'ا','ٱ'=>'ا',
            "\u{200C}"=>' ', "\u{200F}"=>' ', "\u{200E}"=>' ',
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ]);
        $value = preg_replace('/[\x{064B}-\x{065F}\x{0670}\x{06D6}-\x{06ED}]/u', '', $value) ?? $value;
        $value = preg_replace('/[،؛:!?؟!,.؛]+/u', ' ', $value) ?? $value;
        $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
        return trim($value);
    }

    /** @return list<string> */
    public function terms(string $value): array
    {
        $normalized = $this->normalize($value);
        if ($normalized === '') return [];
        $parts = preg_split('/\s+/u', $normalized) ?: [];
        $stop = array_flip(['یه','یک','برای','میخوام','میخاهم','میخواهم','مخوام','واسه','وا','از','به','با','که','رو','را','و','یا','در','روی','خود','لطفا','لطفاً','محتوا','فعالیت']);
        $out = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part === '' || isset($stop[$part])) continue;
            $len = function_exists('mb_strlen') ? mb_strlen($part, 'UTF-8') : strlen($part);
            if ($len < 2) continue;
            $out[$part] = $part;
        }
        return array_values($out);
    }
}
