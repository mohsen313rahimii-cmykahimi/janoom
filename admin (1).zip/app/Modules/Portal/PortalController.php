<?php
declare(strict_types=1);
namespace Mahda\Modules\Portal;
use Mahda\Core\Request;
use Mahda\Core\View;
final class PortalController
{
    public function __construct(private View $view) {}
    public function academy(Request $request): string { return $this->view->render('pages/portal/academy'); }
    public function heiat(Request $request): string { return $this->view->render('pages/portal/heiat'); }
    public function connection(Request $request): string { return $this->view->render('pages/portal/connection'); }
}
