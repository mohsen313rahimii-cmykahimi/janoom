<?php
declare(strict_types=1);
namespace Mahda\Modules\Portal;
use Mahda\Core\Router;
use Mahda\Core\View;
return static function (Router $router, View $view): void {
    $controller = new PortalController($view);
    $router->get('/academy', [$controller, 'academy']);
    $router->get('/heiat', [$controller, 'heiat']);
    $router->get('/connection', [$controller, 'connection']);
};
