<?php
declare(strict_types=1);

use Mahda\Modules\Auth\AuthRepository;
use Mahda\Modules\Mobile\MobileTokenService;
use Mahda\Modules\OfflineSync\DraftSyncService;


function mahda_mobile_require_complete_profile(PDO $db, array $user): void
{
    $stmt = $db->prepare('SELECT kind,name,city,profile_data_json FROM mahda_profiles WHERE id=? AND owner_id=? LIMIT 1');
    $stmt->execute([(int)($user['profile_id'] ?? 0), (int)($user['id'] ?? 0)]);
    $profile = $stmt->fetch();
    if (!$profile) throw new RuntimeException('profile_incomplete');
    $data = json_decode((string)($profile['profile_data_json'] ?? ''), true);
    if (!is_array($data)) $data = [];
    if (!mahda_profile_complete(
        $data,
        (string)$profile['kind'],
        (string)($user['display_name'] ?? ''),
        (string)$profile['name'],
        (string)($profile['city'] ?? '')
    )) {
        throw new RuntimeException('profile_incomplete');
    }
}

function mahda_offline_sync_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['mobile_sync_drafts_push','mobile_sync_drafts_pull'], true)) return false;

    try {
        $repo = new AuthRepository($db);
        $tokens = new MobileTokenService($db, $repo);
        $user = $tokens->authenticateBearer();
        mahda_mobile_require_complete_profile($db, $user);
        $ownerId = (int)$user['id'];
        $profileId = (int)$user['profile_id'];
        $sync = new DraftSyncService($db);

        if ($action === 'mobile_sync_drafts_push' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            mahda_enforce_rate_limit($db, 'mobile_sync_drafts_push', 120, 300);
            $data = mahda_request_data();
            $changes = is_array($data['changes'] ?? null) ? $data['changes'] : [];
            mahda_json($sync->push($ownerId, $profileId, $changes));
        }

        if ($action === 'mobile_sync_drafts_pull' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            mahda_enforce_rate_limit($db, 'mobile_sync_drafts_pull', 180, 300);
            $cursor = max(0, (int)($_GET['cursor'] ?? 0));
            $limit = max(1, min(100, (int)($_GET['limit'] ?? 50)));
            mahda_json($sync->pull($ownerId, $cursor, $limit));
        }

        mahda_json(['error'=>'method_not_allowed'],405);
    } catch (RuntimeException $e) {
        $safe = ['mobile_auth_required','too_many_sync_changes','invalid_draft_key','draft_too_large','temporary_file_reference_not_allowed','invalid_category','profile_not_owned','profile_incomplete'];
        $message = in_array($e->getMessage(), $safe, true) ? $e->getMessage() : 'sync_failed';
        $status = $message === 'mobile_auth_required' ? 401 : ($message === 'profile_incomplete' ? 403 : ($message === 'too_many_sync_changes' ? 413 : 422));
        mahda_json(['error'=>$message], $status);
    }

    return true;
}
