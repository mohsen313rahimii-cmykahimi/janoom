<?php
declare(strict_types=1);

function mahda_record_sync_change(PDO $db, int $ownerId, string $entityType, int $entityId, int $version): void
{
    if ($ownerId < 1 || $entityId < 1 || !mahda_table_exists($db, 'mahda_sync_changes')) return;
    $stmt = $db->prepare('INSERT INTO mahda_sync_changes(owner_id,entity_type,entity_id,entity_version) VALUES(?,?,?,?)');
    $stmt->execute([$ownerId, $entityType, $entityId, max(0, $version)]);
}
