<?php
declare(strict_types=1);

namespace Mahda\Modules\OfflineSync;

use PDO;
use RuntimeException;

final class DraftSyncService
{
    public function __construct(private PDO $db)
    {
    }

    /** @param array<int,mixed> $changes */
    public function push(int $ownerId, int $defaultProfileId, array $changes): array
    {
        if (count($changes) > 25) throw new RuntimeException('too_many_sync_changes');
        $results = [];
        foreach ($changes as $index => $change) {
            if (!is_array($change)) {
                $results[] = ['index'=>$index,'status'=>'invalid','error'=>'invalid_sync_change'];
                continue;
            }
            try {
                $results[] = array_merge(['index'=>$index], $this->pushOne($ownerId, $defaultProfileId, $change));
            } catch (RuntimeException $e) {
                $results[] = ['index'=>$index,'status'=>'invalid','error'=>$e->getMessage()];
            }
        }
        return ['results'=>$results,'serverTime'=>gmdate('c')];
    }

    public function pull(int $ownerId, int $cursor, int $limit = 50): array
    {
        $cursor = max(0, $cursor);
        $limit = max(1, min(100, $limit));
        $stmt = $this->db->prepare("SELECT id,entity_id,entity_version FROM mahda_sync_changes WHERE owner_id=? AND entity_type='content_draft' AND id>? ORDER BY id ASC LIMIT " . ($limit + 1));
        $stmt->execute([$ownerId, $cursor]);
        $rows = $stmt->fetchAll();
        $hasMore = count($rows) > $limit;
        if ($hasMore) $rows = array_slice($rows, 0, $limit);
        if (!$rows) return ['changes'=>[],'nextCursor'=>$cursor,'hasMore'=>false,'serverTime'=>gmdate('c')];

        $nextCursor = (int)$rows[count($rows)-1]['id'];
        $latest = [];
        foreach ($rows as $row) $latest[(int)$row['entity_id']] = (int)$row['entity_version'];
        $ids = array_keys($latest);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $draftStmt = $this->db->prepare("SELECT * FROM mahda_content_drafts WHERE owner_id=? AND id IN ({$placeholders})");
        $draftStmt->execute(array_merge([$ownerId], $ids));
        $drafts = [];
        foreach ($draftStmt->fetchAll() as $row) $drafts[(int)$row['id']] = $row;

        $filesByDraft = [];
        if ($ids && function_exists('mahda_table_exists') && mahda_table_exists($this->db, 'mahda_files')) {
            $fileStmt = $this->db->prepare("SELECT id,draft_id,purpose,original_name,mime_type,size_bytes,status,processing_error,width,height,created_at FROM mahda_files WHERE owner_id=? AND draft_id IN ({$placeholders}) ORDER BY draft_id,purpose,id");
            $fileStmt->execute(array_merge([$ownerId], $ids));
            foreach ($fileStmt->fetchAll() as $f) {
                $draftId = (int)$f['draft_id'];
                $filesByDraft[$draftId][] = [
                    'id'=>(int)$f['id'],'purpose'=>(string)$f['purpose'],'name'=>(string)$f['original_name'],
                    'mime'=>(string)$f['mime_type'],'size'=>(int)$f['size_bytes'],'status'=>(string)($f['status']??'ready'),
                    'error'=>(string)($f['processing_error']??''),'width'=>$f['width']===null?null:(int)$f['width'],
                    'height'=>$f['height']===null?null:(int)$f['height'],
                ];
            }
        }

        $payloads = [];
        foreach ($ids as $id) {
            if (!isset($drafts[$id])) continue;
            $row = $drafts[$id];
            $data = json_decode((string)($row['data_json'] ?? ''), true);
            if (!is_array($data)) $data = [];
            $payloads[] = [
                'entity'=>'contentDraft','draft'=>[
                    'id'=>(int)$row['id'],'clientKey'=>(string)$row['client_key'],'category'=>(string)($row['category_id']??''),
                    'profileId'=>$row['profile_id']===null?null:(int)$row['profile_id'],'step'=>(int)$row['current_step'],
                    'version'=>(int)$row['version'],'data'=>$data,'files'=>$filesByDraft[$id]??[],
                    'completedContentId'=>$row['completed_content_id']===null?null:(int)$row['completed_content_id'],
                    'updatedAt'=>(string)$row['updated_at'],
                ]
            ];
        }
        return ['changes'=>$payloads,'nextCursor'=>$nextCursor,'hasMore'=>$hasMore,'serverTime'=>gmdate('c')];
    }

    /** @param array<string,mixed>|null $draft */
    private function mobileDraftPayload(?array $draft): ?array
    {
        if ($draft === null) return null;
        if (isset($draft['files']) && is_array($draft['files'])) {
            foreach ($draft['files'] as &$file) {
                if (is_array($file)) unset($file['url']);
            }
            unset($file);
        }
        return $draft;
    }

    private function pushOne(int $ownerId, int $defaultProfileId, array $change): array
    {
        $clientKey = trim((string)($change['clientKey'] ?? ''));
        if ($clientKey === '' || preg_match('/^[A-Za-z0-9_-]{10,80}$/', $clientKey) !== 1) throw new RuntimeException('invalid_draft_key');
        $baseVersion = max(0, (int)($change['baseVersion'] ?? 0));
        $step = max(1, min(9, (int)($change['step'] ?? 1)));
        $payload = is_array($change['data'] ?? null) ? $change['data'] : [];
        $raw = json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if (!is_string($raw) || strlen($raw) > 450000) throw new RuntimeException('draft_too_large');
        if (preg_match('/(?:blob:|data:[^,]{0,80};base64,)/i', $raw)) throw new RuntimeException('temporary_file_reference_not_allowed');

        $this->db->beginTransaction();
        try {
            $find = $this->db->prepare('SELECT * FROM mahda_content_drafts WHERE owner_id=? AND client_key=? LIMIT 1 FOR UPDATE');
            $find->execute([$ownerId, $clientKey]);
            $draft = $find->fetch();

            if (!$draft) {
                if ($baseVersion !== 0) {
                    $this->db->rollBack();
                    return ['status'=>'conflict','reason'=>'draft_missing_on_server','draft'=>null];
                }
                $this->db->prepare('INSERT INTO mahda_content_drafts(owner_id,profile_id,client_key,data_json,version,current_step) VALUES(?,?,?,?,1,?)')
                    ->execute([$ownerId, $defaultProfileId, $clientKey, '{}', $step]);
                $draftId = (int)$this->db->lastInsertId();
                $payload = \mahda_sanitize_content_draft_v13($this->db, $payload, $ownerId, $draftId);
                $encoded = json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                if (!is_string($encoded) || strlen($encoded) > 450000) throw new RuntimeException('draft_too_large');
                $profileId = max(0, (int)($payload['profileId'] ?? $defaultProfileId));
                $category = \mahda_string($payload['category'] ?? '', 40);
                $this->db->prepare('UPDATE mahda_content_drafts SET profile_id=?,category_id=?,current_step=?,data_json=? WHERE id=? AND owner_id=?')
                    ->execute([$profileId ?: null, $category ?: null, $step, $encoded, $draftId, $ownerId]);
                \mahda_record_sync_change($this->db, $ownerId, 'content_draft', $draftId, 1);
                $this->db->commit();
                return ['status'=>'applied','draft'=>$this->mobileDraftPayload(\mahda_draft_payload($this->db, $draftId, $ownerId))];
            }

            $draftId = (int)$draft['id'];
            if ($draft['completed_at'] !== null) {
                $this->db->rollBack();
                return ['status'=>'conflict','reason'=>'draft_completed','draft'=>$this->mobileDraftPayload(\mahda_draft_payload($this->db, $draftId, $ownerId))];
            }
            if ((int)$draft['version'] !== $baseVersion) {
                $this->db->rollBack();
                return ['status'=>'conflict','reason'=>'version_mismatch','draft'=>$this->mobileDraftPayload(\mahda_draft_payload($this->db, $draftId, $ownerId))];
            }

            $payload = \mahda_sanitize_content_draft_v13($this->db, $payload, $ownerId, $draftId);
            $encoded = json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            if (!is_string($encoded) || strlen($encoded) > 450000) throw new RuntimeException('draft_too_large');
            $profileId = max(0, (int)($payload['profileId'] ?? $defaultProfileId));
            $category = \mahda_string($payload['category'] ?? '', 40);
            $newVersion = $baseVersion + 1;
            $upd = $this->db->prepare('UPDATE mahda_content_drafts SET profile_id=?,category_id=?,current_step=?,data_json=?,version=? WHERE id=? AND owner_id=? AND completed_at IS NULL AND version=?');
            $upd->execute([$profileId ?: null, $category ?: null, $step, $encoded, $newVersion, $draftId, $ownerId, $baseVersion]);
            if ($upd->rowCount() !== 1) {
                $this->db->rollBack();
                return ['status'=>'conflict','reason'=>'version_mismatch','draft'=>$this->mobileDraftPayload(\mahda_draft_payload($this->db, $draftId, $ownerId))];
            }
            \mahda_record_sync_change($this->db, $ownerId, 'content_draft', $draftId, $newVersion);
            $this->db->commit();
            return ['status'=>'applied','draft'=>$this->mobileDraftPayload(\mahda_draft_payload($this->db, $draftId, $ownerId))];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }
}
