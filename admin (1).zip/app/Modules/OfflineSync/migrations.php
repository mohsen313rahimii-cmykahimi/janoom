<?php
declare(strict_types=1);

function mahda_migrate_offline_sync_v28(PDO $db): void
{
    if (!mahda_table_exists($db, 'mahda_migrations')) return;
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=28 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) return;

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_sync_changes (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        owner_id BIGINT UNSIGNED NOT NULL,
        entity_type VARCHAR(32) NOT NULL,
        entity_id BIGINT UNSIGNED NOT NULL,
        entity_version INT UNSIGNED NOT NULL DEFAULT 0,
        changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY ix_sync_owner_cursor(owner_id,id),
        KEY ix_sync_entity(owner_id,entity_type,entity_id,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if (mahda_table_exists($db, 'mahda_content_drafts')) {
        $db->exec("INSERT INTO mahda_sync_changes(owner_id,entity_type,entity_id,entity_version)
            SELECT owner_id,'content_draft',id,version FROM mahda_content_drafts");
    }

    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(28)')->execute();
}
