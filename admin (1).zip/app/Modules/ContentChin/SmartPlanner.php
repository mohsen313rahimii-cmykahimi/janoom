<?php
declare(strict_types=1);

namespace Mahda\Modules\ContentChin;

use PDO;

/**
 * Deterministic, database-backed planner for ContentChin.
 *
 * This intentionally does not call an LLM. It ranks only real, approved Mahda
 * contents against the brief saved on a plan and returns explainable reasons.
 */
final class SmartPlanner
{
    private const DEFAULT_LIMIT = 6;

    public function __construct(private PDO $db)
    {
    }

    /** @return array<string,mixed> */
    public function suggest(array $planRow, int $limit = self::DEFAULT_LIMIT): array
    {
        $limit = max(1, min(self::DEFAULT_LIMIT, $limit));
        $planId = (int)($planRow['id'] ?? 0);
        $data = json_decode((string)($planRow['data_json'] ?? ''), true);
        if (!is_array($data)) {
            $data = [];
        }

        $brief = $this->brief($planRow, $data);
        $rows = $this->candidateRows($planId, $brief, 220);
        if (!$rows) {
            return [
                'items' => [],
                'matchType' => 'none',
                'summary' => 'فعلاً محتوای تأییدشده‌ای با این معیارها پیدا نشد.',
                'criteria' => $this->criteriaPayload($brief),
                'targetDuration' => $brief['duration'],
                'estimatedDuration' => 0,
                'coverage' => [],
            ];
        }

        $maps = $this->relationMaps(array_map(static fn(array $row): int => (int)$row['id'], $rows));
        $scored = [];
        foreach ($rows as $row) {
            $entry = $this->scoreRow($row, $brief, $maps);
            if ($entry !== null) {
                $scored[] = $entry;
            }
        }

        if (!$scored) {
            return [
                'items' => [],
                'matchType' => 'none',
                'summary' => 'با شرط‌های فعلی، محتوای قابل استفاده‌ای پیدا نشد. یکی از معیارها را کمی بازتر کن.',
                'criteria' => $this->criteriaPayload($brief),
                'targetDuration' => $brief['duration'],
                'estimatedDuration' => 0,
                'coverage' => [],
            ];
        }

        $selected = $this->compose($scored, $brief, $limit);
        $selectedRows = array_map(static fn(array $entry): array => $entry['row'], $selected);
        $items = \mahda_items($this->db, $selectedRows);
        $result = [];
        $estimatedDuration = 0;
        $hasRelaxed = false;
        foreach ($items as $index => $item) {
            $meta = $selected[$index] ?? null;
            if (!$meta) {
                continue;
            }
            $duration = (int)($item['durationMinutes'] ?? 0);
            $estimatedDuration += max(0, $duration);
            if (!empty($meta['relaxed'])) {
                $hasRelaxed = true;
            }
            $item['smart'] = [
                'score' => (int)$meta['score'],
                'fit' => $this->fitLabel((int)$meta['score'], !empty($meta['relaxed'])),
                'reasons' => array_values($meta['reasons']),
                'relaxed' => array_values($meta['relaxed']),
                'slotLabel' => (string)($meta['slotLabel'] ?? ''),
            ];
            $result[] = $item;
        }

        $coverage = $this->coverage($result, $brief);
        $matchType = $result ? ($hasRelaxed ? 'nearest' : 'exact') : 'none';
        $summary = $matchType === 'exact'
            ? 'پیشنهادها با معیارهای اصلی برنامه هماهنگ‌اند.'
            : ($matchType === 'nearest'
                ? 'چند مورد کاملاً منطبق نبود؛ نزدیک‌ترین محتوای تأییدشده مهدا پیشنهاد شده است.'
                : 'فعلاً پیشنهادی پیدا نشد.');

        return [
            'items' => $result,
            'matchType' => $matchType,
            'summary' => $summary,
            'criteria' => $this->criteriaPayload($brief),
            'targetDuration' => $brief['duration'],
            'estimatedDuration' => $estimatedDuration,
            'coverage' => $coverage,
        ];
    }

    /** @return array<string,mixed> */
    private function brief(array $row, array $data): array
    {
        $goalIds = array_values(array_unique(array_filter(array_map('intval', is_array($data['goalIds'] ?? null) ? $data['goalIds'] : []), static fn(int $id): bool => $id > 0)));
        $toolPreference = in_array((string)($data['toolPreference'] ?? ''), ['any', 'none'], true) ? (string)$data['toolPreference'] : 'any';
        $activity = in_array((string)($data['activityPreference'] ?? ''), ['any', 'low', 'medium', 'high'], true) ? (string)$data['activityPreference'] : 'any';
        $space = in_array((string)($data['spacePreference'] ?? ''), ['any', 'indoor', 'outdoor'], true) ? (string)$data['spacePreference'] : 'any';
        return [
            'planType' => (string)($row['plan_type'] ?? 'free'),
            'occasionId' => $row['occasion_id'] === null ? 0 : (int)$row['occasion_id'],
            'ageGroup' => (string)($row['age_group'] ?? ''),
            'duration' => $row['suggested_duration_minutes'] === null ? 60 : (int)$row['suggested_duration_minutes'],
            'goalIds' => array_slice($goalIds, 0, 3),
            'toolPreference' => $toolPreference,
            'activityPreference' => $activity,
            'spacePreference' => $space,
        ];
    }

    /** @return array<int,array<string,mixed>> */
    private function candidateRows(int $planId, array $brief, int $limit): array
    {
        $where = [
            "p.name<>''",
            'owner.is_active=1',
            "owner.email NOT LIKE 'guest-%@mahda.local'",
            "owner.email NOT LIKE 'test-phone-%@mahda.local'",
            'c.archived_at IS NULL',
            "c.visibility<>'hidden'",
            "c.review_status='approved'",
            'cat.is_active=1',
            'COALESCE(cat.show_in_bank,1)=1',
            'NOT EXISTS (SELECT 1 FROM mahda_contentchin_plan_items pi WHERE pi.plan_id=? AND pi.content_id=c.id)',
        ];
        $params = [$planId];

        // Age and explicit "no tools" are hard safety/fit constraints. We do not
        // silently relax them because doing so surprises the planner.
        if ($brief['ageGroup'] === '4-6') {
            $where[] = 'c.age_4_6=1';
        } elseif ($brief['ageGroup'] === '7-10') {
            $where[] = 'c.age_7_10=1';
        }
        if ($brief['toolPreference'] === 'none') {
            $where[] = 'c.tool_free=1';
        }
        if ((int)$brief['occasionId'] > 0) {
            $where[] = '(c.general_occasion=1 OR EXISTS (SELECT 1 FROM mahda_content_occasions sco WHERE sco.content_id=c.id AND sco.occasion_id=?))';
            $params[] = (int)$brief['occasionId'];
        }

        $sql = 'SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color '
            . 'FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_users owner ON owner.id=c.author_id '
            . 'JOIN mahda_categories cat ON cat.id=c.category_id WHERE ' . implode(' AND ', $where)
            . ' ORDER BY c.created_at DESC,c.id DESC LIMIT ' . max(30, min(400, $limit));
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** @param list<int> $ids @return array<string,array<int,list<int>>> */
    private function relationMaps(array $ids): array
    {
        $goalMap = [];
        $occasionMap = [];
        if (!$ids) {
            return ['goals' => [], 'occasions' => []];
        }
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $this->db->prepare("SELECT content_id,goal_id FROM mahda_content_goals WHERE content_id IN ($ph)");
        $stmt->execute($ids);
        foreach ($stmt->fetchAll() as $row) {
            $goalMap[(int)$row['content_id']][] = (int)$row['goal_id'];
        }
        $stmt = $this->db->prepare("SELECT content_id,occasion_id FROM mahda_content_occasions WHERE content_id IN ($ph)");
        $stmt->execute($ids);
        foreach ($stmt->fetchAll() as $row) {
            $occasionMap[(int)$row['content_id']][] = (int)$row['occasion_id'];
        }
        return ['goals' => $goalMap, 'occasions' => $occasionMap];
    }

    /** @return array<string,mixed>|null */
    private function scoreRow(array $row, array $brief, array $maps): ?array
    {
        $id = (int)$row['id'];
        $score = 20; // Approved content baseline.
        $reasons = ['تأییدشده در بانک مهدا'];
        $relaxed = [];

        $occasionIds = $maps['occasions'][$id] ?? [];
        $occasionId = (int)$brief['occasionId'];
        $general = (bool)($row['general_occasion'] ?? false);
        if ($occasionId > 0) {
            if (in_array($occasionId, $occasionIds, true)) {
                $score += 38;
                $reasons[] = 'هم‌مناسبت با برنامه';
            } elseif ($general) {
                $score += 8;
                $reasons[] = 'قابل استفاده در مناسبت‌های مختلف';
                $relaxed[] = 'مناسبت';
            } else {
                $score -= 28;
                $relaxed[] = 'مناسبت';
            }
        } else {
            $score += $general ? 5 : 2;
        }

        $goalIds = $maps['goals'][$id] ?? [];
        $wantedGoals = $brief['goalIds'];
        if ($wantedGoals) {
            $matches = count(array_intersect($wantedGoals, $goalIds));
            if ($matches > 0) {
                $score += min(32, 18 + (($matches - 1) * 7));
                $reasons[] = $matches > 1 ? 'هم‌راستا با چند هدف تربیتی' : 'هم‌راستا با هدف تربیتی';
            } else {
                $score -= 8;
                $relaxed[] = 'هدف تربیتی';
            }
        }

        if ($brief['ageGroup'] === '4-6' && (int)($row['age_4_6'] ?? 0) === 1) {
            $score += 22;
            $reasons[] = 'مناسب ۴ تا ۶ سال';
        } elseif ($brief['ageGroup'] === '7-10' && (int)($row['age_7_10'] ?? 0) === 1) {
            $score += 22;
            $reasons[] = 'مناسب ۷ تا ۱۰ سال';
        }

        if ($brief['toolPreference'] === 'none') {
            $score += 20;
            $reasons[] = 'بدون وسیله';
        } elseif ((int)($row['tool_free'] ?? 0) === 1) {
            $score += 3;
        }

        $activity = (string)($row['activity_level'] ?? '');
        if ($brief['activityPreference'] !== 'any') {
            if ($activity === $brief['activityPreference']) {
                $score += 11;
                $reasons[] = 'ریتم اجرای هماهنگ';
            } elseif ($activity !== '') {
                $score -= 4;
                $relaxed[] = 'ریتم';
            }
        }

        if ($brief['spacePreference'] === 'indoor') {
            if ((int)($row['indoor'] ?? 0) === 1) {
                $score += 9;
                $reasons[] = 'مناسب فضای بسته';
            } else {
                $score -= 5;
                $relaxed[] = 'فضای اجرا';
            }
        } elseif ($brief['spacePreference'] === 'outdoor') {
            if ((int)($row['outdoor'] ?? 0) === 1) {
                $score += 9;
                $reasons[] = 'مناسب فضای باز';
            } else {
                $score -= 5;
                $relaxed[] = 'فضای اجرا';
            }
        }

        $duration = $row['duration_minutes'] === null ? 0 : (int)$row['duration_minutes'];
        if ($duration > 0) {
            $slotCount = $this->slotCount((int)$brief['duration']);
            $ideal = max(6, (int)round(((int)$brief['duration'] * 0.78) / max(1, $slotCount)));
            $distance = abs($duration - $ideal);
            if ($distance <= 4) {
                $score += 10;
                $reasons[] = 'زمان اجرای مناسب';
            } elseif ($distance <= 10) {
                $score += 5;
            } elseif ($duration > max(20, $ideal * 2)) {
                $score -= 8;
            }
        }

        return [
            'row' => $row,
            'score' => max(0, $score),
            'reasons' => array_values(array_unique($reasons)),
            'relaxed' => array_values(array_unique($relaxed)),
            'category' => (string)($row['category_id'] ?? ''),
            'authorId' => (int)($row['author_id'] ?? 0),
            'duration' => $duration,
        ];
    }

    /** @param array<int,array<string,mixed>> $scored @return array<int,array<string,mixed>> */
    private function compose(array $scored, array $brief, int $limit): array
    {
        $blueprint = $this->blueprint((string)$brief['planType'], (int)$brief['duration']);
        $targetCount = min($limit, max(2, count($blueprint)));
        $budget = max(18, (int)round((int)$brief['duration'] * 0.84));
        $selected = [];
        $usedIds = [];
        $categoryCounts = [];
        $authorCounts = [];
        $durationSum = 0;

        for ($slotIndex = 0; $slotIndex < $targetCount; $slotIndex++) {
            $preferredCategory = $blueprint[$slotIndex] ?? '';
            $best = null;
            $bestEffective = -9999;
            foreach ($scored as $entry) {
                $id = (int)$entry['row']['id'];
                if (isset($usedIds[$id])) {
                    continue;
                }
                $effective = (int)$entry['score'];
                $category = (string)$entry['category'];
                if ($preferredCategory !== '' && $category === $preferredCategory) {
                    $effective += 26;
                } elseif ($preferredCategory !== '') {
                    $effective -= 2;
                }
                $effective -= ((int)($categoryCounts[$category] ?? 0)) * 12;
                $effective -= ((int)($authorCounts[(int)$entry['authorId']] ?? 0)) * 5;

                $duration = max(0, (int)$entry['duration']);
                if ($duration > 0 && $durationSum + $duration > (int)round($budget * 1.18)) {
                    $effective -= 16;
                }
                if ($effective > $bestEffective) {
                    $bestEffective = $effective;
                    $best = $entry;
                }
            }
            if ($best === null) {
                break;
            }
            $category = (string)$best['category'];
            $best['score'] = max(0, min(100, (int)round($bestEffective)));
            $best['slotLabel'] = $this->slotLabel($preferredCategory, $slotIndex);
            if ($preferredCategory !== '' && $category === $preferredCategory) {
                $best['reasons'][] = 'مناسب بخش «' . $best['slotLabel'] . '»';
            }
            $selected[] = $best;
            $id = (int)$best['row']['id'];
            $usedIds[$id] = true;
            $categoryCounts[$category] = ((int)($categoryCounts[$category] ?? 0)) + 1;
            $authorId = (int)$best['authorId'];
            $authorCounts[$authorId] = ((int)($authorCounts[$authorId] ?? 0)) + 1;
            $durationSum += max(0, (int)$best['duration']);
        }

        return $selected;
    }

    /** @return list<string> */
    private function blueprint(string $planType, int $duration): array
    {
        $sets = [
            'heiat' => ['game', 'story', 'heiat_lesson', 'activity', 'craft', 'pedagogical'],
            'mokeb' => ['activity', 'game', 'craft', 'story', 'ambiance', 'catering'],
            'class' => ['activity', 'story', 'worksheet', 'game', 'experiment', 'craft'],
            'family' => ['story', 'activity', 'craft', 'game', 'pedagogical', 'worksheet'],
            'celebration' => ['game', 'theater', 'animation', 'activity', 'craft', 'catering'],
            'camp' => ['game', 'activity', 'experiment', 'craft', 'story', 'catering'],
            'free' => ['activity', 'game', 'story', 'craft', 'pedagogical', 'worksheet'],
        ];
        $list = $sets[$planType] ?? $sets['free'];
        return array_slice($list, 0, $this->slotCount($duration));
    }

    private function slotCount(int $duration): int
    {
        if ($duration <= 30) return 3;
        if ($duration <= 60) return 4;
        return 6;
    }

    private function slotLabel(string $category, int $index): string
    {
        $labels = [
            'game' => 'شروع و بازی', 'story' => 'قصه', 'heiat_lesson' => 'طرح درس', 'activity' => 'فعالیت',
            'craft' => 'کاردستی', 'pedagogical' => 'جمع‌بندی تربیتی', 'worksheet' => 'کاربرگ', 'experiment' => 'آزمایش',
            'theater' => 'نمایش', 'animation' => 'ویدئو', 'ambiance' => 'فضاسازی', 'catering' => 'پذیرایی',
        ];
        return $labels[$category] ?? ('بخش ' . ($index + 1));
    }

    private function fitLabel(int $score, bool $relaxed): string
    {
        if (!$relaxed && $score >= 78) return 'تطابق عالی';
        if ($score >= 62) return 'تطابق خوب';
        return 'پیشنهاد نزدیک';
    }

    /** @return array<string,mixed> */
    private function criteriaPayload(array $brief): array
    {
        return [
            'occasionId' => (int)$brief['occasionId'],
            'ageGroup' => (string)$brief['ageGroup'],
            'goalIds' => array_values($brief['goalIds']),
            'toolPreference' => (string)$brief['toolPreference'],
            'activityPreference' => (string)$brief['activityPreference'],
            'spacePreference' => (string)$brief['spacePreference'],
            'duration' => (int)$brief['duration'],
        ];
    }

    /** @param array<int,array<string,mixed>> $items @return array<string,mixed> */
    private function coverage(array $items, array $brief): array
    {
        $categories = [];
        $toolFree = 0;
        foreach ($items as $item) {
            $category = (string)($item['category'] ?? '');
            if ($category !== '') $categories[$category] = true;
            if (($item['isToolFree'] ?? null) === true) $toolFree++;
        }
        return [
            'itemCount' => count($items),
            'categoryCount' => count($categories),
            'toolFreeCount' => $toolFree,
            'goalFocused' => !empty($brief['goalIds']),
        ];
    }
}
