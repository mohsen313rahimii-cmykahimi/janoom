<?php
declare(strict_types=1);
namespace Mahda\Modules\ContentChin;
use Mahda\Core\Router;
use Mahda\Core\View;
return static function (Router $router, View $view): void {
    $controller = new ContentChinController($view);
    $router->get('/contentchin', [$controller, 'index']);
    $router->get('/contentchin/new', [$controller, 'create']);
    $router->get('/contentchin/view/{id}', [$controller, 'view']);
};
