<?php
declare(strict_types=1);
namespace Mahda\Modules\ContentChin;
use Mahda\Core\Request;
use Mahda\Core\View;
final class ContentChinController
{
    public function __construct(private View $view) {}
    public function index(Request $request): string { return $this->view->render('pages/contentchin/index'); }
    public function create(Request $request): string { return $this->view->render('pages/contentchin/new'); }
    public function view(Request $request): string { return $this->view->render('pages/contentchin/view', ['planId' => (int)$request->route('id', 0)]); }
}
