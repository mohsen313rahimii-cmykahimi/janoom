<?php
declare(strict_types=1);

namespace Mahda\Modules\Content;

use Mahda\Core\Request;
use Mahda\Core\View;
use Mahda\Support\LegacyRuntime;

final class ContentController
{
    public function __construct(private View $view)
    {
    }

    public function index(Request $request): string
    {
        return $this->view->render('pages/content/index');
    }

    public function search(Request $request): string
    {
        return $this->view->render('pages/search/index');
    }

    public function detail(Request $request): string
    {
        return $this->view->render('pages/content/detail', ['contentId' => (int)$request->route('id', 0)]);
    }

    public function create(Request $request): string
    {
        $returnTo = '/content/new';
        try {
            $db = LegacyRuntime::bootstrap();
            $user = \mahda_current_user($db, true);
            if (!empty($user['guest'])) {
                header('Location: /profile?returnTo=' . rawurlencode($returnTo), true, 302);
                exit;
            }
            $stmt = $db->prepare('SELECT kind,name,city,profile_data_json FROM mahda_profiles WHERE id=? AND owner_id=? LIMIT 1');
            $stmt->execute([(int)$user['profile_id'], (int)$user['id']]);
            $profile = $stmt->fetch();
            $data = $profile ? json_decode((string)($profile['profile_data_json'] ?? ''), true) : [];
            if (!is_array($data)) {
                $data = [];
            }
            $complete = $profile && \mahda_profile_complete(
                $data,
                (string)$profile['kind'],
                (string)($user['display_name'] ?? ''),
                (string)$profile['name'],
                (string)($profile['city'] ?? '')
            );
            if (!$complete) {
                header('Location: /profile?returnTo=' . rawurlencode($returnTo), true, 302);
                exit;
            }
        } catch (\Throwable $error) {
            // The client-side wizard displays the API/configuration error state.
            error_log('Mahda content create bootstrap: ' . get_class($error));
        }

        return $this->view->render('pages/content/new');
    }
}
