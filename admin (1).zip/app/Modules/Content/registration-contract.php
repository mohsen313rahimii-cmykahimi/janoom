<?php
declare(strict_types=1);

/**
 * Content registration v13 data contract helpers.
 *
 * These helpers deliberately separate draft persistence from final publish
 * validation. Drafts may be incomplete, but only known fields are persisted
 * and category-specific fields from another category are never carried into
 * the active category's server-side draft payload.
 */

function mahda_v13_bool_or_null(mixed $value): ?bool
{
    return $value === true ? true : ($value === false ? false : null);
}

function mahda_v13_clean_short(mixed $value, int $max = 190): string
{
    return trim(mahda_string($value ?? '', $max));
}

function mahda_v13_numeric_text(mixed $value, int $maxLen = 12): string
{
    $raw = trim(mahda_persian_digits((string)($value ?? '')));
    if ($raw === '') return '';
    if (function_exists('mb_substr')) return mb_substr($raw, 0, $maxLen, 'UTF-8');
    return substr($raw, 0, $maxLen);
}

function mahda_v13_string_list(mixed $value, int $maxItems, int $maxLen = 190): array
{
    if (!is_array($value)) return [];
    $out = [];
    foreach ($value as $item) {
        $item = mahda_v13_clean_short($item, $maxLen);
        if ($item === '' || in_array($item, $out, true)) continue;
        $out[] = $item;
        if (count($out) >= $maxItems) break;
    }
    return $out;
}

function mahda_v13_int_ids(mixed $value, int $maxItems): array
{
    if (!is_array($value)) return [];
    $out = [];
    foreach ($value as $item) {
        $id = (int)$item;
        if ($id < 1 || in_array($id, $out, true)) continue;
        $out[] = $id;
        if (count($out) >= $maxItems) break;
    }
    return $out;
}

function mahda_v13_category_exists(PDO $db, string $categoryId): bool
{
    if ($categoryId === '') return false;
    $stmt = $db->prepare('SELECT 1 FROM mahda_categories WHERE id=? AND is_active=1 AND COALESCE(show_in_register,1)=1 LIMIT 1');
    $stmt->execute([$categoryId]);
    return (bool)$stmt->fetchColumn();
}

function mahda_v13_publish_profiles(PDO $db, int $ownerId): array
{
    if ($ownerId < 1) return [];
    $owned = $db->prepare("SELECT p.id,p.kind,p.name,p.slug,p.owner_id
        FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id
        WHERE p.owner_id=? AND p.name<>'' AND u.is_active=1
        ORDER BY (p.kind='personal') DESC,p.kind,p.id");
    $owned->execute([$ownerId]);
    $rows = $owned->fetchAll();
    $byId = [];
    foreach ($rows as $row) { $byId[(int)$row['id']] = $row; }

    if (mahda_table_exists($db, 'mahda_heiat_memberships')) {
        $joined = $db->prepare("SELECT DISTINCT h.id,h.kind,h.name,h.slug,h.owner_id
            FROM mahda_heiat_memberships hm
            JOIN mahda_profiles m ON m.id=hm.mentor_profile_id
            JOIN mahda_profiles h ON h.id=hm.heiat_profile_id AND h.kind='heiat'
            JOIN mahda_users hu ON hu.id=h.owner_id
            WHERE m.owner_id=? AND hm.status='accepted' AND h.name<>'' AND hu.is_active=1
            ORDER BY h.name,h.id");
        $joined->execute([$ownerId]);
        foreach ($joined->fetchAll() as $row) { $byId[(int)$row['id']] = $row; }
    }
    return array_values($byId);
}

function mahda_v13_profile_publishable(PDO $db, int $profileId, int $ownerId): bool
{
    if ($profileId < 1 || $ownerId < 1) return false;
    foreach (mahda_v13_publish_profiles($db, $ownerId) as $profile) {
        if ((int)$profile['id'] === $profileId) return true;
    }
    return false;
}

function mahda_v13_profile_owned(PDO $db, int $profileId, int $ownerId): bool
{
    if ($profileId < 1 || $ownerId < 1) return false;
    $stmt = $db->prepare('SELECT 1 FROM mahda_profiles WHERE id=? AND owner_id=? LIMIT 1');
    $stmt->execute([$profileId, $ownerId]);
    return (bool)$stmt->fetchColumn();
}

function mahda_v13_custom_fields(PDO $db, string $categoryId, mixed $incoming, bool $enforceRequired = false): array
{
    if ($categoryId === '' || !is_array($incoming)) $incoming = [];
    $stmt = $db->prepare('SELECT field_key,field_type,options_json,is_required FROM mahda_category_fields WHERE category_id=? AND is_active=1 ORDER BY sort_order,id');
    $stmt->execute([$categoryId]);
    $out = [];
    foreach ($stmt->fetchAll() as $field) {
        $key = (string)$field['field_key'];
        $type = (string)$field['field_type'];
        $has = array_key_exists($key, $incoming);
        $value = $has ? $incoming[$key] : null;
        $options = json_decode((string)($field['options_json'] ?? '[]'), true);
        if (!is_array($options)) $options = [];
        $options = array_map('strval', $options);

        if ($type === 'boolean') {
            $value = $has ? mahda_v13_bool_or_null($value) : null;
        } elseif ($type === 'multi') {
            $value = mahda_v13_string_list($value, 30, 190);
            if ($options) $value = array_values(array_intersect($value, $options));
        } elseif ($type === 'number') {
            $raw = mahda_v13_numeric_text($value, 32);
            $value = ($raw !== '' && preg_match('/^-?\d+(?:\.\d+)?$/', $raw)) ? (float)$raw : null;
        } else {
            $value = mahda_v13_clean_short($value, 500);
            if (in_array($type, ['select', 'radio'], true) && $value !== '' && $options && !in_array($value, $options, true)) {
                $value = '';
            }
        }

        $empty = $value === null || $value === '' || $value === [];
        if ($enforceRequired && (bool)$field['is_required'] && $empty) {
            throw new RuntimeException('required_custom_field');
        }
        if (!$empty) $out[$key] = $value;
    }
    return $out;
}

function mahda_v13_canonical_goal_suggestions(PDO $db, int $ownerId, int $draftId): array
{
    if ($ownerId < 1 || $draftId < 1 || !mahda_table_exists($db, 'mahda_goal_suggestions')) return [];
    $stmt = $db->prepare("SELECT id,proposed_label,status,matched_goal_id FROM mahda_goal_suggestions WHERE owner_id=? AND draft_id=? AND status IN ('pending','approved') ORDER BY id LIMIT 20");
    $stmt->execute([$ownerId, $draftId]);
    $out = [];
    foreach ($stmt->fetchAll() as $row) {
        $out[] = [
            'id' => (int)$row['id'],
            'label' => (string)$row['proposed_label'],
            'status' => (string)$row['status'],
            'matchedGoalId' => $row['matched_goal_id'] === null ? null : (int)$row['matched_goal_id'],
        ];
    }
    return $out;
}

function mahda_sanitize_content_draft_v13(PDO $db, array $payload, int $ownerId, int $draftId): array
{
    $out = [];
    $category = mahda_v13_clean_short($payload['category'] ?? '', 40);
    if ($category !== '' && !mahda_v13_category_exists($db, $category)) {
        throw new RuntimeException('invalid_category');
    }
    if ($category !== '') $out['category'] = $category;

    $title = mahda_v13_clean_short($payload['title'] ?? '', 190);
    if ($title !== '') $out['title'] = $title;

    $ages = array_values(array_intersect(is_array($payload['ages'] ?? null) ? $payload['ages'] : [], ['4-6','7-10']));
    if ($ages) $out['ages'] = array_values(array_unique($ages));

    $duration = mahda_v13_numeric_text($payload['durationMinutes'] ?? '', 12);
    if ($duration !== '') $out['durationMinutes'] = $duration;

    $spaces = array_values(array_intersect(is_array($payload['spaces'] ?? null) ? $payload['spaces'] : [], ['indoor','outdoor']));
    if ($spaces) $out['spaces'] = array_values(array_unique($spaces));

    if ($category === 'game') {
        $min = mahda_v13_numeric_text($payload['playersMin'] ?? '', 12);
        $max = mahda_v13_numeric_text($payload['playersMax'] ?? '', 12);
        if ($min !== '') $out['playersMin'] = $min;
        if ($max !== '') $out['playersMax'] = $max;
        $activity = (string)($payload['activityLevel'] ?? '');
        if (in_array($activity, ['low','medium','high'], true)) $out['activityLevel'] = $activity;
        $gameStyle = mahda_v13_clean_short($payload['gameStyle'] ?? '', 60);
        if (in_array($gameStyle, ['گروهی','رقابتی','همکاری'], true)) $out['gameStyle'] = $gameStyle;
    } elseif ($category === 'theater') {
        $actors = mahda_v13_numeric_text($payload['theaterActorsCount'] ?? '', 12);
        if ($actors !== '') $out['theaterActorsCount'] = $actors;
        $costume = mahda_v13_bool_or_null($payload['theaterNeedCostume'] ?? null);
        $stage = mahda_v13_bool_or_null($payload['theaterNeedStage'] ?? null);
        if ($costume !== null) $out['theaterNeedCostume'] = $costume;
        if ($stage !== null) $out['theaterNeedStage'] = $stage;
    } elseif ($category === 'experiment') {
        $difficulty = mahda_v13_clean_short($payload['experimentDifficulty'] ?? '', 40);
        if (in_array($difficulty, ['ساده','متوسط','پیشرفته'], true)) $out['experimentDifficulty'] = $difficulty;
        $supervision = mahda_v13_bool_or_null($payload['experimentNeedSupervision'] ?? null);
        if ($supervision !== null) $out['experimentNeedSupervision'] = $supervision;
    }

    if ($category !== '') {
        $custom = mahda_v13_custom_fields($db, $category, $payload['customFields'] ?? [], false);
        if ($custom) $out['customFields'] = $custom;
    }

    $tools = mahda_v13_string_list($payload['tools'] ?? [], 50, 190);
    $toolFree = array_key_exists('toolFree', $payload) ? mahda_v13_bool_or_null($payload['toolFree']) : null;
    if ($toolFree === true) {
        $out['toolFree'] = true;
    } elseif ($tools) {
        $out['tools'] = $tools;
        $out['toolFree'] = false;
    } elseif ($toolFree === false) {
        $out['toolFree'] = false;
    }

    $goalIds = mahda_v13_int_ids($payload['goalIds'] ?? [], 20);
    if ($goalIds) $out['goalIds'] = $goalIds;
    $suggestions = mahda_v13_canonical_goal_suggestions($db, $ownerId, $draftId);
    if ($suggestions) $out['suggestedGoals'] = $suggestions;

    $occasionIds = mahda_v13_int_ids($payload['occasionIds'] ?? [], 40);
    if ($occasionIds) $out['occasionIds'] = $occasionIds;
    if (($payload['generalOccasion'] ?? false) === true) $out['generalOccasion'] = true;

    $mainText = mahda_string($payload['mainText'] ?? '', 100000);
    if (trim($mainText) !== '') $out['mainText'] = $mainText;
    $executionText = mahda_string($payload['executionText'] ?? '', 100000);
    if (trim($executionText) !== '') $out['executionText'] = $executionText;
    $method = (string)($payload['executionMethod'] ?? '');
    if (in_array($method, ['video','image','audio','text'], true)) $out['executionMethod'] = $method;

    $profileId = max(0, (int)($payload['profileId'] ?? 0));
    if ($profileId > 0) {
        if (!mahda_v13_profile_publishable($db, $profileId, $ownerId)) throw new RuntimeException('profile_not_owned');
        $out['profileId'] = $profileId;
    }

    if (array_key_exists('publishShowcase', $payload) && is_bool($payload['publishShowcase'])) $out['publishShowcase'] = $payload['publishShowcase'];
    if (array_key_exists('requestBankReview', $payload) && is_bool($payload['requestBankReview'])) $out['requestBankReview'] = $payload['requestBankReview'];

    return $out;
}

function mahda_v13_positive_int_or_null(mixed $value): ?int
{
    $raw = mahda_v13_numeric_text($value, 12);
    if ($raw === '') return null;
    if (!ctype_digit($raw)) throw new RuntimeException('invalid_positive_integer');
    $number = (int)$raw;
    if ($number < 1) throw new RuntimeException('invalid_positive_integer');
    return $number;
}
