<?php
declare(strict_types=1);

namespace Mahda\Modules\Content;

use PDO;

final class CategoryRepository
{
    public function __construct(private PDO $db)
    {
    }

    /** @return list<array<string, mixed>> */
    public function activeForBank(): array
    {
        $stmt = $this->db->query('SELECT id,label,icon,color,fields_json,description,show_in_register,show_in_bank FROM mahda_categories WHERE is_active=1 AND COALESCE(show_in_bank,1)=1 ORDER BY sort_order,id');
        $items = [];
        foreach ($stmt->fetchAll() as $row) {
            $items[] = [
                'id' => (string)$row['id'],
                'label' => (string)$row['label'],
                'icon' => (string)($row['icon'] ?? ''),
                'color' => (string)($row['color'] ?? '#159658'),
                'fields_json' => (string)($row['fields_json'] ?? ''),
                'description' => (string)($row['description'] ?? ''),
                'showInRegister' => (bool)($row['show_in_register'] ?? true),
                'showInBank' => (bool)($row['show_in_bank'] ?? true),
            ];
        }
        return $items;
    }
}

