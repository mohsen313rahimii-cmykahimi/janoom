<?php
declare(strict_types=1);

namespace Mahda\Modules\Content;

use Mahda\Support\PageResult;
use PDO;

final class ContentRepository
{
    public function __construct(private PDO $db)
    {
    }

    public function search(ContentFilter $filter): PageResult
    {
        [$from, $where, $params] = $this->queryParts($filter);
        $count = $this->db->prepare('SELECT COUNT(DISTINCT c.id) ' . $from . ' WHERE ' . implode(' AND ', $where));
        $this->bind($count, $params);
        $count->execute();
        $total = (int)$count->fetchColumn();

        $order = $filter->sort === 'popular'
            ? 'ORDER BY (SELECT COUNT(*) FROM mahda_interactions pi WHERE pi.content_id=c.id AND pi.kind=\'like\') DESC,c.created_at DESC,c.id DESC'
            : 'ORDER BY c.created_at DESC,c.id DESC';
        $sql = 'SELECT DISTINCT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color '
            . $from . ' WHERE ' . implode(' AND ', $where) . ' ' . $order . ' LIMIT ? OFFSET ?';
        $stmt = $this->db->prepare($sql);
        $index = $this->bind($stmt, $params);
        $stmt->bindValue($index + 1, $filter->perPage, PDO::PARAM_INT);
        $stmt->bindValue($index + 2, $filter->offset(), PDO::PARAM_INT);
        $stmt->execute();

        return new PageResult(array_map(static fn(array $row): array => $row, $stmt->fetchAll()), $filter->page, $filter->perPage, $total);
    }

    /** @return array{0:string,1:list<string>,2:list<mixed>} */
    private function queryParts(ContentFilter $filter): array
    {
        $from = 'FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_users owner ON owner.id=c.author_id JOIN mahda_categories cat ON cat.id=c.category_id';
        $where = [
            "p.name<>''",
            'owner.is_active=1',
            "owner.email NOT LIKE 'guest-%@mahda.local'",
            "owner.email NOT LIKE 'test-phone-%@mahda.local'",
            'c.archived_at IS NULL',
            "(c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved'))",
            'cat.is_active=1',
            'COALESCE(cat.show_in_bank,1)=1',
        ];
        $params = [];

        if ($filter->query !== '') {
            $term = '%' . $filter->query . '%';
            $where[] = '(c.title LIKE ? OR c.body LIKE ? OR c.execution_text LIKE ? OR cat.label LIKE ? OR p.name LIKE ?
                OR EXISTS (SELECT 1 FROM mahda_content_goals cg JOIN mahda_goals g ON g.id=cg.goal_id WHERE cg.content_id=c.id AND (g.label LIKE ? OR g.description LIKE ? OR g.search_terms_json LIKE ?))
                OR EXISTS (SELECT 1 FROM mahda_content_occasions co JOIN mahda_occasions o ON o.id=co.occasion_id WHERE co.content_id=c.id AND (o.label LIKE ? OR o.aliases_json LIKE ? OR o.description LIKE ?))
                OR EXISTS (SELECT 1 FROM mahda_content_topics ct JOIN mahda_topics t ON t.id=ct.topic_id WHERE ct.content_id=c.id AND (t.label LIKE ? OR t.description LIKE ?)))';
            array_push($params, $term, $term, $term, $term, $term, $term, $term, $term, $term, $term, $term, $term, $term);
        }
        if ($filter->category !== '') {
            $where[] = 'c.category_id=?';
            $params[] = $filter->category;
        }
        if ($filter->age === '4-6') {
            $where[] = 'c.age_4_6=1';
        } elseif ($filter->age === '7-10') {
            $where[] = 'c.age_7_10=1';
        }
        if ($filter->space === 'indoor') {
            $where[] = 'c.indoor=1';
        } elseif ($filter->space === 'outdoor') {
            $where[] = 'c.outdoor=1';
        }
        if ($filter->occasionId > 0) {
            $where[] = 'EXISTS (SELECT 1 FROM mahda_content_occasions co WHERE co.content_id=c.id AND co.occasion_id=?)';
            $params[] = $filter->occasionId;
        }
        if ($filter->goalId > 0) {
            $where[] = 'EXISTS (SELECT 1 FROM mahda_content_goals cg WHERE cg.content_id=c.id AND cg.goal_id=?)';
            $params[] = $filter->goalId;
        }
        return [$from, $where, $params];
    }

    /** @param list<mixed> $params */
    private function bind(\PDOStatement $statement, array $params): int
    {
        foreach ($params as $index => $param) {
            $statement->bindValue($index + 1, $param, is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        return count($params);
    }
}
