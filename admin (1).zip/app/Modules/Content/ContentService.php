<?php
declare(strict_types=1);

namespace Mahda\Modules\Content;

use Mahda\Support\PageResult;
use PDO;

final class ContentService
{
    public function __construct(private PDO $db, private ContentRepository $repository)
    {
    }

    public function publicCards(ContentFilter $filter): PageResult
    {
        $result = $this->repository->search($filter);
        $items = function_exists('mahda_items')
            ? mahda_items($this->db, $result->items)
            : array_map([$this, 'basicCard'], $result->items);
        return new PageResult($items, $result->page, $result->perPage, $result->total);
    }

    /** @return array<string, mixed> */
    private function basicCard(array $row): array
    {
        return [
            'id' => (string)$row['id'],
            'title' => (string)$row['title'],
            'category' => (string)$row['category_id'],
            'categoryLabel' => (string)($row['category_label'] ?? ''),
            'categoryIcon' => (string)($row['category_icon'] ?? ''),
            'categoryColor' => (string)($row['category_color'] ?? '#159658'),
            'image' => null,
            'publisher' => (string)($row['profile_name'] ?? ''),
            'author' => (string)($row['profile_name'] ?? ''),
            'profileId' => (int)($row['profile_id'] ?? 0),
            'profileKind' => (string)($row['profile_kind'] ?? 'personal'),
            'durationMinutes' => $row['duration_minutes'] === null ? null : (int)$row['duration_minutes'],
            'reviewStatus' => (string)($row['review_status'] ?? ''),
        ];
    }
}

