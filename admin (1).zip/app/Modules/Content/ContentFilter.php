<?php
declare(strict_types=1);

namespace Mahda\Modules\Content;

final class ContentFilter
{
    public function __construct(
        public readonly string $query = '',
        public readonly string $category = '',
        public readonly string $age = '',
        public readonly int $occasionId = 0,
        public readonly int $goalId = 0,
        public readonly string $space = '',
        public readonly string $sort = 'latest',
        public readonly int $page = 1,
        public readonly int $perPage = 24,
    ) {
    }

    /** @param array<string, mixed> $query */
    public static function fromQuery(array $query): self
    {
        $page = max(1, min(500, (int)($query['page'] ?? 1)));
        $perPage = max(1, min(60, (int)($query['per_page'] ?? ($query['limit'] ?? 24))));
        $age = (string)($query['age'] ?? '');
        if (!in_array($age, ['4-6', '7-10'], true)) {
            $age = '';
        }
        $space = (string)($query['space'] ?? '');
        if (!in_array($space, ['indoor', 'outdoor'], true)) {
            $space = '';
        }
        $sort = (string)($query['sort'] ?? 'latest');
        if (!in_array($sort, ['latest', 'popular'], true)) {
            $sort = 'latest';
        }

        return new self(
            query: trim((string)($query['q'] ?? '')),
            category: trim((string)($query['category'] ?? '')),
            age: $age,
            occasionId: max(0, (int)($query['occasion'] ?? ($query['occasion_id'] ?? 0))),
            goalId: max(0, (int)($query['goal'] ?? ($query['goal_id'] ?? 0))),
            space: $space,
            sort: $sort,
            page: $page,
            perPage: $perPage,
        );
    }

    public function offset(): int
    {
        return ($this->page - 1) * $this->perPage;
    }
}

