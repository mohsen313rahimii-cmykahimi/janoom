<?php
declare(strict_types=1);

/** API actions owned by the ContentWorkflow module. */
function mahda_content_workflow_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['goals', 'occasions', 'content_detail', 'my_contents', 'content_edit_get', 'content_update', 'content_file_delete', 'content_edit_files_commit_v12', 'registration_bootstrap_v12', 'content_draft_start_v12', 'content_draft_get_v12', 'content_draft_save_v12', 'goal_suggest_v12', 'draft_file_upload_v12', 'draft_file_delete_v12', 'content_publish_v12', 'content_create', 'content_delete'], true)) {
        return false;
    }

        if ($action === 'goals' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $query = mahda_string($_GET['q'] ?? '', 190);
            $sql = 'SELECT DISTINCT g.id,g.label,g.description FROM mahda_goals g LEFT JOIN mahda_goal_aliases a ON a.goal_id=g.id WHERE g.is_active=1';
            $params = [];
            if ($query !== '') { $sql .= ' AND (g.label LIKE ? OR g.description LIKE ? OR a.term LIKE ?)'; $term = '%' . $query . '%'; $params = [$term,$term,$term]; }
            $sql .= ' ORDER BY g.label LIMIT 60';
            $stmt = $db->prepare($sql); $stmt->execute($params);
            mahda_json(['items' => $stmt->fetchAll()]);
        }

        if ($action === 'occasions' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $query = mahda_string($_GET['q'] ?? '', 190);
            $group = mahda_string($_GET['group'] ?? '', 30);
            $sql = 'SELECT id,label,occasion_group,aliases_json FROM mahda_occasions WHERE is_active=1'; $params = [];
            if ($query !== '') { $sql .= ' AND (label LIKE ? OR aliases_json LIKE ?)'; $term = '%' . $query . '%'; $params = [$term,$term]; }
            if (in_array($group, ['celebrations','mourning','national','general'], true)) { $sql .= ' AND occasion_group=?'; $params[] = $group; }
            $sql .= ' ORDER BY label LIMIT 100';
            $stmt = $db->prepare($sql); $stmt->execute($params);
            mahda_json(['items' => $stmt->fetchAll()]);
        }

        if ($action === 'content_detail' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $contentId=max(0,(int)($_GET['id']??0)); if($contentId<1)mahda_json(['error'=>'invalid_content'],422);
            $stmt=$db->prepare("SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_users owner ON owner.id=c.author_id JOIN mahda_categories cat ON cat.id=c.category_id WHERE c.id=? AND p.name<>'' AND owner.is_active=1 AND owner.email NOT LIKE 'guest-%@mahda.local' AND owner.email NOT LIKE 'test-phone-%@mahda.local' AND c.archived_at IS NULL LIMIT 1");
            $stmt->execute([$contentId]);$row=$stmt->fetch();if(!$row)mahda_json(['error'=>'content_not_found'],404);
            $isPublic=(string)$row['visibility']==='showcase'||((string)$row['visibility']!=='hidden'&&(string)$row['review_status']==='approved');
            $viewer=mahda_current_user($db,true);$isOwner=empty($viewer['guest'])&&(int)$viewer['id']===(int)$row['author_id'];$staff=false;
            if(!$isPublic&&!$isOwner&&!empty($viewer['role'])&&in_array((string)$viewer['role'],['admin','reviewer'],true)){$staff=mahda_can_access_content($db,$viewer,['desk_id'=>(int)($row['desk_id']??0)],'view');}
            if(!$isPublic&&!$isOwner&&!$staff)mahda_json(['error'=>'content_not_found'],404);
            $item=mahda_item($db,$row);$item['canEdit']=$isOwner;$item['requiresReviewOnEdit']=$isOwner&&(string)$row['review_status']==='approved';$item['isPublic']=$isPublic;$item['visibility']=(string)$row['visibility'];
            $item['customFieldDetails']=[];$extra=json_decode((string)($row['extra_fields_json']??''),true);$custom=is_array($extra['customFields']??null)?$extra['customFields']:[];
            if($custom&&mahda_table_exists($db,'mahda_category_fields')){$cf=$db->prepare('SELECT field_key,label,field_type FROM mahda_category_fields WHERE category_id=? AND is_active=1 AND COALESCE(show_in_detail,1)=1 ORDER BY sort_order,id');$cf->execute([(string)$row['category_id']]);foreach($cf->fetchAll() as $f){$k=(string)$f['field_key'];if(array_key_exists($k,$custom))$item['customFieldDetails'][]=['key'=>$k,'label'=>(string)$f['label'],'type'=>(string)$f['field_type'],'value'=>$custom[$k]];}}
            mahda_json(['item'=>$item]);
        }

        if ($action === 'my_contents' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $user = mahda_require_complete_member($db);
            $status = mahda_string($_GET['status'] ?? 'all', 32);
            $query = mahda_string($_GET['q'] ?? '', 190);
            $limit = max(1, min(200, (int)($_GET['limit'] ?? 100)));
            $offset = max(0, min(100000, (int)($_GET['offset'] ?? 0)));
            $allowed = ['all','pending','approved','revision','rejected','not_requested'];
            if (!in_array($status, $allowed, true)) { $status = 'all'; }

            $where = ['c.author_id=?'];
            $params = [(int)$user['id']];
            if ($status !== 'all') { $where[] = 'c.review_status=?'; $params[] = $status; }
            if ($query !== '') {
                $where[] = '(c.title LIKE ? OR c.body LIKE ? OR cat.label LIKE ? OR p.name LIKE ?)';
                $term = '%' . $query . '%';
                array_push($params, $term, $term, $term, $term);
            }
            $base = " FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_categories cat ON cat.id=c.category_id WHERE " . implode(' AND ', $where);
            $countStmt = $db->prepare('SELECT COUNT(*)' . $base); $countStmt->execute($params); $total = (int)$countStmt->fetchColumn();
            $sql = 'SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color' . $base . ' ORDER BY c.created_at DESC,c.id DESC LIMIT ? OFFSET ?';
            $stmt = $db->prepare($sql);
            $bind = 1;
            foreach ($params as $param) { $stmt->bindValue($bind++, $param, is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR); }
            $stmt->bindValue($bind++, $limit, PDO::PARAM_INT); $stmt->bindValue($bind, $offset, PDO::PARAM_INT); $stmt->execute();
            $rows = $stmt->fetchAll();
            $items = mahda_items($db, $rows);

            $latestByContent = [];
            if ($rows) {
                $ids = array_map(static fn(array $row): int => (int)$row['id'], $rows);
                $ph = implode(',', array_fill(0, count($ids), '?'));
                $reviewStmt = $db->prepare("SELECT ra.content_id,ra.action,ra.note,ra.created_at,u.display_name AS reviewer_name
                    FROM mahda_review_actions ra
                    JOIN (SELECT content_id,MAX(id) AS max_id FROM mahda_review_actions WHERE content_id IN ({$ph}) GROUP BY content_id) latest ON latest.max_id=ra.id
                    LEFT JOIN mahda_users u ON u.id=ra.reviewer_id");
                $reviewStmt->execute($ids);
                foreach ($reviewStmt->fetchAll() as $review) { $latestByContent[(int)$review['content_id']] = $review; }
            }
            foreach ($items as &$item) {
                $id = (int)$item['id'];
                $rawStatus = 'not_requested';
                foreach ($rows as $row) { if ((int)$row['id'] === $id) { $rawStatus = (string)$row['review_status']; break; } }
                $review = $latestByContent[$id] ?? null;
                $lastDecision = $review ? (string)$review['action'] : null;
                // On restricted hosts the schema may still store a revision as
                // rejected; the moderation action preserves the real meaning.
                $item['reviewStatus'] = ($rawStatus === 'rejected' && $lastDecision === 'revision') ? 'revision' : $rawStatus;
                $item['lastDecision'] = $lastDecision;
                $item['reviewNote'] = $review ? (string)($review['note'] ?? '') : '';
                $item['reviewedAt'] = $review ? (string)$review['created_at'] : null;
                $item['reviewerName'] = $review ? (string)($review['reviewer_name'] ?? '') : '';
            }
            unset($item);

            $stats = ['all'=>0,'pending'=>0,'approved'=>0,'revision'=>0,'rejected'=>0,'not_requested'=>0];
            $statStmt = $db->prepare('SELECT review_status,COUNT(*) AS total FROM mahda_contents WHERE author_id=? GROUP BY review_status');
            $statStmt->execute([(int)$user['id']]);
            foreach ($statStmt->fetchAll() as $row) { $key = (string)$row['review_status']; $stats[$key] = (int)$row['total']; $stats['all'] += (int)$row['total']; }
            mahda_json(['items'=>$items,'stats'=>$stats,'total'=>$total,'limit'=>$limit,'offset'=>$offset,'hasMore'=>$offset + count($items) < $total]);
        }

        if ($action === 'content_edit_get' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $user = mahda_require_complete_member($db);
            $contentId = max(0, (int)($_GET['id'] ?? 0));
            if ($contentId < 1) { mahda_json(['error'=>'invalid_content'], 422); }
            $stmt = $db->prepare("SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color
                FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_categories cat ON cat.id=c.category_id
                WHERE c.id=? AND c.author_id=? LIMIT 1");
            $stmt->execute([$contentId,(int)$user['id']]); $row = $stmt->fetch();
            if (!$row) { mahda_json(['error'=>'content_not_owned'], 404); }
            $item = mahda_item($db, $row);
            $extra = json_decode((string)($row['extra_fields_json'] ?? ''), true); if (!is_array($extra)) { $extra = []; }
            $filesStmt = $db->prepare('SELECT id,purpose,original_name,mime_type,size_bytes FROM mahda_files WHERE content_id=? ORDER BY id');
            $filesStmt->execute([$contentId]);
            $files = array_map(static fn(array $f): array => ['id'=>(int)$f['id'],'purpose'=>(string)$f['purpose'],'name'=>(string)$f['original_name'],'mime'=>(string)$f['mime_type'],'size'=>(int)$f['size_bytes'],'url'=>'/mahda-api/index.php?action=file&id='.(int)$f['id']], $filesStmt->fetchAll());
            $reviewStmt = $db->prepare('SELECT ra.action,ra.note,ra.created_at,u.display_name AS reviewer_name FROM mahda_review_actions ra LEFT JOIN mahda_users u ON u.id=ra.reviewer_id WHERE ra.content_id=? ORDER BY ra.id DESC LIMIT 1');
            $reviewStmt->execute([$contentId]); $review = $reviewStmt->fetch() ?: null;
            $profiles = array_map(static fn(array $p): array => ['id'=>(int)$p['id'],'kind'=>(string)$p['kind'],'name'=>(string)$p['name'],'slug'=>(string)$p['slug']], mahda_v13_publish_profiles($db,(int)$user['id']));
            $goalIdsStmt = $db->prepare('SELECT goal_id FROM mahda_content_goals WHERE content_id=? ORDER BY goal_id'); $goalIdsStmt->execute([$contentId]);
            $occasionIdsStmt = $db->prepare('SELECT occasion_id FROM mahda_content_occasions WHERE content_id=? ORDER BY occasion_id'); $occasionIdsStmt->execute([$contentId]);
            $executionMethod = (string)($item['executionMethod'] ?? ($extra['presentationMethod'] ?? ''));
            if ($executionMethod === 'voice') { $executionMethod = 'audio'; }
            if (!in_array($executionMethod, ['video','image','audio','text'], true)) { $executionMethod = ''; }
            mahda_json(['content'=>[
                'id'=>(int)$row['id'],'title'=>(string)$row['title'],'category'=>(string)$row['category_id'],'body'=>(string)($row['body'] ?? ''),
                'executionText'=>(string)($row['execution_text'] ?? ''),
                'durationMinutes'=>$row['duration_minutes'] === null ? null : (int)$row['duration_minutes'],
                'ages'=>array_values(array_filter([(int)$row['age_4_6'] === 1 ? '4-6' : null,(int)$row['age_7_10'] === 1 ? '7-10' : null])),
                'spaces'=>array_values(array_filter([(int)$row['indoor'] === 1 ? 'indoor' : null,(int)$row['outdoor'] === 1 ? 'outdoor' : null])),
                'playersMin'=>$row['players_min'] === null ? null : (int)$row['players_min'], 'playersMax'=>$row['players_max'] === null ? null : (int)$row['players_max'],
                'audienceSize'=>$item['audienceSize'] ?? '', 'activityLevel'=>$item['activityLevelKey'] ?? ($item['activityLevel'] ?? ''),
                'goalIds'=>array_map('intval',$goalIdsStmt->fetchAll(PDO::FETCH_COLUMN)), 'goals'=>$item['goals'] ?? [],
                'occasionIds'=>array_map('intval',$occasionIdsStmt->fetchAll(PDO::FETCH_COLUMN)), 'occasions'=>$item['occasions'] ?? [], 'generalOccasion'=>(bool)($row['general_occasion'] ?? false),
                'requiredTools'=>$item['requiredTools'] ?? [], 'isToolFree'=>$item['isToolFree'] ?? null,
                'executionMethod'=>$executionMethod, 'presentationMethod'=>$executionMethod,
                'gameStyle'=>$extra['gameStyle'] ?? '', 'theaterActorsCount'=>$extra['theaterActorsCount'] ?? '',
                'theaterNeedCostume'=>array_key_exists('theaterNeedCostume',$extra)?$extra['theaterNeedCostume']:null,
                'theaterNeedStage'=>array_key_exists('theaterNeedStage',$extra)?$extra['theaterNeedStage']:null,
                'experimentDifficulty'=>$extra['experimentDifficulty'] ?? '',
                'experimentNeedSupervision'=>array_key_exists('experimentNeedSupervision',$extra)?$extra['experimentNeedSupervision']:null,
                'customFields'=>is_array($extra['customFields'] ?? null)?$extra['customFields']:[],
                'topicIds'=>mahda_table_exists($db,'mahda_content_topics') ? array_map('intval',(function() use($db,$contentId){$st=$db->prepare('SELECT topic_id FROM mahda_content_topics WHERE content_id=? ORDER BY topic_id');$st->execute([$contentId]);return $st->fetchAll(PDO::FETCH_COLUMN);})()) : [],
                'profileId'=>(int)$row['profile_id'],'profileName'=>(string)$row['profile_name'],'reviewStatus'=>(string)$row['review_status'],'visibility'=>(string)$row['visibility'],
                'publisherType'=>$extra['publisherType'] ?? ((string)$row['profile_kind'] === 'heiat' ? 'heiat' : 'personal'),
                'reviewNote'=>$review ? (string)($review['note'] ?? '') : '', 'lastDecision'=>$review ? (string)$review['action'] : null,
                'reviewerName'=>$review ? (string)($review['reviewer_name'] ?? '') : '', 'reviewedAt'=>$review ? (string)$review['created_at'] : null,
            ],'files'=>$files,'profiles'=>$profiles]);
        }

        if ($action === 'content_update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data(); mahda_require_csrf($data); $user = mahda_require_complete_member($db);
            $contentId = max(0, (int)($data['contentId'] ?? 0));
            if ($contentId < 1) { mahda_json(['error'=>'invalid_content'], 422); }
            $owned = $db->prepare('SELECT c.*,p.kind AS profile_kind FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id WHERE c.id=? AND c.author_id=? LIMIT 1');
            $owned->execute([$contentId,(int)$user['id']]); $current = $owned->fetch();
            if (!$current) { mahda_json(['error'=>'content_not_owned'], 403); }

            $targetProfileId = max(1, (int)($data['profileId'] ?? $current['profile_id']));
            if (!mahda_v13_profile_publishable($db,$targetProfileId,(int)$user['id'])) { mahda_json(['error'=>'profile_not_owned'], 403); }
            $profileStmt = $db->prepare('SELECT id,kind,name FROM mahda_profiles WHERE id=? LIMIT 1');
            $profileStmt->execute([$targetProfileId]);
            $targetProfile = $profileStmt->fetch();
            if (!$targetProfile) { mahda_json(['error'=>'profile_not_owned'], 403); }
            $oldExtra = json_decode((string)($current['extra_fields_json'] ?? ''), true); if (!is_array($oldExtra)) { $oldExtra = []; }
            if (array_key_exists('publisherType',$data)) {
                $requestedPublisher = mahda_string($data['publisherType'] ?? '', 20);
                $publisherType = $requestedPublisher === 'anonymous' ? 'anonymous' : ((string)$targetProfile['kind'] === 'heiat' ? 'heiat' : 'personal');
            } else {
                $publisherType = (string)($oldExtra['publisherType'] ?? ((string)$targetProfile['kind'] === 'heiat' ? 'heiat' : 'personal'));
                if (!in_array($publisherType,['anonymous','heiat','personal'],true)) { $publisherType = (string)$targetProfile['kind'] === 'heiat' ? 'heiat' : 'personal'; }
                if ($publisherType !== 'anonymous') { $publisherType = (string)$targetProfile['kind'] === 'heiat' ? 'heiat' : 'personal'; }
            }

            $categoryId = mahda_string($data['category'] ?? $current['category_id'], 40);
            if (!mahda_category($db, $categoryId)) { mahda_json(['error'=>'invalid_category'], 422); }
            $categoryChanged = $categoryId !== (string)$current['category_id'];
            $title = trim(mahda_string($data['title'] ?? $current['title'], 190));
            $titleLength = function_exists('mb_strlen') ? mb_strlen($title, 'UTF-8') : strlen($title);
            if ($titleLength < 2) { mahda_json(['error'=>'title_required'], 422); }
            $body = mahda_string($data['directTextContent'] ?? ($data['body'] ?? $current['body']), 100000);
            $executionText = array_key_exists('executionText',$data) ? mahda_string($data['executionText'],100000) : (string)($current['execution_text'] ?? '');

            if (array_key_exists('ages',$data)) {
                $ages = array_values(array_unique(array_intersect(is_array($data['ages'])?$data['ages']:[], ['4-6','7-10'])));
            } else {
                $ages = array_values(array_filter([(int)$current['age_4_6']===1?'4-6':null,(int)$current['age_7_10']===1?'7-10':null]));
            }
            if (!$ages) { mahda_json(['error'=>'age_required'],422); }

            if (array_key_exists('durationMinutes',$data) || array_key_exists('duration',$data)) {
                $durationRaw = mahda_persian_digits(trim((string)($data['durationMinutes'] ?? $data['duration'] ?? '')));
                if ($durationRaw === '') { $minutes = null; }
                elseif (!ctype_digit($durationRaw) || (int)$durationRaw < 1 || (int)$durationRaw > 1440) { mahda_json(['error'=>'invalid_duration'],422); }
                else { $minutes = (int)$durationRaw; }
            } else { $minutes = $current['duration_minutes'] === null ? null : (int)$current['duration_minutes']; }

            if (array_key_exists('spaces',$data)) { $spaces = mahda_spaces($data['spaces']); }
            else { $spaces = array_values(array_filter([(int)$current['indoor']===1?'indoor':null,(int)$current['outdoor']===1?'outdoor':null])); }
            if (!$spaces) { mahda_json(['error'=>'space_required'],422); }

            $players = [null,null];
            if ($categoryId === 'game') {
                if (array_key_exists('playersMin',$data) || array_key_exists('playersMax',$data)) {
                    $minRaw=mahda_persian_digits(trim((string)($data['playersMin']??''))); $maxRaw=mahda_persian_digits(trim((string)($data['playersMax']??'')));
                    if ($minRaw==='' || $maxRaw==='' || !ctype_digit($minRaw) || !ctype_digit($maxRaw)) { mahda_json(['error'=>'invalid_players'],422); }
                    $players=[(int)$minRaw,(int)$maxRaw];
                } elseif (array_key_exists('audienceSize',$data)) { $players=mahda_player_range($data['audienceSize']); }
                elseif (!$categoryChanged) { $players=[$current['players_min']===null?null:(int)$current['players_min'],$current['players_max']===null?null:(int)$current['players_max']]; }
                if ($players[0]===null || $players[1]===null || $players[0]<1 || $players[1]<1 || $players[0]>$players[1] || $players[1]>10000) { mahda_json(['error'=>'invalid_players'],422); }
            }

            if ($categoryId === 'game') {
                $activityLabel = array_key_exists('activityLevel',$data) ? mahda_string($data['activityLevel'],20) : (!$categoryChanged ? (string)($current['activity_level']??'') : '');
                $activity = ['کم'=>'low','متوسط'=>'medium','زیاد'=>'high','low'=>'low','medium'=>'medium','high'=>'high',''=>''][$activityLabel] ?? null;
                if ($activity === '') { $activity = null; }
            } else { $activity = null; }

            $toolStateStmt=$db->prepare('SELECT COUNT(*) FROM mahda_content_tools WHERE content_id=?');$toolStateStmt->execute([$contentId]);$existingToolCount=(int)$toolStateStmt->fetchColumn();
            $currentToolFreeSpecified = array_key_exists('toolFreeSpecified',$oldExtra) ? (bool)$oldExtra['toolFreeSpecified'] : ((bool)$current['tool_free'] || $existingToolCount > 0);
            if (array_key_exists('isToolFree',$data)) {
                $toolFree = $data['isToolFree'] === true ? true : ($data['isToolFree'] === false ? false : null);
            } else { $toolFree = $currentToolFreeSpecified ? (bool)$current['tool_free'] : null; }

            $toolsProvided = array_key_exists('requiredTools',$data);
            if ($toolsProvided) { $tools=mahda_list($data['requiredTools'],30); }
            else { $st=$db->prepare('SELECT label FROM mahda_content_tools WHERE content_id=? ORDER BY sort_order,id');$st->execute([$contentId]);$tools=array_map('strval',$st->fetchAll(PDO::FETCH_COLUMN)); }
            if ($toolFree === true && $tools) { mahda_json(['error'=>'tool_free_conflict'],422); }
            if ($toolFree === true) { $tools=[]; }

            $generalOccasion = array_key_exists('generalOccasion',$data) ? (($data['generalOccasion']??false)===true) : (bool)($current['general_occasion']??false);

            $goalsProvided = array_key_exists('goalIds',$data) || array_key_exists('goals',$data);
            $goalIds=[];
            if (array_key_exists('goalIds',$data)) {
                $goalIds=array_values(array_unique(array_filter(array_map('intval',is_array($data['goalIds'])?$data['goalIds']:[]),fn($v)=>$v>0)));
                if ($goalIds) {
                    $ph=implode(',',array_fill(0,count($goalIds),'?'));$st=$db->prepare("SELECT id FROM mahda_goals WHERE is_active=1 AND id IN ($ph)");$st->execute($goalIds);$valid=array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN));sort($valid);$check=$goalIds;sort($check);if($valid!==$check)mahda_json(['error'=>'invalid_goal'],422);
                }
            } elseif (array_key_exists('goals',$data)) {
                $labels=mahda_list($data['goals'],20);$goalRows=$db->query('SELECT id,label FROM mahda_goals WHERE is_active=1')->fetchAll();$goalMap=[];$aliasStmt=$db->prepare("SELECT term FROM mahda_goal_aliases WHERE goal_id=? AND relation='synonym'");
                foreach($goalRows as $g){$id=(int)$g['id'];$goalMap[mahda_normalize_fa_text((string)$g['label'])]=$id;$aliasStmt->execute([$id]);foreach($aliasStmt->fetchAll(PDO::FETCH_COLUMN) as $term)$goalMap[mahda_normalize_fa_text((string)$term)]=$id;}
                foreach($labels as $label){$key=mahda_normalize_fa_text($label);if($key===''||!isset($goalMap[$key]))mahda_json(['error'=>'unknown_goal','label'=>$label],422);$goalIds[]=$goalMap[$key];}$goalIds=array_values(array_unique($goalIds));
            } else { $st=$db->prepare('SELECT goal_id FROM mahda_content_goals WHERE content_id=? ORDER BY goal_id');$st->execute([$contentId]);$goalIds=array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN)); }

            $occasionsProvided = array_key_exists('occasionIds',$data) || array_key_exists('occasions',$data);
            $occasionIds=[];
            if (array_key_exists('occasionIds',$data)) {
                $occasionIds=array_values(array_unique(array_filter(array_map('intval',is_array($data['occasionIds'])?$data['occasionIds']:[]),fn($v)=>$v>0)));
                if ($occasionIds) {
                    $ph=implode(',',array_fill(0,count($occasionIds),'?'));$st=$db->prepare("SELECT id FROM mahda_occasions WHERE is_active=1 AND id IN ($ph)");$st->execute($occasionIds);$valid=array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN));sort($valid);$check=$occasionIds;sort($check);if($valid!==$check)mahda_json(['error'=>'invalid_occasion'],422);
                }
            } elseif (array_key_exists('occasions',$data)) {
                $labels=mahda_list($data['occasions'],30);$occRows=$db->query('SELECT id,label,aliases_json FROM mahda_occasions WHERE is_active=1')->fetchAll();$occMap=[];
                foreach($occRows as $o){$id=(int)$o['id'];$occMap[mahda_normalize_fa_text((string)$o['label'])]=$id;$aliases=json_decode((string)($o['aliases_json']??'[]'),true);if(is_array($aliases))foreach($aliases as $term)$occMap[mahda_normalize_fa_text((string)$term)]=$id;}
                foreach($labels as $label){$key=mahda_normalize_fa_text($label);if($key===''||!isset($occMap[$key]))mahda_json(['error'=>'unknown_occasion','label'=>$label],422);$occasionIds[]=$occMap[$key];}$occasionIds=array_values(array_unique($occasionIds));
            } else { $st=$db->prepare('SELECT occasion_id FROM mahda_content_occasions WHERE content_id=? ORDER BY occasion_id');$st->execute([$contentId]);$occasionIds=array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN)); }

            if (array_key_exists('customFields',$data)) {
                try { $customFields=mahda_v13_custom_fields($db,$categoryId,$data['customFields'],true); }
                catch(RuntimeException $e){ if($e->getMessage()==='required_custom_field')mahda_json(['error'=>'required_custom_field'],422); throw $e; }
            } elseif (!$categoryChanged) { $customFields=is_array($oldExtra['customFields']??null)?$oldExtra['customFields']:[]; }
            else {
                try { $customFields=mahda_v13_custom_fields($db,$categoryId,[],true); }
                catch(RuntimeException $e){ if($e->getMessage()==='required_custom_field')mahda_json(['error'=>'required_custom_field'],422); throw $e; }
            }

            $topicIdsProvided=array_key_exists('topicIds',$data);
            $topicIds=array_values(array_unique(array_filter(array_map('intval',is_array($data['topicIds']??null)?$data['topicIds']:[]),fn($v)=>$v>0)));

            $extra=$oldExtra;
            foreach(['presentationMethod','gameStyle','theaterActorsCount','theaterNeedCostume','theaterNeedStage','experimentDifficulty','experimentTools','experimentNeedSupervision','categorySpecificChoice','customFields','publisherType','toolFreeSpecified'] as $k){unset($extra[$k]);}
            $extra['publisherType']=$publisherType;
            $extra['toolFreeSpecified']=$toolFree!==null;
            if($customFields)$extra['customFields']=$customFields;
            $incomingMethod=$data['executionMethod']??($data['presentationMethod']??null);
            if($incomingMethod===null && !$categoryChanged)$incomingMethod=$oldExtra['executionMethod']??($oldExtra['presentationMethod']??null);
            if($incomingMethod==='voice')$incomingMethod='audio';
            if($incomingMethod!==null && $incomingMethod!=='' && !in_array($incomingMethod,['video','image','audio','text'],true))mahda_json(['error'=>'invalid_execution_method'],422);
            if(in_array($incomingMethod,['video','image','audio','text'],true))$extra['executionMethod']=$incomingMethod;else unset($extra['executionMethod']);

            if($categoryId==='game'){
                $gameStyle=array_key_exists('gameStyle',$data)?mahda_string($data['gameStyle'],60):(!$categoryChanged?mahda_string($oldExtra['gameStyle']??'',60):'');
                if($gameStyle!==''&&!in_array($gameStyle,['گروهی','رقابتی','همکاری'],true))mahda_json(['error'=>'invalid_game_style'],422);if($gameStyle!=='')$extra['gameStyle']=$gameStyle;
            } elseif($categoryId==='theater'){
                $actors=array_key_exists('theaterActorsCount',$data)?mahda_v13_positive_int_or_null($data['theaterActorsCount']):(!$categoryChanged?mahda_v13_positive_int_or_null($oldExtra['theaterActorsCount']??null):null);if($actors!==null)$extra['theaterActorsCount']=$actors;
                foreach(['theaterNeedCostume','theaterNeedStage'] as $k){if(array_key_exists($k,$data))$extra[$k]=mahda_v13_bool_or_null($data[$k]);elseif(!$categoryChanged&&array_key_exists($k,$oldExtra))$extra[$k]=$oldExtra[$k];}
            } elseif($categoryId==='experiment'){
                $difficulty=array_key_exists('experimentDifficulty',$data)?mahda_string($data['experimentDifficulty'],40):(!$categoryChanged?mahda_string($oldExtra['experimentDifficulty']??'',40):'');if($difficulty!==''&&!in_array($difficulty,['ساده','متوسط','پیشرفته'],true))mahda_json(['error'=>'invalid_experiment_difficulty'],422);if($difficulty!=='')$extra['experimentDifficulty']=$difficulty;
                if(array_key_exists('experimentNeedSupervision',$data))$extra['experimentNeedSupervision']=mahda_v13_bool_or_null($data['experimentNeedSupervision']);elseif(!$categoryChanged&&array_key_exists('experimentNeedSupervision',$oldExtra))$extra['experimentNeedSupervision']=$oldExtra['experimentNeedSupervision'];
            }

            $previous=(string)$current['review_status'];
            $requestReview=array_key_exists('requestBankReview',$data)?(($data['requestBankReview']??false)===true):null;
            if($previous==='not_requested' && $requestReview!==true){$newStatus='not_requested';}
            else{$newStatus=mahda_setting_bool($db,'review_required',true)?'pending':'approved';}

            $db->beginTransaction();
            try {
                $db->prepare('UPDATE mahda_contents SET profile_id=?,category_id=?,title=?,body=?,execution_text=?,duration_minutes=?,age_4_6=?,age_7_10=?,indoor=?,outdoor=?,players_min=?,players_max=?,activity_level=?,tool_free=?,general_occasion=?,extra_fields_json=?,review_status=? WHERE id=? AND author_id=?')
                    ->execute([$targetProfileId,$categoryId,$title,$body,$executionText,$minutes,in_array('4-6',$ages,true)?1:0,in_array('7-10',$ages,true)?1:0,in_array('indoor',$spaces,true)?1:0,in_array('outdoor',$spaces,true)?1:0,$players[0],$players[1],$activity,$toolFree===true?1:0,$generalOccasion?1:0,json_encode($extra,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$newStatus,$contentId,(int)$user['id']]);
                mahda_assign_content_desk($db,$contentId,$categoryId);
                if($goalsProvided){$db->prepare('DELETE FROM mahda_content_goals WHERE content_id=?')->execute([$contentId]);$link=$db->prepare('INSERT INTO mahda_content_goals(content_id,goal_id) VALUES(?,?)');foreach($goalIds as $id)$link->execute([$contentId,$id]);}
                if($occasionsProvided){$db->prepare('DELETE FROM mahda_content_occasions WHERE content_id=?')->execute([$contentId]);$link=$db->prepare('INSERT INTO mahda_content_occasions(content_id,occasion_id) VALUES(?,?)');foreach($occasionIds as $id)$link->execute([$contentId,$id]);}
                if($toolsProvided){$db->prepare('DELETE FROM mahda_content_tools WHERE content_id=?')->execute([$contentId]);$link=$db->prepare('INSERT INTO mahda_content_tools(content_id,label,sort_order) VALUES(?,?,?)');foreach($tools as $idx=>$tool)$link->execute([$contentId,$tool,$idx]);}
                if (mahda_table_exists($db,'mahda_content_topics') && $topicIdsProvided) {
                    $db->prepare('DELETE FROM mahda_content_topics WHERE content_id=?')->execute([$contentId]);
                    if ($topicIds) {$validTopic=$db->prepare('SELECT id FROM mahda_topics WHERE id=? AND is_active=1 LIMIT 1');$linkTopic=$db->prepare('INSERT IGNORE INTO mahda_content_topics(content_id,topic_id) VALUES(?,?)');foreach(array_slice($topicIds,0,20) as $topicId){$validTopic->execute([$topicId]);if($validTopic->fetchColumn())$linkTopic->execute([$contentId,$topicId]);}}
                }
                mahda_audit($db,(int)$user['id'],$newStatus==='not_requested'?'content_update':'content_resubmit','content',$contentId,['previous'=>$previous,'new'=>$newStatus]);
                $db->commit();
                if ($newStatus === 'pending' && $previous !== 'pending') { mahda_admin_notify($db,'content_resubmitted','محتوا دوباره ارسال شد','محتوای «'.$title.'» پس از اصلاح دوباره وارد صف بررسی شد.','content',$contentId,'content:pending:'.$contentId.':'.time()); }
            } catch (Throwable $error) { if ($db->inTransaction()) { $db->rollBack(); } throw $error; }
            $find = $db->prepare("SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_categories cat ON cat.id=c.category_id WHERE c.id=?");
            $find->execute([$contentId]);
            mahda_json(['ok'=>true,'status'=>$newStatus,'item'=>mahda_item($db,$find->fetch())]);
        }

        if ($action === 'content_file_delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data(); mahda_require_csrf($data); $user = mahda_require_complete_member($db);
            $fileId = max(0,(int)($data['fileId'] ?? 0)); if ($fileId < 1) { mahda_json(['error'=>'invalid_file'],422); }
            $stmt = $db->prepare('SELECT f.id,f.storage_key,f.content_id,c.author_id FROM mahda_files f JOIN mahda_contents c ON c.id=f.content_id WHERE f.id=? LIMIT 1');
            $stmt->execute([$fileId]); $file = $stmt->fetch(); if (!$file || (int)$file['author_id'] !== (int)$user['id']) { mahda_json(['error'=>'file_not_owned'],403); }
            $db->prepare('DELETE FROM mahda_files WHERE id=?')->execute([$fileId]);
            $path = mahda_existing_upload_path((string)$file['storage_key']); if ($path) { @unlink($path); }
            mahda_json(['ok'=>true,'fileId'=>$fileId]);
        }

        if ($action === 'content_edit_files_commit_v12' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data();
            mahda_require_csrf($data);
            $user = mahda_require_complete_member($db);
            $contentId = max(0, (int)($data['contentId'] ?? 0));
            $draftId = max(0, (int)($data['draftId'] ?? 0));
            if ($contentId < 1 || $draftId < 1) { mahda_json(['error'=>'invalid_content'],422); }

            $owned = $db->prepare('SELECT id FROM mahda_contents WHERE id=? AND author_id=? LIMIT 1');
            $owned->execute([$contentId,(int)$user['id']]);
            if (!$owned->fetchColumn()) { mahda_json(['error'=>'content_not_owned'],403); }

            $draftStmt = $db->prepare('SELECT id,data_json,completed_content_id FROM mahda_content_drafts WHERE id=? AND owner_id=? LIMIT 1');
            $draftStmt->execute([$draftId,(int)$user['id']]);
            $draftRow = $draftStmt->fetch();
            if (!$draftRow) { mahda_json(['error'=>'draft_not_found'],404); }
            if ($draftRow['completed_content_id'] !== null && (int)$draftRow['completed_content_id'] === $contentId) {
                mahda_json(['ok'=>true,'contentId'=>$contentId,'duplicate'=>true]);
            }
            $draftData = json_decode((string)($draftRow['data_json'] ?? ''), true);
            if (!is_array($draftData) || (int)($draftData['editContentId'] ?? 0) !== $contentId) {
                mahda_json(['error'=>'edit_draft_mismatch'],409);
            }

            $replace = [];
            foreach ((array)($data['replacedPurposes'] ?? []) as $purpose) {
                $purpose = mahda_string($purpose,32);
                if (in_array($purpose,['cover','main_file'],true) && !in_array($purpose,$replace,true)) $replace[]=$purpose;
            }
            $deletedIds = array_values(array_unique(array_filter(array_map('intval',is_array($data['deletedExistingFileIds'] ?? null)?$data['deletedExistingFileIds']:[]),fn($v)=>$v>0)));
            $clearLegacy = ($data['clearLegacyExecution'] ?? false) === true;

            $newFilesStmt = $db->prepare("SELECT * FROM mahda_files WHERE draft_id=? AND owner_id=? AND content_id IS NULL AND COALESCE(status,'ready')='ready' ORDER BY id");
            $newFilesStmt->execute([$draftId,(int)$user['id']]);
            $newFiles = $newFilesStmt->fetchAll();
            $newByPurpose=[]; foreach($newFiles as $f){$newByPurpose[(string)$f['purpose']][]=$f;}
            foreach ($replace as $purpose) {
                if (empty($newByPurpose[$purpose])) { mahda_json(['error'=>'replacement_file_missing','purpose'=>$purpose],422); }
            }

            $removeRows=[];
            $db->beginTransaction();
            try {
                if ($deletedIds) {
                    $ph=implode(',',array_fill(0,count($deletedIds),'?'));
                    $args=array_merge([$contentId,(int)$user['id']],$deletedIds);
                    $st=$db->prepare("SELECT f.* FROM mahda_files f JOIN mahda_contents c ON c.id=f.content_id WHERE f.content_id=? AND c.author_id=? AND f.id IN ($ph)");
                    $st->execute($args); foreach($st->fetchAll() as $r)$removeRows[(int)$r['id']]=$r;
                }
                foreach ($replace as $purpose) {
                    $st=$db->prepare('SELECT f.* FROM mahda_files f JOIN mahda_contents c ON c.id=f.content_id WHERE f.content_id=? AND c.author_id=? AND f.purpose=?');
                    $st->execute([$contentId,(int)$user['id'],$purpose]); foreach($st->fetchAll() as $r)$removeRows[(int)$r['id']]=$r;
                }
                if ($clearLegacy) {
                    $st=$db->prepare("SELECT f.* FROM mahda_files f JOIN mahda_contents c ON c.id=f.content_id WHERE f.content_id=? AND c.author_id=? AND f.purpose IN ('execution_video','execution_audio')");
                    $st->execute([$contentId,(int)$user['id']]); foreach($st->fetchAll() as $r)$removeRows[(int)$r['id']]=$r;
                }
                if ($removeRows) {
                    $del=$db->prepare('DELETE FROM mahda_files WHERE id=? AND content_id=?');
                    foreach(array_keys($removeRows) as $fid)$del->execute([(int)$fid,$contentId]);
                }
                $move=$db->prepare('UPDATE mahda_files SET content_id=?,draft_id=NULL,is_temporary=0,updated_at=NOW() WHERE id=? AND draft_id=? AND owner_id=? AND content_id IS NULL');
                foreach($newFiles as $f)$move->execute([$contentId,(int)$f['id'],$draftId,(int)$user['id']]);
                $showcase = ($data['publishShowcase'] ?? false) === true;
                $db->prepare('UPDATE mahda_contents SET visibility=?,published_at=IF(?=1,COALESCE(published_at,NOW()),published_at) WHERE id=? AND author_id=?')
                   ->execute([$showcase?'showcase':'hidden',$showcase?1:0,$contentId,(int)$user['id']]);
                $db->prepare('UPDATE mahda_content_drafts SET completed_content_id=?,completed_at=NOW(),version=version+1,current_step=9 WHERE id=? AND owner_id=?')
                   ->execute([$contentId,$draftId,(int)$user['id']]);
                mahda_audit($db,(int)$user['id'],'content_edit_wizard_commit','content',$contentId,['draftId'=>$draftId,'replacedPurposes'=>$replace,'deletedFileIds'=>array_keys($removeRows)]);
                $db->commit();
            } catch (Throwable $e) {
                if ($db->inTransaction()) $db->rollBack();
                throw $e;
            }
            foreach($removeRows as $row) mahda_safe_remove_file_keys($row);
            mahda_json(['ok'=>true,'contentId'=>$contentId,'movedFiles'=>count($newFiles)]);
        }

        if ($action === 'registration_bootstrap_v12' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $user = mahda_require_complete_member($db);
            $cats = $db->query("SELECT id,label,icon,color,description,sort_order FROM mahda_categories WHERE is_active=1 AND COALESCE(show_in_register,1)=1 ORDER BY sort_order,id")->fetchAll();
            $fieldStmt=$db->prepare('SELECT field_key,label,field_type,options_json,is_required,sort_order FROM mahda_category_fields WHERE category_id=? AND is_active=1 ORDER BY sort_order,id');
            foreach($cats as &$cat){$fieldStmt->execute([(string)$cat['id']]);$fields=[];foreach($fieldStmt->fetchAll() as $f){$fields[]=['key'=>(string)$f['field_key'],'label'=>(string)$f['label'],'type'=>(string)$f['field_type'],'options'=>json_decode((string)($f['options_json']??'[]'),true)?:[],'required'=>(bool)$f['is_required'],'sortOrder'=>(int)$f['sort_order']];}$cat=['id'=>(string)$cat['id'],'label'=>(string)$cat['label'],'icon'=>(string)$cat['icon'],'color'=>(string)$cat['color'],'description'=>(string)($cat['description']??''),'fields'=>$fields];}unset($cat);
            $goals=[];$gst=$db->query("SELECT id,label,description,goal_group FROM mahda_goals WHERE is_active=1 ORDER BY sort_order,label LIMIT 400");$ast=$db->prepare('SELECT term,relation FROM mahda_goal_aliases WHERE goal_id=? ORDER BY relation,term');
            foreach($gst->fetchAll() as $g){$ast->execute([(int)$g['id']]);$aliases=['synonym'=>[],'related'=>[],'antonym'=>[]];foreach($ast->fetchAll() as $a){$rel=(string)$a['relation'];if(!isset($aliases[$rel]))$aliases[$rel]=[];$aliases[$rel][]=(string)$a['term'];}$goals[]=['id'=>(int)$g['id'],'label'=>(string)$g['label'],'description'=>(string)($g['description']??''),'group'=>(string)($g['goal_group']??'ethical'),'synonyms'=>$aliases['synonym'],'related'=>$aliases['related'],'antonyms'=>$aliases['antonym']];}
            $occasions=[];$ost=$db->query("SELECT id,label,occasion_group,aliases_json,description FROM mahda_occasions WHERE is_active=1 ORDER BY sort_order,label LIMIT 500");foreach($ost->fetchAll() as $o){$occasions[]=['id'=>(int)$o['id'],'label'=>(string)$o['label'],'group'=>(string)$o['occasion_group'],'aliases'=>json_decode((string)($o['aliases_json']??'[]'),true)?:[],'description'=>(string)($o['description']??'')];}
            $profiles=[];foreach(mahda_v13_publish_profiles($db,(int)$user['id']) as $p){$profiles[]=['id'=>(int)$p['id'],'kind'=>(string)$p['kind'],'name'=>(string)$p['name'],'slug'=>(string)$p['slug']];}
            $policies=[];foreach(['cover','main_file','execution_video','execution_audio','attachment'] as $purpose){$pol=mahda_upload_policy($db,$purpose);$policies[$purpose]=['maxBytes'=>(int)$pol['max_bytes'],'maxMB'=>round((int)$pol['max_bytes']/1048576,1),'mimes'=>array_values((array)$pol['mimes'])];}
            $cap=mahda_media_capabilities();mahda_json(['csrf'=>mahda_csrf(),'user'=>['id'=>(int)$user['id'],'profileId'=>(int)$user['profile_id']],'categories'=>$cats,'goals'=>$goals,'occasions'=>$occasions,'profiles'=>$profiles,'uploadPolicies'=>$policies,'mediaCapabilities'=>['gd'=>(bool)$cap['gd'],'imagick'=>(bool)$cap['imagick'],'ffmpeg'=>(bool)$cap['ffmpeg'],'backgroundTranscode'=>(bool)$cap['backgroundTranscode'],'videoDirectMaxBytes'=>(int)(mahda_media_config()['video_output_max_bytes']??20*1024*1024),'videoMaxDurationSeconds'=>(int)(mahda_media_config()['video_max_duration_seconds']??300)],'rules'=>['version'=>(string)mahda_setting($db,'content_rules_version','1'),'text'=>(string)mahda_setting($db,'publish_rules_text','')]]);
        }

        if ($action === 'content_draft_start_v12' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_complete_member($db);$clientKey=mahda_string($data['clientKey']??'',80);
            if($clientKey===''||!preg_match('/^[A-Za-z0-9_-]{10,80}$/',$clientKey))mahda_json(['error'=>'invalid_draft_key'],422);
            $find=$db->prepare('SELECT id FROM mahda_content_drafts WHERE owner_id=? AND client_key=? LIMIT 1');$find->execute([(int)$user['id'],$clientKey]);$id=(int)($find->fetchColumn()?:0);
            if($id<1){$db->prepare('INSERT INTO mahda_content_drafts(owner_id,profile_id,client_key,data_json) VALUES(?,?,?,?)')->execute([(int)$user['id'],(int)$user['profile_id'],$clientKey,'{}']);$id=(int)$db->lastInsertId();mahda_record_sync_change($db,(int)$user['id'],'content_draft',$id,1);}
            // Opportunistic cleanup of abandoned private uploads; only unlinked temporary files older than the configured TTL.
            $ttl=max(1,min(180,(int)mahda_setting($db,'content_draft_ttl_days','30')));$old=$db->query("SELECT id,storage_key,original_storage_key,thumbnail_storage_key FROM mahda_files WHERE content_id IS NULL AND COALESCE(is_temporary,0)=1 AND created_at<DATE_SUB(NOW(),INTERVAL {$ttl} DAY) ORDER BY id LIMIT 50");$cleaned=[];foreach($old->fetchAll() as $f){$deleted=$db->prepare('DELETE FROM mahda_files WHERE id=? AND content_id IS NULL AND COALESCE(is_temporary,0)=1');$deleted->execute([(int)$f['id']]);if($deleted->rowCount()===1){mahda_safe_remove_file_keys($f);$cleaned[]=(int)$f['id'];}}if($cleaned)mahda_audit($db,(int)$user['id'],'draft_temp_cleanup','file',0,['fileIds'=>$cleaned,'ttlDays'=>$ttl,'scope'=>'global_unlinked_temp']);
            mahda_json(['draft'=>mahda_draft_payload($db,$id,(int)$user['id'])],201);
        }

        if ($action === 'content_draft_get_v12' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $user=mahda_require_complete_member($db);$id=max(0,(int)($_GET['id']??0));$draft=mahda_draft_payload($db,$id,(int)$user['id']);if(!$draft)mahda_json(['error'=>'draft_not_found'],404);mahda_json(['draft'=>$draft]);
        }

        if ($action === 'content_draft_save_v12' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_complete_member($db);$id=max(0,(int)($data['draftId']??0));$version=max(0,(int)($data['version']??0));$step=max(1,min(9,(int)($data['step']??1)));$payload=is_array($data['data']??null)?$data['data']:[];
            $rawEncoded=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if(!is_string($rawEncoded)||strlen($rawEncoded)>450000)mahda_json(['error'=>'draft_too_large'],413);if(preg_match('/(?:blob:|data:[^,]{0,80};base64,)/i',$rawEncoded))mahda_json(['error'=>'temporary_file_reference_not_allowed'],422);
            try{$payload=mahda_sanitize_content_draft_v13($db,$payload,(int)$user['id'],$id);}catch(RuntimeException $e){$safe=in_array($e->getMessage(),['invalid_category','profile_not_owned'],true)?$e->getMessage():'invalid_draft_data';mahda_json(['error'=>$safe],$safe==='profile_not_owned'?403:422);}
            $encoded=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if(!is_string($encoded)||strlen($encoded)>450000)mahda_json(['error'=>'draft_too_large'],413);
            $category=mahda_string($payload['category']??'',40);$profileId=max(0,(int)($payload['profileId']??0));
            $upd=$db->prepare('UPDATE mahda_content_drafts SET profile_id=?,category_id=?,current_step=?,data_json=?,version=version+1 WHERE id=? AND owner_id=? AND completed_at IS NULL AND version=?');$upd->execute([$profileId?:null,$category?:null,$step,$encoded,$id,(int)$user['id'],$version]);
            if($upd->rowCount()!==1){$current=mahda_draft_payload($db,$id,(int)$user['id']);if(!$current)mahda_json(['error'=>'draft_not_found'],404);mahda_json(['error'=>'draft_conflict','draft'=>$current],409);}
            mahda_record_sync_change($db,(int)$user['id'],'content_draft',$id,$version+1);
            mahda_json(['draft'=>mahda_draft_payload($db,$id,(int)$user['id'])]);
        }

        if ($action === 'goal_suggest_v12' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_complete_member($db);$draftId=max(0,(int)($data['draftId']??0));$label=mahda_string($data['label']??'',190);$normalized=mahda_normalize_fa_text($label);$normalizedLen=function_exists('mb_strlen')?mb_strlen($normalized,'UTF-8'):strlen($normalized);if($normalizedLen<2)mahda_json(['error'=>'goal_label_required'],422);
            if($draftId>0){$d=$db->prepare('SELECT 1 FROM mahda_content_drafts WHERE id=? AND owner_id=? AND completed_at IS NULL');$d->execute([$draftId,(int)$user['id']]);if(!$d->fetchColumn())mahda_json(['error'=>'draft_not_found'],404);}
            $all=$db->query('SELECT id,label FROM mahda_goals WHERE is_active=1')->fetchAll();$alias=$db->prepare('SELECT term FROM mahda_goal_aliases WHERE goal_id=? AND relation=\'synonym\'');$matches=[];
            foreach($all as $g){$alias->execute([(int)$g['id']]);$terms=array_merge([(string)$g['label']],array_map('strval',$alias->fetchAll(PDO::FETCH_COLUMN)));foreach($terms as $term){$n=mahda_normalize_fa_text($term);if($n===$normalized){mahda_json(['existingGoal'=>['id'=>(int)$g['id'],'label'=>(string)$g['label']],'suggestion'=>null]);}if(str_contains($n,$normalized)||str_contains($normalized,$n)){$matches[(int)$g['id']]=(string)$g['label'];break;}}}
            $st=$db->prepare("SELECT id,status FROM mahda_goal_suggestions WHERE owner_id=? AND normalized_label=? AND status='pending' ORDER BY id DESC LIMIT 1");$st->execute([(int)$user['id'],$normalized]);$existing=$st->fetch();if($existing)mahda_json(['suggestion'=>['id'=>(int)$existing['id'],'label'=>$label,'status'=>'pending'],'matches'=>array_map(fn($id,$l)=>['id'=>$id,'label'=>$l],array_keys($matches),array_values($matches))]);
            $db->prepare('INSERT INTO mahda_goal_suggestions(owner_id,draft_id,proposed_label,normalized_label,status) VALUES(?,?,?,?,\'pending\')')->execute([(int)$user['id'],$draftId?:null,$label,$normalized]);$sid=(int)$db->lastInsertId();mahda_json(['suggestion'=>['id'=>$sid,'label'=>$label,'status'=>'pending'],'matches'=>array_map(fn($id,$l)=>['id'=>$id,'label'=>$l],array_keys($matches),array_values($matches))],201);
        }

        if ($action === 'draft_file_upload_v12' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $contentLength=max(0,(int)($_SERVER['CONTENT_LENGTH']??0));$phpUploadLimit=mahda_effective_php_upload_limit();if($phpUploadLimit>0&&$phpUploadLimit<PHP_INT_MAX&&$contentLength>$phpUploadLimit+1048576)mahda_json(['error'=>'file_too_large'],413);
            mahda_require_csrf([]);mahda_enforce_rate_limit($db,'draft_file_upload',30,300);$user=mahda_require_complete_member($db);$draftId=max(0,(int)($_POST['draft_id']??0));$purpose=mahda_string($_POST['purpose']??'',32);if($draftId<1||!in_array($purpose,['cover','main_file','execution_video','execution_audio','attachment'],true))mahda_json(['error'=>'invalid_file_upload'],422);
            $d=$db->prepare('SELECT 1 FROM mahda_content_drafts WHERE id=? AND owner_id=? AND completed_at IS NULL');$d->execute([$draftId,(int)$user['id']]);if(!$d->fetchColumn())mahda_json(['error'=>'draft_not_found'],404);if(empty($_FILES['file'])||!is_array($_FILES['file']))mahda_json(['error'=>'file_required'],422);
            try{$stored=mahda_store_uploaded_v12($db,$_FILES['file'],$purpose);}catch(RuntimeException $e){$safe=in_array($e->getMessage(),['file_too_large','file_required','upload_failed','file_type_not_allowed','storage_unavailable','cover_ratio_required','archive_contains_executable','image_compression_failed','media_processing_unavailable','video_too_long','video_transcode_unavailable'],true)?$e->getMessage():'upload_failed';mahda_json(['error'=>$safe],$safe==='file_too_large'?413:422);}
            $dup=$db->prepare('SELECT * FROM mahda_files WHERE owner_id=? AND draft_id=? AND purpose=? AND sha256=? AND content_id IS NULL AND COALESCE(status,\'ready\')=\'ready\' LIMIT 1');$dup->execute([(int)$user['id'],$draftId,$purpose,$stored['sha256']]);$dupe=$dup->fetch();if($dupe){mahda_safe_remove_file_keys($stored);mahda_json(['file'=>mahda_file_public_payload($dupe),'deduplicated'=>true]);}
            $old=[];if($purpose!=='attachment'){$st=$db->prepare('SELECT * FROM mahda_files WHERE owner_id=? AND draft_id=? AND purpose=? AND content_id IS NULL');$st->execute([(int)$user['id'],$draftId,$purpose]);$old=$st->fetchAll();}
            $db->beginTransaction();try{if($purpose!=='attachment')$db->prepare('DELETE FROM mahda_files WHERE owner_id=? AND draft_id=? AND purpose=? AND content_id IS NULL')->execute([(int)$user['id'],$draftId,$purpose]);$db->prepare('INSERT INTO mahda_files(owner_id,content_id,purpose,storage_key,original_name,mime_type,size_bytes,sha256,draft_id,status,processing_error,original_storage_key,thumbnail_storage_key,width,height,is_temporary,updated_at) VALUES(?,NULL,?,?,?,?,?,?,?,\'ready\',NULL,?,?,?,?,1,NOW())')->execute([(int)$user['id'],$purpose,$stored['storage_key'],$stored['original_name'],$stored['mime'],$stored['size'],$stored['sha256'],$draftId,$stored['original_storage_key'],$stored['thumbnail_storage_key'],$stored['width'],$stored['height']]);$id=(int)$db->lastInsertId();$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();mahda_safe_remove_file_keys($stored);throw $e;}
            foreach($old as $f)mahda_safe_remove_file_keys($f);mahda_queue_media_processing_v12($db,$id,$purpose,$stored['mime']);$dv=$db->prepare('SELECT version FROM mahda_content_drafts WHERE id=? AND owner_id=?');$dv->execute([$draftId,(int)$user['id']]);mahda_record_sync_change($db,(int)$user['id'],'content_draft',$draftId,(int)($dv->fetchColumn()?:0));$st=$db->prepare('SELECT * FROM mahda_files WHERE id=?');$st->execute([$id]);mahda_json(['file'=>mahda_file_public_payload($st->fetch()),'stored'=>true],201);
        }

        if ($action === 'draft_file_delete_v12' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_complete_member($db);$fileId=max(0,(int)($data['fileId']??0));$st=$db->prepare('SELECT * FROM mahda_files WHERE id=? AND owner_id=? AND content_id IS NULL AND COALESCE(is_temporary,0)=1 LIMIT 1');$st->execute([$fileId,(int)$user['id']]);$f=$st->fetch();if(!$f)mahda_json(['error'=>'file_not_found'],404);$db->prepare('DELETE FROM mahda_files WHERE id=? AND owner_id=? AND content_id IS NULL')->execute([$fileId,(int)$user['id']]);mahda_safe_remove_file_keys($f);$draftId=(int)($f['draft_id']??0);if($draftId>0){$dv=$db->prepare('SELECT version FROM mahda_content_drafts WHERE id=? AND owner_id=?');$dv->execute([$draftId,(int)$user['id']]);mahda_record_sync_change($db,(int)$user['id'],'content_draft',$draftId,(int)($dv->fetchColumn()?:0));}mahda_json(['ok'=>true]);
        }

        if ($action === 'content_publish_v12' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$user=mahda_require_complete_member($db);$draftId=max(0,(int)($data['draftId']??0));$version=max(0,(int)($data['version']??0));if($draftId<1)mahda_json(['error'=>'draft_not_found'],404);
            $st=$db->prepare('SELECT * FROM mahda_content_drafts WHERE id=? AND owner_id=? LIMIT 1 FOR UPDATE');
            $db->beginTransaction();try{$st->execute([$draftId,(int)$user['id']]);$draft=$st->fetch();if(!$draft){$db->rollBack();mahda_json(['error'=>'draft_not_found'],404);}if($draft['completed_content_id']!==null){$cid=(int)$draft['completed_content_id'];$done=$db->prepare('SELECT visibility,review_status FROM mahda_contents WHERE id=? AND author_id=? LIMIT 1');$done->execute([$cid,(int)$user['id']]);$doneRow=$done->fetch();$db->commit();if(!$doneRow)mahda_json(['error'=>'published_content_not_found'],404);mahda_json(['ok'=>true,'contentId'=>$cid,'duplicate'=>true,'publishedToShowcase'=>(string)$doneRow['visibility']==='showcase','bankReviewRequested'=>(string)$doneRow['review_status']!=='not_requested','reviewStatus'=>(string)$doneRow['review_status']]);}if((int)$draft['version']!==$version){$db->rollBack();mahda_json(['error'=>'draft_conflict','draft'=>mahda_draft_payload($db,$draftId,(int)$user['id'])],409);}if(!(bool)($data['rulesAccepted']??false)){$db->rollBack();mahda_json(['error'=>'rules_required'],422);}
                $p=json_decode((string)($draft['data_json']??''),true);if(!is_array($p))$p=[];$p=mahda_sanitize_content_draft_v13($db,$p,(int)$user['id'],$draftId);$category=mahda_string($p['category']??'',40);$cs=$db->prepare('SELECT id,label FROM mahda_categories WHERE id=? AND is_active=1 AND COALESCE(show_in_register,1)=1');$cs->execute([$category]);if(!$cs->fetch())throw new RuntimeException('invalid_category');$title=trim(mahda_string($p['title']??'',190));if($title===''||(function_exists('mb_strlen')?mb_strlen($title,'UTF-8'):strlen($title))<2)throw new RuntimeException('title_required');
                $ages=array_values(array_intersect(is_array($p['ages']??null)?$p['ages']:[],['4-6','7-10']));if(!$ages)throw new RuntimeException('age_required');$spaces=array_values(array_intersect(is_array($p['spaces']??null)?$p['spaces']:[],['indoor','outdoor']));if(!$spaces)throw new RuntimeException('space_required');
                $durationRaw=mahda_persian_digits((string)($p['durationMinutes']??''));$minutes=null;if(trim($durationRaw)!==''){if(!preg_match('/^\d+$/',$durationRaw))throw new RuntimeException('invalid_duration');$minutes=(int)$durationRaw;if($minutes<1||$minutes>1440)throw new RuntimeException('invalid_duration');}
                $players=[null,null];if($category==='game'){$a=mahda_persian_digits((string)($p['playersMin']??''));$b=mahda_persian_digits((string)($p['playersMax']??''));if($a===''||$b===''||!ctype_digit($a)||!ctype_digit($b)||(int)$a<1||(int)$b<1||(int)$a>(int)$b)throw new RuntimeException('invalid_players');$players=[(int)$a,(int)$b];}
                $profileId=max(0,(int)($p['profileId']??$draft['profile_id']??0));if(!mahda_v13_profile_publishable($db,$profileId,(int)$user['id']))throw new RuntimeException('profile_not_owned');$ps=$db->prepare('SELECT id,kind FROM mahda_profiles WHERE id=? LIMIT 1');$ps->execute([$profileId]);$profile=$ps->fetch();if(!$profile)throw new RuntimeException('profile_not_owned');
                $mainText=mahda_string($p['mainText']??'',100000);$executionText=mahda_string($p['executionText']??'',100000);$fileSt=$db->prepare("SELECT * FROM mahda_files WHERE draft_id=? AND owner_id=? AND content_id IS NULL AND COALESCE(status,'ready')='ready' ORDER BY id");$fileSt->execute([$draftId,(int)$user['id']]);$draftFiles=$fileSt->fetchAll();$byPurpose=[];foreach($draftFiles as $f)$byPurpose[(string)$f['purpose']][]=$f;if(empty($byPurpose['cover']))throw new RuntimeException('cover_required');if($mainText===''&&empty($byPurpose['main_file']))throw new RuntimeException('main_content_required');
                $toolFree=array_key_exists('toolFree',$p)?$p['toolFree']:null;$tools=[];foreach(array_slice(is_array($p['tools']??null)?$p['tools']:[],0,50) as $t){$t=trim(mahda_string($t,190));if($t!==''&&!in_array($t,$tools,true))$tools[]=$t;}if($toolFree===true)$tools=[];
                $goalIds=array_values(array_unique(array_filter(array_map('intval',is_array($p['goalIds']??null)?$p['goalIds']:[]),fn($v)=>$v>0)));$occasionIds=array_values(array_unique(array_filter(array_map('intval',is_array($p['occasionIds']??null)?$p['occasionIds']:[]),fn($v)=>$v>0)));$general=(bool)($p['generalOccasion']??false);
                $activity=['low','medium','high'];$activityLevel=$category==='game'&&in_array((string)($p['activityLevel']??''),$activity,true)?(string)$p['activityLevel']:null;
                $custom=mahda_v13_custom_fields($db,$category,$p['customFields']??[],true);
                $suggestions=mahda_v13_canonical_goal_suggestions($db,(int)$user['id'],$draftId);$suggestedGoalIds=array_values(array_map(fn($x)=>(int)$x['id'],$suggestions));
                $executionMethod=in_array((string)($p['executionMethod']??''),['video','image','audio','text'],true)?(string)$p['executionMethod']:'';
                $extra=['publisherType'=>((string)$profile['kind']==='heiat'?'heiat':'personal'),'toolFreeSpecified'=>($toolFree===true||$toolFree===false),'customFields'=>$custom];
                if($executionMethod!=='')$extra['executionMethod']=$executionMethod;if($suggestedGoalIds)$extra['suggestedGoalIds']=$suggestedGoalIds;
                if($category==='game'){$gameStyle=mahda_string($p['gameStyle']??'',60);if($gameStyle!==''&&!in_array($gameStyle,['گروهی','رقابتی','همکاری'],true))throw new RuntimeException('invalid_game_style');if($gameStyle!=='')$extra['gameStyle']=$gameStyle;}
                elseif($category==='theater'){$actors=mahda_v13_positive_int_or_null($p['theaterActorsCount']??null);if($actors!==null)$extra['theaterActorsCount']=$actors;if(array_key_exists('theaterNeedCostume',$p))$extra['theaterNeedCostume']=mahda_v13_bool_or_null($p['theaterNeedCostume']);if(array_key_exists('theaterNeedStage',$p))$extra['theaterNeedStage']=mahda_v13_bool_or_null($p['theaterNeedStage']);}
                elseif($category==='experiment'){$difficulty=mahda_string($p['experimentDifficulty']??'',40);if($difficulty!==''&&!in_array($difficulty,['ساده','متوسط','پیشرفته'],true))throw new RuntimeException('invalid_experiment_difficulty');if($difficulty!=='')$extra['experimentDifficulty']=$difficulty;if(array_key_exists('experimentNeedSupervision',$p))$extra['experimentNeedSupervision']=mahda_v13_bool_or_null($p['experimentNeedSupervision']);}
                $publishShowcase=($data['publishShowcase']??false)===true;$requestBank=($data['requestBankReview']??false)===true;$visibility=$publishShowcase?'showcase':'hidden';$reviewStatus=$requestBank?'pending':'not_requested';$rulesVersion=(string)mahda_setting($db,'content_rules_version','1');$publishedAt=$publishShowcase?date('Y-m-d H:i:s'):null;$bankAt=$requestBank?date('Y-m-d H:i:s'):null;
                $stmt=$db->prepare("INSERT INTO mahda_contents(author_id,profile_id,category_id,title,body,execution_text,duration_minutes,age_4_6,age_7_10,indoor,outdoor,players_min,players_max,activity_level,tool_free,general_occasion,extra_fields_json,visibility,review_status,rules_accepted_at,published_at,bank_requested_at,rules_version,source_draft_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),?,?,?,?)");
                $stmt->execute([(int)$user['id'],$profileId,$category,$title,$mainText,$executionText,$minutes,in_array('4-6',$ages,true)?1:0,in_array('7-10',$ages,true)?1:0,in_array('indoor',$spaces,true)?1:0,in_array('outdoor',$spaces,true)?1:0,$players[0],$players[1],$activityLevel,$toolFree===true?1:0,$general?1:0,json_encode($extra,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$visibility,$reviewStatus,$publishedAt,$bankAt,$rulesVersion,$draftId]);$contentId=(int)$db->lastInsertId();mahda_assign_content_desk($db,$contentId,$category);
                $goalCheck=$db->prepare('SELECT id FROM mahda_goals WHERE id=? AND is_active=1');$goalLink=$db->prepare('INSERT IGNORE INTO mahda_content_goals(content_id,goal_id) VALUES(?,?)');foreach(array_slice($goalIds,0,20) as $gid){$goalCheck->execute([$gid]);if($goalCheck->fetchColumn())$goalLink->execute([$contentId,$gid]);}
                $occCheck=$db->prepare('SELECT id FROM mahda_occasions WHERE id=? AND is_active=1');$occLink=$db->prepare('INSERT IGNORE INTO mahda_content_occasions(content_id,occasion_id) VALUES(?,?)');foreach(array_slice($occasionIds,0,40) as $oid){$occCheck->execute([$oid]);if($occCheck->fetchColumn())$occLink->execute([$contentId,$oid]);}
                $toolLink=$db->prepare('INSERT INTO mahda_content_tools(content_id,label,sort_order) VALUES(?,?,?)');foreach($tools as $i=>$tool)$toolLink->execute([$contentId,$tool,$i]);
                $db->prepare("UPDATE mahda_files SET content_id=?,draft_id=NULL,is_temporary=0,updated_at=NOW() WHERE draft_id=? AND owner_id=? AND content_id IS NULL AND COALESCE(status,'ready')='ready'")->execute([$contentId,$draftId,(int)$user['id']]);
                $db->prepare('UPDATE mahda_content_drafts SET completed_content_id=?,completed_at=NOW(),version=version+1,current_step=9 WHERE id=? AND owner_id=?')->execute([$contentId,$draftId,(int)$user['id']]);mahda_record_sync_change($db,(int)$user['id'],'content_draft',$draftId,(int)$draft['version']+1);mahda_audit($db,(int)$user['id'],'content_publish_v12','content',$contentId,['showcase'=>$publishShowcase,'bankReview'=>$requestBank,'draftId'=>$draftId]);$db->commit();
                if($requestBank)mahda_admin_notify($db,'content_submitted','محتوای جدید برای بررسی','محتوای «'.$title.'» وارد صف بررسی بانک مهدا شد.','content',$contentId,'content:pending:'.$contentId);
                mahda_json(['ok'=>true,'contentId'=>$contentId,'publishedToShowcase'=>$publishShowcase,'bankReviewRequested'=>$requestBank,'reviewStatus'=>$reviewStatus],201);
            }catch(RuntimeException $e){if($db->inTransaction())$db->rollBack();$safe=in_array($e->getMessage(),['invalid_category','title_required','age_required','space_required','invalid_duration','invalid_players','profile_not_owned','cover_required','main_content_required','required_custom_field','invalid_positive_integer','invalid_game_style','invalid_experiment_difficulty'],true)?$e->getMessage():'publish_validation_failed';mahda_json(['error'=>$safe],422);}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
        }

        if ($action === 'content_create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            mahda_json(['error'=>'legacy_content_create_disabled','use'=>'content_publish_v12'],410);
        }

        if ($action === 'content_delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data();
            mahda_require_csrf($data);
            $user = mahda_require_member($db);
            $contentId = max(0, (int)($data['contentId'] ?? 0));
            if ($contentId < 1) { mahda_json(['error' => 'invalid_content'], 422); }

            // Only the owner or an admin may delete content. Keep the lookup
            // independent from the public visibility query so an owner can also
            // remove a draft or a rejected item from their own showcase.
            $owned = $db->prepare('SELECT id,author_id,desk_id FROM mahda_contents WHERE id=? LIMIT 1');
            $owned->execute([$contentId]);
            $content = $owned->fetch();
            if (!$content) { mahda_json(['error' => 'content_not_found'], 404); }
            if ((int)$content['author_id'] !== (int)$user['id']) {
                if (!in_array((string)($user['role'] ?? ''), ['admin','reviewer'], true) || !mahda_can_access_content($db,$user,$content,'delete')) {
                    mahda_json(['error' => 'content_not_owned'], 403);
                }
            }

            $filesStmt = $db->prepare('SELECT storage_key FROM mahda_files WHERE content_id=?');
            $filesStmt->execute([$contentId]);
            $storageKeys = array_values(array_filter(array_map(
                static fn(array $row): string => basename((string)($row['storage_key'] ?? '')),
                $filesStmt->fetchAll()
            ), static fn(string $key): bool => $key !== '' && $key !== '.' && $key !== '..'));

            $db->beginTransaction();
            try {
                // Explicit child deletes keep this endpoint compatible with older
                // installations whose foreign keys did not all use CASCADE.
                foreach ([
                    'mahda_package_items',
                    'mahda_reviews',
                    'mahda_notifications',
                    'mahda_comments',
                    'mahda_interactions',
                    'mahda_content_tools',
                    'mahda_content_occasions',
                    'mahda_content_goals',
                    'mahda_content_topics',
                    'mahda_home_section_items',
                    'mahda_special_page_items',
                    'mahda_review_actions',
                    'mahda_files',
                ] as $table) {
                    $db->prepare("DELETE FROM {$table} WHERE content_id=?")->execute([$contentId]);
                }
                $db->prepare('DELETE FROM mahda_contents WHERE id=?')->execute([$contentId]);
                $db->commit();
            } catch (Throwable $error) {
                if ($db->inTransaction()) { $db->rollBack(); }
                throw $error;
            }

            $deletedFiles = 0;
            $storage = mahda_storage_adapter();
            foreach ($storageKeys as $storageKey) {
                if ($storage->exists($storageKey)) { $storage->delete($storageKey); $deletedFiles++; }
            }
            mahda_json(['ok' => true, 'deletedId' => (string)$contentId, 'deletedFiles' => $deletedFiles]);
        }

    mahda_json(['error' => 'method_not_allowed'], 405);
}
