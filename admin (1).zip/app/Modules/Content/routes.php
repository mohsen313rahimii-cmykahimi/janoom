<?php
declare(strict_types=1);

namespace Mahda\Modules\Content;

use Mahda\Core\Router;
use Mahda\Core\View;

return static function (Router $router, View $view): void {
    $controller = new ContentController($view);
    $router->get('/content', [$controller, 'index']);
    $router->get('/content/item/{id}', [$controller, 'detail']);
    $router->get('/content/new', [$controller, 'create']);
    $router->get('/search', [$controller, 'search']);
};
