<?php
declare(strict_types=1);

namespace Mahda\Modules\Content;

use PDO;

/**
 * Guided, deterministic search for the public Mahda content bank.
 *
 * This service deliberately does not call an LLM. It translates the user's
 * step-by-step choices into validated filters, ranks approved real contents,
 * and returns at most a small recommendation set.
 */
final class GuidedSearchService
{
    private const MAX_RESULTS = 6;

    public function __construct(private PDO $db)
    {
    }

    /** @return array<string,mixed> */
    public function bootstrap(): array
    {
        $categories = $this->db->query(
            "SELECT id,label,icon,color,description FROM mahda_categories
             WHERE is_active=1 AND COALESCE(show_in_bank,1)=1
             ORDER BY sort_order,id"
        )->fetchAll();

        $goals = $this->db->query(
            "SELECT id,label,description,goal_group FROM mahda_goals
             WHERE is_active=1 ORDER BY sort_order,label LIMIT 300"
        )->fetchAll();

        $occasions = $this->db->query(
            "SELECT id,label,occasion_group,description FROM mahda_occasions
             WHERE is_active=1 ORDER BY sort_order,label LIMIT 400"
        )->fetchAll();

        return [
            'categories' => array_map(static fn(array $row): array => [
                'id' => (string)$row['id'],
                'label' => (string)$row['label'],
                'icon' => (string)($row['icon'] ?? ''),
                'color' => (string)($row['color'] ?? '#159658'),
                'description' => (string)($row['description'] ?? ''),
            ], $categories),
            'goals' => array_map(static fn(array $row): array => [
                'id' => (int)$row['id'],
                'label' => (string)$row['label'],
                'description' => (string)($row['description'] ?? ''),
                'group' => (string)($row['goal_group'] ?? ''),
            ], $goals),
            'occasions' => array_map(static fn(array $row): array => [
                'id' => (int)$row['id'],
                'label' => (string)$row['label'],
                'group' => (string)($row['occasion_group'] ?? ''),
                'description' => (string)($row['description'] ?? ''),
            ], $occasions),
            'ages' => [
                ['id' => '4-6', 'label' => '۴ تا ۶ سال'],
                ['id' => '7-10', 'label' => '۷ تا ۱۰ سال'],
                ['id' => 'any', 'label' => 'همه سنین'],
            ],
            'durations' => [
                ['id' => '15', 'label' => 'تا ۱۵ دقیقه'],
                ['id' => '30', 'label' => '۱۵ تا ۳۰ دقیقه'],
                ['id' => '60', 'label' => '۳۰ تا ۶۰ دقیقه'],
                ['id' => '60+', 'label' => 'بیشتر از یک ساعت'],
                ['id' => 'any', 'label' => 'مهم نیست'],
            ],
            'participants' => [
                ['id' => '1', 'label' => 'یک نفر'],
                ['id' => '2-5', 'label' => '۲ تا ۵ نفر'],
                ['id' => '6-15', 'label' => '۶ تا ۱۵ نفر'],
                ['id' => '16+', 'label' => 'بیشتر از ۱۵ نفر'],
                ['id' => 'any', 'label' => 'مهم نیست'],
            ],
            'spaces' => [
                ['id' => 'indoor', 'label' => 'فضای بسته'],
                ['id' => 'outdoor', 'label' => 'فضای باز'],
                ['id' => 'any', 'label' => 'فرقی ندارد'],
            ],
        ];
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public function recommend(array $input): array
    {
        $filters = $this->validate($input);
        $whereParams = [];
        $scoreParams = [];
        $exactParams = [];
        $where = [
            "p.name<>''",
            'owner.is_active=1',
            "owner.email NOT LIKE 'guest-%@mahda.local'",
            "owner.email NOT LIKE 'test-phone-%@mahda.local'",
            'c.archived_at IS NULL',
            "c.visibility<>'hidden'",
            "c.review_status='approved'",
            'cat.is_active=1',
            'COALESCE(cat.show_in_bank,1)=1',
        ];

        // Category and age define the user's core intent. Keep these hard so
        // "nearest" never silently becomes an unrelated type or age group.
        if ($filters['category'] !== 'any') {
            $where[] = 'c.category_id=?';
            $whereParams[] = $filters['category'];
        }
        if ($filters['age'] === '4-6') {
            $where[] = 'c.age_4_6=1';
        } elseif ($filters['age'] === '7-10') {
            $where[] = 'c.age_7_10=1';
        }

        $scoreParts = ['20'];
        $exactParts = ['1=1'];

        if ($filters['occasionId'] > 0) {
            $condition = 'EXISTS (SELECT 1 FROM mahda_content_occasions gso WHERE gso.content_id=c.id AND gso.occasion_id=?)';
            $scoreParts[] = "CASE WHEN {$condition} THEN 28 WHEN c.general_occasion=1 THEN 10 ELSE 0 END";
            $scoreParams[] = $filters['occasionId'];
            $exactParts[] = $condition;
            $exactParams[] = $filters['occasionId'];
        }

        if ($filters['goalIds']) {
            $goalPlaceholders = implode(',', array_fill(0, count($filters['goalIds']), '?'));
            $scoreParts[] = "LEAST(24, (SELECT COUNT(*) FROM mahda_content_goals gsg WHERE gsg.content_id=c.id AND gsg.goal_id IN ({$goalPlaceholders})) * 12)";
            foreach ($filters['goalIds'] as $goalId) $scoreParams[] = $goalId;
            $exactParts[] = "EXISTS (SELECT 1 FROM mahda_content_goals gse WHERE gse.content_id=c.id AND gse.goal_id IN ({$goalPlaceholders}))";
            foreach ($filters['goalIds'] as $goalId) $exactParams[] = $goalId;
        }

        if ($filters['equipment'] === 'none') {
            $scoreParts[] = 'CASE WHEN c.tool_free=1 THEN 14 ELSE 0 END';
            $exactParts[] = 'c.tool_free=1';
        }

        $durationCondition = $this->durationCondition($filters['duration']);
        if ($durationCondition !== '') {
            $scoreParts[] = "CASE WHEN {$durationCondition} THEN 12 ELSE 0 END";
            $exactParts[] = $durationCondition;
        }

        $participantCondition = $this->participantCondition($filters['participants']);
        if ($participantCondition !== '') {
            $scoreParts[] = "CASE WHEN {$participantCondition} THEN 10 ELSE 0 END";
            $exactParts[] = $participantCondition;
        }

        if ($filters['space'] === 'indoor') {
            $scoreParts[] = 'CASE WHEN c.indoor=1 THEN 8 ELSE 0 END';
            $exactParts[] = 'c.indoor=1';
        } elseif ($filters['space'] === 'outdoor') {
            $scoreParts[] = 'CASE WHEN c.outdoor=1 THEN 8 ELSE 0 END';
            $exactParts[] = 'c.outdoor=1';
        }

        $from = 'FROM mahda_contents c
            JOIN mahda_profiles p ON p.id=c.profile_id
            JOIN mahda_users owner ON owner.id=c.author_id
            JOIN mahda_categories cat ON cat.id=c.category_id';

        $sql = 'SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color,('
            . implode(' + ', $scoreParts) . ') AS guided_score,CASE WHEN (' . implode(' AND ', $exactParts) . ') THEN 1 ELSE 0 END AS guided_exact '
            . $from . ' WHERE ' . implode(' AND ', $where)
            . ' ORDER BY guided_exact DESC,guided_score DESC,c.published_at DESC,c.created_at DESC,c.id DESC LIMIT 30';

        $stmt = $this->db->prepare($sql);
        $params = array_merge($scoreParams, $exactParams, $whereParams);
        foreach ($params as $index => $param) {
            $stmt->bindValue($index + 1, $param, is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();
        $rows = $stmt->fetchAll();
        $items = function_exists('mahda_items') ? mahda_items($this->db, $rows) : [];

        $rowMeta = [];
        foreach ($rows as $row) {
            $rowMeta[(string)$row['id']] = [
                'score' => (int)($row['guided_score'] ?? 0),
                'exact' => (bool)($row['guided_exact'] ?? false),
            ];
        }

        $result = [];
        foreach ($items as $item) {
            $id = (string)($item['id'] ?? '');
            $meta = $rowMeta[$id] ?? ['score' => 0, 'exact' => false];
            $item['matchScore'] = $meta['score'];
            $item['isExactMatch'] = $meta['exact'];
            $item['matchReasons'] = $this->reasons($item, $filters);
            $result[] = $item;
            if (count($result) >= self::MAX_RESULTS) break;
        }

        $hasExact = false;
        foreach ($result as $item) {
            if (!empty($item['isExactMatch'])) { $hasExact = true; break; }
        }

        return [
            'items' => $result,
            'matchType' => $result ? ($hasExact ? 'exact' : 'nearest') : 'none',
            'total' => count($result),
            'filters' => $filters,
        ];
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    private function validate(array $input): array
    {
        $category = trim((string)($input['category'] ?? 'any'));
        if ($category !== 'any') {
            $stmt = $this->db->prepare('SELECT 1 FROM mahda_categories WHERE id=? AND is_active=1 AND COALESCE(show_in_bank,1)=1 LIMIT 1');
            $stmt->execute([$category]);
            if (!$stmt->fetchColumn()) $category = 'any';
        }

        $age = (string)($input['age'] ?? 'any');
        if (!in_array($age, ['4-6', '7-10', 'any'], true)) $age = 'any';

        $occasionId = max(0, (int)($input['occasionId'] ?? $input['occasion_id'] ?? 0));
        if ($occasionId > 0) {
            $stmt = $this->db->prepare('SELECT 1 FROM mahda_occasions WHERE id=? AND is_active=1 LIMIT 1');
            $stmt->execute([$occasionId]);
            if (!$stmt->fetchColumn()) $occasionId = 0;
        }

        $goalIds = $input['goalIds'] ?? $input['goal_ids'] ?? [];
        if (is_string($goalIds)) $goalIds = preg_split('/\s*,\s*/', $goalIds, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (!is_array($goalIds)) $goalIds = [];
        $goalIds = array_values(array_unique(array_filter(array_map('intval', array_slice($goalIds, 0, 5)), static fn(int $id): bool => $id > 0)));
        if ($goalIds) {
            $ph = implode(',', array_fill(0, count($goalIds), '?'));
            $stmt = $this->db->prepare("SELECT id FROM mahda_goals WHERE is_active=1 AND id IN ({$ph})");
            $stmt->execute($goalIds);
            $valid = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
            $goalIds = array_values(array_intersect($goalIds, $valid));
        }

        $equipment = (string)($input['equipment'] ?? 'any');
        if (!in_array($equipment, ['none', 'any'], true)) $equipment = 'any';
        $duration = (string)($input['duration'] ?? 'any');
        if (!in_array($duration, ['15', '30', '60', '60+', 'any'], true)) $duration = 'any';
        $participants = (string)($input['participants'] ?? 'any');
        if (!in_array($participants, ['1', '2-5', '6-15', '16+', 'any'], true)) $participants = 'any';
        $space = (string)($input['space'] ?? 'any');
        if (!in_array($space, ['indoor', 'outdoor', 'any'], true)) $space = 'any';

        return compact('category', 'age', 'occasionId', 'goalIds', 'equipment', 'duration', 'participants', 'space');
    }

    private function durationCondition(string $bucket): string
    {
        return match ($bucket) {
            '15' => '(c.duration_minutes IS NOT NULL AND c.duration_minutes<=15)',
            '30' => '(c.duration_minutes BETWEEN 16 AND 30)',
            '60' => '(c.duration_minutes BETWEEN 31 AND 60)',
            '60+' => '(c.duration_minutes>60)',
            default => '',
        };
    }

    private function participantCondition(string $bucket): string
    {
        return match ($bucket) {
            '1' => '(COALESCE(c.players_min,1)<=1 AND COALESCE(c.players_max,1)>=1)',
            '2-5' => '(COALESCE(c.players_min,2)<=5 AND COALESCE(c.players_max,5)>=2)',
            '6-15' => '(COALESCE(c.players_min,6)<=15 AND COALESCE(c.players_max,15)>=6)',
            '16+' => '(COALESCE(c.players_max,c.players_min,0)>=16)',
            default => '',
        };
    }

    /** @param array<string,mixed> $item @param array<string,mixed> $filters @return list<string> */
    private function reasons(array $item, array $filters): array
    {
        $reasons = [];
        if ($filters['category'] !== 'any') $reasons[] = (string)($item['categoryLabel'] ?? 'هم‌دسته');
        if ($filters['age'] !== 'any') $reasons[] = 'مناسب گروه سنی';
        if ($filters['occasionId'] > 0 && !empty($item['isExactMatch'])) $reasons[] = 'هم‌مناسبت';
        if ($filters['goalIds'] && !empty($item['goals'])) $reasons[] = 'هم‌راستا با هدف';
        if ($filters['equipment'] === 'none' && !empty($item['isToolFree'])) $reasons[] = 'بدون وسیله';
        if ($filters['duration'] !== 'any' && !empty($item['durationMinutes'])) $reasons[] = 'زمان مناسب';
        if ($filters['participants'] !== 'any' && !empty($item['audienceSize'])) $reasons[] = 'تعداد مناسب';
        if ($filters['space'] !== 'any' && in_array($filters['space'], (array)($item['spaces'] ?? []), true)) $reasons[] = 'فضای مناسب';
        return array_slice(array_values(array_unique($reasons)), 0, 4);
    }
}
