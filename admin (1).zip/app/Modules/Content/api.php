<?php
declare(strict_types=1);

use Mahda\Modules\Content\CategoryRepository;
use Mahda\Modules\Content\ContentFilter;
use Mahda\Modules\Content\ContentRepository;
use Mahda\Modules\Content\ContentService;
use Mahda\Modules\Content\GuidedSearchService;

/**
 * Transitional adapter for the public bank/search actions. The old API file
 * remains as a compatibility entrypoint; these actions are served by the
 * focused Content module first and keep their existing JSON contract.
 */
function mahda_content_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['categories', 'contents', 'global_search', 'guided_search_bootstrap', 'guided_search'], true)) {
        return false;
    }

    $categories = new CategoryRepository($db);
    $repository = new ContentRepository($db);
    $service = new ContentService($db, $repository);
    $guided = new GuidedSearchService($db);

    try {
        if ($action === 'categories' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            mahda_json(['items' => $categories->activeForBank()]);
        }

        if ($action === 'contents' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            $filter = ContentFilter::fromQuery($_GET);
            $result = $service->publicCards($filter);
            mahda_json([
                'items' => $result->items,
                'limit' => $result->perPage,
                'offset' => $filter->offset(),
                'total' => $result->total,
                'hasMore' => $result->hasMore(),
            ]);
        }

        if ($action === 'guided_search_bootstrap' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            mahda_json($guided->bootstrap());
        }

        if ($action === 'guided_search' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            mahda_json($guided->recommend($_GET));
        }

        if ($action === 'global_search' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            $query = trim((string)($_GET['q'] ?? ''));
            $limit = max(1, min(30, (int)($_GET['limit'] ?? 12)));
            if ($query === '') {
                mahda_json(['query' => '', 'contents' => [], 'profiles' => [], 'cities' => [], 'topics' => [], 'goals' => [], 'occasions' => [], 'total' => 0]);
            }

            $contentResult = $service->publicCards(new ContentFilter(query: $query, perPage: $limit));
            $profiles = mahda_content_module_profiles($db, $query, $limit);
            $cities = mahda_content_module_cities($db, $query);
            $topics = mahda_content_module_taxonomy($db, 'mahda_topics', $query);
            $goals = mahda_content_module_taxonomy($db, 'mahda_goals', $query);
            $occasions = mahda_content_module_occasions($db, $query);
            $contents = $contentResult->items;
            $total = count($contents) + count($profiles) + count($cities) + count($topics) + count($goals) + count($occasions);
            mahda_json(compact('query', 'contents', 'profiles', 'cities', 'topics', 'goals', 'occasions', 'total'));
        }
        mahda_json(['error' => 'method_not_allowed'], 405);
    } catch (\Throwable $error) {
        mahda_json(['error' => 'content_service_unavailable'], 503);
    }

    return true;
}

/** @return list<array<string,mixed>> */
function mahda_content_module_profiles(PDO $db, string $query, int $limit): array
{
    $term = '%' . $query . '%';
    $max = min(12, $limit);
    $stmt = $db->prepare("SELECT p.id,p.slug,p.name,p.kind,p.bio,p.city,p.profile_role,p.is_verified,
        (SELECT COUNT(*) FROM mahda_follows f WHERE f.profile_id=p.id) followers,
        (SELECT COUNT(*) FROM mahda_contents c WHERE c.profile_id=p.id AND c.archived_at IS NULL AND c.visibility<>'hidden' AND c.review_status='approved') content_count
        FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id
        WHERE p.name<>'' AND u.is_active=1 AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local'
          AND p.profile_role IN ('mentor','heiat') AND (p.name LIKE ? OR p.bio LIKE ? OR p.city LIKE ?)
        ORDER BY p.is_verified DESC,followers DESC,p.id DESC LIMIT {$max}");
    $stmt->execute([$term, $term, $term]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $items[] = [
            'id' => (int)$row['id'],
            'slug' => (string)$row['slug'],
            'name' => (string)$row['name'],
            'kind' => (string)$row['kind'],
            'role' => (string)($row['profile_role'] ?? ($row['kind'] === 'heiat' ? 'heiat' : 'mentor')),
            'bio' => (string)($row['bio'] ?? ''),
            'city' => (string)($row['city'] ?? ''),
            'verified' => (bool)$row['is_verified'],
            'avatarUrl' => '/mahda-api/index.php?action=profile_avatar&id=' . (int)$row['id'],
            'badges' => [],
            'followers' => (int)$row['followers'],
            'contentCount' => (int)$row['content_count'],
        ];
    }
    return $items;
}

/** @return list<array<string,mixed>> */
function mahda_content_module_cities(PDO $db, string $query): array
{
    $term = '%' . $query . '%';
    $stmt = $db->prepare('SELECT c.id,c.name,c.slug,c.latitude,c.longitude,p.name province_name FROM mahda_cities c JOIN mahda_provinces p ON p.id=c.province_id WHERE c.name LIKE ? OR p.name LIKE ? ORDER BY c.name LIMIT 20');
    $stmt->execute([$term, $term]);
    return array_map(static fn(array $row): array => array_merge($row, ['id' => (int)$row['id']]), $stmt->fetchAll());
}

/** @return list<array<string,mixed>> */
function mahda_content_module_taxonomy(PDO $db, string $table, string $query): array
{
    if (!preg_match('/^mahda_(topics|goals)$/', $table)) {
        return [];
    }
    $term = '%' . $query . '%';
    $stmt = $db->prepare("SELECT id,label FROM {$table} WHERE is_active=1 AND (label LIKE ? OR description LIKE ?) ORDER BY sort_order,label LIMIT 20");
    $stmt->execute([$term, $term]);
    return array_map(static fn(array $row): array => ['id' => (int)$row['id'], 'label' => (string)$row['label']], $stmt->fetchAll());
}

/** @return list<array<string,mixed>> */
function mahda_content_module_occasions(PDO $db, string $query): array
{
    $term = '%' . $query . '%';
    $stmt = $db->prepare('SELECT id,label,occasion_group FROM mahda_occasions WHERE is_active=1 AND (label LIKE ? OR aliases_json LIKE ? OR description LIKE ?) ORDER BY sort_order,label LIMIT 20');
    $stmt->execute([$term, $term, $term]);
    return array_map(static fn(array $row): array => ['id' => (int)$row['id'], 'label' => (string)$row['label'], 'occasion_group' => (string)$row['occasion_group']], $stmt->fetchAll());
}
