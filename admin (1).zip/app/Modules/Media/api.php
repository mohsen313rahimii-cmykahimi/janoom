<?php
declare(strict_types=1);

/** API actions owned by the Media module. */
function mahda_media_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['file_upload', 'file'], true)) {
        return false;
    }

        if ($action === 'file_upload' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            mahda_start_session();
            mahda_enforce_rate_limit($db,'file_upload',30,300);
            $user = mahda_require_complete_member($db);
            mahda_require_csrf([]);
            $contentId = max(0, (int)($_POST['content_id'] ?? 0));
            $purpose = mahda_string($_POST['purpose'] ?? '', 30);
            if ($contentId < 1 || !in_array($purpose, ['cover','execution_video','execution_audio','attachment'], true)) { mahda_json(['error'=>'invalid_file_upload'], 422); }
            if (empty($_FILES['file']) || !is_array($_FILES['file'])) { mahda_json(['error'=>'file_required'], 422); }
            $uploaded = $_FILES['file'];
            $uploadError = (int)($uploaded['error'] ?? UPLOAD_ERR_NO_FILE);
            if (in_array($uploadError, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) { mahda_json(['error'=>'file_too_large'], 413); }
            if ($uploadError === UPLOAD_ERR_NO_FILE) { mahda_json(['error'=>'file_required'], 422); }
            if ($uploadError !== UPLOAD_ERR_OK || !is_uploaded_file((string)($uploaded['tmp_name'] ?? ''))) { mahda_json(['error'=>'upload_failed'], 422); }
            try {
                $stored = mahda_store_uploaded_v12($db, $uploaded, $purpose);
            } catch (RuntimeException $e) {
                $safe = in_array($e->getMessage(), ['file_too_large','file_required','upload_failed','file_type_not_allowed','storage_unavailable','cover_ratio_required','archive_contains_executable','image_compression_failed','media_processing_unavailable'], true) ? $e->getMessage() : 'upload_failed';
                mahda_json(['error'=>$safe], $safe==='file_too_large' ? 413 : 422);
            }
            $storageKey=(string)$stored['storage_key'];$mime=(string)$stored['mime'];$size=(int)$stored['size'];$sha=(string)$stored['sha256'];$originalName=(string)$stored['original_name'];
            $owner = $db->prepare('SELECT author_id,profile_id,visibility,review_status,extra_fields_json FROM mahda_contents WHERE id=? LIMIT 1');
            $owner->execute([$contentId]); $content = $owner->fetch();
            if (!$content || (int)$content['author_id'] !== (int)$user['id']) { mahda_safe_remove_file_keys($stored); mahda_json(['error'=>'content_not_owned'], 403); }
            $oldFiles = [];
            $db->beginTransaction();
            try {
                if ($purpose !== 'attachment') {
                    $old = $db->prepare('SELECT * FROM mahda_files WHERE content_id=? AND purpose=?'); $old->execute([$contentId,$purpose]); $oldFiles = $old->fetchAll();
                    $db->prepare('DELETE FROM mahda_files WHERE content_id=? AND purpose=?')->execute([$contentId,$purpose]);
                }
                $db->prepare("INSERT INTO mahda_files(owner_id,content_id,purpose,storage_key,original_name,mime_type,size_bytes,sha256,status,processing_error,original_storage_key,thumbnail_storage_key,width,height,is_temporary,updated_at) VALUES(?,?,?,?,?,?,?,?,'ready',NULL,?,?,?,?,0,NOW())")->execute([(int)$user['id'],$contentId,$purpose,$storageKey,$originalName,$mime,$size,$sha,$stored['original_storage_key'],$stored['thumbnail_storage_key'],$stored['width'],$stored['height']]);
                $fileId = (int)$db->lastInsertId();
                $extra = json_decode((string)($content['extra_fields_json'] ?? ''), true); if (!is_array($extra)) { $extra = []; }
                if ($purpose === 'execution_video') { $extra['videoFileName'] = $originalName; }
                elseif ($purpose === 'execution_audio') { $extra['voiceFileName'] = $originalName; $extra['voiceDuration'] = mahda_string($_POST['voice_duration'] ?? '', 30); }
                $db->prepare('UPDATE mahda_contents SET extra_fields_json=? WHERE id=?')->execute([json_encode(array_filter($extra, static fn(mixed $value): bool => $value !== '' && $value !== false), JSON_UNESCAPED_UNICODE), $contentId]);
                $db->commit();
            } catch (Throwable $error) {
                if ($db->inTransaction()) { $db->rollBack(); }
                mahda_safe_remove_file_keys($stored);
                throw $error;
            }
            foreach ($oldFiles as $oldFile) { mahda_safe_remove_file_keys($oldFile); }
            mahda_queue_media_processing_v12($db,$fileId,$purpose,$mime);
            $find = $db->prepare("SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_categories cat ON cat.id=c.category_id WHERE c.id=?");
            $find->execute([$contentId]);
            $fileRow=$db->prepare('SELECT * FROM mahda_files WHERE id=?');$fileRow->execute([$fileId]);mahda_json(['file'=>mahda_file_public_payload($fileRow->fetch()), 'item'=>mahda_item($db, $find->fetch()), 'stored'=>true], 201);
        }

        if ($action === 'file' && in_array($_SERVER['REQUEST_METHOD'], ['GET','HEAD'], true)) {
            $id = max(0, (int)($_GET['id'] ?? 0));
            if ($id < 1) { http_response_code(404); exit; }
            $stmt = $db->prepare("SELECT f.storage_key,f.mime_type,f.original_name,f.owner_id,f.content_id,f.draft_id,f.status,f.purpose,f.sha256,f.updated_at,c.visibility,c.review_status,c.author_id,c.archived_at,c.desk_id,u.is_active AS owner_active FROM mahda_files f LEFT JOIN mahda_contents c ON c.id=f.content_id LEFT JOIN mahda_users u ON u.id=COALESCE(c.author_id,f.owner_id) WHERE f.id=? LIMIT 1");
            $stmt->execute([$id]); $file = $stmt->fetch();
            if (!$file || (int)($file['owner_active'] ?? 0) !== 1 || (string)($file['status']??'ready')!=='ready') { http_response_code(404); exit; }
            $viewer = mahda_current_user($db, true); $isDraft=$file['content_id']===null;
            $isPublicMedia = !$isDraft && empty($file['archived_at']) && ((string)($file['visibility']??'')==='showcase' || ((string)($file['visibility']??'')!=='hidden' && (string)($file['review_status']??'')==='approved'));
            if($isDraft){$canView=empty($viewer['guest'])&&(int)($viewer['id']??0)===(int)$file['owner_id'];}
            else{$canView=$isPublicMedia;
                if(!$canView&&empty($viewer['guest'])&&(int)($viewer['id']??0)===(int)($file['author_id']??0))$canView=true;
                elseif(!$canView&&empty($viewer['guest'])&&in_array((string)($viewer['role']??''),['admin','reviewer'],true))$canView=mahda_can_access_content($db,$viewer,['desk_id'=>(int)($file['desk_id']??0)],'view');}
            if (!$canView) { http_response_code(404); exit; }
            $key = basename((string)$file['storage_key']); $full = mahda_existing_upload_path($key);
            if (!$full) { http_response_code(404); exit; }
            $size = (int)filesize($full);
            if ($size < 0) { http_response_code(404); exit; }
            $mime = preg_match('#^[a-z0-9.+-]+/[a-z0-9.+-]+$#i', (string)$file['mime_type']) ? (string)$file['mime_type'] : 'application/octet-stream';
            $name = str_replace(["\r","\n"], '', (string)$file['original_name']);
            if ($name === '') { $name = 'file'; }
            $start = 0; $end = max(0, $size - 1); $status = 200;
            $range = (string)($_SERVER['HTTP_RANGE'] ?? '');
            if ($size > 0 && $range !== '') {
                if (!preg_match('/^bytes=(\d*)-(\d*)$/', trim($range), $match)) {
                    header('Content-Range: bytes */' . $size); http_response_code(416); exit;
                }
                $left = $match[1]; $right = $match[2];
                if ($left === '' && $right === '') { header('Content-Range: bytes */' . $size); http_response_code(416); exit; }
                if ($left === '') {
                    if ((int)$right < 1) { header('Content-Range: bytes */' . $size); http_response_code(416); exit; } $suffix = (int)$right; $start = max(0, $size - $suffix);
                } else {
                    $start = (int)$left;
                }
                $end = $right !== '' && $left !== '' ? min($end, (int)$right) : $end;
                if ($start < 0 || $start >= $size || $end < $start) { header('Content-Range: bytes */' . $size); http_response_code(416); exit; }
                $status = 206;
            }
            $length = $size === 0 ? 0 : ($end - $start + 1);
            $purpose = (string)($file['purpose'] ?? '');
            $isImage = str_starts_with($mime, 'image/');
            // Public cover/content images use the browser HTTP cache for a short period.
            // The URL contains a file id; replacing a cover creates a new id, so old cache entries never overwrite a new cover.
            if ($isPublicMedia) {
                if ($purpose === 'cover' || ($purpose === 'main_file' && $isImage)) {
                    $cacheControl = 'public, max-age=604800, stale-while-revalidate=2592000'; // 7 days fresh, up to 30 days stale while refreshing
                } elseif ($isImage) {
                    $cacheControl = 'public, max-age=259200, stale-while-revalidate=604800'; // 3 days
                } else {
                    $cacheControl = 'public, max-age=86400, stale-while-revalidate=604800'; // 1 day for larger media/files
                }
            } else {
                $cacheControl = 'private, no-store';
            }
            $sha = trim((string)($file['sha256'] ?? ''));
            $etagSeed = $sha !== '' ? $sha : ($id . ':' . $size . ':' . (string)@filemtime($full));
            $etag = '"' . substr(hash('sha256', $etagSeed), 0, 32) . '"';
            $lastModifiedTs = (int)@filemtime($full);
            if ($isPublicMedia && $range === '') {
                $ifNoneMatch = trim((string)($_SERVER['HTTP_IF_NONE_MATCH'] ?? ''));
                if ($ifNoneMatch !== '' && $ifNoneMatch === $etag) {
                    http_response_code(304);
                    header('Cache-Control: ' . $cacheControl);
                    header('ETag: ' . $etag);
                    if ($lastModifiedTs > 0) { header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $lastModifiedTs) . ' GMT'); }
                    exit;
                }
            }
            http_response_code($status);
            header('Content-Type: ' . $mime);
            header('Accept-Ranges: bytes');
            header('Cache-Control: ' . $cacheControl);
            if ($isPublicMedia) {
                header('ETag: ' . $etag);
                if ($lastModifiedTs > 0) { header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $lastModifiedTs) . ' GMT'); }
            }
            header("Content-Disposition: inline; filename*=UTF-8''" . rawurlencode($name));
            header('Content-Length: ' . $length);
            if ($status === 206) { header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size); }
            if ($_SERVER['REQUEST_METHOD'] === 'HEAD') { exit; }
            if ($length === 0) { exit; }
            $handle = fopen($full, 'rb');
            if ($handle === false) { http_response_code(404); exit; }
            if ($start > 0) { fseek($handle, $start); }
            $remaining = $length;
            while ($remaining > 0 && !feof($handle)) {
                $chunk = fread($handle, min(1024 * 1024, $remaining));
                if ($chunk === false || $chunk === '') { break; }
                echo $chunk;
                $remaining -= strlen($chunk);
                if (function_exists('fastcgi_finish_request') && connection_aborted()) { break; }
                flush();
            }
            fclose($handle);
            exit;
        }

    mahda_json(['error' => 'method_not_allowed'], 405);
}
