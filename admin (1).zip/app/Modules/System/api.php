<?php
declare(strict_types=1);

/** API actions owned by the System module. */
function mahda_system_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['health'], true)) {
        return false;
    }

        if ($action === 'health' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $version = $db->query('SELECT MAX(version) FROM mahda_migrations')->fetchColumn();
            mahda_json(['status' => 'ok', 'schema_version' => (int)$version, 'api_version' => 52, 'write_enabled' => true, 'frontend_connected' => true, 'features' => ['files','phone_auth','admin_login','interactions','notifications','own_showcase','library','review_workflow','admin_users','admin_profiles','admin_categories','admin_settings','media_range_streaming','review_notifications','batched_content_hydration','creator_studio','content_edit_resubmit','revision_status','owner_private_media','content_bank_sorting','safe_profile_publish','mvp_finalization','admin_mobile_dashboard','admin_content_lifecycle','granular_permissions','specialist_desks','admin_username_login','content_topics','dynamic_category_fields','goal_vocabulary','occasion_management','profile_roles','badges','heiat_memberships','reports','admin_notifications','homepage_builder','special_pages','atlas_places','file_manager','system_health','audit_log','public_atlas_drilldown','atlas_choropleth','atlas_city_sync_v25','atlas_home_entry_v25','profile_avatar_global_v27','atlas_profile_card_v27','public_showcase_stage4','profile_editor_stage5','atlas_shell_stage6','library_stage8','global_search_stage9','public_notifications_stage10','public_admin_sync_stage11','content_registration_v12','draft_uploads_v12','content_detail_unified_v12','background_media_processing_v12','content_registration_data_v13','profile_media_v13','profile_avatar_file_upload_v13','profile_avatar_lazy_migration_v14','profile_data_image_sanitized_v14','profile_city_validation_v14','showcase_social_privacy_v15','search_atlas_routing_v16','library_notification_integrity_v17','registration_e2e_integrity_v18','file_infrastructure_v19','admin_public_consistency_v20','phone_auth_fail_closed_v21','contentchin_full_builder_v2','modular_php_api_v48']]);
        }

    mahda_json(['error' => 'method_not_allowed'], 405);
}
