<?php
declare(strict_types=1);

/** API actions owned by the Profile module. */
function mahda_profile_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['profile_avatar', 'profile_avatar_upload', 'profile_update', 'profile', 'profiles_suggested'], true)) {
        return false;
    }

        if ($action === 'profile_avatar' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $profileId = max(0, (int)($_GET['id'] ?? 0));
            if ($profileId < 1) { http_response_code(404); exit; }
            $stmt = $db->prepare("SELECT p.kind,p.profile_data_json FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE p.id=? AND u.is_active=1 LIMIT 1");
            $stmt->execute([$profileId]);
            $row = $stmt->fetch();
            if (!$row) { http_response_code(404); exit; }

            // Prefer a real stored file. If this is an older account, convert its
            // legacy base64 image lazily before serving it; failure is non-destructive
            // and falls back to the old read-only stream below.
            $media = mahda_profile_media_row($db, $profileId);
            if (!$media && mahda_profile_avatar_data((string)($row['profile_data_json'] ?? ''), (string)($row['kind'] ?? 'personal')) !== null) {
                mahda_profile_media_migrate_legacy($db, $profileId, (string)($row['profile_data_json'] ?? ''), (string)($row['kind'] ?? 'personal'));
                $media = mahda_profile_media_row($db, $profileId);
            }
            if ($media) {
                $full = mahda_existing_upload_path((string)$media['storage_key']);
                if ($full === null) {
                    $candidate = mahda_private_upload_dir() . '/' . basename((string)$media['storage_key']);
                    if (is_file($candidate)) $full = $candidate;
                }
                if ($full && is_file($full)) {
                    $mime = (string)$media['mime_type'];
                    $size = (int)filesize($full);
                    if ($size > 0 && in_array($mime, ['image/jpeg','image/png','image/webp'], true)) {
                        $etag = '"' . substr(hash_file('sha256', $full), 0, 24) . '"';
                        if (trim((string)($_SERVER['HTTP_IF_NONE_MATCH'] ?? '')) === $etag) { http_response_code(304); exit; }
                        header_remove('Content-Type');
                        header('Content-Type: ' . $mime);
                        header('Content-Length: ' . $size);
                        header('Cache-Control: public, max-age=300, must-revalidate');
                        header('ETag: ' . $etag);
                        readfile($full);
                        exit;
                    }
                }
            }

            $dataUrl = mahda_profile_avatar_data((string)($row['profile_data_json'] ?? ''), (string)($row['kind'] ?? 'personal'));
            if ($dataUrl === null || preg_match('#^data:(image/(?:jpeg|jpg|png|webp));base64,(.+)$#is', $dataUrl, $m) !== 1) { http_response_code(404); exit; }
            $bytes = base64_decode(preg_replace('/\s+/', '', $m[2]), true);
            if (!is_string($bytes) || $bytes === '' || strlen($bytes) > 6 * 1024 * 1024) { http_response_code(404); exit; }
            $mime = strtolower($m[1]) === 'image/jpg' ? 'image/jpeg' : strtolower($m[1]);
            header_remove('Content-Type');
            header('Content-Type: ' . $mime);
            header('Content-Length: ' . strlen($bytes));
            header('Cache-Control: public, max-age=300, must-revalidate');
            header('ETag: "' . substr(hash('sha256', $bytes), 0, 24) . '"');
            echo $bytes;
            exit;
        }

        if ($action === 'profile_avatar_upload' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            mahda_require_csrf([]);
            mahda_enforce_rate_limit($db, 'profile_avatar_upload', 20, 300);
            $user = mahda_require_member($db);
            $profileId = max(0, (int)($_POST['profileId'] ?? $user['profile_id'] ?? 0));
            if ($profileId < 1) { mahda_json(['error'=>'invalid_profile'],422); }
            $owned = $db->prepare('SELECT id,kind,profile_data_json FROM mahda_profiles WHERE id=? AND owner_id=? LIMIT 1');
            $owned->execute([$profileId,(int)$user['id']]);
            $profile = $owned->fetch();
            if (!$profile) { mahda_json(['error'=>'profile_not_owned'],403); }
            $upload = $_FILES['file'] ?? null;
            if (!is_array($upload)) { mahda_json(['error'=>'file_required'],422); }
            $error=(int)($upload['error']??UPLOAD_ERR_NO_FILE);
            if(in_array($error,[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE],true)) mahda_json(['error'=>'file_too_large'],413);
            if($error!==UPLOAD_ERR_OK || !is_uploaded_file((string)($upload['tmp_name']??''))) mahda_json(['error'=>'upload_failed'],422);
            $size=(int)($upload['size']??0); $phpLimit=mahda_effective_php_upload_limit(); $limit=min(6*1024*1024,$phpLimit>0?$phpLimit:6*1024*1024);
            if($size<1||$size>$limit) mahda_json(['error'=>'file_too_large','maxBytes'=>$limit],413);
            $tmp=(string)$upload['tmp_name']; $mime='';
            if(function_exists('finfo_open')){$f=finfo_open(FILEINFO_MIME_TYPE);if($f){$mime=(string)finfo_file($f,$tmp);finfo_close($f);}}
            if(!in_array($mime,['image/jpeg','image/png','image/webp'],true)) mahda_json(['error'=>'file_type_not_allowed'],422);
            $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime];
            try{$storage=mahda_storage_adapter();$storage->ensureReady();$dir=$storage->directory();}catch(RuntimeException $e){mahda_json(['error'=>'storage_unavailable'],500);}
            $key='profile-'.bin2hex(random_bytes(24)).'.'.$ext; $full=$dir.'/'.$key;
            if(!move_uploaded_file($tmp,$full)) mahda_json(['error'=>'storage_unavailable'],500); @chmod($full,0640);
            mahda_optimize_image_file_v12($full,$mime,'profile_avatar');
            $target=max(32*1024,(int)(mahda_media_config()['image_target_bytes']??200*1024));
            if((int)filesize($full)>$target){@unlink($full);mahda_json(['error'=>'image_compression_failed'],422);}
            [$width,$height]=mahda_image_size_safe($full); $finalSize=(int)filesize($full);
            try { $storage->putFile($key, $full); } catch(Throwable $e) { @unlink($full); mahda_json(['error'=>'storage_unavailable'],500); }
            $old=mahda_profile_media_row($db,$profileId);
            $db->beginTransaction();
            try {
                $db->prepare("INSERT INTO mahda_profile_media(profile_id,owner_id,purpose,storage_key,original_name,mime_type,size_bytes,width,height) VALUES(?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE owner_id=VALUES(owner_id),purpose=VALUES(purpose),storage_key=VALUES(storage_key),original_name=VALUES(original_name),mime_type=VALUES(mime_type),size_bytes=VALUES(size_bytes),width=VALUES(width),height=VALUES(height),updated_at=NOW()")
                    ->execute([$profileId,(int)$user['id'],(string)$profile['kind']==='heiat'?'logo':'avatar',$key,mahda_string($upload['name']??'profile-image',255),$mime,$finalSize,$width,$height]);
                // Once the real file is safely recorded, remove legacy base64 blobs
                // from JSON to keep session/profile payloads small.
                $pd=json_decode((string)($profile['profile_data_json']??''),true); if(!is_array($pd))$pd=[]; unset($pd['avatarDataUrl'],$pd['heiatLogoDataUrl']);
                $db->prepare('UPDATE mahda_profiles SET profile_data_json=? WHERE id=? AND owner_id=?')->execute([json_encode($pd,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$profileId,(int)$user['id']]);
                $db->commit();
            } catch(Throwable $e) { if($db->inTransaction())$db->rollBack(); $storage->delete($key); throw $e; }
            if($old && (string)$old['storage_key']!==$key){mahda_storage_adapter()->delete(basename((string)$old['storage_key']));}
            $fresh=$db->prepare('SELECT kind,profile_data_json FROM mahda_profiles WHERE id=? LIMIT 1');$fresh->execute([$profileId]);$freshRow=$fresh->fetch()?:[];
            mahda_json(['ok'=>true,'profileId'=>$profileId,'avatarUrl'=>mahda_profile_avatar_url_db($db,$profileId,(string)($freshRow['profile_data_json']??''),(string)($freshRow['kind']??'personal')),'width'=>$width,'height'=>$height,'size'=>$finalSize]);
        }

        if ($action === 'profile_update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data();
            mahda_require_csrf($data);
            $current = mahda_require_member($db);
            $currentStmt = $db->prepare('SELECT p.id,p.kind,p.name,p.bio,p.city,p.profile_data_json,u.display_name,u.created_at FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE p.id=? AND p.owner_id=? LIMIT 1');
            $currentStmt->execute([(int)$current['profile_id'], (int)$current['id']]);
            $currentProfile = $currentStmt->fetch();
            if (!$currentProfile) { mahda_json(['error' => 'profile_not_found'], 404); }

            // Validate a submitted city before creating/switching profile context so
            // an invalid request cannot leave an empty alternate profile behind.
            $incomingCityProvided = array_key_exists('city', $data);
            $incomingCity = $incomingCityProvided ? mahda_string($data['city'], 120) : '';
            $incomingCityRow = $incomingCity !== '' ? mahda_resolve_city_name($db, $incomingCity) : null;
            if ($incomingCityProvided && $incomingCity !== '' && !$incomingCityRow) {
                mahda_json(['error'=>'invalid_city'], 422);
            }

            $profileKind = ($data['profileKind'] ?? $currentProfile['kind']) === 'heiat' ? 'heiat' : 'personal';
            $target = $currentProfile;
            $targetNeedsInsert = false;
            $newProfileSlug = '';
            if ($profileKind !== (string)$currentProfile['kind']) {
                $findProfile = $db->prepare('SELECT id,kind,name,bio,city,profile_data_json FROM mahda_profiles WHERE owner_id=? AND kind=? ORDER BY id LIMIT 1');
                $findProfile->execute([(int)$current['id'], $profileKind]);
                $found = $findProfile->fetch();
                if ($found) {
                    $target = array_merge($currentProfile, $found);
                } else {
                    // Keep the original personal/heiat profile intact. Defer the
                    // alternate-profile insert until the update transaction so a
                    // later failure cannot leave an empty orphan profile behind.
                    $newProfileSlug = ($profileKind === 'heiat' ? 'h-' : 'm-') . (int)$current['id'] . '-' . substr(hash('sha256', $profileKind . microtime(true) . random_int(1, PHP_INT_MAX)), 0, 12);
                    $initialName = $profileKind === 'heiat'
                        ? mahda_string($data['profileName'] ?? (($data['profileData']['heiatName'] ?? '')), 190)
                        : mahda_string($data['profileName'] ?? ($data['displayName'] ?? ''), 190);
                    $targetNeedsInsert = true;
                    $target = [
                        'id' => 0,
                        'kind' => $profileKind,
                        'name' => $initialName,
                        'bio' => null,
                        'city' => null,
                        'profile_data_json' => '{}',
                        'display_name' => (string)$currentProfile['display_name'],
                        'created_at' => (string)$currentProfile['created_at'],
                    ];
                }
            }

            $targetData = json_decode((string)($target['profile_data_json'] ?? ''), true);
            if (!is_array($targetData)) { $targetData = []; }
            $incomingData = $data['profileData'] ?? [];
            if (!is_array($incomingData)) { $incomingData = []; }
            // Profile images are uploaded through profile_avatar_upload. Never trust
            // new base64 blobs submitted inside JSON; retain any legacy blob only
            // until a real file replaces it.
            unset($incomingData['avatarDataUrl'], $incomingData['heiatLogoDataUrl']);
            $profileData = array_replace($targetData, array_slice($incomingData, 0, 80, true));
            foreach ($profileData as $key => $value) {
                if (is_string($value)) {
                    $profileData[$key] = mahda_string($value, 4000);
                }
                if (is_array($value)) { $profileData[$key] = array_slice($value, 0, 80); }
            }

            $displayName = array_key_exists('displayName', $data) ? mahda_string($data['displayName'], 120) : (string)$currentProfile['display_name'];
            $bio = array_key_exists('bio', $data) ? mahda_string($data['bio'], 2000) : (string)($target['bio'] ?? '');
            $city = $incomingCityProvided ? $incomingCity : (string)($target['city'] ?? '');
            $profileName = array_key_exists('profileName', $data) ? mahda_string($data['profileName'], 190) : (string)($target['name'] ?? '');
            if ($profileName === '' && $profileKind === 'heiat' && isset($profileData['heiatName'])) { $profileName = mahda_string($profileData['heiatName'], 190); }
            if ($profileName === '' && $displayName !== '' && ($data['complete'] ?? false)) { $profileName = $displayName; }
            $profileId = (int)$target['id'];
            $profileRole = mahda_string($data['profileRole'] ?? ($profileKind === 'heiat' ? 'heiat' : 'mentor'), 30);
            if ($profileKind === 'heiat') { $profileRole = 'heiat'; }
            elseif (!in_array($profileRole, ['mentor','family','khadem','other'], true)) { $profileRole = 'mentor'; }
            $profileData['profileRole'] = $profileRole;
            // Keep role-specific metadata isolated. Switching between a personal
            // profile and a heiat profile must not copy incompatible fields into
            // the new public identity.
            if ($profileRole === 'heiat') {
                $profileData['primaryRole'] = 'heiat';
                unset($profileData['firstName'],$profileData['lastName'],$profileData['specialties'],$profileData['role']);
            } elseif ($profileRole === 'mentor') {
                $profileData['primaryRole'] = 'mentor';
                unset($profileData['heiatName'],$profileData['role']);
            } else {
                $profileData['primaryRole'] = 'other';
                $profileData['role'] = $profileRole === 'family' ? 'family' : ($profileRole === 'khadem' ? 'cultural_servant' : 'other');
                unset($profileData['heiatName'],$profileData['specialties'],$profileData['ages'],$profileData['firstName'],$profileData['lastName']);
            }
            $cityRow = $incomingCityProvided ? $incomingCityRow : ($city !== '' ? mahda_resolve_city_name($db, $city) : null);
            $canonicalCity = $cityRow ? (string)$cityRow['name'] : $city;
            $canonicalCityId = $cityRow ? (int)$cityRow['id'] : null;
            $canonicalProvinceId = $cityRow ? (int)$cityRow['province_id'] : null;
            $profileData['profileComplete'] = mahda_profile_complete($profileData, $profileKind, $displayName, $profileName, $canonicalCity);
            $db->beginTransaction();
            try {
                if ($targetNeedsInsert) {
                    $db->prepare('INSERT INTO mahda_profiles(owner_id,slug,name,kind,profile_data_json) VALUES(?,?,?,?,?)')
                        ->execute([(int)$current['id'], $newProfileSlug, $profileName, $profileKind, '{}']);
                    $profileId = (int)$db->lastInsertId();
                    if ($profileId < 1) {
                        throw new RuntimeException('profile_create_failed');
                    }
                }
                $db->prepare('UPDATE mahda_users SET display_name=? WHERE id=?')->execute([$displayName, (int)$current['id']]);
                $db->prepare('UPDATE mahda_profiles SET name=?,bio=?,city=?,city_id=?,province_id=?,profile_role=?,atlas_visible=?,profile_data_json=? WHERE id=? AND owner_id=?')
                    ->execute([$profileName, $bio !== '' ? $bio : null, $canonicalCity !== '' ? $canonicalCity : null, $canonicalCityId, $canonicalProvinceId, $profileRole, in_array($profileRole,['mentor','heiat'],true)?1:0, json_encode($profileData, JSON_UNESCAPED_UNICODE), $profileId, (int)$current['id']]);
                $db->commit();
            } catch (Throwable $error) {
                if ($db->inTransaction()) { $db->rollBack(); }
                throw $error;
            }
            $_SESSION['display_name'] = $displayName;
            $_SESSION['profile_id'] = $profileId;
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            $updated = ['id'=>(int)$current['id'],'profile_id'=>$profileId,'display_name'=>$displayName,'role'=>(string)$current['role'],'guest'=>false,'profile_kind'=>$profileKind,'profile_name'=>$profileName,'profile_data'=>$profileData,'city'=>$canonicalCity,'created_at'=>(string)$currentProfile['created_at'],'phone'=>(string)($current['phone'] ?? '')];
            mahda_json(['user'=>mahda_user_payload($db, $updated, $profileId), 'csrf'=>$_SESSION['csrf']]);
        }

        if ($action === 'profile' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $scope = mahda_string($_GET['scope'] ?? '', 20);
            $profileId = max(0, (int)($_GET['id'] ?? 0));
            $slug = mahda_string($_GET['slug'] ?? '', 120);
            if ($scope === 'me') {
                $current = mahda_require_complete_member($db);
                $profileId = (int)$current['profile_id'];
            }
            if ($profileId > 0) {
                $stmt = $db->prepare("SELECT p.id,p.owner_id,p.slug,p.name,p.kind,p.bio,p.city,p.profile_role,p.is_verified,p.profile_data_json,u.display_name FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE p.id=? AND p.name<>'' AND u.is_active=1 AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local' LIMIT 1");
                $stmt->execute([$profileId]);
            } elseif ($slug !== '') {
                $stmt = $db->prepare("SELECT p.id,p.owner_id,p.slug,p.name,p.kind,p.bio,p.city,p.profile_role,p.is_verified,p.profile_data_json,u.display_name FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE p.slug=? AND p.name<>'' AND u.is_active=1 AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local' LIMIT 1");
                $stmt->execute([$slug]);
            } else {
                $kind = mahda_string($_GET['kind'] ?? 'personal', 20);
                if (!in_array($kind, ['personal', 'heiat'], true)) { $kind = 'personal'; }
                $stmt = $db->prepare("SELECT p.id,p.owner_id,p.slug,p.name,p.kind,p.bio,p.city,p.profile_role,p.is_verified,p.profile_data_json,u.display_name FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE p.kind=? AND p.name<>'' AND u.is_active=1 AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local' ORDER BY p.id LIMIT 1");
                $stmt->execute([$kind]);
            }
            $profile = $stmt->fetch();
            if (!$profile) { mahda_json(['error' => 'profile_not_found'], 404); }
            $profile['id'] = (int)$profile['id'];
            $ownerId = (int)$profile['owner_id'];
            unset($profile['owner_id']);
            $profile['verified'] = (bool)($profile['is_verified'] ?? false);
            $profile['role'] = (string)($profile['profile_role'] ?? (($profile['kind'] ?? '') === 'heiat' ? 'heiat' : 'mentor'));
            $publicData = json_decode((string)($profile['profile_data_json'] ?? ''), true); if (!is_array($publicData)) $publicData = [];
            $profile['specialties'] = [];
            if (is_array($publicData['specialties'] ?? null)) { foreach (array_slice($publicData['specialties'],0,12) as $value) { $value=mahda_string($value,80); if($value!=='')$profile['specialties'][]=$value; } }
            $profile['ages'] = is_array($publicData['ages'] ?? null) ? array_values(array_intersect(['4-6','7-10'], $publicData['ages'])) : [];
            $profile['avatarUrl'] = mahda_profile_avatar_url_db($db, (int)$profile['id'], (string)($profile['profile_data_json'] ?? ''), (string)($profile['kind'] ?? 'personal'));
            $profile['badges'] = mahda_profile_badges_public($db, (int)$profile['id']);
            unset($profile['profile_data_json'],$profile['profile_role'],$profile['is_verified']);
            $followers = $db->prepare('SELECT COUNT(*) FROM mahda_follows WHERE profile_id=?'); $followers->execute([$profile['id']]);
            $following = $db->prepare('SELECT COUNT(*) FROM mahda_follows WHERE user_id=?'); $following->execute([$ownerId]);
            $profileAttribution=mahda_attributed_content_sql('c');
            $contentCount = $db->prepare("SELECT COUNT(*) FROM mahda_contents c WHERE c.profile_id=? AND {$profileAttribution} AND (c.archived_at IS NULL AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved')))"); $contentCount->execute([$profile['id']]);
            $viewer = mahda_current_user($db, true);
            $viewerId = empty($viewer['guest']) ? (int)$viewer['id'] : 0;
            mahda_json(['profile'=>$profile,'followers'=>(int)$followers->fetchColumn(),'following'=>(int)$following->fetchColumn(),'contentCount'=>(int)$contentCount->fetchColumn(),'isOwn'=>$viewerId > 0 && $viewerId === $ownerId]);
        }

        if ($action === 'profiles_suggested' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $viewer = mahda_current_user($db, true);
            $viewerId = empty($viewer['guest']) ? (int)$viewer['id'] : 0;
            $stmt = $db->prepare("SELECT p.id,p.slug,p.name,p.kind,p.city,p.profile_data_json,COUNT(f.user_id) AS followers FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id LEFT JOIN mahda_follows f ON f.profile_id=p.id WHERE p.owner_id<>? AND p.kind='heiat' AND p.name<>'' AND u.is_active=1 AND u.email NOT LIKE 'guest-%@mahda.local' AND u.email NOT LIKE 'test-phone-%@mahda.local' GROUP BY p.id,p.slug,p.name,p.kind,p.city,p.profile_data_json ORDER BY followers DESC,p.id DESC LIMIT 8");
            $stmt->execute([$viewerId]);
            $items = [];
            foreach ($stmt->fetchAll() as $row) { $row['id'] = (int)$row['id']; $row['followers'] = (int)$row['followers']; $row['avatarUrl']=mahda_profile_avatar_url_db($db,(int)$row['id'],(string)($row['profile_data_json']??''),(string)($row['kind']??'heiat')); unset($row['profile_data_json']); $items[] = $row; }
            mahda_json(['items'=>$items]);
        }

    mahda_json(['error' => 'method_not_allowed'], 405);
}
