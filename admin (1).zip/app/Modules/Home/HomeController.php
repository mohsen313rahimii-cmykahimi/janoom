<?php
declare(strict_types=1);

namespace Mahda\Modules\Home;

use Mahda\Core\Request;
use Mahda\Core\View;

final class HomeController
{
    public function __construct(private View $view)
    {
    }

    public function index(Request $request): string
    {
        return $this->view->render('pages/home');
    }
}

