<?php
declare(strict_types=1);

/** API actions owned by the Home module. */
function mahda_home_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['homepage_config'], true)) {
        return false;
    }

        if ($action === 'homepage_config' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $allSections=$db->query("SELECT id,section_key,section_type,title,subtitle,source_mode,config_json,is_active,sort_order FROM mahda_home_sections ORDER BY sort_order,id")->fetchAll();
            $itemSt=$db->prepare('SELECT content_id FROM mahda_home_section_items WHERE section_id=? ORDER BY sort_order,content_id');
            $sections=[];
            foreach($allSections as &$r){
                $itemSt->execute([(int)$r['id']]);$r['contentIds']=array_map('intval',$itemSt->fetchAll(PDO::FETCH_COLUMN));$r['config']=json_decode((string)($r['config_json']??'{}'),true)?:[];$r['active']=(bool)$r['is_active'];unset($r['config_json'],$r['is_active']);
                if($r['active']){$sections[]=$r;}
            }unset($r);
            $pages=$db->query("SELECT id,slug,title,subtitle,cover_file_id,sort_order FROM mahda_special_pages WHERE is_active=1 ORDER BY sort_order,id")->fetchAll();
            mahda_json(['sections'=>$sections,'allSections'=>$allSections,'pages'=>$pages]);
        }

    mahda_json(['error' => 'method_not_allowed'], 405);
}
