<?php
declare(strict_types=1);

/** API actions owned by the Admin module. */
function mahda_admin_module_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['auth_admin_login', 'admin_context_v2', 'admin_dashboard_v2', 'admin_contents_v2', 'admin_content_v2', 'admin_delete_preview_v2', 'admin_content_update_v2', 'admin_content_action_v2', 'admin_staff_v2', 'admin_staff_save_v2', 'admin_desks_v2', 'admin_desk_v2', 'admin_desk_save_v2', 'admin_structure_v3', 'admin_category_save_v3', 'admin_category_reorder_v3', 'admin_topics_v3', 'admin_topic_save_v3', 'admin_category_fields_v3', 'admin_category_field_save_v3', 'admin_category_field_toggle_v3', 'admin_goals_v3', 'admin_goal_save_v3', 'admin_goal_merge_v3', 'admin_goal_toggle_v3', 'admin_occasions_v3', 'admin_occasion_save_v3', 'admin_occasion_toggle_v3', 'admin_profiles_v3', 'admin_profile_identity_v3', 'admin_badges_v3', 'admin_badge_save_v3', 'admin_profile_badge_v3', 'admin_memberships_v3', 'admin_membership_save_v3', 'admin_reports_v3', 'admin_report_action_v3', 'admin_notifications_v3', 'admin_notifications_read_v3', 'admin_home_v3', 'admin_home_section_save_v3', 'admin_home_reorder_v3', 'admin_special_page_save_v3', 'admin_atlas_v3', 'admin_atlas_profile_save_v3', 'admin_city_save_v3', 'admin_files_v3', 'admin_file_delete_v3', 'admin_orphan_cleanup_v3', 'admin_audit_v3', 'admin_system_health_v3', 'admin_system_errors_v3', 'admin_system_error_resolve_v3', 'admin_dashboard', 'admin_review_queue', 'admin_content_detail', 'admin_review_action', 'admin_users', 'admin_user_update', 'admin_profiles', 'admin_profile_update', 'admin_categories', 'admin_category_save', 'admin_settings', 'admin_settings_save', 'admin_goal_suggestions_v12', 'admin_goal_suggestion_action_v12'], true)) {
        return false;
    }

        if ($action === 'auth_admin_login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data();
            mahda_require_csrf($data);
            mahda_start_session();
            $login = trim((string)($data['login'] ?? ($data['email'] ?? '')));
            $password = (string)($data['password'] ?? '');
            if ($login === '' || $password === '') {
                mahda_json(['error' => 'invalid_credentials'], 422);
            }
            $isEmail = filter_var(strtolower($login), FILTER_VALIDATE_EMAIL) !== false;
            if (!$isEmail && !preg_match('/^[A-Za-z0-9._-]{3,80}$/', $login)) {
                mahda_json(['error' => 'invalid_credentials'], 422);
            }
            $stmt = $db->prepare("SELECT u.id,u.display_name,u.password_hash,u.role,u.created_at,u.admin_username,u.is_super_admin,p.id AS profile_id,p.kind AS profile_kind,p.name AS profile_name,p.city
                FROM mahda_users u
                JOIN mahda_profiles p ON p.owner_id=u.id
                WHERE " . ($isEmail ? "LOWER(u.email)=LOWER(?)" : "LOWER(u.admin_username)=LOWER(?)") . " AND u.is_active=1
                ORDER BY (p.kind='personal') DESC,p.id LIMIT 1");
            $stmt->execute([$login]);
            $row = $stmt->fetch();
            if (!$row || !password_verify($password, (string)$row['password_hash'])) {
                mahda_json(['error' => 'invalid_credentials'], 401);
            }
            if (!in_array((string)$row['role'], ['admin', 'reviewer'], true)) {
                mahda_json(['error' => 'admin_required'], 403);
            }
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$row['id'];
            $_SESSION['profile_id'] = (int)$row['profile_id'];
            $_SESSION['display_name'] = (string)$row['display_name'];
            $_SESSION['role'] = (string)$row['role'];
            $_SESSION['guest'] = false;
            unset($_SESSION['phone']);
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            $row['guest'] = false;
            mahda_json([
                'user' => mahda_user_payload($db, $row),
                'csrf' => $_SESSION['csrf'],
                'staff' => [
                    'username' => (string)($row['admin_username'] ?? ''),
                    'isSuperAdmin' => (bool)($row['is_super_admin'] ?? false),
                    'permissions' => mahda_staff_permissions($db, (int)$row['id']),
                ],
            ]);
        }

        if ($action === 'admin_context_v2' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $staff = mahda_require_staff($db);
            $userId = (int)$staff['id'];
            $isSuper = mahda_is_super_admin($db, $userId);
            $permissions = mahda_staff_permissions($db, $userId);
            $desks = [];
            if ($isSuper || in_array('desks.manage', $permissions, true) || in_array('content.view', $permissions, true)) {
                $deskStmt = $db->query("SELECT id,name,slug,is_active FROM mahda_desks ORDER BY is_active DESC,name");
            } else {
                $deskStmt = $db->prepare("SELECT d.id,d.name,d.slug,d.is_active FROM mahda_desks d JOIN mahda_desk_members dm ON dm.desk_id=d.id WHERE dm.user_id=? AND dm.can_view=1 ORDER BY d.is_active DESC,d.name");
                $deskStmt->execute([$userId]);
            }
            foreach ($deskStmt->fetchAll() as $row) {
                $desks[] = ['id'=>(int)$row['id'],'name'=>(string)$row['name'],'slug'=>(string)$row['slug'],'active'=>(bool)$row['is_active']];
            }
            $categories = array_map(static fn(array $row): array => [
                'id'=>(string)$row['id'],'label'=>(string)$row['label'],'icon'=>(string)$row['icon'],'color'=>(string)$row['color'],'active'=>(bool)$row['is_active']
            ], $db->query('SELECT id,label,icon,color,is_active FROM mahda_categories ORDER BY sort_order,id')->fetchAll());
            mahda_json([
                'staff'=>[
                    'id'=>$userId,
                    'name'=>(string)($staff['display_name'] ?? ''),
                    'role'=>(string)$staff['role'],
                    'isSuperAdmin'=>$isSuper,
                    'permissions'=>$permissions,
                ],
                'permissionCatalog'=>$isSuper ? mahda_permission_catalog() : [],
                'desks'=>$desks,
                'categories'=>$categories,
            ]);
        }

        if ($action === 'admin_dashboard_v2' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $staff = mahda_require_permission($db, 'dashboard.view');
            $uid = (int)$staff['id'];
            $canViewAll = mahda_is_super_admin($db,$uid) || mahda_has_permission($db,$staff,'content.view');
            $deskIds = $canViewAll ? [] : mahda_staff_desk_ids($db,$uid,'view');
            $scopeSql = '';
            $scopeParams = [];
            if (!$canViewAll) {
                if (!$deskIds) {
                    $scopeSql = ' AND 1=0';
                } else {
                    $scopeSql = ' AND desk_id IN (' . implode(',',array_fill(0,count($deskIds),'?')) . ')';
                    $scopeParams = $deskIds;
                }
            }
            $countScoped = static function(PDO $db,string $condition,string $scopeSql,array $params): int {
                $stmt=$db->prepare("SELECT COUNT(*) FROM mahda_contents WHERE {$condition}{$scopeSql}");
                foreach($params as $i=>$v)$stmt->bindValue($i+1,$v,PDO::PARAM_INT);
                $stmt->execute();
                return (int)$stmt->fetchColumn();
            };
            $stats=[
                'pending'=>$countScoped($db,"archived_at IS NULL AND visibility<>'hidden' AND review_status='pending'",$scopeSql,$scopeParams),
                'revision'=>$countScoped($db,"archived_at IS NULL AND visibility<>'hidden' AND review_status='revision'",$scopeSql,$scopeParams),
                'approved'=>$countScoped($db,"archived_at IS NULL AND visibility<>'hidden' AND review_status='approved'",$scopeSql,$scopeParams),
                'rejected'=>$countScoped($db,"archived_at IS NULL AND visibility<>'hidden' AND review_status='rejected'",$scopeSql,$scopeParams),
                'hidden'=>$countScoped($db,"archived_at IS NULL AND visibility='hidden'",$scopeSql,$scopeParams),
                'archived'=>$countScoped($db,"archived_at IS NOT NULL",$scopeSql,$scopeParams),
            ];
            $activeUsers=(int)$db->query('SELECT COUNT(*) FROM mahda_users WHERE is_active=1')->fetchColumn();
            $activeStaff=(int)$db->query("SELECT COUNT(*) FROM mahda_users WHERE role IN ('admin','reviewer') AND is_active=1")->fetchColumn();

            $desks=[];
            $deskSql="SELECT d.id,d.name,d.slug,
                    SUM(CASE WHEN c.archived_at IS NULL AND c.visibility<>'hidden' AND c.review_status='pending' THEN 1 ELSE 0 END) AS pending_count,
                    SUM(CASE WHEN c.archived_at IS NULL AND c.visibility<>'hidden' AND c.review_status='revision' THEN 1 ELSE 0 END) AS revision_count
                FROM mahda_desks d
                LEFT JOIN mahda_contents c ON c.desk_id=d.id
                WHERE d.is_active=1";
            if(!$canViewAll){
                if(!$deskIds){$deskSql.=" AND 1=0";}
                else{$deskSql.=" AND d.id IN (".implode(',',array_fill(0,count($deskIds),'?')).")";}
            }
            $deskSql.=" GROUP BY d.id,d.name,d.slug ORDER BY pending_count DESC,revision_count DESC,d.name LIMIT 12";
            $ds=$db->prepare($deskSql);
            foreach($deskIds as $i=>$v)$ds->bindValue($i+1,$v,PDO::PARAM_INT);
            $ds->execute();
            foreach($ds->fetchAll() as $row)$desks[]=['id'=>(int)$row['id'],'name'=>(string)$row['name'],'slug'=>(string)$row['slug'],'pending'=>(int)$row['pending_count'],'revision'=>(int)$row['revision_count']];

            $recent=[];
            if(mahda_table_exists($db,'mahda_audit_log') && (mahda_is_super_admin($db,$uid) || mahda_has_permission($db,$staff,'audit.view'))){
                $q=$db->query("SELECT a.id,a.action,a.entity_type,a.entity_id,a.created_at,COALESCE(u.display_name,'مدیر حذف‌شده') actor FROM mahda_audit_log a LEFT JOIN mahda_users u ON u.id=a.actor_id ORDER BY a.created_at DESC,a.id DESC LIMIT 10");
                foreach($q->fetchAll() as $r)$recent[]=['id'=>(int)$r['id'],'action'=>(string)$r['action'],'entityType'=>(string)$r['entity_type'],'entityId'=>$r['entity_id']!==null?(int)$r['entity_id']:null,'actor'=>(string)$r['actor'],'createdAt'=>(string)$r['created_at']];
            }

            $uploadPath=mahda_private_upload_dir();
            $uploadsReady=is_dir($uploadPath)?is_writable($uploadPath):is_writable(dirname($uploadPath));
            $schemaVersion=(int)$db->query('SELECT COALESCE(MAX(version),0) FROM mahda_migrations')->fetchColumn();
            mahda_json([
                'stats'=>$stats,
                'users'=>['active'=>$activeUsers,'staff'=>$activeStaff],
                'desks'=>$desks,
                'recentActions'=>$recent,
                'system'=>['database'=>true,'schemaVersion'=>$schemaVersion,'uploadsReady'=>$uploadsReady]
            ]);
        }

        if ($action === 'admin_contents_v2' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $staff = mahda_require_staff($db);
            $canViewAll = mahda_is_super_admin($db, (int)$staff['id']) || mahda_has_permission($db, $staff, 'content.view');
            $deskIds = $canViewAll ? [] : mahda_staff_desk_ids($db, (int)$staff['id'], 'view');
            if (!$canViewAll && !$deskIds) {
                mahda_json(['items'=>[],'total'=>0,'limit'=>50,'offset'=>0]);
            }

            $state = mahda_string($_GET['state'] ?? 'pending', 32);
            $category = mahda_string($_GET['category'] ?? '', 40);
            $query = mahda_string($_GET['q'] ?? '', 190);
            $deskId = max(0, (int)($_GET['desk'] ?? 0));
            $limit = max(1, min(100, (int)($_GET['limit'] ?? 50)));
            $offset = max(0, min(100000, (int)($_GET['offset'] ?? 0)));
            if (!in_array($state, ['all','pending','revision','approved','rejected','hidden','archived','not_requested'], true)) {
                $state = 'pending';
            }

            $where = ['1=1'];
            $params = [];
            if ($state === 'archived') {
                $where[] = 'c.archived_at IS NOT NULL';
            } elseif ($state === 'hidden') {
                $where[] = "c.archived_at IS NULL AND c.visibility='hidden'";
            } elseif ($state !== 'all') {
                $where[] = "c.archived_at IS NULL AND c.visibility<>'hidden' AND c.review_status=?";
                $params[] = $state;
            }
            if ($category !== '') { $where[] = 'c.category_id=?'; $params[] = $category; }
            if ($deskId > 0) { $where[] = 'c.desk_id=?'; $params[] = $deskId; }
            if ($query !== '') {
                $term = '%' . $query . '%';
                $where[] = '(c.title LIKE ? OR p.name LIKE ? OR u.display_name LIKE ? OR cat.label LIKE ?)';
                array_push($params,$term,$term,$term,$term);
            }
            if (!$canViewAll) {
                $placeholders = implode(',', array_fill(0, count($deskIds), '?'));
                $where[] = "c.desk_id IN ({$placeholders})";
                foreach ($deskIds as $id) $params[] = $id;
            }

            $base = " FROM mahda_contents c
                JOIN mahda_profiles p ON p.id=c.profile_id
                JOIN mahda_users u ON u.id=c.author_id
                JOIN mahda_categories cat ON cat.id=c.category_id
                LEFT JOIN mahda_desks d ON d.id=c.desk_id
                WHERE " . implode(' AND ', $where);

            $countStmt = $db->prepare('SELECT COUNT(*)' . $base);
            $countStmt->execute($params);
            $total = (int)$countStmt->fetchColumn();

            $sql = "SELECT c.id,c.title,c.category_id,c.desk_id,c.review_status,c.visibility,c.created_at,c.archived_at,c.hidden_reason,c.archive_reason,
                    p.id AS profile_id,p.name AS profile_name,p.kind AS profile_kind,u.id AS author_id,u.display_name AS author_name,
                    cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color,d.name AS desk_name,
                    (SELECT f.id FROM mahda_files f WHERE f.content_id=c.id AND f.purpose='cover' ORDER BY f.id DESC LIMIT 1) AS cover_file_id,
                    (SELECT COUNT(*) FROM mahda_files f2 WHERE f2.content_id=c.id) AS file_count" . $base .
                    " ORDER BY COALESCE(c.admin_updated_at,c.created_at) DESC,c.id DESC LIMIT ? OFFSET ?";
            $stmt = $db->prepare($sql);
            $i=1;
            foreach ($params as $param) {
                $stmt->bindValue($i++, $param, is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            $stmt->bindValue($i++, $limit, PDO::PARAM_INT);
            $stmt->bindValue($i, $offset, PDO::PARAM_INT);
            $stmt->execute();
            $items=[];
            foreach ($stmt->fetchAll() as $row) {
                $contentAccess = ['desk_id'=>(int)($row['desk_id'] ?? 0)];
                $items[]=[
                    'id'=>(int)$row['id'],'title'=>(string)$row['title'],
                    'categoryId'=>(string)$row['category_id'],'categoryLabel'=>(string)$row['category_label'],'categoryIcon'=>(string)$row['category_icon'],'categoryColor'=>(string)$row['category_color'],
                    'deskId'=>(int)($row['desk_id'] ?? 0),'deskName'=>(string)($row['desk_name'] ?? ''),
                    'status'=>(string)$row['review_status'],'visibility'=>(string)$row['visibility'],'archived'=>(bool)$row['archived_at'],
                    'hiddenReason'=>(string)($row['hidden_reason'] ?? ''),'archiveReason'=>(string)($row['archive_reason'] ?? ''),
                    'profileId'=>(int)$row['profile_id'],'profileName'=>(string)$row['profile_name'],'profileKind'=>(string)$row['profile_kind'],
                    'authorId'=>(int)$row['author_id'],'authorName'=>(string)$row['author_name'],'createdAt'=>(string)$row['created_at'],
                    'coverUrl'=>(int)($row['cover_file_id'] ?? 0)>0?'/mahda-api/index.php?action=file&id='.(int)$row['cover_file_id']:'',
                    'fileCount'=>(int)$row['file_count'],
                    'can'=>[
                        'edit'=>mahda_can_access_content($db,$staff,$contentAccess,'edit'),
                        'approve'=>mahda_can_access_content($db,$staff,$contentAccess,'approve'),
                        'revision'=>mahda_can_access_content($db,$staff,$contentAccess,'revision'),
                        'reject'=>mahda_can_access_content($db,$staff,$contentAccess,'reject'),
                        'hide'=>mahda_can_access_content($db,$staff,$contentAccess,'hide'),
                        'archive'=>mahda_can_access_content($db,$staff,$contentAccess,'archive'),
                        'delete'=>mahda_can_access_content($db,$staff,$contentAccess,'delete'),
                        'assign'=>mahda_can_access_content($db,$staff,$contentAccess,'assign'),
                    ],
                ];
            }
            mahda_json(['items'=>$items,'total'=>$total,'limit'=>$limit,'offset'=>$offset]);
        }

        if ($action === 'admin_content_v2' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $staff = mahda_require_staff($db);
            $contentId = max(0, (int)($_GET['id'] ?? 0));
            if ($contentId < 1) mahda_json(['error'=>'invalid_content'],422);
            $stmt=$db->prepare("SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,p.slug AS profile_slug,u.email AS author_email,u.display_name AS author_name,
                    cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color,d.name AS desk_name
                FROM mahda_contents c
                JOIN mahda_profiles p ON p.id=c.profile_id
                JOIN mahda_users u ON u.id=c.author_id
                JOIN mahda_categories cat ON cat.id=c.category_id
                LEFT JOIN mahda_desks d ON d.id=c.desk_id
                WHERE c.id=? LIMIT 1");
            $stmt->execute([$contentId]); $row=$stmt->fetch();
            if(!$row) mahda_json(['error'=>'content_not_found'],404);
            if(!mahda_can_access_content($db,$staff,$row,'view')) mahda_json(['error'=>'permission_denied'],403);

            $filesStmt=$db->prepare('SELECT id,purpose,original_name,mime_type,size_bytes FROM mahda_files WHERE content_id=? ORDER BY id');
            $filesStmt->execute([$contentId]);
            $files=array_map(static fn(array $f):array=>[
                'id'=>(int)$f['id'],'purpose'=>(string)$f['purpose'],'name'=>(string)$f['original_name'],'mime'=>(string)$f['mime_type'],'size'=>(int)$f['size_bytes'],
                'url'=>'/mahda-api/index.php?action=file&id='.(int)$f['id']
            ],$filesStmt->fetchAll());

            $reviewStmt=$db->prepare("SELECT r.id,r.action,r.previous_status,r.new_status,r.note,r.created_at,COALESCE(u.display_name,'مدیر حذف‌شده') AS actor
                FROM mahda_review_actions r LEFT JOIN mahda_users u ON u.id=r.reviewer_id WHERE r.content_id=? ORDER BY r.created_at DESC,r.id DESC");
            $reviewStmt->execute([$contentId]);
            $history=[];
            foreach($reviewStmt->fetchAll() as $h){
                $history[]=['type'=>'review','id'=>(int)$h['id'],'action'=>(string)$h['action'],'previousStatus'=>(string)$h['previous_status'],'newStatus'=>(string)$h['new_status'],'note'=>(string)($h['note']??''),'actor'=>(string)$h['actor'],'createdAt'=>(string)$h['created_at']];
            }
            if(mahda_table_exists($db,'mahda_audit_log')){
                $audit=$db->prepare("SELECT a.id,a.action,a.meta_json,a.created_at,COALESCE(u.display_name,'مدیر حذف‌شده') AS actor FROM mahda_audit_log a LEFT JOIN mahda_users u ON u.id=a.actor_id WHERE a.entity_type='content' AND a.entity_id=? AND a.action NOT LIKE 'content_review_%' ORDER BY a.created_at DESC,a.id DESC LIMIT 100");
                $audit->execute([$contentId]);
                foreach($audit->fetchAll() as $h){
                    $history[]=['type'=>'audit','id'=>(int)$h['id'],'action'=>(string)$h['action'],'meta'=>json_decode((string)($h['meta_json']??''),true)?:[],'actor'=>(string)$h['actor'],'createdAt'=>(string)$h['created_at']];
                }
            }
            usort($history,static fn(array $a,array $b):int=>strcmp((string)$b['createdAt'],(string)$a['createdAt']));

            $counts=['files'=>count($files),'comments'=>0,'interactions'=>0];
            foreach([['comments','mahda_comments'],['interactions','mahda_interactions']] as [$key,$table]){
                if(mahda_table_exists($db,$table)){ $q=$db->prepare("SELECT COUNT(*) FROM {$table} WHERE content_id=?"); $q->execute([$contentId]); $counts[$key]=(int)$q->fetchColumn(); }
            }
            $caps=[];
            foreach(['edit','approve','revision','reject','hide','archive','delete','assign'] as $op) $caps[$op]=mahda_can_access_content($db,$staff,$row,$op);

            mahda_json([
                'content'=>mahda_item($db,$row),
                'admin'=>[
                    'status'=>(string)$row['review_status'],'visibility'=>(string)$row['visibility'],'archivedAt'=>(string)($row['archived_at']??''),
                    'hiddenReason'=>(string)($row['hidden_reason']??''),'archiveReason'=>(string)($row['archive_reason']??''),
                    'deskId'=>(int)($row['desk_id']??0),'deskName'=>(string)($row['desk_name']??''),
                    'authorEmail'=>(string)$row['author_email'],'authorName'=>(string)$row['author_name'],'profileSlug'=>(string)$row['profile_slug'],
                    'executionText'=>(string)($row['execution_text'] ?? ''),'rulesAcceptedAt'=>(string)($row['rules_accepted_at'] ?? ''),
                    'can'=>$caps,
                ],
                'files'=>$files,'history'=>$history,'impact'=>$counts
            ]);
        }

        if ($action === 'admin_delete_preview_v2' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $staff=mahda_require_staff($db);
            $contentId=max(0,(int)($_GET['id']??0));
            $stmt=$db->prepare('SELECT id,title,desk_id FROM mahda_contents WHERE id=? LIMIT 1'); $stmt->execute([$contentId]); $content=$stmt->fetch();
            if(!$content) mahda_json(['error'=>'content_not_found'],404);
            if(!mahda_can_access_content($db,$staff,$content,'delete')) mahda_json(['error'=>'permission_denied'],403);
            $impact=['files'=>0,'fileBytes'=>0,'comments'=>0,'interactions'=>0,'reviews'=>0,'reports'=>0,'homepage'=>0];
            if(mahda_table_exists($db,'mahda_files')){ $q=$db->prepare('SELECT COUNT(*),COALESCE(SUM(size_bytes),0) FROM mahda_files WHERE content_id=?');$q->execute([$contentId]);$r=$q->fetch(PDO::FETCH_NUM)?:[0,0];$impact['files']=(int)$r[0];$impact['fileBytes']=(int)$r[1];}
            foreach([['comments','mahda_comments'],['interactions','mahda_interactions'],['reviews','mahda_review_actions']] as [$key,$table]){if(mahda_table_exists($db,$table)){$q=$db->prepare("SELECT COUNT(*) FROM {$table} WHERE content_id=?");$q->execute([$contentId]);$impact[$key]=(int)$q->fetchColumn();}}
            if(mahda_table_exists($db,'mahda_reports')){$q=$db->prepare("SELECT COUNT(*) FROM mahda_reports WHERE target_type='content' AND target_id=?");$q->execute([$contentId]);$impact['reports']=(int)$q->fetchColumn();}
            if(mahda_table_exists($db,'mahda_home_section_items')){$q=$db->prepare('SELECT COUNT(*) FROM mahda_home_section_items WHERE content_id=?');$q->execute([$contentId]);$impact['homepage']+=(int)$q->fetchColumn();}
            if(mahda_table_exists($db,'mahda_special_page_items')){$q=$db->prepare('SELECT COUNT(*) FROM mahda_special_page_items WHERE content_id=?');$q->execute([$contentId]);$impact['homepage']+=(int)$q->fetchColumn();}
            mahda_json(['id'=>$contentId,'title'=>(string)$content['title'],'impact'=>$impact]);
        }

        if ($action === 'admin_content_update_v2' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data(); mahda_require_csrf($data); $staff=mahda_require_staff($db);
            $contentId=max(0,(int)($data['contentId']??0));
            $find=$db->prepare('SELECT id,title,body,execution_text,category_id,desk_id FROM mahda_contents WHERE id=? LIMIT 1');$find->execute([$contentId]);$content=$find->fetch();
            if(!$content) mahda_json(['error'=>'content_not_found'],404);
            if(!mahda_can_access_content($db,$staff,$content,'edit')) mahda_json(['error'=>'permission_denied'],403);
            $title=mahda_string($data['title']??$content['title'],190);
            $body=mahda_string($data['body']??($content['body']??''),12000);
            $execution=mahda_string($data['executionText']??($content['execution_text']??''),20000);
            $category=mahda_string($data['categoryId']??$content['category_id'],40);
            if($title==='') mahda_json(['error'=>'title_required'],422);
            $cat=$db->prepare('SELECT id FROM mahda_categories WHERE id=? AND is_active=1 LIMIT 1');$cat->execute([$category]);if(!$cat->fetchColumn())mahda_json(['error'=>'category_not_found'],422);
            $db->prepare('UPDATE mahda_contents SET title=?,body=?,execution_text=?,category_id=?,admin_updated_at=NOW() WHERE id=?')->execute([$title,$body,$execution,$category,$contentId]);
            if($category!==(string)$content['category_id']) mahda_assign_content_desk($db,$contentId,$category);
            mahda_audit($db,(int)$staff['id'],'content_admin_edit','content',$contentId,['before'=>['title'=>(string)$content['title'],'category'=>(string)$content['category_id']],'after'=>['title'=>$title,'category'=>$category]]);
            mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_content_action_v2' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data(); mahda_require_csrf($data); $staff=mahda_require_staff($db);
            $contentId=max(0,(int)($data['contentId']??0));
            $operation=mahda_string($data['operation']??'',40);
            $note=mahda_string($data['note']??'',4000);
            $find=$db->prepare('SELECT id,title,author_id,profile_id,category_id,desk_id,review_status,visibility,archived_at FROM mahda_contents WHERE id=? LIMIT 1');$find->execute([$contentId]);$content=$find->fetch();
            if(!$content) mahda_json(['error'=>'content_not_found'],404);

            if(in_array($operation,['approve','revision','reject','pending'],true)){
                $cap=$operation==='revision'?'revision':($operation==='reject'?'reject':'approve');
                if(!mahda_can_access_content($db,$staff,$content,$cap)) mahda_json(['error'=>'permission_denied'],403);
                if(in_array($operation,['revision','reject'],true)&&$note==='') mahda_json(['error'=>'review_note_required'],422);
                $previous=(string)$content['review_status'];
                $newStatus=$operation==='approve'?'approved':($operation==='pending'?'pending':($operation==='revision'?mahda_revision_storage_status($db):'rejected'));
                $db->beginTransaction();
                try{
                    $db->prepare('UPDATE mahda_contents SET review_status=?,admin_updated_at=NOW() WHERE id=?')->execute([$newStatus,$contentId]);
                    $db->prepare('INSERT INTO mahda_review_actions(content_id,reviewer_id,action,previous_status,new_status,note) VALUES(?,?,?,?,?,?)')->execute([$contentId,(int)$staff['id'],$operation,$previous,$newStatus,$note!==''?$note:null]);
                    mahda_audit($db,(int)$staff['id'],'content_review_'.$operation,'content',$contentId,['previous'=>$previous,'new'=>$newStatus,'note'=>$note]);
                    $db->commit();
                }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
                $kind=$operation==='approve'?'review_approved':($operation==='revision'?'review_revision':($operation==='reject'?'review_rejected':null));
                if($kind){try{mahda_notify($db,(int)$content['author_id'],(int)$staff['id'],$kind,$contentId,(int)$content['profile_id'],['note'=>$note,'decision'=>$operation]);}catch(Throwable $ignored){}}
                mahda_json(['ok'=>true,'status'=>$newStatus]);
            }

            if($operation==='hide'){
                if(!mahda_can_access_content($db,$staff,$content,'hide')) mahda_json(['error'=>'permission_denied'],403);
                if($note==='') mahda_json(['error'=>'reason_required'],422);
                $db->prepare("UPDATE mahda_contents SET visibility='hidden',hidden_reason=?,admin_updated_at=NOW() WHERE id=?")->execute([$note,$contentId]);
                mahda_audit($db,(int)$staff['id'],'content_hide','content',$contentId,['reason'=>$note]); mahda_json(['ok'=>true]);
            }
            if($operation==='unhide'){
                if(!mahda_can_access_content($db,$staff,$content,'hide')) mahda_json(['error'=>'permission_denied'],403);
                $db->prepare("UPDATE mahda_contents SET visibility='showcase',hidden_reason=NULL,admin_updated_at=NOW() WHERE id=?")->execute([$contentId]);
                mahda_audit($db,(int)$staff['id'],'content_unhide','content',$contentId); mahda_json(['ok'=>true]);
            }
            if($operation==='archive'){
                if(!mahda_can_access_content($db,$staff,$content,'archive')) mahda_json(['error'=>'permission_denied'],403);
                $db->prepare('UPDATE mahda_contents SET archived_at=NOW(),archived_by=?,archive_reason=?,admin_updated_at=NOW() WHERE id=?')->execute([(int)$staff['id'],$note!==''?$note:null,$contentId]);
                mahda_audit($db,(int)$staff['id'],'content_archive','content',$contentId,['reason'=>$note]); mahda_json(['ok'=>true]);
            }
            if($operation==='restore'){
                if(!mahda_can_access_content($db,$staff,$content,'archive')) mahda_json(['error'=>'permission_denied'],403);
                $db->prepare('UPDATE mahda_contents SET archived_at=NULL,archived_by=NULL,archive_reason=NULL,admin_updated_at=NOW() WHERE id=?')->execute([$contentId]);
                mahda_audit($db,(int)$staff['id'],'content_restore','content',$contentId); mahda_json(['ok'=>true]);
            }
            if($operation==='assign_desk'){
                if(!mahda_can_access_content($db,$staff,$content,'assign')) mahda_json(['error'=>'permission_denied'],403);
                $newDesk=max(0,(int)($data['deskId']??0));
                if($newDesk>0){$d=$db->prepare('SELECT id FROM mahda_desks WHERE id=? AND is_active=1 LIMIT 1');$d->execute([$newDesk]);if(!$d->fetchColumn())mahda_json(['error'=>'desk_not_found'],422);}
                $db->prepare('UPDATE mahda_contents SET desk_id=?,admin_updated_at=NOW() WHERE id=?')->execute([$newDesk>0?$newDesk:null,$contentId]);
                mahda_audit($db,(int)$staff['id'],'content_assign_desk','content',$contentId,['previous'=>(int)($content['desk_id']??0),'new'=>$newDesk,'note'=>$note]); mahda_json(['ok'=>true]);
            }
            if($operation==='delete'){
                if(!mahda_can_access_content($db,$staff,$content,'delete')) mahda_json(['error'=>'permission_denied'],403);
                $confirm=mahda_string($data['confirmTitle']??'',190);
                if($note===''||$confirm!==(string)$content['title']) mahda_json(['error'=>'delete_confirmation_required'],422);
                $filesStmt=$db->prepare('SELECT storage_key FROM mahda_files WHERE content_id=?');$filesStmt->execute([$contentId]);
                $storageKeys=array_values(array_filter(array_map(static fn(array $r):string=>basename((string)($r['storage_key']??'')),$filesStmt->fetchAll()),static fn(string $x):bool=>$x!==''&&$x!=='.'&&$x!=='..'));
                $db->beginTransaction();
                try{
                    foreach(['mahda_package_items','mahda_reviews','mahda_notifications','mahda_comments','mahda_interactions','mahda_content_tools','mahda_content_occasions','mahda_content_goals','mahda_content_topics','mahda_home_section_items','mahda_special_page_items','mahda_files','mahda_review_actions'] as $table){
                        if(mahda_table_exists($db,$table)){$db->prepare("DELETE FROM {$table} WHERE content_id=?")->execute([$contentId]);}
                    }
                    if(mahda_table_exists($db,'mahda_reports')){$db->prepare("DELETE FROM mahda_reports WHERE target_type='content' AND target_id=?")->execute([$contentId]);}
                    if(mahda_table_exists($db,'mahda_admin_notifications')){$db->prepare("DELETE FROM mahda_admin_notifications WHERE entity_type='content' AND entity_id=?")->execute([$contentId]);}
                    if(mahda_table_exists($db,'mahda_reports')){$db->prepare("DELETE FROM mahda_reports WHERE target_type='content' AND target_id=?")->execute([$contentId]);}
                    if(mahda_table_exists($db,'mahda_admin_notifications')){$db->prepare("DELETE FROM mahda_admin_notifications WHERE entity_type='content' AND entity_id=?")->execute([$contentId]);}
                    $db->prepare('DELETE FROM mahda_contents WHERE id=?')->execute([$contentId]);
                    $db->commit();
                }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
                mahda_audit($db,(int)$staff['id'],'content_hard_delete','content',$contentId,['title'=>(string)$content['title'],'reason'=>$note]);
                $deletedFiles=0;foreach($storageKeys as $key){$path=mahda_existing_upload_path($key);if($path&&@unlink($path))$deletedFiles++;}
                mahda_json(['ok'=>true,'deletedFiles'=>$deletedFiles]);
            }
            mahda_json(['error'=>'invalid_content_action'],422);
        }

        if ($action === 'admin_staff_v2' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $super=mahda_require_super_admin($db);
            $rows=$db->query("SELECT id,email,admin_username,display_name,role,is_active,is_super_admin,created_at FROM mahda_users WHERE role IN ('admin','reviewer') ORDER BY is_super_admin DESC,is_active DESC,display_name,id")->fetchAll();
            $items=[];
            foreach($rows as $row){
                $uid=(int)$row['id'];
                $deskStmt=$db->prepare("SELECT d.id,d.name,dm.can_view,dm.can_edit,dm.can_request_revision,dm.can_final_approve FROM mahda_desk_members dm JOIN mahda_desks d ON d.id=dm.desk_id WHERE dm.user_id=? ORDER BY d.name");$deskStmt->execute([$uid]);
                $items[]=['id'=>$uid,'name'=>(string)$row['display_name'],'username'=>(string)($row['admin_username']??''),'email'=>(string)$row['email'],'role'=>(string)$row['role'],'active'=>(bool)$row['is_active'],'isSuperAdmin'=>(bool)$row['is_super_admin'],'permissions'=>mahda_staff_permissions($db,$uid),'desks'=>$deskStmt->fetchAll(),'createdAt'=>(string)$row['created_at']];
            }
            mahda_json(['items'=>$items,'permissionCatalog'=>mahda_permission_catalog(),'currentUserId'=>(int)$super['id']]);
        }

        if ($action === 'admin_staff_save_v2' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$super=mahda_require_super_admin($db);
            $userId=max(0,(int)($data['userId']??0));
            $name=mahda_string($data['name']??'',120);
            $username=strtolower(mahda_string($data['username']??'',80));
            $password=(string)($data['password']??'');
            $role=mahda_string($data['role']??'reviewer',20);
            $active=(bool)($data['active']??true);
            $incoming=is_array($data['permissions']??null)?$data['permissions']:[];
            if($name===''||!in_array($role,['admin','reviewer'],true))mahda_json(['error'=>'invalid_staff'],422);
            if($userId===0 && !preg_match('/^[a-z0-9._-]{3,80}$/',$username))mahda_json(['error'=>'invalid_staff'],422);
            if($userId>0 && $username!=='' && !preg_match('/^[a-z0-9._-]{3,80}$/',$username))mahda_json(['error'=>'invalid_staff'],422);
            $catalog=mahda_permission_catalog();$permissions=[];
            foreach($incoming as $perm){$perm=(string)$perm;if(isset($catalog[$perm])&&!in_array($perm,$permissions,true))$permissions[]=$perm;}
            if($userId===0 && strlen($password)<12) mahda_json(['error'=>'password_too_short'],422);
            if($password!=='' && strlen($password)<12) mahda_json(['error'=>'password_too_short'],422);

            if($userId>0){
                $find=$db->prepare("SELECT id,is_super_admin FROM mahda_users WHERE id=? AND role IN ('admin','reviewer') LIMIT 1");$find->execute([$userId]);$before=$find->fetch();
                if(!$before)mahda_json(['error'=>'staff_not_found'],404);
                if((bool)$before['is_super_admin'] && $userId!==(int)$super['id'])mahda_json(['error'=>'cannot_edit_other_super_admin'],409);
                if($userId===(int)$super['id'] && (!$active||$role!=='admin'))mahda_json(['error'=>'cannot_lock_self'],409);
                if($username!==''){
                    $dup=$db->prepare('SELECT id FROM mahda_users WHERE LOWER(admin_username)=LOWER(?) AND id<>? LIMIT 1');$dup->execute([$username,$userId]);if($dup->fetchColumn())mahda_json(['error'=>'username_exists'],409);
                }
                $storedUsername=$username!==''?$username:null;
                if($password!==''){
                    $db->prepare('UPDATE mahda_users SET display_name=?,admin_username=?,role=?,is_active=?,password_hash=? WHERE id=?')->execute([$name,$storedUsername,$role,$active?1:0,password_hash($password,PASSWORD_DEFAULT),$userId]);
                }else{
                    $db->prepare('UPDATE mahda_users SET display_name=?,admin_username=?,role=?,is_active=? WHERE id=?')->execute([$name,$storedUsername,$role,$active?1:0,$userId]);
                }
            }else{
                $dup=$db->prepare('SELECT id FROM mahda_users WHERE LOWER(admin_username)=LOWER(?) LIMIT 1');$dup->execute([$username]);if($dup->fetchColumn())mahda_json(['error'=>'username_exists'],409);
                $email='staff-'.$username.'@mahda.local';
                $db->beginTransaction();
                try{
                    $db->prepare("INSERT INTO mahda_users(email,admin_username,display_name,password_hash,role,is_active,is_super_admin) VALUES(?,?,?,?,?,?,0)")->execute([$email,$username,$name,password_hash($password,PASSWORD_DEFAULT),$role,$active?1:0]);
                    $userId=(int)$db->lastInsertId();
                    $slug='staff-'.$userId.'-'.substr(hash('sha256',$username.microtime(true)),0,10);
                    $db->prepare("INSERT INTO mahda_profiles(owner_id,slug,name,kind,profile_data_json) VALUES(?,?,?,'personal','{}')")->execute([$userId,$slug,$name]);
                    $db->commit();
                }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
            }
            if(!mahda_is_super_admin($db,$userId)){
                $db->prepare('DELETE FROM mahda_staff_permissions WHERE user_id=?')->execute([$userId]);
                $ins=$db->prepare('INSERT INTO mahda_staff_permissions(user_id,permission_key,granted_by) VALUES(?,?,?)');
                foreach($permissions as $perm)$ins->execute([$userId,$perm,(int)$super['id']]);
            }
            mahda_audit($db,(int)$super['id'],'staff_save','user',$userId,['role'=>$role,'active'=>$active,'permissions'=>$permissions,'username'=>$username]);
            mahda_json(['ok'=>true,'userId'=>$userId]);
        }

        if ($action === 'admin_desks_v2' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $staff=mahda_require_staff($db);$uid=(int)$staff['id'];
            $canManage=mahda_is_super_admin($db,$uid)||mahda_has_permission($db,$staff,'desks.manage');
            if($canManage){
                $stmt=$db->query("SELECT d.*,(SELECT COUNT(*) FROM mahda_desk_categories dc WHERE dc.desk_id=d.id) AS category_count,(SELECT COUNT(*) FROM mahda_desk_members dm WHERE dm.desk_id=d.id) AS member_count,(SELECT COUNT(*) FROM mahda_contents c WHERE c.desk_id=d.id AND c.archived_at IS NULL AND c.review_status='pending') AS pending_count FROM mahda_desks d ORDER BY d.is_active DESC,d.name");
            }else{
                $stmt=$db->prepare("SELECT d.*,(SELECT COUNT(*) FROM mahda_desk_categories dc WHERE dc.desk_id=d.id) AS category_count,(SELECT COUNT(*) FROM mahda_desk_members dmm WHERE dmm.desk_id=d.id) AS member_count,(SELECT COUNT(*) FROM mahda_contents c WHERE c.desk_id=d.id AND c.archived_at IS NULL AND c.review_status='pending') AS pending_count FROM mahda_desks d JOIN mahda_desk_members dm ON dm.desk_id=d.id WHERE dm.user_id=? AND dm.can_view=1 ORDER BY d.is_active DESC,d.name");$stmt->execute([$uid]);
            }
            $items=array_map(static fn(array $r):array=>['id'=>(int)$r['id'],'name'=>(string)$r['name'],'slug'=>(string)$r['slug'],'description'=>(string)($r['description']??''),'active'=>(bool)$r['is_active'],'categoryCount'=>(int)$r['category_count'],'memberCount'=>(int)$r['member_count'],'pendingCount'=>(int)$r['pending_count']],$stmt->fetchAll());
            mahda_json(['items'=>$items,'canManage'=>$canManage]);
        }

        if ($action === 'admin_desk_v2' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $staff=mahda_require_staff($db);$deskId=max(0,(int)($_GET['id']??0));
            $canManage=mahda_is_super_admin($db,(int)$staff['id'])||mahda_has_permission($db,$staff,'desks.manage');
            $access=$deskId>0?mahda_staff_desk_access($db,(int)$staff['id'],$deskId):null;
            if($deskId===0&&!$canManage)mahda_json(['error'=>'permission_denied'],403);
            if($deskId>0&&!$canManage&&!$access)mahda_json(['error'=>'permission_denied'],403);
            if($deskId>0){
                $d=$db->prepare('SELECT id,name,slug,description,is_active FROM mahda_desks WHERE id=? LIMIT 1');$d->execute([$deskId]);$desk=$d->fetch();if(!$desk)mahda_json(['error'=>'desk_not_found'],404);
                $cat=$db->prepare('SELECT category_id FROM mahda_desk_categories WHERE desk_id=? ORDER BY category_id');$cat->execute([$deskId]);
                $selectedCategories=array_map('strval',$cat->fetchAll(PDO::FETCH_COLUMN));
            }else{
                $desk=['id'=>0,'name'=>'','slug'=>'','description'=>'','is_active'=>1];
                $selectedCategories=[];
            }
            $members=[];
            if($deskId>0){
                $mem=$db->prepare("SELECT dm.user_id,dm.can_view,dm.can_edit,dm.can_request_revision,dm.can_final_approve,u.display_name,u.admin_username,u.role,u.is_active FROM mahda_desk_members dm JOIN mahda_users u ON u.id=dm.user_id WHERE dm.desk_id=? ORDER BY u.display_name");$mem->execute([$deskId]);
                $members=array_map(static fn(array $r):array=>['userId'=>(int)$r['user_id'],'name'=>(string)$r['display_name'],'username'=>(string)($r['admin_username']??''),'role'=>(string)$r['role'],'active'=>(bool)$r['is_active'],'view'=>(bool)$r['can_view'],'edit'=>(bool)$r['can_edit'],'revision'=>(bool)$r['can_request_revision'],'approve'=>(bool)$r['can_final_approve']],$mem->fetchAll());
            }
            $eligible=[];
            if($canManage){$eligible=array_map(static fn(array $r):array=>['id'=>(int)$r['id'],'name'=>(string)$r['display_name'],'username'=>(string)($r['admin_username']??''),'role'=>(string)$r['role'],'active'=>(bool)$r['is_active']],$db->query("SELECT id,display_name,admin_username,role,is_active FROM mahda_users WHERE role IN ('admin','reviewer') ORDER BY is_active DESC,display_name")->fetchAll());}
            $categories=array_map(static fn(array $r):array=>['id'=>(string)$r['id'],'label'=>(string)$r['label'],'active'=>(bool)$r['is_active']],$db->query('SELECT id,label,is_active FROM mahda_categories ORDER BY sort_order,id')->fetchAll());
            mahda_json(['desk'=>['id'=>(int)$desk['id'],'name'=>(string)$desk['name'],'slug'=>(string)$desk['slug'],'description'=>(string)($desk['description']??''),'active'=>(bool)$desk['is_active'],'categories'=>$selectedCategories,'members'=>$members],'eligibleStaff'=>$eligible,'categories'=>$categories,'canManage'=>$canManage]);
        }

        if ($action === 'admin_desk_save_v2' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$staff=mahda_require_permission($db,'desks.manage');
            $deskId=max(0,(int)($data['deskId']??0));$name=mahda_string($data['name']??'',120);$slug=strtolower(mahda_string($data['slug']??'',80));$description=mahda_string($data['description']??'',2000);$active=(bool)($data['active']??true);
            if($name===''||!preg_match('/^[a-z0-9_-]{2,80}$/',$slug))mahda_json(['error'=>'invalid_desk'],422);
            $categories=is_array($data['categories']??null)?array_values(array_unique(array_map(static fn($x)=>mahda_string($x,40),$data['categories']))):[];
            $members=is_array($data['members']??null)?$data['members']:[];
            $dup=$db->prepare('SELECT id FROM mahda_desks WHERE slug=? AND id<>? LIMIT 1');$dup->execute([$slug,$deskId]);if($dup->fetchColumn())mahda_json(['error'=>'desk_slug_exists'],409);
            if($deskId>0){$find=$db->prepare('SELECT id FROM mahda_desks WHERE id=? LIMIT 1');$find->execute([$deskId]);if(!$find->fetchColumn())mahda_json(['error'=>'desk_not_found'],404);}
            $db->beginTransaction();
            try{
                if($deskId>0){$db->prepare('UPDATE mahda_desks SET name=?,slug=?,description=?,is_active=? WHERE id=?')->execute([$name,$slug,$description!==''?$description:null,$active?1:0,$deskId]);}
                else{$db->prepare('INSERT INTO mahda_desks(name,slug,description,is_active,created_by) VALUES(?,?,?,?,?)')->execute([$name,$slug,$description!==''?$description:null,$active?1:0,(int)$staff['id']]);$deskId=(int)$db->lastInsertId();}
                $db->prepare('DELETE FROM mahda_desk_categories WHERE desk_id=?')->execute([$deskId]);
                $insCat=$db->prepare('INSERT INTO mahda_desk_categories(desk_id,category_id,is_primary) VALUES(?,?,1)');
                foreach($categories as $category){if($category==='')continue;$check=$db->prepare('SELECT id FROM mahda_categories WHERE id=? LIMIT 1');$check->execute([$category]);if($check->fetchColumn())$insCat->execute([$deskId,$category]);}
                $db->prepare('DELETE FROM mahda_desk_members WHERE desk_id=?')->execute([$deskId]);
                $insMem=$db->prepare('INSERT INTO mahda_desk_members(desk_id,user_id,can_view,can_edit,can_request_revision,can_final_approve) VALUES(?,?,?,?,?,?)');
                foreach($members as $member){if(!is_array($member))continue;$uid=max(0,(int)($member['userId']??0));if($uid<1)continue;$check=$db->prepare("SELECT id FROM mahda_users WHERE id=? AND role IN ('admin','reviewer') LIMIT 1");$check->execute([$uid]);if(!$check->fetchColumn())continue;$insMem->execute([$deskId,$uid,!empty($member['view'])?1:0,!empty($member['edit'])?1:0,!empty($member['revision'])?1:0,!empty($member['approve'])?1:0]);}
                if($categories){$ph=implode(',',array_fill(0,count($categories),'?'));$sql="UPDATE mahda_contents SET desk_id=? WHERE desk_id IS NULL AND category_id IN ({$ph})";$q=$db->prepare($sql);$vals=array_merge([$deskId],$categories);$q->execute($vals);}
                mahda_audit($db,(int)$staff['id'],'desk_save','desk',$deskId,['name'=>$name,'categories'=>$categories,'members'=>array_map(static fn($m)=>is_array($m)?(int)($m['userId']??0):0,$members)]);
                $db->commit();
            }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
            mahda_json(['ok'=>true,'deskId'=>$deskId]);
        }

        if ($action === 'admin_structure_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db, 'structure.manage');
            $categories = $db->query("SELECT c.id,c.label,c.icon,c.color,c.fields_json,c.is_active,c.sort_order,c.description,c.show_in_register,c.show_in_bank,
                (SELECT d.name FROM mahda_desk_categories dc JOIN mahda_desks d ON d.id=dc.desk_id WHERE dc.category_id=c.id ORDER BY dc.is_primary DESC,d.id LIMIT 1) AS desk_name,
                (SELECT COUNT(*) FROM mahda_contents mc WHERE mc.category_id=c.id) AS usage_count
                FROM mahda_categories c ORDER BY c.sort_order,c.id")->fetchAll();
            foreach ($categories as &$row) {
                $row['active']=(bool)$row['is_active']; $row['sortOrder']=(int)$row['sort_order'];
                $row['showInRegister']=(bool)$row['show_in_register']; $row['showInBank']=(bool)$row['show_in_bank'];
                $row['usageCount']=(int)$row['usage_count'];
                $row['fields']=json_decode((string)($row['fields_json']??'{}'),true)?:[];
                unset($row['is_active'],$row['sort_order'],$row['show_in_register'],$row['show_in_bank'],$row['usage_count'],$row['fields_json']);
            }
            unset($row);
            $topics=$db->query("SELECT t.*,(SELECT COUNT(*) FROM mahda_content_topics ct WHERE ct.topic_id=t.id) AS usage_count FROM mahda_topics t ORDER BY t.sort_order,t.label")->fetchAll();
            $topicCat=$db->prepare('SELECT category_id FROM mahda_category_topics WHERE topic_id=? ORDER BY category_id');
            foreach($topics as &$row){$row['id']=(int)$row['id'];$row['active']=(bool)$row['is_active'];$row['sortOrder']=(int)$row['sort_order'];$row['usageCount']=(int)$row['usage_count'];$topicCat->execute([$row['id']]);$row['categoryIds']=array_values(array_map('strval',$topicCat->fetchAll(PDO::FETCH_COLUMN)));unset($row['is_active'],$row['sort_order'],$row['usage_count']);}unset($row);
            mahda_json(['categories'=>$categories,'topics'=>$topics]);
        }

        if ($action === 'admin_category_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data(); mahda_require_csrf($data); $admin=mahda_require_permission($db,'structure.manage');
            $id=strtolower(mahda_string($data['id']??'',40)); $label=mahda_string($data['label']??'',120);
            $icon=mahda_string($data['icon']??'library',60); $color=mahda_string($data['color']??'#2f8f46',20);
            $description=mahda_string($data['description']??'',1000); $sort=max(0,min(9999,(int)($data['sortOrder']??0)));
            $active=(bool)($data['active']??true); $showRegister=(bool)($data['showInRegister']??true); $showBank=(bool)($data['showInBank']??true);
            $deskId=max(0,(int)($data['deskId']??0));
            if(!preg_match('/^[a-z0-9][a-z0-9_-]{1,39}$/',$id)||$label===''||!preg_match('/^#[0-9a-fA-F]{6}$/',$color)){mahda_json(['error'=>'invalid_category'],422);}
            $old=$db->prepare('SELECT id,fields_json FROM mahda_categories WHERE id=? LIMIT 1');$old->execute([$id]);$oldRow=$old->fetch();
            $fieldsJson=$oldRow?(string)($oldRow['fields_json']??'{}'):'{}';
            $db->prepare("INSERT INTO mahda_categories(id,label,icon,color,fields_json,is_active,sort_order,description,show_in_register,show_in_bank)
                VALUES(?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE label=VALUES(label),icon=VALUES(icon),color=VALUES(color),is_active=VALUES(is_active),sort_order=VALUES(sort_order),description=VALUES(description),show_in_register=VALUES(show_in_register),show_in_bank=VALUES(show_in_bank)")
                ->execute([$id,$label,$icon,$color,$fieldsJson,$active?1:0,$sort,$description!==''?$description:null,$showRegister?1:0,$showBank?1:0]);
            $db->prepare('DELETE FROM mahda_desk_categories WHERE category_id=?')->execute([$id]);
            if($deskId>0){$deskCheck=$db->prepare('SELECT id FROM mahda_desks WHERE id=? LIMIT 1');$deskCheck->execute([$deskId]);if(!$deskCheck->fetchColumn())mahda_json(['error'=>'desk_not_found'],422);$db->prepare('INSERT INTO mahda_desk_categories(desk_id,category_id,is_primary) VALUES(?,?,1)')->execute([$deskId,$id]);$db->prepare('UPDATE mahda_contents SET desk_id=? WHERE category_id=? AND (desk_id IS NULL OR desk_id=0)')->execute([$deskId,$id]);}else{$db->prepare('UPDATE mahda_contents SET desk_id=NULL WHERE category_id=? AND desk_id IS NOT NULL')->execute([$id]);}
            mahda_audit($db,(int)$admin['id'],'category_save','category',null,['id'=>$id,'label'=>$label,'active'=>$active,'deskId'=>$deskId]);
            mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_category_reorder_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data(); mahda_require_csrf($data); $admin=mahda_require_permission($db,'structure.manage');
            $ids=$data['ids']??[]; if(!is_array($ids))mahda_json(['error'=>'invalid_order'],422);
            $stmt=$db->prepare('UPDATE mahda_categories SET sort_order=? WHERE id=?');$i=10;foreach(array_slice($ids,0,200) as $id){$id=mahda_string($id,40);if($id!==''){$stmt->execute([$i,$id]);$i+=10;}}
            mahda_audit($db,(int)$admin['id'],'category_reorder','category',null,['count'=>count($ids)]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_topics_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'structure.manage');$q=mahda_string($_GET['q']??'',120);
            $sql="SELECT t.*,(SELECT COUNT(*) FROM mahda_content_topics ct WHERE ct.topic_id=t.id) AS usage_count FROM mahda_topics t";$params=[];
            if($q!==''){$sql.=" WHERE t.label LIKE ? OR t.description LIKE ?";$term='%'.$q.'%';$params=[$term,$term];}$sql.=" ORDER BY t.sort_order,t.label LIMIT 300";
            $st=$db->prepare($sql);$st->execute($params);$items=$st->fetchAll();$topicCat=$db->prepare('SELECT category_id FROM mahda_category_topics WHERE topic_id=? ORDER BY category_id');foreach($items as &$r){$r['id']=(int)$r['id'];$r['active']=(bool)$r['is_active'];$r['sortOrder']=(int)$r['sort_order'];$r['usageCount']=(int)$r['usage_count'];$topicCat->execute([$r['id']]);$r['categoryIds']=array_values(array_map('strval',$topicCat->fetchAll(PDO::FETCH_COLUMN)));unset($r['is_active'],$r['sort_order'],$r['usage_count']);}unset($r);mahda_json(['items'=>$items]);
        }

        if ($action === 'admin_topic_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'structure.manage');
            $id=max(0,(int)($data['id']??0));$label=mahda_string($data['label']??'',140);$slug=strtolower(mahda_string($data['slug']??'',100));$desc=mahda_string($data['description']??'',1000);$active=(bool)($data['active']??true);$sort=max(0,(int)($data['sortOrder']??0));
            if($label==='')mahda_json(['error'=>'topic_label_required'],422);if($slug===''){$slug='topic-'.substr(hash('sha256',$label),0,12);}if(!preg_match('/^[a-z0-9][a-z0-9_-]{1,99}$/',$slug))mahda_json(['error'=>'invalid_topic_slug'],422);
            if($id>0){$db->prepare('UPDATE mahda_topics SET label=?,slug=?,description=?,is_active=?,sort_order=? WHERE id=?')->execute([$label,$slug,$desc!==''?$desc:null,$active?1:0,$sort,$id]);}
            else{$db->prepare('INSERT INTO mahda_topics(label,slug,description,is_active,sort_order,created_by) VALUES(?,?,?,?,?,?)')->execute([$label,$slug,$desc!==''?$desc:null,$active?1:0,$sort,(int)$admin['id']]);$id=(int)$db->lastInsertId();}
            $categoryIds=is_array($data['categoryIds']??null)?array_values(array_unique(array_map(fn($x)=>mahda_string($x,40),$data['categoryIds']))):[];$db->prepare('DELETE FROM mahda_category_topics WHERE topic_id=?')->execute([$id]);$ct=$db->prepare('INSERT IGNORE INTO mahda_category_topics(category_id,topic_id) VALUES(?,?)');foreach(array_slice($categoryIds,0,100) as $cid){if($cid==='')continue;$chk=$db->prepare('SELECT id FROM mahda_categories WHERE id=? LIMIT 1');$chk->execute([$cid]);if($chk->fetchColumn())$ct->execute([$cid,$id]);}
            mahda_audit($db,(int)$admin['id'],'topic_save','topic',$id,['label'=>$label,'active'=>$active,'categories'=>$categoryIds]);mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_category_fields_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'structure.manage');$category=mahda_string($_GET['category']??'',40);if($category==='')mahda_json(['error'=>'category_required'],422);
            $st=$db->prepare('SELECT * FROM mahda_category_fields WHERE category_id=? ORDER BY sort_order,id');$st->execute([$category]);$items=$st->fetchAll();
            foreach($items as &$r){$r['id']=(int)$r['id'];$r['required']=(bool)$r['is_required'];$r['showInSearch']=(bool)$r['show_in_search'];$r['showInDetail']=(bool)$r['show_in_detail'];$r['active']=(bool)$r['is_active'];$r['sortOrder']=(int)$r['sort_order'];$r['options']=json_decode((string)($r['options_json']??'[]'),true)?:[];unset($r['is_required'],$r['show_in_search'],$r['show_in_detail'],$r['is_active'],$r['sort_order'],$r['options_json']);}unset($r);mahda_json(['items'=>$items]);
        }

        if ($action === 'admin_category_field_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'structure.manage');
            $id=max(0,(int)($data['id']??0));$category=mahda_string($data['categoryId']??'',40);$key=strtolower(mahda_string($data['key']??'',80));$label=mahda_string($data['label']??'',140);$help=mahda_string($data['help']??'',600);$type=mahda_string($data['type']??'text',24);
            if(!in_array($type,['text','textarea','number','range','select','multi','boolean'],true))$type='text';
            if($category===''||$label===''||!preg_match('/^[a-z0-9][a-z0-9_-]{1,79}$/',$key))mahda_json(['error'=>'invalid_category_field'],422);
            $categoryCheck=$db->prepare('SELECT id FROM mahda_categories WHERE id=? LIMIT 1');$categoryCheck->execute([$category]);if(!$categoryCheck->fetchColumn())mahda_json(['error'=>'category_not_found'],404);
            $options=$data['options']??[];if(!is_array($options))$options=[];$options=array_values(array_slice(array_filter(array_map(fn($x)=>mahda_string($x,120),$options)),0,80));
            $required=(bool)($data['required']??false);$search=(bool)($data['showInSearch']??false);$detail=(bool)($data['showInDetail']??true);$active=(bool)($data['active']??true);$sort=max(0,(int)($data['sortOrder']??0));
            if($id>0){$db->prepare('UPDATE mahda_category_fields SET field_key=?,label=?,help_text=?,field_type=?,options_json=?,is_required=?,show_in_search=?,show_in_detail=?,is_active=?,sort_order=? WHERE id=? AND category_id=?')->execute([$key,$label,$help!==''?$help:null,$type,json_encode($options,JSON_UNESCAPED_UNICODE),$required?1:0,$search?1:0,$detail?1:0,$active?1:0,$sort,$id,$category]);}
            else{$db->prepare('INSERT INTO mahda_category_fields(category_id,field_key,label,help_text,field_type,options_json,is_required,show_in_search,show_in_detail,is_active,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute([$category,$key,$label,$help!==''?$help:null,$type,json_encode($options,JSON_UNESCAPED_UNICODE),$required?1:0,$search?1:0,$detail?1:0,$active?1:0,$sort]);$id=(int)$db->lastInsertId();}
            mahda_sync_category_fields_json($db,$category);mahda_audit($db,(int)$admin['id'],'category_field_save','category_field',$id,['category'=>$category,'key'=>$key]);mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_category_field_toggle_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'structure.manage');$id=max(0,(int)($data['id']??0));$active=(bool)($data['active']??false);
            $st=$db->prepare('SELECT category_id FROM mahda_category_fields WHERE id=? LIMIT 1');$st->execute([$id]);$category=(string)($st->fetchColumn()?:'');if($category==='')mahda_json(['error'=>'field_not_found'],404);
            $db->prepare('UPDATE mahda_category_fields SET is_active=? WHERE id=?')->execute([$active?1:0,$id]);mahda_sync_category_fields_json($db,$category);mahda_audit($db,(int)$admin['id'],'category_field_toggle','category_field',$id,['active'=>$active]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_goals_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'structure.manage');$q=mahda_string($_GET['q']??'',120);$group=mahda_string($_GET['group']??'',24);
            $sql="SELECT g.*,(SELECT COUNT(*) FROM mahda_content_goals cg WHERE cg.goal_id=g.id) AS usage_count FROM mahda_goals g WHERE 1=1";$params=[];
            if($q!==''){$sql.=" AND (g.label LIKE ? OR g.description LIKE ? OR EXISTS(SELECT 1 FROM mahda_goal_aliases ga WHERE ga.goal_id=g.id AND ga.term LIKE ?))";$term='%'.$q.'%';$params=[$term,$term,$term];}
            if(in_array($group,['ethical','social','skill','belief'],true)){$sql.=" AND g.goal_group=?";$params[]=$group;}$sql.=" ORDER BY g.sort_order,g.label LIMIT 300";
            $st=$db->prepare($sql);$st->execute($params);$items=$st->fetchAll();$alias=$db->prepare('SELECT term,relation FROM mahda_goal_aliases WHERE goal_id=? ORDER BY relation,term');
            foreach($items as &$r){$alias->execute([(int)$r['id']]);$syn=[];$rel=[];$ant=[];foreach($alias->fetchAll() as $a){$relation=(string)($a['relation']??'synonym');if($relation==='related'){$rel[]=(string)$a['term'];}elseif($relation==='antonym'){$ant[]=(string)$a['term'];}else{$syn[]=(string)$a['term'];}}$r['id']=(int)$r['id'];$r['active']=(bool)$r['is_active'];$r['sortOrder']=(int)($r['sort_order']??0);$r['usageCount']=(int)$r['usage_count'];$r['synonyms']=$syn;$r['relatedTerms']=$rel;$r['antonyms']=$ant;unset($r['is_active'],$r['sort_order'],$r['usage_count']);}unset($r);mahda_json(['items'=>$items]);
        }

        if ($action === 'admin_goal_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'structure.manage');$id=max(0,(int)($data['id']??0));$label=mahda_string($data['label']??'',190);$desc=mahda_string($data['description']??'',2000);$group=mahda_string($data['group']??'ethical',24);if(!in_array($group,['ethical','social','skill','belief'],true))$group='ethical';$active=(bool)($data['active']??true);$sort=max(0,(int)($data['sortOrder']??0));if($label==='')mahda_json(['error'=>'goal_label_required'],422);
            if($id>0){$db->prepare('UPDATE mahda_goals SET label=?,description=?,goal_group=?,is_active=?,sort_order=? WHERE id=?')->execute([$label,$desc,$group,$active?1:0,$sort,$id]);}
            else{$db->prepare('INSERT INTO mahda_goals(label,description,goal_group,is_active,sort_order) VALUES(?,?,?,?,?)')->execute([$label,$desc,$group,$active?1:0,$sort]);$id=(int)$db->lastInsertId();}
            $db->prepare('DELETE FROM mahda_goal_aliases WHERE goal_id=?')->execute([$id]);$ins=$db->prepare('INSERT IGNORE INTO mahda_goal_aliases(goal_id,term,relation) VALUES(?,?,?)');
            foreach([['synonyms','synonym'],['relatedTerms','related'],['antonyms','antonym']] as [$key,$relation]){foreach(array_slice(is_array($data[$key]??null)?$data[$key]:[],0,80) as $term){$term=mahda_string($term,190);if($term!==''&&$term!==$label)$ins->execute([$id,$term,$relation]);}}
            mahda_audit($db,(int)$admin['id'],'goal_save','goal',$id,['label'=>$label,'group'=>$group]);mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_goal_merge_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'structure.manage');$source=max(0,(int)($data['sourceId']??0));$target=max(0,(int)($data['targetId']??0));if($source<1||$target<1||$source===$target)mahda_json(['error'=>'invalid_goal_merge'],422);
            $db->beginTransaction();try{$db->prepare('INSERT IGNORE INTO mahda_content_goals(content_id,goal_id) SELECT content_id,? FROM mahda_content_goals WHERE goal_id=?')->execute([$target,$source]);$db->prepare('DELETE FROM mahda_content_goals WHERE goal_id=?')->execute([$source]);$aliases=$db->prepare('SELECT term,relation FROM mahda_goal_aliases WHERE goal_id=?');$aliases->execute([$source]);$ins=$db->prepare('INSERT IGNORE INTO mahda_goal_aliases(goal_id,term,relation) VALUES(?,?,?)');foreach($aliases->fetchAll() as $a)$ins->execute([$target,$a['term'],$a['relation']]);$db->prepare('UPDATE mahda_goals SET is_active=0 WHERE id=?')->execute([$source]);$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
            mahda_audit($db,(int)$admin['id'],'goal_merge','goal',$target,['sourceId'=>$source]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_goal_toggle_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'structure.manage');$id=max(0,(int)($data['id']??0));$active=(bool)($data['active']??false);$db->prepare('UPDATE mahda_goals SET is_active=? WHERE id=?')->execute([$active?1:0,$id]);mahda_audit($db,(int)$admin['id'],'goal_toggle','goal',$id,['active'=>$active]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_occasions_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'structure.manage');$q=mahda_string($_GET['q']??'',120);$group=mahda_string($_GET['group']??'',30);$sql="SELECT o.*,(SELECT COUNT(*) FROM mahda_content_occasions co WHERE co.occasion_id=o.id) AS usage_count FROM mahda_occasions o WHERE 1=1";$params=[];if($q!==''){$sql.=" AND (o.label LIKE ? OR o.aliases_json LIKE ?)";$term='%'.$q.'%';$params=[$term,$term];}if(in_array($group,['celebrations','mourning','national','general'],true)){$sql.=" AND o.occasion_group=?";$params[]=$group;}$sql.=" ORDER BY o.sort_order,o.label LIMIT 400";$st=$db->prepare($sql);$st->execute($params);$items=$st->fetchAll();foreach($items as &$r){$r['id']=(int)$r['id'];$r['active']=(bool)$r['is_active'];$r['sortOrder']=(int)($r['sort_order']??0);$r['usageCount']=(int)$r['usage_count'];$r['aliases']=json_decode((string)($r['aliases_json']??'[]'),true)?:[];unset($r['is_active'],$r['sort_order'],$r['usage_count'],$r['aliases_json']);}unset($r);mahda_json(['items'=>$items]);
        }

        if ($action === 'admin_occasion_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'structure.manage');$id=max(0,(int)($data['id']??0));$label=mahda_string($data['label']??'',190);$group=mahda_string($data['group']??'general',30);if(!in_array($group,['celebrations','mourning','national','general'],true))$group='general';$desc=mahda_string($data['description']??'',1500);$aliases=array_values(array_slice(array_filter(array_map(fn($x)=>mahda_string($x,120),is_array($data['aliases']??null)?$data['aliases']:[])),0,80));$active=(bool)($data['active']??true);$sort=max(0,(int)($data['sortOrder']??0));if($label==='')mahda_json(['error'=>'occasion_label_required'],422);
            if($id>0){$db->prepare('UPDATE mahda_occasions SET label=?,occasion_group=?,aliases_json=?,description=?,is_active=?,sort_order=? WHERE id=?')->execute([$label,$group,json_encode($aliases,JSON_UNESCAPED_UNICODE),$desc!==''?$desc:null,$active?1:0,$sort,$id]);}
            else{$db->prepare('INSERT INTO mahda_occasions(label,occasion_group,aliases_json,description,is_active,sort_order) VALUES(?,?,?,?,?,?)')->execute([$label,$group,json_encode($aliases,JSON_UNESCAPED_UNICODE),$desc!==''?$desc:null,$active?1:0,$sort]);$id=(int)$db->lastInsertId();}
            mahda_audit($db,(int)$admin['id'],'occasion_save','occasion',$id,['label'=>$label,'group'=>$group]);mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_occasion_toggle_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'structure.manage');$id=max(0,(int)($data['id']??0));$active=(bool)($data['active']??false);$db->prepare('UPDATE mahda_occasions SET is_active=? WHERE id=?')->execute([$active?1:0,$id]);mahda_audit($db,(int)$admin['id'],'occasion_toggle','occasion',$id,['active'=>$active]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_profiles_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'users.view');$role=mahda_string($_GET['role']??'',24);$q=mahda_string($_GET['q']??'',120);$state=mahda_string($_GET['state']??'all',20);$cityId=max(0,(int)($_GET['cityId']??0));
            $where=['1=1'];$params=[];if(in_array($role,['mentor','heiat','family','khadem'],true)){$where[]='p.profile_role=?';$params[]=$role;}if($q!==''){$where[]='(p.name LIKE ? OR u.display_name LIKE ? OR u.email LIKE ? OR p.city LIKE ?)';$term='%'.$q.'%';array_push($params,$term,$term,$term,$term);}if($state==='active')$where[]='u.is_active=1';elseif($state==='inactive')$where[]='u.is_active=0';if($cityId>0){$where[]='p.city_id=?';$params[]=$cityId;}
            $sql="SELECT p.id,p.owner_id,p.name,p.kind,p.profile_role,p.city,p.city_id,p.province_id,p.latitude,p.longitude,p.atlas_visible,p.is_verified,p.verification_note,u.display_name,u.email,u.is_active,u.role,
                (SELECT COUNT(*) FROM mahda_contents c WHERE c.profile_id=p.id) content_count,
                (SELECT COUNT(*) FROM mahda_follows f WHERE f.profile_id=p.id) follower_count
                FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE ".implode(' AND ',$where)." ORDER BY u.is_active DESC,p.name LIMIT 300";
            $st=$db->prepare($sql);$st->execute($params);$items=$st->fetchAll();$badgeSt=$db->prepare('SELECT b.id,b.title,b.slug,b.icon,b.color,pb.granted_at FROM mahda_profile_badges pb JOIN mahda_badges b ON b.id=pb.badge_id WHERE pb.profile_id=? AND b.is_active=1 ORDER BY b.sort_order,b.id');
            foreach($items as &$r){$badgeSt->execute([(int)$r['id']]);$r['id']=(int)$r['id'];$r['ownerId']=(int)$r['owner_id'];$r['active']=(bool)$r['is_active'];$r['verified']=(bool)$r['is_verified'];$r['atlasVisible']=(bool)$r['atlas_visible'];$r['cityId']=$r['city_id']!==null?(int)$r['city_id']:null;$r['provinceId']=$r['province_id']!==null?(int)$r['province_id']:null;$r['contentCount']=(int)$r['content_count'];$r['followerCount']=(int)$r['follower_count'];$r['badges']=$badgeSt->fetchAll();unset($r['owner_id'],$r['is_active'],$r['is_verified'],$r['atlas_visible'],$r['city_id'],$r['province_id'],$r['content_count'],$r['follower_count']);}unset($r);mahda_json(['items'=>$items]);
        }

        if ($action === 'admin_profile_identity_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'users.manage');$id=max(0,(int)($data['profileId']??0));$role=mahda_string($data['role']??'',24);if(!in_array($role,['mentor','heiat','family','khadem'],true))mahda_json(['error'=>'invalid_profile_role'],422);$verified=(bool)($data['verified']??false);$note=mahda_string($data['verificationNote']??'',500);
            $db->prepare('UPDATE mahda_profiles SET profile_role=?,is_verified=?,verification_note=?,verified_at=?,verified_by=? WHERE id=?')->execute([$role,$verified?1:0,$note!==''?$note:null,$verified?date('Y-m-d H:i:s'):null,$verified?(int)$admin['id']:null,$id]);mahda_audit($db,(int)$admin['id'],'profile_identity','profile',$id,['role'=>$role,'verified'=>$verified]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_badges_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'users.view');$items=$db->query("SELECT b.*,(SELECT COUNT(*) FROM mahda_profile_badges pb WHERE pb.badge_id=b.id) usage_count FROM mahda_badges b ORDER BY b.sort_order,b.id")->fetchAll();foreach($items as &$r){$r['id']=(int)$r['id'];$r['active']=(bool)$r['is_active'];$r['sortOrder']=(int)$r['sort_order'];$r['usageCount']=(int)$r['usage_count'];unset($r['is_active'],$r['sort_order'],$r['usage_count']);}unset($r);mahda_json(['items'=>$items]);
        }

        if ($action === 'admin_badge_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'users.manage');$id=max(0,(int)($data['id']??0));$title=mahda_string($data['title']??'',120);$slug=strtolower(mahda_string($data['slug']??'',80));$desc=mahda_string($data['description']??'',500);$icon=mahda_string($data['icon']??'award',80);$color=mahda_string($data['color']??'#2f8f46',30);$applies=mahda_string($data['appliesTo']??'all',40);$active=(bool)($data['active']??true);$sort=max(0,(int)($data['sortOrder']??0));if($title===''||!preg_match('/^[a-z0-9][a-z0-9_-]{1,79}$/',$slug))mahda_json(['error'=>'invalid_badge'],422);if(!in_array($applies,['all','mentor','heiat','family','khadem'],true))mahda_json(['error'=>'invalid_badge_applies_to'],422);
            if($id>0){$db->prepare('UPDATE mahda_badges SET title=?,slug=?,description=?,icon=?,color=?,applies_to=?,is_active=?,sort_order=? WHERE id=?')->execute([$title,$slug,$desc,$icon,$color,$applies,$active?1:0,$sort,$id]);}else{$db->prepare('INSERT INTO mahda_badges(title,slug,description,icon,color,applies_to,is_active,sort_order,created_by) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$title,$slug,$desc,$icon,$color,$applies,$active?1:0,$sort,(int)$admin['id']]);$id=(int)$db->lastInsertId();}mahda_audit($db,(int)$admin['id'],'badge_save','badge',$id,['title'=>$title]);mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_profile_badge_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'users.manage');$profile=max(0,(int)($data['profileId']??0));$badge=max(0,(int)($data['badgeId']??0));$grant=(bool)($data['grant']??true);$note=mahda_string($data['note']??'',500);if($profile<1||$badge<1)mahda_json(['error'=>'invalid_badge_assignment'],422);
            $profileCheck=$db->prepare('SELECT profile_role FROM mahda_profiles WHERE id=? LIMIT 1');$profileCheck->execute([$profile]);$profileRole=$profileCheck->fetchColumn();if($profileRole===false)mahda_json(['error'=>'profile_not_found'],404);
            $badgeCheck=$db->prepare('SELECT applies_to,is_active FROM mahda_badges WHERE id=? LIMIT 1');$badgeCheck->execute([$badge]);$badgeRow=$badgeCheck->fetch();if(!$badgeRow)mahda_json(['error'=>'badge_not_found'],404);
            if($grant){if(!(bool)$badgeRow['is_active'])mahda_json(['error'=>'badge_not_active'],422);$applies=(string)$badgeRow['applies_to'];if($applies!=='all'&&$applies!==(string)$profileRole)mahda_json(['error'=>'badge_not_applicable'],422);$db->prepare('INSERT INTO mahda_profile_badges(profile_id,badge_id,granted_by,note) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE granted_by=VALUES(granted_by),note=VALUES(note),granted_at=CURRENT_TIMESTAMP')->execute([$profile,$badge,(int)$admin['id'],$note!==''?$note:null]);}else{$db->prepare('DELETE FROM mahda_profile_badges WHERE profile_id=? AND badge_id=?')->execute([$profile,$badge]);}
            mahda_audit($db,(int)$admin['id'],$grant?'badge_grant':'badge_revoke','profile',$profile,['badgeId'=>$badge]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_memberships_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'users.view');$st=$db->query("SELECT hm.*,h.name heiat_name,m.name mentor_name FROM mahda_heiat_memberships hm JOIN mahda_profiles h ON h.id=hm.heiat_profile_id JOIN mahda_profiles m ON m.id=hm.mentor_profile_id ORDER BY hm.created_at DESC LIMIT 300");mahda_json(['items'=>$st->fetchAll()]);
        }

        if ($action === 'admin_membership_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'users.manage');$heiat=max(0,(int)($data['heiatProfileId']??0));$mentor=max(0,(int)($data['mentorProfileId']??0));$status=mahda_string($data['status']??'pending',24);if(!in_array($status,['pending','accepted','rejected','removed'],true)||$heiat<1||$mentor<1)mahda_json(['error'=>'invalid_membership'],422);$db->prepare('INSERT INTO mahda_heiat_memberships(heiat_profile_id,mentor_profile_id,invited_by,status,responded_at) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status),responded_at=VALUES(responded_at)')->execute([$heiat,$mentor,(int)$admin['id'],$status,$status==='pending'?null:date('Y-m-d H:i:s')]);mahda_audit($db,(int)$admin['id'],'membership_save','profile',$heiat,['mentor'=>$mentor,'status'=>$status]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_reports_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'reports.manage');$type=mahda_string($_GET['type']??'all',24);$status=mahda_string($_GET['status']??'all',24);$q=mahda_string($_GET['q']??'',120);$where=['1=1'];$params=[];if(in_array($type,['content','comment'],true)){$where[]='r.target_type=?';$params[]=$type;}if(in_array($status,['new','in_progress','resolved'],true)){$where[]='r.status=?';$params[]=$status;}if($q!==''){$where[]='(r.note LIKE ? OR ru.display_name LIKE ?)';$term='%'.$q.'%';$params=[$term,$term];}
            $sql="SELECT r.*,ru.display_name reporter_name,
                CASE WHEN r.target_type='content' THEN (SELECT title FROM mahda_contents WHERE id=r.target_id) ELSE (SELECT LEFT(body,120) FROM mahda_comments WHERE id=r.target_id) END target_title
                FROM mahda_reports r LEFT JOIN mahda_users ru ON ru.id=r.reporter_user_id WHERE ".implode(' AND ',$where)." ORDER BY FIELD(r.status,'new','in_progress','resolved'),r.created_at DESC LIMIT 300";
            $st=$db->prepare($sql);$st->execute($params);$counts=['new'=>(int)$db->query("SELECT COUNT(*) FROM mahda_reports WHERE status='new'")->fetchColumn(),'in_progress'=>(int)$db->query("SELECT COUNT(*) FROM mahda_reports WHERE status='in_progress'")->fetchColumn(),'resolved'=>(int)$db->query("SELECT COUNT(*) FROM mahda_reports WHERE status='resolved'")->fetchColumn()];mahda_json(['items'=>$st->fetchAll(),'counts'=>$counts]);
        }

        if ($action === 'admin_report_action_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'reports.manage');$id=max(0,(int)($data['reportId']??0));$op=mahda_string($data['operation']??'',40);$note=mahda_string($data['note']??'',2000);$st=$db->prepare('SELECT * FROM mahda_reports WHERE id=? LIMIT 1');$st->execute([$id]);$r=$st->fetch();if(!$r)mahda_json(['error'=>'report_not_found'],404);
            if($op==='start'){$db->prepare("UPDATE mahda_reports SET status='in_progress',assigned_to=? WHERE id=?")->execute([(int)$admin['id'],$id]);}
            elseif($op==='resolve'){$db->prepare("UPDATE mahda_reports SET status='resolved',resolution_note=?,resolved_by=?,resolved_at=NOW() WHERE id=?")->execute([$note!==''?$note:null,(int)$admin['id'],$id]);}
            elseif($op==='hide'&&$r['target_type']==='content'){$db->prepare("UPDATE mahda_contents SET visibility='hidden',hidden_reason=?,admin_updated_at=NOW() WHERE id=?")->execute([$note!==''?$note:'گزارش مدیریتی',(int)$r['target_id']]);}
            elseif($op==='restore'&&$r['target_type']==='content'){$db->prepare("UPDATE mahda_contents SET visibility='showcase',hidden_reason=NULL,admin_updated_at=NOW() WHERE id=?")->execute([(int)$r['target_id']]);}
            elseif($op==='revision'&&$r['target_type']==='content'){$status=mahda_revision_storage_status($db);$prevSt=$db->prepare('SELECT review_status FROM mahda_contents WHERE id=? LIMIT 1');$prevSt->execute([(int)$r['target_id']]);$previous=(string)($prevSt->fetchColumn()?:'');$db->prepare('UPDATE mahda_contents SET review_status=?,admin_updated_at=NOW() WHERE id=?')->execute([$status,(int)$r['target_id']]);$db->prepare("INSERT INTO mahda_review_actions(content_id,reviewer_id,action,previous_status,new_status,note) VALUES(?,?,'revision',?,?,?)")->execute([(int)$r['target_id'],(int)$admin['id'],$previous,$status,$note]);}
            elseif($op==='hide_comment'&&$r['target_type']==='comment'){$db->prepare('UPDATE mahda_comments SET is_hidden=1,hidden_by=?,hidden_reason=?,hidden_at=NOW() WHERE id=?')->execute([(int)$admin['id'],$note!==''?$note:'گزارش مدیریتی',(int)$r['target_id']]);}
            elseif($op==='restore_comment'&&$r['target_type']==='comment'){$db->prepare('UPDATE mahda_comments SET is_hidden=0,hidden_by=NULL,hidden_reason=NULL,hidden_at=NULL WHERE id=?')->execute([(int)$r['target_id']]);}
            else mahda_json(['error'=>'invalid_report_operation'],422);
            mahda_audit($db,(int)$admin['id'],'report_'.$op,'report',$id,['note'=>$note]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_notifications_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $staff=mahda_require_staff($db);$uid=(int)$staff['id'];$st=$db->prepare('SELECT * FROM mahda_admin_notifications WHERE recipient_user_id IS NULL OR recipient_user_id=? ORDER BY is_read,created_at DESC LIMIT 100');$st->execute([$uid]);$items=$st->fetchAll();$unread=0;foreach($items as $r)if(!(bool)$r['is_read'])$unread++;mahda_json(['items'=>$items,'unread'=>$unread]);
        }

        if ($action === 'admin_notifications_read_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$staff=mahda_require_staff($db);$id=max(0,(int)($data['id']??0));if($id>0){$db->prepare('UPDATE mahda_admin_notifications SET is_read=1 WHERE id=? AND (recipient_user_id IS NULL OR recipient_user_id=?)')->execute([$id,(int)$staff['id']]);}else{$db->prepare('UPDATE mahda_admin_notifications SET is_read=1 WHERE recipient_user_id IS NULL OR recipient_user_id=?')->execute([(int)$staff['id']]);}mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_home_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'homepage.manage');$sections=$db->query('SELECT * FROM mahda_home_sections ORDER BY sort_order,id')->fetchAll();$itemSt=$db->prepare('SELECT content_id,sort_order FROM mahda_home_section_items WHERE section_id=? ORDER BY sort_order,content_id');foreach($sections as &$r){$itemSt->execute([(int)$r['id']]);$r['id']=(int)$r['id'];$r['active']=(bool)$r['is_active'];$r['sortOrder']=(int)$r['sort_order'];$r['config']=json_decode((string)($r['config_json']??'{}'),true)?:[];$r['contentIds']=array_map('intval',$itemSt->fetchAll(PDO::FETCH_COLUMN));unset($r['is_active'],$r['sort_order'],$r['config_json']);}unset($r);$pages=$db->query('SELECT * FROM mahda_special_pages ORDER BY sort_order,id')->fetchAll();$pitems=$db->prepare('SELECT content_id FROM mahda_special_page_items WHERE page_id=? ORDER BY sort_order,content_id');foreach($pages as &$r){$pitems->execute([(int)$r['id']]);$r['id']=(int)$r['id'];$r['active']=(bool)$r['is_active'];$r['sortOrder']=(int)$r['sort_order'];$r['contentIds']=array_map('intval',$pitems->fetchAll(PDO::FETCH_COLUMN));unset($r['is_active'],$r['sort_order']);}unset($r);mahda_json(['sections'=>$sections,'pages'=>$pages]);
        }

        if ($action === 'admin_home_section_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'homepage.manage');$id=max(0,(int)($data['id']??0));$key=strtolower(mahda_string($data['key']??'',80));$type=mahda_string($data['type']??'content_row',40);$title=mahda_string($data['title']??'',160);$subtitle=mahda_string($data['subtitle']??'',300);$mode=mahda_string($data['sourceMode']??'auto',20);if(!in_array($mode,['auto','manual'],true))$mode='auto';$active=(bool)($data['active']??true);$sort=max(0,(int)($data['sortOrder']??0));$config=is_array($data['config']??null)?$data['config']:[];$contentIds=array_values(array_unique(array_map('intval',is_array($data['contentIds']??null)?$data['contentIds']:[])));if($title==='')mahda_json(['error'=>'section_title_required'],422);if($key==='')$key='section-'.substr(hash('sha256',$title.microtime(true)),0,12);
            if($id>0){$db->prepare('UPDATE mahda_home_sections SET section_key=?,section_type=?,title=?,subtitle=?,source_mode=?,config_json=?,is_active=?,sort_order=? WHERE id=?')->execute([$key,$type,$title,$subtitle,$mode,json_encode($config,JSON_UNESCAPED_UNICODE),$active?1:0,$sort,$id]);}
            else{$db->prepare('INSERT INTO mahda_home_sections(section_key,section_type,title,subtitle,source_mode,config_json,is_active,sort_order,created_by) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$key,$type,$title,$subtitle,$mode,json_encode($config,JSON_UNESCAPED_UNICODE),$active?1:0,$sort,(int)$admin['id']]);$id=(int)$db->lastInsertId();}
            $db->prepare('DELETE FROM mahda_home_section_items WHERE section_id=?')->execute([$id]);$ins=$db->prepare('INSERT IGNORE INTO mahda_home_section_items(section_id,content_id,sort_order) VALUES(?,?,?)');$i=10;foreach(array_slice($contentIds,0,100) as $cid){if($cid>0){$ins->execute([$id,$cid,$i]);$i+=10;}}
            mahda_audit($db,(int)$admin['id'],'home_section_save','home_section',$id,['title'=>$title]);mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_home_reorder_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'homepage.manage');$ids=is_array($data['ids']??null)?$data['ids']:[];$st=$db->prepare('UPDATE mahda_home_sections SET sort_order=? WHERE id=?');$i=10;foreach(array_slice($ids,0,100) as $id){$id=(int)$id;if($id>0){$st->execute([$i,$id]);$i+=10;}}mahda_audit($db,(int)$admin['id'],'home_reorder','homepage',null,['count'=>count($ids)]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_special_page_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'homepage.manage');$id=max(0,(int)($data['id']??0));$slug=strtolower(mahda_string($data['slug']??'',100));$title=mahda_string($data['title']??'',180);$subtitle=mahda_string($data['subtitle']??'',400);$cover=max(0,(int)($data['coverFileId']??0));$active=(bool)($data['active']??true);$sort=max(0,(int)($data['sortOrder']??0));$contentIds=array_values(array_unique(array_map('intval',is_array($data['contentIds']??null)?$data['contentIds']:[])));if($title==='')mahda_json(['error'=>'page_title_required'],422);if($slug==='')$slug='page-'.substr(hash('sha256',$title.microtime(true)),0,12);
            if($id>0){$db->prepare('UPDATE mahda_special_pages SET slug=?,title=?,subtitle=?,cover_file_id=?,is_active=?,sort_order=? WHERE id=?')->execute([$slug,$title,$subtitle,$cover?:null,$active?1:0,$sort,$id]);}
            else{$db->prepare('INSERT INTO mahda_special_pages(slug,title,subtitle,cover_file_id,is_active,sort_order,created_by) VALUES(?,?,?,?,?,?,?)')->execute([$slug,$title,$subtitle,$cover?:null,$active?1:0,$sort,(int)$admin['id']]);$id=(int)$db->lastInsertId();}
            $db->prepare('DELETE FROM mahda_special_page_items WHERE page_id=?')->execute([$id]);$ins=$db->prepare('INSERT IGNORE INTO mahda_special_page_items(page_id,content_id,sort_order) VALUES(?,?,?)');$i=10;foreach(array_slice($contentIds,0,100) as $cid){if($cid>0){$ins->execute([$id,$cid,$i]);$i+=10;}}
            mahda_audit($db,(int)$admin['id'],'special_page_save','special_page',$id,['title'=>$title]);mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_atlas_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'atlas.manage');$mode=mahda_string($_GET['mode']??'cities',20);$q=mahda_string($_GET['q']??'',120);$province=max(0,(int)($_GET['provinceId']??0));$city=max(0,(int)($_GET['cityId']??0));
            if($mode==='provinces'){$sql='SELECT p.*,(SELECT COUNT(*) FROM mahda_cities c WHERE c.province_id=p.id) city_count FROM mahda_provinces p';$params=[];if($q!==''){$sql.=' WHERE p.name LIKE ?';$params[]='%'.$q.'%';}$sql.=' ORDER BY p.name';$st=$db->prepare($sql);$st->execute($params);mahda_json(['items'=>$st->fetchAll()]);}
            if($mode==='cities'){$where=['1=1'];$params=[];if($q!==''){$where[]='c.name LIKE ?';$params[]='%'.$q.'%';}if($province>0){$where[]='c.province_id=?';$params[]=$province;}$sql="SELECT c.*,p.name province_name,(SELECT COUNT(*) FROM mahda_profiles mp WHERE mp.city_id=c.id AND mp.profile_role='mentor' AND mp.atlas_visible=1) mentor_count,(SELECT COUNT(*) FROM mahda_profiles hp WHERE hp.city_id=c.id AND hp.profile_role='heiat' AND hp.atlas_visible=1) heiat_count FROM mahda_cities c JOIN mahda_provinces p ON p.id=c.province_id WHERE ".implode(' AND ',$where)." ORDER BY (mentor_count+heiat_count) DESC,c.name LIMIT 500";$st=$db->prepare($sql);$st->execute($params);mahda_json(['items'=>$st->fetchAll()]);}
            $role=$mode==='heiats'?'heiat':'mentor';$where=['p.profile_role=?','p.atlas_visible=1'];$params=[$role];if($q!==''){$where[]='(p.name LIKE ? OR p.city LIKE ?)';$term='%'.$q.'%';$params[]=$term;$params[]=$term;}if($province>0){$where[]='p.province_id=?';$params[]=$province;}if($city>0){$where[]='p.city_id=?';$params[]=$city;}$sql="SELECT p.id,p.name,p.city,p.city_id,p.province_id,p.latitude,p.longitude,p.is_verified,u.display_name,u.is_active,(SELECT COUNT(*) FROM mahda_contents c WHERE c.profile_id=p.id) content_count FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE ".implode(' AND ',$where)." ORDER BY p.is_verified DESC,p.name LIMIT 500";$st=$db->prepare($sql);$st->execute($params);mahda_json(['items'=>$st->fetchAll()]);
        }

        if ($action === 'admin_atlas_profile_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'atlas.manage');$profile=max(0,(int)($data['profileId']??0));$cityId=max(0,(int)($data['cityId']??0));$visible=(bool)($data['visible']??true);$lat=$data['latitude']??null;$lng=$data['longitude']??null;if($profile<1)mahda_json(['error'=>'invalid_profile'],422);
            $cityRow=null;if($cityId>0){$st=$db->prepare('SELECT c.id,c.name,c.province_id,c.latitude,c.longitude FROM mahda_cities c WHERE c.id=? LIMIT 1');$st->execute([$cityId]);$cityRow=$st->fetch();if(!$cityRow)mahda_json(['error'=>'city_not_found'],404);}
            if($lat!==null&&!is_numeric($lat))$lat=null;if($lng!==null&&!is_numeric($lng))$lng=null;if($lat===null&&$cityRow)$lat=$cityRow['latitude'];if($lng===null&&$cityRow)$lng=$cityRow['longitude'];
            $db->prepare('UPDATE mahda_profiles SET city_id=?,province_id=?,city=?,latitude=?,longitude=?,atlas_visible=? WHERE id=?')->execute([$cityId?:null,$cityRow['province_id']??null,$cityRow['name']??null,$lat,$lng,$visible?1:0,$profile]);mahda_audit($db,(int)$admin['id'],'atlas_profile_save','profile',$profile,['cityId'=>$cityId,'visible'=>$visible]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_city_save_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'atlas.manage');$id=max(0,(int)($data['id']??0));$province=max(0,(int)($data['provinceId']??0));$name=mahda_string($data['name']??'',120);$slug=mahda_string($data['slug']??$name,140);$lat=$data['latitude']??null;$lng=$data['longitude']??null;if($province<1||$name===''||!is_numeric($lat)||!is_numeric($lng))mahda_json(['error'=>'invalid_city'],422);if($id<1)$id=(int)$db->query('SELECT COALESCE(MAX(id),0)+1 FROM mahda_cities')->fetchColumn();$db->prepare('INSERT INTO mahda_cities(id,province_id,name,slug,latitude,longitude) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE province_id=VALUES(province_id),name=VALUES(name),slug=VALUES(slug),latitude=VALUES(latitude),longitude=VALUES(longitude)')->execute([$id,$province,$name,$slug,(float)$lat,(float)$lng]);mahda_audit($db,(int)$admin['id'],'city_save','city',$id,['name'=>$name]);mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_files_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'files.manage');$q=mahda_string($_GET['q']??'',120);$health=mahda_string($_GET['health']??'all',20);$purpose=mahda_string($_GET['purpose']??'',30);$where=['1=1'];$params=[];if($q!==''){$where[]='(f.original_name LIKE ? OR p.name LIKE ? OR c.title LIKE ?)';$term='%'.$q.'%';$params=[$term,$term,$term];}if($purpose!==''){$where[]='f.purpose=?';$params[]=$purpose;}$sql="SELECT f.id,f.content_id,f.owner_id,f.purpose,f.storage_key,f.original_name,f.mime_type,f.size_bytes,f.created_at,c.title content_title,p.name owner_name FROM mahda_files f LEFT JOIN mahda_contents c ON c.id=f.content_id LEFT JOIN mahda_profiles p ON p.owner_id=f.owner_id WHERE ".implode(' AND ',$where)." ORDER BY f.created_at DESC LIMIT 500";$st=$db->prepare($sql);$st->execute($params);$items=[];$missing=0;$healthy=0;foreach($st->fetchAll() as $r){$path=mahda_existing_upload_path((string)$r['storage_key']);$ok=$path!==null;$r['health']=$ok?'healthy':'missing';$r['actualSize']=$ok?(int)filesize($path):0;if($ok)$healthy++;else$missing++;if($health==='healthy'&&!$ok)continue;if($health==='missing'&&$ok)continue;$items[]=$r;}
            $referencedKeys=[];foreach($db->query('SELECT storage_key,original_storage_key,thumbnail_storage_key FROM mahda_files')->fetchAll() as $refRow){foreach(['storage_key','original_storage_key','thumbnail_storage_key'] as $col){$key=basename((string)($refRow[$col]??''));if($key!==''&&$key!=='.'&&$key!=='..')$referencedKeys[$key]=true;}}
            $orphans=[];foreach(mahda_storage_dirs() as $dir){if(!is_dir($dir))continue;foreach(scandir($dir)?:[] as $name){if($name==='.'||$name==='..'||$name==='.htaccess'||$name==='index.html')continue;$full=$dir.'/'.$name;if(is_file($full)&&!isset($referencedKeys[$name]))$orphans[]=['storageKey'=>$name,'sizeBytes'=>(int)filesize($full),'storageRoot'=>$dir===mahda_private_upload_dir()?'private':'legacy_public'];}}
            $primary=mahda_private_upload_dir();$diskPath=is_dir($primary)?$primary:dirname($primary);$dbBytes=(int)$db->query('SELECT COALESCE(SUM(size_bytes),0) FROM mahda_files')->fetchColumn();$diskTotal=@disk_total_space($diskPath)?:0;$diskFree=@disk_free_space($diskPath)?:0;mahda_json(['items'=>$items,'stats'=>['dbBytes'=>$dbBytes,'healthy'=>$healthy,'missing'=>$missing,'orphanCount'=>count($orphans),'orphanBytes'=>array_sum(array_column($orphans,'sizeBytes')),'diskTotal'=>$diskTotal,'diskFree'=>$diskFree],'orphans'=>array_slice($orphans,0,200)]);
        }

        if ($action === 'admin_file_delete_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'files.manage');$id=max(0,(int)($data['fileId']??0));$reason=mahda_string($data['reason']??'',500);if($id<1||$reason==='')mahda_json(['error'=>'delete_reason_required'],422);$st=$db->prepare('SELECT * FROM mahda_files WHERE id=? LIMIT 1');$st->execute([$id]);$r=$st->fetch();if(!$r)mahda_json(['error'=>'file_not_found'],404);$db->prepare('DELETE FROM mahda_files WHERE id=?')->execute([$id]);mahda_safe_remove_file_keys($r);mahda_audit($db,(int)$admin['id'],'file_delete','file',$id,['reason'=>$reason,'name'=>$r['original_name']]);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_orphan_cleanup_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'files.manage');$keys=is_array($data['storageKeys']??null)?$data['storageKeys']:[];$deleted=0;$bytes=0;$check=$db->prepare('SELECT id FROM mahda_files WHERE storage_key=? OR original_storage_key=? OR thumbnail_storage_key=? LIMIT 1');foreach(array_slice($keys,0,200) as $key){$key=basename(mahda_string($key,255));if($key===''||$key==='.'||$key==='..')continue;$check->execute([$key,$key,$key]);if($check->fetchColumn())continue;foreach(mahda_storage_dirs() as $dir){$full=$dir.'/'.$key;if(is_file($full)){$bytes+=(int)filesize($full);if(@unlink($full))$deleted++;}}}mahda_audit($db,(int)$admin['id'],'orphan_cleanup','storage',null,['deleted'=>$deleted,'bytes'=>$bytes]);mahda_json(['ok'=>true,'deleted'=>$deleted,'bytes'=>$bytes]);
        }

        if ($action === 'admin_audit_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'audit.view');$q=mahda_string($_GET['q']??'',120);$sql="SELECT a.*,u.display_name actor_name,u.admin_username actor_username FROM mahda_audit_log a LEFT JOIN mahda_users u ON u.id=a.actor_id";$params=[];if($q!==''){$sql.=" WHERE a.action LIKE ? OR a.entity_type LIKE ? OR u.display_name LIKE ?";$term='%'.$q.'%';$params=[$term,$term,$term];}$sql.=" ORDER BY a.id DESC LIMIT 500";$st=$db->prepare($sql);$st->execute($params);mahda_json(['items'=>$st->fetchAll()]);
        }

        if ($action === 'admin_system_health_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'settings.manage');$upload=mahda_private_upload_dir();$storageProbe=is_dir($upload)?$upload:dirname($upload);$dbOk=true;try{$db->query('SELECT 1')->fetchColumn();}catch(Throwable $e){$dbOk=false;}$errorCount=mahda_table_exists($db,'mahda_system_errors')?(int)$db->query('SELECT COUNT(*) FROM mahda_system_errors WHERE resolved_at IS NULL')->fetchColumn():0;$missing=0;if(mahda_table_exists($db,'mahda_files')){foreach($db->query('SELECT storage_key FROM mahda_files')->fetchAll(PDO::FETCH_COLUMN) as $key)if(!mahda_existing_upload_path((string)$key))$missing++;}
            mahda_json(['database'=>['ok'=>$dbOk,'schemaVersion'=>(int)$db->query('SELECT MAX(version) FROM mahda_migrations')->fetchColumn()],'storage'=>['path'=>$upload,'legacyPath'=>mahda_public_upload_path(),'writable'=>(is_dir($upload)?is_writable($upload):is_writable(dirname($upload))),'diskTotal'=>@disk_total_space($storageProbe)?:0,'diskFree'=>@disk_free_space($storageProbe)?:0,'missingFiles'=>$missing],'php'=>['version'=>PHP_VERSION,'uploadMax'=>ini_get('upload_max_filesize'),'postMax'=>ini_get('post_max_size'),'memoryLimit'=>ini_get('memory_limit')],'errors'=>['open'=>$errorCount]]);
        }

        if ($action === 'admin_system_errors_v3' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'settings.manage');$items=$db->query('SELECT * FROM mahda_system_errors ORDER BY resolved_at IS NULL DESC,id DESC LIMIT 300')->fetchAll();mahda_json(['items'=>$items]);
        }

        if ($action === 'admin_system_error_resolve_v3' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'settings.manage');$id=max(0,(int)($data['id']??0));$db->prepare('UPDATE mahda_system_errors SET resolved_at=NOW() WHERE id=?')->execute([$id]);mahda_audit($db,(int)$admin['id'],'system_error_resolve','system_error',$id);mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_dashboard' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $staff = mahda_require_permission($db, 'dashboard.view');
            // Legacy dashboard has no desk scoping. Keep it available only to
            // staff who can view the whole content bank; the current UI uses v2.
            if (!mahda_is_super_admin($db,(int)$staff['id']) && !mahda_has_permission($db,$staff,'content.view')) {
                mahda_json(['error'=>'permission_denied'],403);
            }
            $tableExists = static function (PDO $connection, string $table): bool {
                $check = $connection->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?");
                $check->execute([$table]);
                return (int)$check->fetchColumn() === 1;
            };
            $count = static function (PDO $connection, string $sql): int {
                return (int)$connection->query($sql)->fetchColumn();
            };
            $pending = $count($db, "SELECT COUNT(*) FROM mahda_contents WHERE review_status='pending'");
            $needsRevision = $count($db, "SELECT COUNT(*) FROM mahda_contents WHERE review_status='revision'");
            $rejected = $count($db, "SELECT COUNT(*) FROM mahda_contents WHERE review_status='rejected'");
            $approved = $count($db, "SELECT COUNT(*) FROM mahda_contents WHERE review_status='approved'");
            $activeUsers = $count($db, 'SELECT COUNT(*) FROM mahda_users WHERE is_active=1');
            $activeCategories = $count($db, 'SELECT COUNT(*) FROM mahda_categories WHERE is_active=1');
            $fileCount = 0;
            $fileBytes = 0;
            if ($tableExists($db, 'mahda_files')) {
                $fileStats = $db->query('SELECT COUNT(*),COALESCE(SUM(size_bytes),0) FROM mahda_files')->fetch(PDO::FETCH_NUM) ?: [0, 0];
                $fileCount = (int)($fileStats[0] ?? 0);
                $fileBytes = (int)($fileStats[1] ?? 0);
            }

            $pendingByCategory = [];
            $categoryStmt = $db->query("SELECT cat.id,cat.label,cat.icon,cat.color,COUNT(c.id) AS pending_count
                FROM mahda_categories cat
                LEFT JOIN mahda_contents c ON c.category_id=cat.id AND c.review_status='pending'
                WHERE cat.is_active=1
                GROUP BY cat.id,cat.label,cat.icon,cat.color
                ORDER BY pending_count DESC,cat.sort_order,cat.id");
            foreach ($categoryStmt->fetchAll() as $row) {
                $pendingByCategory[] = [
                    'id' => (string)$row['id'],
                    'label' => (string)$row['label'],
                    'icon' => (string)$row['icon'],
                    'color' => (string)$row['color'],
                    'pending' => (int)$row['pending_count'],
                ];
            }

            $recentActions = [];
            if ($tableExists($db, 'mahda_audit_log')) {
                $actions = $db->query("SELECT a.id,a.action,a.entity_id,a.created_at,COALESCE(u.display_name,'مدیر حذف‌شده') AS actor_name
                    FROM mahda_audit_log a LEFT JOIN mahda_users u ON u.id=a.actor_id
                    ORDER BY a.created_at DESC,a.id DESC LIMIT 8");
                foreach ($actions->fetchAll() as $row) {
                    $recentActions[] = [
                        'id' => (string)$row['id'],
                        'action' => (string)$row['action'],
                        'entityId' => $row['entity_id'] !== null ? (string)$row['entity_id'] : null,
                        'actorName' => (string)$row['actor_name'],
                        'createdAt' => (string)$row['created_at'],
                    ];
                }
            }

            $uploadsPath = mahda_private_upload_dir();
            $uploadsReady = is_dir($uploadsPath) ? is_writable($uploadsPath) : is_writable(dirname($uploadsPath));
            $schemaVersion = (int)$db->query('SELECT COALESCE(MAX(version),0) FROM mahda_migrations')->fetchColumn();
            mahda_json([
                'staff' => ['id' => (int)$staff['id'], 'role' => (string)$staff['role']],
                'database' => ['connected' => true, 'schemaVersion' => $schemaVersion],
                'stats' => [
                    'pendingReview' => $pending,
                    'needsRevision' => $needsRevision,
                    'rejected' => $rejected,
                    'approved' => $approved,
                    'activeUsers' => $activeUsers,
                    'activeCategories' => $activeCategories,
                    'fileCount' => $fileCount,
                    'fileBytes' => $fileBytes,
                ],
                'reports' => ['available' => false, 'count' => null],
                'storage' => ['uploadsReady' => $uploadsReady],
                'pendingByCategory' => $pendingByCategory,
                'recentActions' => $recentActions,
            ]);
        }

        if ($action === 'admin_review_queue' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db, 'content.view');
            $status = mahda_string($_GET['status'] ?? 'pending', 32);
            $category = mahda_string($_GET['category'] ?? '', 40);
            $query = mahda_string($_GET['q'] ?? '', 190);
            $limit = max(1, min(100, (int)($_GET['limit'] ?? 50)));
            $offset = max(0, min(100000, (int)($_GET['offset'] ?? 0)));
            $allowedStatuses = ['all','pending','approved','revision','rejected','not_requested'];
            if (!in_array($status, $allowedStatuses, true)) { $status = 'pending'; }
            $where = ['1=1'];
            $params = [];
            if ($status !== 'all') { $where[] = 'c.review_status=?'; $params[] = $status; }
            if ($category !== '') { $where[] = 'c.category_id=?'; $params[] = $category; }
            if ($query !== '') {
                $where[] = '(c.title LIKE ? OR p.name LIKE ? OR u.display_name LIKE ?)';
                $term = '%' . $query . '%';
                array_push($params, $term, $term, $term);
            }
            $base = ' FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_users u ON u.id=c.author_id JOIN mahda_categories cat ON cat.id=c.category_id WHERE ' . implode(' AND ', $where);
            $countStmt = $db->prepare('SELECT COUNT(*)' . $base); $countStmt->execute($params); $total = (int)$countStmt->fetchColumn();
            $sql = 'SELECT c.id,c.title,c.category_id,c.review_status,c.visibility,c.created_at,p.id AS profile_id,p.name AS profile_name,p.kind AS profile_kind,u.id AS author_id,u.display_name AS author_name,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color' . $base . ' ORDER BY c.created_at DESC,c.id DESC LIMIT ? OFFSET ?';
            $stmt = $db->prepare($sql);
            $bind = 1;
            foreach ($params as $param) { $stmt->bindValue($bind++, $param, PDO::PARAM_STR); }
            $stmt->bindValue($bind++, $limit, PDO::PARAM_INT);
            $stmt->bindValue($bind, $offset, PDO::PARAM_INT);
            $stmt->execute();
            $items = [];
            foreach ($stmt->fetchAll() as $row) {
                $items[] = [
                    'id'=>(int)$row['id'],'title'=>(string)$row['title'],'categoryId'=>(string)$row['category_id'],'categoryLabel'=>(string)$row['category_label'],
                    'categoryIcon'=>(string)$row['category_icon'],'categoryColor'=>(string)$row['category_color'],'status'=>(string)$row['review_status'],
                    'visibility'=>(string)$row['visibility'],'profileId'=>(int)$row['profile_id'],'profileName'=>(string)$row['profile_name'],'profileKind'=>(string)$row['profile_kind'],
                    'authorId'=>(int)$row['author_id'],'authorName'=>(string)$row['author_name'],'createdAt'=>(string)$row['created_at'],
                ];
            }
            mahda_json(['items'=>$items,'total'=>$total,'limit'=>$limit,'offset'=>$offset]);
        }

        if ($action === 'admin_content_detail' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db, 'content.view');
            $contentId = max(0, (int)($_GET['id'] ?? 0));
            if ($contentId < 1) { mahda_json(['error'=>'invalid_content'], 422); }
            $stmt = $db->prepare("SELECT c.*,p.name AS profile_name,p.kind AS profile_kind,p.slug AS profile_slug,u.email AS author_email,u.display_name AS author_name,cat.label AS category_label,cat.icon AS category_icon,cat.color AS category_color FROM mahda_contents c JOIN mahda_profiles p ON p.id=c.profile_id JOIN mahda_users u ON u.id=c.author_id JOIN mahda_categories cat ON cat.id=c.category_id WHERE c.id=? LIMIT 1");
            $stmt->execute([$contentId]); $row = $stmt->fetch();
            if (!$row) { mahda_json(['error'=>'content_not_found'], 404); }
            $filesStmt = $db->prepare('SELECT id,purpose,original_name,mime_type,size_bytes FROM mahda_files WHERE content_id=? ORDER BY id');
            $filesStmt->execute([$contentId]);
            $files = array_map(static fn(array $f): array => ['id'=>(int)$f['id'],'purpose'=>(string)$f['purpose'],'name'=>(string)$f['original_name'],'mime'=>(string)$f['mime_type'],'size'=>(int)$f['size_bytes'],'url'=>'/mahda-api/index.php?action=file&id='.(int)$f['id']], $filesStmt->fetchAll());
            $historyStmt = $db->prepare('SELECT r.id,r.action,r.previous_status,r.new_status,r.note,r.created_at,u.display_name AS reviewer_name FROM mahda_review_actions r LEFT JOIN mahda_users u ON u.id=r.reviewer_id WHERE r.content_id=? ORDER BY r.created_at DESC,r.id DESC');
            $historyStmt->execute([$contentId]);
            $history = array_map(static fn(array $r): array => ['id'=>(int)$r['id'],'action'=>(string)$r['action'],'previousStatus'=>(string)$r['previous_status'],'newStatus'=>(string)$r['new_status'],'note'=>(string)($r['note'] ?? ''),'reviewerName'=>(string)($r['reviewer_name'] ?? 'مدیر'),'createdAt'=>(string)$r['created_at']], $historyStmt->fetchAll());
            mahda_json(['content'=>mahda_item($db,$row),'review'=>['status'=>(string)$row['review_status'],'visibility'=>(string)$row['visibility'],'body'=>(string)($row['body'] ?? ''),'authorEmail'=>(string)$row['author_email'],'authorName'=>(string)$row['author_name'],'profileSlug'=>(string)$row['profile_slug']],'files'=>$files,'history'=>$history]);
        }

        if ($action === 'admin_review_action' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = mahda_request_data(); mahda_require_csrf($data); $staff = mahda_require_staff($db);
            $contentId = max(0, (int)($data['contentId'] ?? 0));
            $decision = mahda_string($data['decision'] ?? '', 32);
            $note = mahda_string($data['note'] ?? '', 4000);
            if ($contentId < 1 || !in_array($decision, ['approve','revision','reject','pending'], true)) { mahda_json(['error'=>'invalid_review_action'], 422); }
            if (in_array($decision, ['revision','reject'], true) && $note === '') { mahda_json(['error'=>'review_note_required'], 422); }
            $find = $db->prepare('SELECT id,title,author_id,profile_id,desk_id,review_status FROM mahda_contents WHERE id=? LIMIT 1'); $find->execute([$contentId]); $content = $find->fetch();
            if (!$content) { mahda_json(['error'=>'content_not_found'], 404); }
            $requiredOp = $decision === 'revision' ? 'revision' : ($decision === 'reject' ? 'reject' : 'approve');
            if (!mahda_can_access_content($db,$staff,$content,$requiredOp)) { mahda_json(['error'=>'permission_denied'],403); }
            $previous = (string)$content['review_status'];
            $newStatus = $decision === 'approve' ? 'approved' : ($decision === 'pending' ? 'pending' : ($decision === 'revision' ? mahda_revision_storage_status($db) : 'rejected'));
            $db->beginTransaction();
            try {
                $db->prepare('UPDATE mahda_contents SET review_status=? WHERE id=?')->execute([$newStatus,$contentId]);
                $db->prepare('INSERT INTO mahda_review_actions(content_id,reviewer_id,action,previous_status,new_status,note) VALUES(?,?,?,?,?,?)')
                    ->execute([$contentId,(int)$staff['id'],$decision,$previous,$newStatus,$note !== '' ? $note : null]);
                mahda_audit($db,(int)$staff['id'],'content_review_' . $decision,'content',$contentId,['previous'=>$previous,'new'=>$newStatus,'note'=>$note]);
                $db->commit();
            } catch (Throwable $error) { if ($db->inTransaction()) { $db->rollBack(); } throw $error; }
            $reviewNotificationKind = $decision === 'approve' ? 'review_approved' : ($decision === 'revision' ? 'review_revision' : ($decision === 'reject' ? 'review_rejected' : null));
            if ($reviewNotificationKind !== null) {
                try {
                    mahda_notify($db, (int)$content['author_id'], (int)$staff['id'], $reviewNotificationKind, $contentId, (int)$content['profile_id'], ['note'=>$note,'decision'=>$decision]);
                } catch (Throwable $notificationError) {
                    // The moderation decision is already committed; a temporary
                    // notification failure must not make the admin think the
                    // review itself failed and repeat the action.
                }
            }
            mahda_json(['ok'=>true,'contentId'=>$contentId,'status'=>$newStatus,'decision'=>$decision]);
        }

        if ($action === 'admin_users' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db, 'users.view');
            $query = mahda_string($_GET['q'] ?? '', 190); $role = mahda_string($_GET['role'] ?? 'all', 20); $state = mahda_string($_GET['state'] ?? 'all', 20);
            $limit=max(1,min(100,(int)($_GET['limit']??50))); $offset=max(0,min(100000,(int)($_GET['offset']??0)));
            $where=['1=1']; $params=[];
            if (in_array($role,['member','reviewer','admin'],true)) { $where[]='u.role=?'; $params[]=$role; }
            if ($state==='active') { $where[]='u.is_active=1'; } elseif ($state==='inactive') { $where[]='u.is_active=0'; }
            if ($query!=='') { $where[]='(u.display_name LIKE ? OR u.email LIKE ?)'; $term='%'.$query.'%'; array_push($params,$term,$term); }
            $whereSql=implode(' AND ',$where);
            $count=$db->prepare('SELECT COUNT(*) FROM mahda_users u WHERE '.$whereSql); $count->execute($params); $total=(int)$count->fetchColumn();
            $sql="SELECT u.id,u.email,u.display_name,u.role,u.is_active,u.created_at,(SELECT COUNT(*) FROM mahda_profiles p WHERE p.owner_id=u.id) AS profile_count,(SELECT COUNT(*) FROM mahda_contents c WHERE c.author_id=u.id) AS content_count FROM mahda_users u WHERE {$whereSql} ORDER BY u.created_at DESC,u.id DESC LIMIT ? OFFSET ?";
            $stmt=$db->prepare($sql); $i=1; foreach($params as $param){$stmt->bindValue($i++,$param,PDO::PARAM_STR);} $stmt->bindValue($i++,$limit,PDO::PARAM_INT); $stmt->bindValue($i,$offset,PDO::PARAM_INT); $stmt->execute();
            $items=[]; foreach($stmt->fetchAll() as $row){ $email=(string)$row['email']; $phone=''; if(preg_match('/^(?:test-)?phone-(98\d+)@mahda\.local$/',$email,$m)){ $phone=$m[1]; }
                $items[]=['id'=>(int)$row['id'],'email'=>$email,'phone'=>$phone,'displayName'=>(string)$row['display_name'],'role'=>(string)$row['role'],'active'=>(bool)$row['is_active'],'profileCount'=>(int)$row['profile_count'],'contentCount'=>(int)$row['content_count'],'createdAt'=>(string)$row['created_at']]; }
            mahda_json(['items'=>$items,'total'=>$total,'limit'=>$limit,'offset'=>$offset]);
        }

        if ($action === 'admin_user_update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data(); mahda_require_csrf($data); $admin=mahda_require_permission($db, 'users.manage');
            $userId=max(0,(int)($data['userId']??0)); $role=mahda_string($data['role']??'',20); $active=array_key_exists('active',$data)?(bool)$data['active']:null;
            if($userId<1 || !in_array($role,['member','reviewer','admin'],true) || $active===null){ mahda_json(['error'=>'invalid_user_update'],422); }
            if($userId===(int)$admin['id'] && ($role!=='admin' || !$active)){ mahda_json(['error'=>'cannot_lock_self'],409); }
            $find=$db->prepare('SELECT id,role,is_active,is_super_admin FROM mahda_users WHERE id=? LIMIT 1'); $find->execute([$userId]); $before=$find->fetch(); if(!$before){mahda_json(['error'=>'user_not_found'],404);}
            $staffRoleChange = in_array((string)$before['role'],['admin','reviewer'],true) || in_array($role,['admin','reviewer'],true);
            if ($staffRoleChange && !mahda_is_super_admin($db,(int)$admin['id'])) { mahda_json(['error'=>'super_admin_required'],403); }
            if ((bool)($before['is_super_admin'] ?? false) && !mahda_is_super_admin($db,(int)$admin['id'])) { mahda_json(['error'=>'super_admin_required'],403); }
            $db->prepare('UPDATE mahda_users SET role=?,is_active=? WHERE id=?')->execute([$role,$active?1:0,$userId]);
            mahda_audit($db,(int)$admin['id'],'user_update','user',$userId,['before'=>['role'=>(string)$before['role'],'active'=>(bool)$before['is_active']],'after'=>['role'=>$role,'active'=>$active]]);
            mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_profiles' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db, 'users.view');
            $query=mahda_string($_GET['q']??'',190); $kind=mahda_string($_GET['kind']??'all',20); $limit=max(1,min(100,(int)($_GET['limit']??50))); $offset=max(0,min(100000,(int)($_GET['offset']??0)));
            $where=['1=1']; $params=[]; if(in_array($kind,['personal','heiat'],true)){ $where[]='p.kind=?'; $params[]=$kind; }
            if($query!==''){ $where[]='(p.name LIKE ? OR p.city LIKE ? OR u.display_name LIKE ? OR u.email LIKE ?)'; $term='%'.$query.'%'; array_push($params,$term,$term,$term,$term); }
            $whereSql=implode(' AND ',$where); $count=$db->prepare('SELECT COUNT(*) FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE '.$whereSql); $count->execute($params); $total=(int)$count->fetchColumn();
            $sql="SELECT p.id,p.owner_id,p.slug,p.name,p.kind,p.bio,p.city,u.created_at AS created_at,u.display_name,u.email,u.is_active,(SELECT COUNT(*) FROM mahda_contents c WHERE c.profile_id=p.id) AS content_count,(SELECT COUNT(*) FROM mahda_follows f WHERE f.profile_id=p.id) AS follower_count FROM mahda_profiles p JOIN mahda_users u ON u.id=p.owner_id WHERE {$whereSql} ORDER BY p.created_at DESC,p.id DESC LIMIT ? OFFSET ?";
            $stmt=$db->prepare($sql); $i=1; foreach($params as $param){$stmt->bindValue($i++,$param,PDO::PARAM_STR);} $stmt->bindValue($i++,$limit,PDO::PARAM_INT); $stmt->bindValue($i,$offset,PDO::PARAM_INT); $stmt->execute();
            $items=[]; foreach($stmt->fetchAll() as $row){$items[]=['id'=>(int)$row['id'],'ownerId'=>(int)$row['owner_id'],'slug'=>(string)$row['slug'],'name'=>(string)$row['name'],'kind'=>(string)$row['kind'],'bio'=>(string)($row['bio']??''),'city'=>(string)($row['city']??''),'ownerName'=>(string)$row['display_name'],'ownerEmail'=>(string)$row['email'],'ownerActive'=>(bool)$row['is_active'],'contentCount'=>(int)$row['content_count'],'followerCount'=>(int)$row['follower_count'],'createdAt'=>(string)$row['created_at']];}
            mahda_json(['items'=>$items,'total'=>$total,'limit'=>$limit,'offset'=>$offset]);
        }

        if ($action === 'admin_profile_update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data(); mahda_require_csrf($data); $admin=mahda_require_permission($db, 'users.manage'); $profileId=max(0,(int)($data['profileId']??0));
            $name=mahda_string($data['name']??'',190); $city=mahda_string($data['city']??'',120); $bio=mahda_string($data['bio']??'',2000); if($profileId<1||$name===''){mahda_json(['error'=>'invalid_profile_update'],422);}
            $find=$db->prepare('SELECT id,name,city,bio FROM mahda_profiles WHERE id=? LIMIT 1'); $find->execute([$profileId]); $before=$find->fetch(); if(!$before){mahda_json(['error'=>'profile_not_found'],404);}
            $cityRow=$city!==''?mahda_resolve_city_name($db,$city):null;$canonicalCity=$cityRow?(string)$cityRow['name']:$city;$db->prepare('UPDATE mahda_profiles SET name=?,city=?,city_id=?,province_id=?,bio=? WHERE id=?')->execute([$name,$canonicalCity!==''?$canonicalCity:null,$cityRow?(int)$cityRow['id']:null,$cityRow?(int)$cityRow['province_id']:null,$bio!==''?$bio:null,$profileId]);
            mahda_audit($db,(int)$admin['id'],'profile_update','profile',$profileId,['name'=>$name,'city'=>$city]); mahda_json(['ok'=>true]);
        }

        if ($action === 'admin_categories' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db, 'structure.manage');
            $items=$db->query('SELECT id,label,icon,color,fields_json,is_active,sort_order FROM mahda_categories ORDER BY sort_order,id')->fetchAll();
            $items=array_map(static fn(array $row):array=>['id'=>(string)$row['id'],'label'=>(string)$row['label'],'icon'=>(string)$row['icon'],'color'=>(string)$row['color'],'fields'=>json_decode((string)($row['fields_json']??'{}'),true)?:[],'active'=>(bool)$row['is_active'],'sortOrder'=>(int)$row['sort_order']],$items);
            mahda_json(['items'=>$items]);
        }

        if ($action === 'admin_category_save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data(); mahda_require_csrf($data); $admin=mahda_require_permission($db, 'structure.manage');
            $id=strtolower(mahda_string($data['id']??'',40)); $label=mahda_string($data['label']??'',120); $icon=mahda_string($data['icon']??'library',60); $color=mahda_string($data['color']??'#5f7f58',40); $sortOrder=max(0,min(9999,(int)($data['sortOrder']??0))); $active=(bool)($data['active']??true);
            if(!preg_match('/^[a-z0-9][a-z0-9_-]{1,39}$/',$id)||$label===''||!preg_match('/^[a-zA-Z0-9_-]{1,60}$/',$icon)||!preg_match('/^#[0-9a-fA-F]{6}$/',$color)){mahda_json(['error'=>'invalid_category'],422);}
            $find=$db->prepare('SELECT fields_json FROM mahda_categories WHERE id=? LIMIT 1'); $find->execute([$id]); $existingFields=$find->fetchColumn(); $fieldsJson=$existingFields!==false?(string)$existingFields:'{}';
            $db->prepare('INSERT INTO mahda_categories(id,label,icon,color,fields_json,is_active,sort_order) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE label=VALUES(label),icon=VALUES(icon),color=VALUES(color),is_active=VALUES(is_active),sort_order=VALUES(sort_order)')
                ->execute([$id,$label,$icon,$color,$fieldsJson,$active?1:0,$sortOrder]);
            mahda_audit($db,(int)$admin['id'],'category_save','category',null,['id'=>$id,'label'=>$label,'active'=>$active,'sortOrder'=>$sortOrder]); mahda_json(['ok'=>true,'id'=>$id]);
        }

        if ($action === 'admin_settings' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db, 'settings.manage'); $rows=$db->query('SELECT setting_key,setting_value,updated_at FROM mahda_settings ORDER BY setting_key')->fetchAll(); $items=[]; foreach($rows as $row){$items[(string)$row['setting_key']]=(string)($row['setting_value']??'');} mahda_json(['items'=>$items]);
        }

        if ($action === 'admin_settings_save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data(); mahda_require_csrf($data); $admin=mahda_require_permission($db, 'settings.manage'); $incoming=$data['settings']??[]; if(!is_array($incoming)){mahda_json(['error'=>'invalid_settings'],422);}
            $allowed=['review_required','site_title','admin_notice','support_email','upload_cover_max_mb','upload_video_max_mb','upload_audio_max_mb','upload_attachment_max_mb','allowed_upload_mimes','publish_rules_text']; $normalized=[];
            foreach($allowed as $key){
                if(!array_key_exists($key,$incoming)) continue;
                if($key==='review_required'){$value=(bool)$incoming[$key]?'1':'0';}
                elseif(in_array($key,['upload_cover_max_mb','upload_video_max_mb','upload_audio_max_mb','upload_attachment_max_mb'],true)){$value=(string)max(1,min(500,(int)$incoming[$key]));}
                elseif($key==='allowed_upload_mimes'){$value=mahda_string($incoming[$key],2000);}
                elseif(in_array($key,['admin_notice','publish_rules_text'],true)){$value=mahda_string($incoming[$key],5000);}
                else{$value=mahda_string($incoming[$key],190);}
                if($key==='support_email'&&$value!==''&&!filter_var($value,FILTER_VALIDATE_EMAIL)){mahda_json(['error'=>'invalid_support_email'],422);}
                $normalized[$key]=$value;
            }
            $stmt=$db->prepare('INSERT INTO mahda_settings(setting_key,setting_value,updated_by) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_by=VALUES(updated_by)'); foreach($normalized as $key=>$value){$stmt->execute([$key,$value,(int)$admin['id']]);}
            mahda_audit($db,(int)$admin['id'],'settings_update','settings',null,['keys'=>array_keys($normalized)]); mahda_json(['ok'=>true,'items'=>$normalized]);
        }

        if ($action === 'admin_goal_suggestions_v12' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            mahda_require_permission($db,'structure.manage');$rows=$db->query("SELECT s.id,s.proposed_label,s.normalized_label,s.status,s.matched_goal_id,s.created_at,u.display_name AS owner_name FROM mahda_goal_suggestions s LEFT JOIN mahda_users u ON u.id=s.owner_id ORDER BY FIELD(s.status,'pending','approved','rejected'),s.created_at DESC LIMIT 300")->fetchAll();foreach($rows as &$r){$r['id']=(int)$r['id'];$r['matchedGoalId']=$r['matched_goal_id']===null?null:(int)$r['matched_goal_id'];unset($r['matched_goal_id']);}unset($r);mahda_json(['items'=>$rows]);
        }

        if ($action === 'admin_goal_suggestion_action_v12' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data=mahda_request_data();mahda_require_csrf($data);$admin=mahda_require_permission($db,'structure.manage');$id=max(0,(int)($data['id']??0));$decision=mahda_string($data['decision']??'',20);if(!in_array($decision,['approve','reject'],true))mahda_json(['error'=>'invalid_decision'],422);$s=$db->prepare('SELECT * FROM mahda_goal_suggestions WHERE id=? AND status=\'pending\' LIMIT 1');$s->execute([$id]);$row=$s->fetch();if(!$row)mahda_json(['error'=>'suggestion_not_found'],404);$goalId=null;if($decision==='approve'){$label=(string)$row['proposed_label'];$f=$db->prepare('SELECT id FROM mahda_goals WHERE label=? LIMIT 1');$f->execute([$label]);$goalId=(int)($f->fetchColumn()?:0);if($goalId<1){$db->prepare('INSERT INTO mahda_goals(label,description,goal_group,is_active,sort_order) VALUES(?,?,\'ethical\',1,999)')->execute([$label,'هدف پیشنهادی تأییدشده توسط مدیریت']);$goalId=(int)$db->lastInsertId();}$db->prepare("UPDATE mahda_goal_suggestions SET status='approved',matched_goal_id=?,reviewed_at=NOW(),reviewed_by=? WHERE id=?")->execute([$goalId,(int)$admin['id'],$id]);}else{$db->prepare("UPDATE mahda_goal_suggestions SET status='rejected',reviewed_at=NOW(),reviewed_by=? WHERE id=?")->execute([(int)$admin['id'],$id]);}mahda_audit($db,(int)$admin['id'],'goal_suggestion_'.$decision,'goal_suggestion',$id,['goalId'=>$goalId]);mahda_json(['ok'=>true,'goalId'=>$goalId]);
        }

    mahda_json(['error' => 'method_not_allowed'], 405);
}
