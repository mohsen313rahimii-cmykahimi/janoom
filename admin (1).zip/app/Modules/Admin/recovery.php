<?php
declare(strict_types=1);

require dirname(__DIR__, 3) . '/mahda-api/bootstrap.php';

$recoveryKey = mahda_admin_recovery_key();
$lockFile = mahda_private_path() . '/recovery-used';

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

$key = (string)($_GET['key'] ?? $_POST['key'] ?? '');
$locked = is_file($lockFile);
$configured = $recoveryKey !== '';
$authorized = $configured && !$locked && $key !== '' && hash_equals($recoveryKey, $key);
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $authorized) {
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $displayName = mahda_string($_POST['display_name'] ?? 'مدیر مهدا', 120);
    $password = (string)($_POST['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $errorMessage = 'ایمیل معتبر وارد کنید.';
    } elseif (strlen($password) < 12 || strlen($password) > 72) {
        $errorMessage = 'رمز عبور باید حداقل ۱۲ و حداکثر ۷۲ نویسه باشد.';
    } elseif ($displayName === '') {
        $errorMessage = 'نام مدیر را وارد کنید.';
    } else {
        try {
            $db = mahda_db();
            mahda_migrate_social($db);
            mahda_migrate_auth($db);
            $db->beginTransaction();
            $find = $db->prepare('SELECT id FROM mahda_users WHERE email=? LIMIT 1');
            $find->execute([$email]);
            $userId = (int)($find->fetchColumn() ?: 0);
            $hash = password_hash($password, PASSWORD_DEFAULT);
            if ($userId > 0) {
                $db->prepare("UPDATE mahda_users SET display_name=?,password_hash=?,role='admin',is_active=1 WHERE id=?")
                    ->execute([$displayName, $hash, $userId]);
                $profile = $db->prepare("SELECT id FROM mahda_profiles WHERE owner_id=? ORDER BY (kind='personal') DESC,id LIMIT 1");
                $profile->execute([$userId]);
                $profileId = (int)($profile->fetchColumn() ?: 0);
                if ($profileId < 1) {
                    $slug = 'm-' . $userId . '-' . substr(hash('sha256', $email), 0, 12);
                    $db->prepare("INSERT INTO mahda_profiles(owner_id,slug,name,kind,profile_data_json) VALUES(?,?,?,'personal',?)")
                        ->execute([$userId, $slug, $displayName, '{}']);
                    $profileId = (int)$db->lastInsertId();
                }
            } else {
                $db->prepare("INSERT INTO mahda_users(email,display_name,password_hash,role,is_active) VALUES(?,?,?,'admin',1)")
                    ->execute([$email, $displayName, $hash]);
                $userId = (int)$db->lastInsertId();
                $slug = 'm-' . $userId . '-' . substr(hash('sha256', $email), 0, 12);
                $db->prepare("INSERT INTO mahda_profiles(owner_id,slug,name,kind,profile_data_json) VALUES(?,?,?,'personal',?)")
                    ->execute([$userId, $slug, $displayName, '{}']);
                $profileId = (int)$db->lastInsertId();
            }
            $db->commit();

            $lockDir = dirname($lockFile);
            if ((!is_dir($lockDir) && !@mkdir($lockDir, 0750, true)) || @file_put_contents($lockFile, date('c') . "\n", LOCK_EX) === false) {
                // The account is already repaired; not being able to create
                // the marker must not roll back a successful credential reset.
                $errorMessage = 'حساب مدیر ساخته شد، اما قفل بازیابی ایجاد نشد. مسیر خصوصی سرور را بررسی کنید و ابزار بازیابی را غیرفعال کنید.';
            }

            mahda_start_session();
            session_regenerate_id(true);
            $_SESSION['user_id'] = $userId;
            $_SESSION['profile_id'] = $profileId;
            $_SESSION['display_name'] = $displayName;
            $_SESSION['role'] = 'admin';
            $_SESSION['guest'] = false;
            unset($_SESSION['phone']);
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            header('Location: /admin', true, 303);
            exit;
        } catch (Throwable $error) {
            if (isset($db) && $db instanceof PDO && $db->inTransaction()) { $db->rollBack(); }
            $errorMessage = 'بازیابی انجام نشد. اتصال دیتابیس یا ساختار حساب را بررسی کنید.';
        }
    }
}
?><!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>بازیابی مدیر مهدا</title>
<style>@font-face{font-family:v;src:url('/assets/vazirmatn-arabic-wght-normal-Cafbb7Zc.woff2')}*{box-sizing:border-box}body{font-family:v,Tahoma,sans-serif;background:#f3f7ef;color:#283529;min-height:100vh;display:grid;place-items:center;margin:0;padding:18px}.box{width:min(100%,500px);background:#fff;border:1px solid #dce7d6;border-radius:24px;padding:26px;box-shadow:0 20px 60px #38523518}h1{margin:0 0 8px;font-size:23px}p{line-height:1.9;color:#6c786b;font-size:13px}.warn{background:#fff5df;border:1px solid #ecd39c;color:#71561c;border-radius:13px;padding:11px 13px;margin:14px 0;font-size:13px;line-height:1.8}.err{background:#fff0ee;border-color:#efc8c2;color:#91362e}label{display:block;font-size:13px;font-weight:700;margin:13px 2px 6px}input{width:100%;border:1px solid #d4dfce;border-radius:13px;padding:12px 13px;font:inherit}button{width:100%;margin-top:18px;border:0;border-radius:14px;background:#526e4d;color:#fff;padding:13px;font:inherit;font-weight:800;cursor:pointer}a{color:#526e4d;text-decoration:none;font-size:13px}</style></head><body><main class="box">
<h1>بازیابی یک‌باره مدیر</h1>
<?php if (!$configured): ?>
<div class="warn">بازیابی مدیر روی این سرور فعال نشده است. مدیر سرور باید یک کلید امن در MAHDA_ADMIN_RECOVERY_KEY یا admin_recovery_key در تنظیمات خصوصی تعیین کند.</div><a href="/admin">بازگشت به ورود مدیریت</a>
<?php elseif ($locked): ?>
<div class="warn">این ابزار قبلاً استفاده شده و اکنون قفل است.</div><a href="/admin">رفتن به ورود مدیریت</a>
<?php elseif (!$authorized): ?>
<div class="warn">کلید بازیابی معتبر نیست یا ارسال نشده است.</div><a href="/admin">بازگشت به ورود مدیریت</a>
<?php else: ?>
<p>می‌توانید یک حساب جدید مدیر بسازید یا اگر این ایمیل از قبل وجود دارد، همان حساب را به مدیر ارتقا دهید و رمز آن را بازنشانی کنید. بعد از موفقیت، این صفحه خودکار قفل می‌شود.</p>
<?php if ($errorMessage !== ''): ?><div class="warn err"><?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<form method="post" autocomplete="off"><input type="hidden" name="key" value="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>">
<label>ایمیل مدیر</label><input type="email" name="email" required autocomplete="username">
<label>نام نمایشی</label><input type="text" name="display_name" value="مدیر مهدا" required maxlength="120">
<label>رمز جدید (حداقل ۱۲ نویسه)</label><input type="password" name="password" required minlength="12" maxlength="72" autocomplete="new-password">
<button type="submit">ساخت / بازیابی حساب مدیر</button></form>
<?php endif; ?>
</main></body></html>
