<?php
declare(strict_types=1);

namespace Mahda\Support;

final class PageResult
{
    /** @param list<array<string, mixed>> $items */
    public function __construct(
        public readonly array $items,
        public readonly int $page,
        public readonly int $perPage,
        public readonly int $total,
    ) {
    }

    public function hasMore(): bool
    {
        return $this->page * $this->perPage < $this->total;
    }
}

