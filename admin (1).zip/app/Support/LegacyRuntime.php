<?php
declare(strict_types=1);

namespace Mahda\Support;

use PDO;

final class LegacyRuntime
{
    private function __construct() {}

    public static function bootstrap(): PDO
    {
        require_once dirname(__DIR__, 2) . '/mahda-api/bootstrap.php';
        $db = \mahda_db();
        \mahda_seed_taxonomy($db);
        \mahda_migrate_social($db);
        \mahda_migrate_auth($db);
        \mahda_migrate_admin($db);
        \mahda_migrate_stage7($db);
        \mahda_migrate_creator_studio($db);
        \mahda_migrate_admin_stage14($db);
        \mahda_migrate_admin_stage23($db);
        \mahda_migrate_public_atlas($db);
        \mahda_migrate_atlas_location_v11($db);
        \mahda_migrate_content_registration_v12($db);
        \mahda_migrate_profile_media_v13($db);
        return $db;
    }
}
