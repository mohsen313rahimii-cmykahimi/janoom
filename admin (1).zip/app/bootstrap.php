<?php
declare(strict_types=1);

require_once __DIR__ . '/Core/Autoloader.php';

\Mahda\Core\Autoloader::register(__DIR__);

$config = \Mahda\Core\Config::fromFile(dirname(__DIR__) . '/config/app.php');
date_default_timezone_set((string)($config['timezone'] ?? 'Asia/Tehran'));

$request = new \Mahda\Core\Request($_SERVER);
$response = new \Mahda\Core\Response();
$router = new \Mahda\Core\Router();
$view = new \Mahda\Core\View((string)$config['view_path']);

$registerRoutes = require dirname(__DIR__) . '/config/routes.php';
if (!is_callable($registerRoutes)) {
    throw new \RuntimeException('Route registrar is invalid.');
}
$registerRoutes($router, $view);

return new \Mahda\Core\App($request, $response, $router);

