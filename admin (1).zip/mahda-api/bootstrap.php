<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/app/Core/Autoloader.php';
\Mahda\Core\Autoloader::register(dirname(__DIR__) . '/app');
require_once dirname(__DIR__) . '/app/Modules/Mobile/migrations.php';
require_once dirname(__DIR__) . '/app/Modules/OfflineSync/migrations.php';
require_once dirname(__DIR__) . '/app/Modules/OfflineSync/support.php';

function mahda_private_path(): string
{
    $configuredPath = getenv('MAHDA_PRIVATE_PATH');
    if ($configuredPath !== false && trim((string)$configuredPath) !== '') {
        return rtrim((string)$configuredPath, '/\\');
    }
    $configuredConfig = getenv('MAHDA_PRIVATE_CONFIG');
    if ($configuredConfig !== false && trim((string)$configuredConfig) !== '') {
        return dirname((string)$configuredConfig);
    }
    // Keep secrets and private uploads outside the public project root by default.
    return dirname(__DIR__, 2) . '/.mahda-private';
}

/**
 * Legacy public uploads are kept only for backward compatibility. New media is
 * stored under .mahda-private/uploads and served through the authenticated API.
 */
function mahda_public_upload_path(): string
{
    return dirname(__DIR__) . '/uploads';
}

function mahda_storage_config(): array
{
    static $config;
    if (is_array($config ?? null)) return $config;
    $path = dirname(__DIR__) . '/config/storage.php';
    $config = is_file($path) ? require $path : ['driver'=>'local'];
    if (!is_array($config)) $config = ['driver'=>'local'];
    try {
        $private = mahda_config();
        if (isset($private['storage']) && is_array($private['storage'])) {
            $config = array_replace($config, $private['storage']);
        }
    } catch (Throwable $ignored) {}
    return $config;
}

function mahda_storage_adapter(): \Mahda\Core\Storage\StorageInterface
{
    static $storage;
    if ($storage instanceof \Mahda\Core\Storage\StorageInterface) return $storage;
    $storage = \Mahda\Core\Storage\StorageFactory::make(
        mahda_storage_config(),
        mahda_private_path() . '/uploads',
        [mahda_public_upload_path()]
    );
    return $storage;
}

function mahda_existing_upload_path(string $storageKey): ?string
{
    return mahda_storage_adapter()->path($storageKey);
}

function mahda_media_config(): array
{
    static $config;
    if (is_array($config ?? null)) return $config;
    $path = dirname(__DIR__) . '/config/media.php';
    $config = is_file($path) ? require $path : [];
    return is_array($config) ? $config : [];
}

function mahda_config(): array
{
    static $config;
    if (is_array($config ?? null)) {
        return $config;
    }
    $configuredPath = getenv('MAHDA_PRIVATE_CONFIG');
    $path = $configuredPath !== false && trim((string)$configuredPath) !== ''
        ? (string)$configuredPath
        : mahda_private_path() . '/config.php';
    if (!is_file($path)) {
        throw new RuntimeException('not_installed');
    }
    $config = require $path;
    if (!is_array($config) || !isset($config['dsn'], $config['user'], $config['password'])) {
        throw new RuntimeException('invalid_config');
    }
    return $config;
}

/**
 * Phone test authentication is opt-in and must use a server-side secret code.
 * It is never enabled by default. Production phone login remains closed until
 * a real SMS/OTP provider is integrated.
 */

function mahda_admin_recovery_key(): string
{
    $raw = getenv('MAHDA_ADMIN_RECOVERY_KEY');
    if ($raw === false) {
        try {
            $config = mahda_config();
        } catch (RuntimeException $error) {
            return '';
        }
        $raw = (string)($config['admin_recovery_key'] ?? '');
    }
    $key = trim((string)$raw);
    // Recovery is intentionally fail-closed. Require enough entropy to avoid
    // accidentally enabling it with a short, guessable value.
    return strlen($key) >= 32 ? $key : '';
}

function mahda_test_phone_auth_enabled(): bool
{
    $env = getenv('MAHDA_TEST_PHONE_AUTH');
    if ($env !== false) {
        return in_array(strtolower(trim((string)$env)), ['1', 'true', 'yes', 'on'], true);
    }
    $config = mahda_config();
    return array_key_exists('test_phone_auth', $config) ? (bool)$config['test_phone_auth'] : false;
}

function mahda_test_phone_auth_code(): string
{
    $raw = getenv('MAHDA_TEST_PHONE_AUTH_CODE');
    if ($raw === false) {
        $config = mahda_config();
        $raw = (string)($config['test_phone_auth_code'] ?? '');
    }
    $code = preg_replace('/\D+/', '', (string)$raw);
    return is_string($code) && preg_match('/^\d{6,12}$/', $code) ? $code : '';
}

function mahda_phone_auth_mode(): string
{
    return mahda_test_phone_auth_enabled() && mahda_test_phone_auth_code() !== '' ? 'test' : 'disabled';
}

function mahda_db(): PDO
{
    static $db;
    if ($db instanceof PDO) {
        return $db;
    }
    $config = mahda_config();
    $db = new PDO($config['dsn'], $config['user'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    return $db;
}

function mahda_json(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function mahda_request_data(): array
{
    $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > 12 * 1024 * 1024) {
        mahda_json(['error' => 'payload_too_large'], 413);
    }
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        mahda_json(['error' => 'invalid_json'], 400);
    }
    return $decoded;
}

function mahda_request_is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    $forwarded = strtolower(trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0] ?? ''));
    if ($forwarded === 'https') {
        return true;
    }
    return strtolower((string)($_SERVER['HTTP_X_FORWARDED_SSL'] ?? '')) === 'on';
}

function mahda_start_session(): void
{
    (new \Mahda\Core\Session())->start();
}

/**
 * Return an ephemeral guest identity.  Guests deliberately have no database
 * row, profile, or display name: public requests can carry a CSRF token, but
 * they can never accidentally become a fake "مربی مهمان" account.
 */
function mahda_guest(?PDO $db = null): array
{
    mahda_start_session();
    unset($_SESSION['user_id'], $_SESSION['profile_id'], $_SESSION['phone'], $_SESSION['display_name'], $_SESSION['role']);
    $_SESSION['guest'] = true;
    $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
    return [
        'id' => 0,
        'profile_id' => 0,
        'phone' => '',
        'display_name' => '',
        'role' => 'guest',
        'guest' => true,
        'profile_kind' => null,
        'profile_name' => '',
        'profile_data' => [],
        'profile_complete' => false,
    ];
}

/**
 * Return the current session user. Guest state is session-only and never
 * creates a database record. Private actions must call mahda_require_member().
 */
function mahda_current_user(PDO $db, bool $allowGuest = true): array
{
    mahda_start_session();
    if (isset($_SESSION['user_id'], $_SESSION['profile_id'])
        && (int)$_SESSION['user_id'] > 0
        && (int)$_SESSION['profile_id'] > 0
        && empty($_SESSION['guest'])) {
        // A database reset, account deletion or an expired migration may
        // leave an old PHP session cookie on the browser. Validate both
        // identifiers before treating that cookie as a real account; stale
        // sessions become guests instead of pointing at a deleted user.
        $valid = $db->prepare('SELECT u.id,p.id AS profile_id,u.role,u.display_name FROM mahda_users u JOIN mahda_profiles p ON p.id=? AND p.owner_id=u.id WHERE u.id=? AND u.is_active=1 LIMIT 1');
        $valid->execute([(int)$_SESSION['profile_id'], (int)$_SESSION['user_id']]);
        $validUser = $valid->fetch();
        if ($validUser) {
            $_SESSION['role'] = (string)$validUser['role'];
            $_SESSION['display_name'] = (string)$validUser['display_name'];
            return [
                'id' => (int)$_SESSION['user_id'],
                'profile_id' => (int)$_SESSION['profile_id'],
                'phone' => (string)($_SESSION['phone'] ?? ''),
                'display_name' => (string)$validUser['display_name'],
                'role' => (string)$validUser['role'],
                'guest' => false,
            ];
        }
        unset($_SESSION['user_id'], $_SESSION['profile_id'], $_SESSION['phone'], $_SESSION['display_name'], $_SESSION['role'], $_SESSION['guest']);
    }
    // Clear legacy guest-session fields from releases that persisted a fake
    // profile.  This does not delete any real user or content row.
    if (!empty($_SESSION['guest'])) {
        unset($_SESSION['user_id'], $_SESSION['profile_id'], $_SESSION['phone'], $_SESSION['display_name'], $_SESSION['role']);
    }
    if (!$allowGuest) {
        mahda_json(['error' => 'auth_required'], 401);
    }
    return mahda_guest();
}

function mahda_require_member(PDO $db): array
{
    $user = mahda_current_user($db, false);
    if (!empty($user['guest'])) {
        mahda_json(['error' => 'auth_required'], 401);
    }
    return $user;
}

/**
 * Staff-only guard for the private management surface. The browser may hide
 * the route from regular members, but every management API must enforce the
 * role again on the server.
 */
function mahda_require_staff(PDO $db): array
{
    $user = mahda_require_member($db);
    // Read the role again from the database so a promotion or revocation is
    // effective immediately, even when the browser still has an older PHP
    // session cookie.
    $roleStmt = $db->prepare('SELECT role FROM mahda_users WHERE id=? AND is_active=1 LIMIT 1');
    $roleStmt->execute([(int)$user['id']]);
    $role = (string)($roleStmt->fetchColumn() ?: '');
    if (!in_array($role, ['admin', 'reviewer'], true)) {
        mahda_json(['error' => 'admin_required'], 403);
    }
    $user['role'] = $role;
    $_SESSION['role'] = $role;
    return $user;
}


function mahda_require_admin(PDO $db): array
{
    $user = mahda_require_staff($db);
    if ((string)$user['role'] !== 'admin') {
        mahda_json(['error' => 'admin_only'], 403);
    }
    return $user;
}

function mahda_csrf(): string
{
    mahda_start_session();
    $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
    return (string)$_SESSION['csrf'];
}

function mahda_require_csrf(array $data = []): void
{
    // X-CSRF-Token is the canonical contract. `_csrf` is kept for older
    // clients and `csrf` is accepted temporarily so cached pre-cleanup pages
    // can recover instead of making login look broken.
    $provided = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($data['_csrf'] ?? ($data['csrf'] ?? '')));
    mahda_start_session();
    $current = (string)($_SESSION['csrf'] ?? '');
    if ($provided === '' || $current === '' || !hash_equals($current, $provided)) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        mahda_json(['error' => 'csrf_failed', 'csrf' => $_SESSION['csrf']], 419);
    }
}

function mahda_string(mixed $value, int $max = 190): string
{
    $value = trim(is_string($value) ? $value : (string)$value);
    $length = function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
    if ($length > $max) {
        return function_exists('mb_substr') ? mb_substr($value, 0, $max, 'UTF-8') : substr($value, 0, $max);
    }
    return $value;
}

function mahda_normalize_phone(mixed $value): string
{
    $raw = mahda_persian_digits((string)$value);
    $phone = preg_replace('/\D+/', '', $raw) ?? '';
    if (str_starts_with($phone, '0098')) { $phone = substr($phone, 2); }
    if (str_starts_with($phone, '0')) { $phone = '98' . substr($phone, 1); }
    if (!str_starts_with($phone, '98') && strlen($phone) === 10) { $phone = '98' . $phone; }
    return $phone;
}

function mahda_migrate_auth(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=4 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) {
        return;
    }
    $column = $db->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='mahda_profiles' AND COLUMN_NAME='profile_data_json'");
    $column->execute();
    if ((int)$column->fetchColumn() === 0) {
        $db->exec('ALTER TABLE mahda_profiles ADD COLUMN profile_data_json LONGTEXT NULL AFTER city');
    }
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(4)')->execute();
}

function mahda_table_exists(PDO $db, string $table): bool
{
    $stmt = $db->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');
    $stmt->execute([$table]);
    return (int)$stmt->fetchColumn() === 1;
}

function mahda_column_exists(PDO $db, string $table, string $column): bool
{
    $stmt = $db->prepare('SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?');
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() === 1;
}

function mahda_setting(PDO $db, string $key, ?string $default = null): ?string
{
    if (!mahda_table_exists($db, 'mahda_settings')) {
        return $default;
    }
    $stmt = $db->prepare('SELECT setting_value FROM mahda_settings WHERE setting_key=? LIMIT 1');
    $stmt->execute([$key]);
    $value = $stmt->fetchColumn();
    return $value === false ? $default : (string)$value;
}

function mahda_setting_bool(PDO $db, string $key, bool $default = false): bool
{
    $fallback = $default ? '1' : '0';
    $value = strtolower(trim((string)mahda_setting($db, $key, $fallback)));
    return in_array($value, ['1','true','yes','on'], true);
}

/**
 * Management schema used by review history, audit trail and lightweight
 * runtime settings.  It is additive only: no existing content or account
 * table is rebuilt or dropped.
 */
function mahda_migrate_admin(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=5 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) {
        return;
    }
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_review_actions (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        content_id BIGINT UNSIGNED NOT NULL,
        reviewer_id BIGINT UNSIGNED NOT NULL,
        action VARCHAR(32) NOT NULL,
        previous_status VARCHAR(32) NOT NULL,
        new_status VARCHAR(32) NOT NULL,
        note TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY ix_review_content(content_id,created_at),
        KEY ix_review_reviewer(reviewer_id,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_audit_log (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        actor_id BIGINT UNSIGNED NULL,
        action VARCHAR(80) NOT NULL,
        entity_type VARCHAR(40) NOT NULL,
        entity_id BIGINT UNSIGNED NULL,
        meta_json LONGTEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY ix_audit_actor(actor_id,created_at),
        KEY ix_audit_entity(entity_type,entity_id,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value LONGTEXT NULL,
        updated_by BIGINT UNSIGNED NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    // Some older install bundles already shipped a minimal audit table. Add
    // only the management columns that are missing instead of replacing it.
    if (!mahda_column_exists($db, 'mahda_audit_log', 'entity_type')) {
        $db->exec("ALTER TABLE mahda_audit_log ADD COLUMN entity_type VARCHAR(40) NOT NULL DEFAULT 'unknown' AFTER action");
    }
    if (!mahda_column_exists($db, 'mahda_audit_log', 'meta_json')) {
        $db->exec('ALTER TABLE mahda_audit_log ADD COLUMN meta_json LONGTEXT NULL');
    }
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_media_jobs (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        file_id BIGINT UNSIGNED NOT NULL,
        job_type VARCHAR(32) NOT NULL,
        status VARCHAR(24) NOT NULL DEFAULT 'pending',
        attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
        error_message VARCHAR(255) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        started_at DATETIME NULL,
        finished_at DATETIME NULL,
        UNIQUE KEY ux_media_job_file_type(file_id,job_type),
        KEY ix_media_job_status(status,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $seed = $db->prepare('INSERT IGNORE INTO mahda_settings(setting_key,setting_value) VALUES(?,?)');
    foreach ([
        ['review_required','1'],
        ['show_unapproved_in_showcase','1'],
        ['site_title','مهدا'],
        ['admin_notice',''],
        ['support_email',''],
    ] as [$key,$value]) {
        $seed->execute([$key,$value]);
    }
    // Older releases told the user that a newly registered showcase item had
    // been sent to the review desk, but stored it as not_requested. Migrate
    // those already-published showcase rows into the real pending queue.
    $db->exec("UPDATE mahda_contents SET review_status='pending' WHERE review_status='not_requested' AND visibility='showcase'");
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(5)')->execute();
}

function mahda_audit(PDO $db, int $actorId, string $action, string $entityType, ?int $entityId = null, array $meta = []): void
{
    if (!mahda_table_exists($db, 'mahda_audit_log')) {
        return;
    }
    $db->prepare('INSERT INTO mahda_audit_log(actor_id,action,entity_type,entity_id,meta_json) VALUES(?,?,?,?,?)')
        ->execute([
            $actorId > 0 ? $actorId : null,
            mahda_string($action, 80),
            mahda_string($entityType, 40),
            $entityId,
            $meta ? json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
        ]);
}

function mahda_profile_data(PDO $db, int $profileId): array
{
    $stmt = $db->prepare('SELECT profile_data_json FROM mahda_profiles WHERE id=? LIMIT 1');
    $stmt->execute([$profileId]);
    $raw = $stmt->fetchColumn();
    $data = is_string($raw) ? json_decode($raw, true) : null;
    return is_array($data) ? $data : [];
}


/** Remove legacy image blobs from every API-facing profile_data payload. */
function mahda_profile_public_data(array $data): array
{
    unset($data['avatarDataUrl'], $data['heiatLogoDataUrl']);
    return $data;
}

/**
 * Decode the preferred legacy image for a profile. Heiat logos have priority
 * for heiat profiles; personal avatars have priority everywhere else.
 */
function mahda_profile_legacy_image_payload(?string $rawJson, string $kind = 'personal'): ?array
{
    if (!is_string($rawJson) || trim($rawJson) === '') return null;
    $data = json_decode($rawJson, true);
    if (!is_array($data)) return null;
    $candidates = $kind === 'heiat'
        ? [['heiatLogoDataUrl','logo'], ['avatarDataUrl','avatar']]
        : [['avatarDataUrl','avatar'], ['heiatLogoDataUrl','logo']];
    foreach ($candidates as [$field, $purpose]) {
        $candidate = $data[$field] ?? null;
        if (!is_string($candidate) || $candidate === '') continue;
        if (preg_match('#^data:(image/(?:jpeg|jpg|png|webp));base64,(.+)$#is', $candidate, $m) !== 1) continue;
        $bytes = base64_decode(preg_replace('/\s+/', '', $m[2]), true);
        if (!is_string($bytes) || $bytes === '' || strlen($bytes) > 6 * 1024 * 1024) continue;
        $declaredMime = strtolower($m[1]) === 'image/jpg' ? 'image/jpeg' : strtolower($m[1]);
        return [
            'sourceField' => $field,
            'purpose' => $kind === 'heiat' ? 'logo' : $purpose,
            'declaredMime' => $declaredMime,
            'bytes' => $bytes,
            'dataUrl' => $candidate,
        ];
    }
    return null;
}

/** Resolve the user's legacy uploaded profile image without exposing it in JSON. */
function mahda_profile_avatar_data(?string $rawJson, string $kind = 'personal'): ?string
{
    $payload = mahda_profile_legacy_image_payload($rawJson, $kind);
    return is_array($payload) ? (string)$payload['dataUrl'] : null;
}

function mahda_profile_avatar_url(int $profileId, ?string $rawJson, string $kind = 'personal'): string
{
    if ($profileId < 1) return '';
    $dataUrl = mahda_profile_avatar_data($rawJson, $kind);
    if ($dataUrl === null) return '';
    $version = substr(hash('sha256', $dataUrl), 0, 12);
    return '/mahda-api/index.php?action=profile_avatar&id=' . $profileId . '&v=' . $version;
}

/**
 * Stage 13 created the profile media table. Legacy releases may still contain
 * base64 images in profile_data_json; those are converted lazily and safely on
 * first use. The JSON blob is removed only after the file and DB row are both
 * committed, so an unavailable disk can never make an old avatar disappear.
 */
function mahda_migrate_profile_media_v13(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=13 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) return;
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_profile_media (
        profile_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
        owner_id BIGINT UNSIGNED NOT NULL,
        purpose VARCHAR(20) NOT NULL DEFAULT 'avatar',
        storage_key VARCHAR(255) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        mime_type VARCHAR(100) NOT NULL,
        size_bytes BIGINT UNSIGNED NOT NULL,
        width INT UNSIGNED NULL,
        height INT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY ix_profile_media_owner(owner_id,profile_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(13)')->execute();
}

function mahda_profile_media_row(PDO $db, int $profileId): ?array
{
    if ($profileId < 1 || !mahda_table_exists($db, 'mahda_profile_media')) return null;
    $stmt = $db->prepare('SELECT profile_id,owner_id,purpose,storage_key,original_name,mime_type,size_bytes,width,height,updated_at FROM mahda_profile_media WHERE profile_id=? LIMIT 1');
    $stmt->execute([$profileId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** Best-effort lazy conversion of a legacy base64 avatar/logo to real storage. */
function mahda_profile_media_migrate_legacy(PDO $db, int $profileId, ?string $rawJson, string $kind = 'personal'): bool
{
    static $attempted = [];
    if ($profileId < 1 || isset($attempted[$profileId])) return false;
    $attempted[$profileId] = true;
    if (mahda_profile_media_row($db, $profileId)) return true;
    $payload = mahda_profile_legacy_image_payload($rawJson, $kind);
    if (!$payload) return false;

    $ownerStmt = $db->prepare('SELECT owner_id,kind,profile_data_json FROM mahda_profiles WHERE id=? LIMIT 1');
    $ownerStmt->execute([$profileId]);
    $profile = $ownerStmt->fetch();
    if (!$profile) return false;
    $currentRaw = (string)($profile['profile_data_json'] ?? '');
    // Do not migrate stale JSON captured before another request updated it.
    if ($currentRaw !== (string)$rawJson) {
        $payload = mahda_profile_legacy_image_payload($currentRaw, (string)($profile['kind'] ?? $kind));
        if (!$payload) return false;
        $rawJson = $currentRaw;
        $kind = (string)($profile['kind'] ?? $kind);
    }

    $dir = mahda_private_upload_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    if (!is_writable($dir)) return false;

    $tmp = $dir . '/profile-migrate-' . bin2hex(random_bytes(18)) . '.tmp';
    if (@file_put_contents($tmp, (string)$payload['bytes'], LOCK_EX) === false || !is_file($tmp)) { @unlink($tmp); return false; }
    @chmod($tmp, 0640);
    $mime = '';
    if (function_exists('finfo_open')) {
        $f = finfo_open(FILEINFO_MIME_TYPE);
        if ($f) { $mime = strtolower((string)finfo_file($f, $tmp)); finfo_close($f); }
    }
    if ($mime === 'image/jpg') $mime = 'image/jpeg';
    $extMap = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if (!isset($extMap[$mime])) { @unlink($tmp); return false; }
    [$width,$height] = mahda_image_size_safe($tmp);
    if (!$width || !$height) { @unlink($tmp); return false; }

    $key = 'profile-' . bin2hex(random_bytes(24)) . '.' . $extMap[$mime];
    $full = $dir . '/' . $key;
    if (!@rename($tmp, $full)) { @unlink($tmp); return false; }
    @chmod($full, 0640);
    mahda_optimize_image_file_v12($full, $mime, 'profile_avatar');
    [$width,$height] = mahda_image_size_safe($full);
    $size = is_file($full) ? (int)filesize($full) : 0;
    if ($size < 1 || !$width || !$height) { @unlink($full); return false; }

    $json = json_decode((string)$rawJson, true);
    if (!is_array($json)) { @unlink($full); return false; }
    $json = mahda_profile_public_data($json);
    $purpose = $kind === 'heiat' ? 'logo' : 'avatar';
    $original = $purpose === 'logo' ? 'legacy-heiat-logo.' . $extMap[$mime] : 'legacy-avatar.' . $extMap[$mime];

    $storage = mahda_storage_adapter();
    try { $storage->putFile($key, $full); }
    catch (Throwable $e) { @unlink($full); return false; }

    try {
        $db->beginTransaction();
        $insert = $db->prepare('INSERT IGNORE INTO mahda_profile_media(profile_id,owner_id,purpose,storage_key,original_name,mime_type,size_bytes,width,height) VALUES(?,?,?,?,?,?,?,?,?)');
        $insert->execute([$profileId,(int)$profile['owner_id'],$purpose,$key,$original,$mime,$size,$width,$height]);
        if ($insert->rowCount() < 1) {
            // A concurrent real upload won the race. Keep that file, discard ours,
            // and only remove the obsolete JSON blob if a media row now exists.
            if (!mahda_profile_media_row($db, $profileId)) { $db->rollBack(); $storage->delete($key); return false; }
            $clean = $db->prepare('UPDATE mahda_profiles SET profile_data_json=? WHERE id=? AND profile_data_json=?');
            $clean->execute([json_encode($json, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$profileId,(string)$rawJson]);
            $db->commit();
            $storage->delete($key);
            return true;
        }
        $clean = $db->prepare('UPDATE mahda_profiles SET profile_data_json=? WHERE id=? AND profile_data_json=?');
        $clean->execute([json_encode($json, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$profileId,(string)$rawJson]);
        if ($clean->rowCount() !== 1) {
            $db->rollBack();
            $storage->delete($key);
            return false;
        }
        $db->commit();
        return true;
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $storage->delete($key);
        return false;
    }
}

function mahda_profile_avatar_url_db(PDO $db, int $profileId, ?string $rawJson, string $kind = 'personal'): string
{
    if ($profileId < 1) return '';
    $media = mahda_profile_media_row($db, $profileId);
    if (!$media && mahda_profile_avatar_data($rawJson, $kind) !== null) {
        mahda_profile_media_migrate_legacy($db, $profileId, $rawJson, $kind);
        $media = mahda_profile_media_row($db, $profileId);
    }
    if ($media) {
        $version = substr(hash('sha256', (string)$media['storage_key'] . '|' . (string)$media['updated_at']), 0, 12);
        return '/mahda-api/index.php?action=profile_avatar&id=' . $profileId . '&v=' . $version;
    }
    return mahda_profile_avatar_url($profileId, $rawJson, $kind);
}

function mahda_profile_badges_public(PDO $db, int $profileId): array
{
    if ($profileId < 1 || !mahda_table_exists($db, 'mahda_profile_badges') || !mahda_table_exists($db, 'mahda_badges')) return [];
    $stmt = $db->prepare("SELECT b.id,b.title,b.slug,b.icon,b.color FROM mahda_profile_badges pb JOIN mahda_badges b ON b.id=pb.badge_id WHERE pb.profile_id=? AND b.is_active=1 ORDER BY b.sort_order,b.id LIMIT 12");
    $stmt->execute([$profileId]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $items[] = [
            'id' => (int)$row['id'],
            'title' => (string)$row['title'],
            'slug' => (string)$row['slug'],
            'icon' => (string)($row['icon'] ?? ''),
            'color' => (string)($row['color'] ?? '#2f9a48'),
        ];
    }
    return $items;
}

/**
 * SQL predicate for content that may be attributed to its stored profile.
 * Anonymous publications remain public in the feed/bank, but must never be
 * exposed through a profile showcase or a public profile content counter.
 */
function mahda_attributed_content_sql(string $alias = 'c'): string
{
    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $alias)) {
        throw new InvalidArgumentException('invalid_sql_alias');
    }
    return "({$alias}.extra_fields_json IS NULL OR {$alias}.extra_fields_json NOT REGEXP '\"publisherType\"[[:space:]]*:[[:space:]]*\"anonymous\"')";
}

function mahda_has_values(mixed $value): bool
{
    if (is_string($value)) return trim($value) !== '';
    if (is_array($value)) return count(array_filter($value, static fn($item) => is_string($item) ? trim($item) !== '' : $item !== null)) > 0;
    return $value !== null && $value !== false;
}

function mahda_profile_complete(array $data, string $kind, string $displayName, string $profileName, string $city): bool
{
    $legacyProfileRole = (string)($data['profileRole'] ?? '');
    $primary = (string)($data['primaryRole'] ?? '');
    if ($primary === '') {
        if ($kind === 'heiat' || $legacyProfileRole === 'heiat') $primary = 'heiat';
        elseif ($legacyProfileRole === 'mentor') $primary = 'mentor';
        else $primary = 'other';
    }
    $identityReady = mahda_has_values($displayName) && mahda_has_values($profileName) && mahda_has_values($city);
    if ($primary === 'mentor') {
        return $identityReady
            && mahda_has_values($data['firstName'] ?? null) && mahda_has_values($data['lastName'] ?? null)
            && mahda_has_values($data['specialties'] ?? null) && mahda_has_values($data['ages'] ?? null);
    }
    if ($primary === 'heiat' || $kind === 'heiat') {
        return $identityReady && mahda_has_values($data['heiatName'] ?? $profileName)
            && mahda_has_values($data['ages'] ?? null);
    }
    $otherRole = (string)($data['role'] ?? '');
    if ($otherRole === '') {
        if ($legacyProfileRole === 'family') $otherRole = 'family';
        elseif ($legacyProfileRole === 'khadem') $otherRole = 'cultural_servant';
    }
    return $identityReady && $primary === 'other'
        && in_array($otherRole, ['family', 'cultural_servant'], true);
}

/**
 * Account-owned content and social mutations require the role onboarding to
 * be complete as well as the session to be authenticated.  profile_update
 * intentionally uses mahda_require_member() so an interrupted registration
 * can still be resumed and saved.
 */
function mahda_require_complete_member(PDO $db): array
{
    $user = mahda_require_member($db);
    $stmt = $db->prepare('SELECT kind,name,city,profile_data_json FROM mahda_profiles WHERE id=? AND owner_id=? LIMIT 1');
    $stmt->execute([(int)$user['profile_id'], (int)$user['id']]);
    $profile = $stmt->fetch();
    if (!$profile) {
        mahda_json(['error' => 'profile_incomplete'], 403);
    }
    $data = is_array(json_decode((string)($profile['profile_data_json'] ?? ''), true)) ? json_decode((string)($profile['profile_data_json'] ?? ''), true) : [];
    $complete = mahda_profile_complete($data, (string)$profile['kind'], (string)$user['display_name'], (string)$profile['name'], (string)($profile['city'] ?? ''));
    if (!$complete) {
        mahda_json(['error' => 'profile_incomplete'], 403);
    }
    return $user;
}

function mahda_user_payload(PDO $db, array $row, ?int $profileId = null): array
{
    $resolvedProfileId = $profileId ?? (int)($row['profile_id'] ?? 0);
    $profileData = $resolvedProfileId > 0 ? mahda_profile_data($db, $resolvedProfileId) : [];
    $publicProfileData = mahda_profile_public_data($profileData);
    $kind = (string)($row['profile_kind'] ?? 'personal');
    $profileName = (string)($row['profile_name'] ?? '');
    $displayName = (string)($row['display_name'] ?? '');
    return [
        'id' => (int)$row['id'],
        'profile_id' => $resolvedProfileId,
        'phone' => isset($row['phone']) ? (string)$row['phone'] : '',
        'display_name' => $displayName,
        'role' => (string)($row['role'] ?? 'member'),
        'guest' => !empty($row['guest']),
        'profile_kind' => $kind,
        'profile_name' => $profileName,
        'profile_data' => $publicProfileData,
        'avatar_url' => mahda_profile_avatar_url_db($db, $resolvedProfileId, $profileData ? json_encode($profileData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '', $kind),
        'profile_complete' => mahda_profile_complete($profileData, $kind, $displayName, $profileName, (string)($row['city'] ?? '')),
        'created_at' => isset($row['created_at']) ? (string)$row['created_at'] : null,
    ];
}

function mahda_seed_taxonomy(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=2 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) {
        return;
    }
    $goals = [
        ['همکاری و کار گروهی', 'تقویت روحیه تعاون، مشارکت و دستیابی به هدف مشترک', ['همکاری','تعاون','همیاری','مشارکت','کار تیمی','کار گروهی','همراهی','همدلی']],
        ['راستگویی و صداقت', 'ترویج گفتار و رفتار صادقانه و پرهیز از فریب', ['راستگویی','راستی','صداقت','دروغ نگفتن','یکرنگی','درستکاری','امانت‌داری','امانت داری']],
        ['محبت و مهرورزی', 'رشد احساس مهربانی، دلسوزی و دوست داشتن دیگران', ['مهربانی','محبت','عطوفت','مهرورزی','کمک به دیگران','دلسوزی','دوستی','همراهی']],
        ['صبر و بردباری', 'توانایی شکیبایی در برابر سختی‌ها و رعایت نوبت', ['صبر','بردباری','شکیبایی','حوصله','تحمل','عجله نکردن','آرامش']],
        ['مسئولیت‌پذیری و وظیفه‌شناسی', 'پذیرش وظایف فردی و جمعی و پاسخگویی', ['مسئولیت‌پذیری','مسئولیت پذیری','تعهد','وظیفه‌شناسی','پاسخگویی','انجام وظیفه']],
        ['خلاقیت و حل مسئله', 'پرورش ایده‌پردازی، کنجکاوی و پیدا کردن راه‌های تازه', ['خلاقیت','نوآوری','ایده‌پردازی','حل مسئله','تفکر','کنجکاوی']],
        ['احترام و ادب', 'رعایت حرمت خود، خانواده و دیگران در گفتار و رفتار', ['احترام','ادب','خوش‌رفتاری','رعایت نوبت','گوش دادن','نزاکت']],
        ['شجاعت و دلیری', 'ایستادگی در برابر ترس و دفاع از حق', ['شجاعت','دلیری','شهامت','جرأت','نترسیدن','دلاوری']],
        ['نظم و انضباط', 'سامان‌دهی کارها، وسایل و زمان', ['نظم','انضباط','ترتیب','وقت‌شناسی','مرتب بودن','تمیزی']],
        ['همدلی و گفتگو', 'شناخت احساس دیگران و بیان درست احساس خود', ['همدلی','گفتگو','شنیدن','درک احساس','ارتباط','همراهی']],
    ];
    $insertGoal = $db->prepare('INSERT IGNORE INTO mahda_goals(label,description) VALUES(?,?)');
    $findGoal = $db->prepare('SELECT id FROM mahda_goals WHERE label=? LIMIT 1');
    $insertAlias = $db->prepare('INSERT IGNORE INTO mahda_goal_aliases(goal_id,term,relation) VALUES(?,?,?)');
    foreach ($goals as [$label,$description,$aliases]) {
        $insertGoal->execute([$label,$description]);
        $findGoal->execute([$label]);
        $goalId = (int)$findGoal->fetchColumn();
        foreach (array_unique(array_merge([$label], $aliases)) as $alias) { $insertAlias->execute([$goalId,$alias,'synonym']); }
    }
    $occasions = [
        ['عمومی (قابل استفاده در تمام ایام سال)','general',['عمومی','همه سال','تمام ایام']],
        ['عید سعید غدیر خم','celebrations',['غدیر','ولایت']],['عید سعید فطر','celebrations',['فطر','رمضان']],['عید سعید قربان','celebrations',['قربان','حج']],
        ['عید سعید مبعث پیامبر اعظم(ص)','celebrations',['مبعث','پیامبر']],['نیمه شعبان و ولادت امام زمان(عج)','celebrations',['نیمه شعبان','مهدی','مهدویت']],
        ['ولادت پیامبر اکرم(ص) و امام جعفر صادق(ع)','celebrations',['هفته وحدت','پیامبر','امام صادق']],['ولادت امام علی(ع) و روز پدر','celebrations',['امام علی','امیرالمؤمنین','مولا علی','پدر','روز پدر']],
        ['ولادت حضرت فاطمه زهرا(س) و روز مادر','celebrations',['حضرت زهرا','فاطمه','مادر','روز مادر']],['ولادت امام حسن مجتبی(ع)','celebrations',['امام حسن','نیمه رمضان']],
        ['ولادت امام حسین(ع) و اعیاد شعبانیه','celebrations',['امام حسین','شعبان','حضرت عباس']],['ولادت امام رضا(ع) و دهه کرامت','celebrations',['امام رضا','مشهد','دهه کرامت']],
        ['ولادت حضرت معصومه(س) و روز دختر','celebrations',['حضرت معصومه','قم','دختر','روز دختر']],['محرم و عاشورای حسینی','mourning',['محرم','عاشورا','کربلا','امام حسین','سیدالشهدا']],
        ['اربعین حسینی','mourning',['اربعین','پیاده‌روی','امام حسین','کربلا']],['تاسوعا و شهادت حضرت عباس(ع)','mourning',['تاسوعا','حضرت عباس','ابوالفضل']],
        ['ایام فاطمیه و شهادت حضرت فاطمه زهرا(س)','mourning',['فاطمیه','حضرت زهرا','مادر']],['شهادت امام علی(ع) و شب‌های قدر','mourning',['امام علی','شب قدر','رمضان']],
        ['رحلت پیامبر(ص) و شهادت امام حسن(ع)','mourning',['رحلت پیامبر','امام حسن']],['شهادت امام رضا(ع)','mourning',['امام رضا','آخر صفر']],
        ['شهادت امام سجاد(ع)','mourning',['امام سجاد']],['شهادت امام باقر(ع)','mourning',['امام باقر']],['شهادت امام صادق(ع)','mourning',['امام صادق']],
        ['شهادت امام کاظم(ع)','mourning',['امام کاظم']],['شهادت امام جواد(ع)','mourning',['امام جواد']],['شهادت امام هادی(ع)','mourning',['امام هادی']],
        ['شهادت امام حسن عسکری(ع)','mourning',['امام حسن عسکری']],['وفات حضرت معصومه(س)','mourning',['حضرت معصومه','قم']],['وفات حضرت زینب(س)','mourning',['حضرت زینب']],
        ['نوروز و آغاز بهار','national',['نوروز','بهار','سال نو']],['شب یلدا','national',['یلدا','زمستان']],['روز کودک','national',['کودک','مهر']],
        ['روز مادر','national',['مادر']],['روز پدر','national',['پدر']],['روز معلم','national',['معلم','استاد']],['روز دانش‌آموز','national',['دانش‌آموز','نوجوان']],
        ['هفته دفاع مقدس','national',['دفاع مقدس','شهدا']],['دهه فجر و پیروزی انقلاب اسلامی','national',['دهه فجر','۲۲ بهمن','انقلاب']],['روز درختکاری و روز طبیعت','national',['درختکاری','طبیعت','سیزده بدر']],
    ];
    $insertOccasion = $db->prepare('INSERT IGNORE INTO mahda_occasions(label,occasion_group,aliases_json) VALUES(?,?,?)');
    foreach ($occasions as [$label,$group,$aliases]) { $insertOccasion->execute([$label,$group,json_encode($aliases,JSON_UNESCAPED_UNICODE)]); }
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(2)')->execute();
}

/**
 * Phase 3 is deliberately self-migrating so an already installed Mahda
 * database receives the social notification table without running the
 * destructive first-install wizard again.
 */
function mahda_migrate_social(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=3 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) {
        return;
    }
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_notifications (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        recipient_user_id BIGINT UNSIGNED NOT NULL,
        actor_user_id BIGINT UNSIGNED NOT NULL,
        kind ENUM('like','comment','executed','follow') NOT NULL,
        content_id BIGINT UNSIGNED NULL,
        profile_id BIGINT UNSIGNED NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY ix_notification_inbox(recipient_user_id,is_read,created_at),
        KEY ix_notification_content(content_id),
        FOREIGN KEY(recipient_user_id) REFERENCES mahda_users(id) ON DELETE CASCADE,
        FOREIGN KEY(actor_user_id) REFERENCES mahda_users(id) ON DELETE CASCADE,
        FOREIGN KEY(content_id) REFERENCES mahda_contents(id) ON DELETE CASCADE,
        FOREIGN KEY(profile_id) REFERENCES mahda_profiles(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(3)')->execute();
}

/**
 * Stage 5-7 production hardening: extend notification kinds used by the
 * moderation workflow. The migration is additive and preserves all existing
 * notifications.
 */
function mahda_migrate_stage7(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=6 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) {
        return;
    }
    if (mahda_table_exists($db, 'mahda_notifications')) {
        $db->exec("ALTER TABLE mahda_notifications MODIFY COLUMN kind ENUM('like','comment','executed','follow','review_approved','review_revision','review_rejected') NOT NULL");
        if (!mahda_column_exists($db, 'mahda_notifications', 'meta_json')) {
            $db->exec('ALTER TABLE mahda_notifications ADD COLUMN meta_json LONGTEXT NULL AFTER profile_id');
        }
    }
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(6)')->execute();
}



/**
 * Final MVP workflow migration.
 * Distinguish "needs revision" from a hard rejection so creators can see the
 * exact moderation state and resubmit without exposing rejected content.
 */
function mahda_migrate_creator_studio(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=7 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) {
        return;
    }

    if (mahda_table_exists($db, 'mahda_contents') && mahda_column_exists($db, 'mahda_contents', 'review_status')) {
        // Older installs used an ENUM without a separate revision state. A
        // VARCHAR keeps backward compatibility while allowing future states.
        try {
            $db->exec("ALTER TABLE mahda_contents MODIFY COLUMN review_status VARCHAR(32) NOT NULL DEFAULT 'not_requested'");
        } catch (Throwable $ignored) {
            // If a host restricts ALTER privileges, keep the old type. The
            // remaining migration stays safe; setting revision may then fall
            // back to rejected in the review endpoint below.
        }

        // Recover the intent of older moderation records where both
        // "revision" and "reject" were stored as review_status='rejected'.
        try {
            $db->exec("UPDATE mahda_contents c
                JOIN (
                    SELECT ra.content_id,ra.action
                    FROM mahda_review_actions ra
                    JOIN (
                        SELECT content_id,MAX(id) AS max_id
                        FROM mahda_review_actions
                        GROUP BY content_id
                    ) latest ON latest.max_id=ra.id
                ) last_review ON last_review.content_id=c.id
                SET c.review_status='revision'
                WHERE c.review_status='rejected' AND last_review.action='revision'");
        } catch (Throwable $ignored) {
        }
    }

    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(7)')->execute();
}



/**
 * Admin stages 12-14: full content lifecycle, granular staff permissions and
 * specialist desks. The migration is additive and safe for existing installs.
 */
function mahda_migrate_admin_stage14(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=8 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) {
        return;
    }

    if (mahda_table_exists($db, 'mahda_users')) {
        if (!mahda_column_exists($db, 'mahda_users', 'admin_username')) {
            $db->exec("ALTER TABLE mahda_users ADD COLUMN admin_username VARCHAR(80) NULL AFTER email");
        }
        if (!mahda_column_exists($db, 'mahda_users', 'is_super_admin')) {
            $db->exec("ALTER TABLE mahda_users ADD COLUMN is_super_admin TINYINT(1) NOT NULL DEFAULT 0 AFTER role");
        }
        try {
            $db->exec("CREATE UNIQUE INDEX ux_mahda_users_admin_username ON mahda_users(admin_username)");
        } catch (Throwable $ignored) {
        }
        // Preserve access for admins created before granular permissions existed.
        $db->exec("UPDATE mahda_users SET is_super_admin=1 WHERE role='admin' AND is_super_admin=0");
    }

    if (mahda_table_exists($db, 'mahda_contents')) {
        if (!mahda_column_exists($db, 'mahda_contents', 'desk_id')) {
            $db->exec("ALTER TABLE mahda_contents ADD COLUMN desk_id BIGINT UNSIGNED NULL AFTER category_id");
        }
        if (!mahda_column_exists($db, 'mahda_contents', 'archived_at')) {
            $db->exec("ALTER TABLE mahda_contents ADD COLUMN archived_at DATETIME NULL");
        }
        if (!mahda_column_exists($db, 'mahda_contents', 'archived_by')) {
            $db->exec("ALTER TABLE mahda_contents ADD COLUMN archived_by BIGINT UNSIGNED NULL");
        }
        if (!mahda_column_exists($db, 'mahda_contents', 'archive_reason')) {
            $db->exec("ALTER TABLE mahda_contents ADD COLUMN archive_reason TEXT NULL");
        }
        if (!mahda_column_exists($db, 'mahda_contents', 'hidden_reason')) {
            $db->exec("ALTER TABLE mahda_contents ADD COLUMN hidden_reason TEXT NULL");
        }
        if (!mahda_column_exists($db, 'mahda_contents', 'admin_updated_at')) {
            $db->exec("ALTER TABLE mahda_contents ADD COLUMN admin_updated_at DATETIME NULL");
        }
    }

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_staff_permissions (
        user_id BIGINT UNSIGNED NOT NULL,
        permission_key VARCHAR(80) NOT NULL,
        granted_by BIGINT UNSIGNED NULL,
        granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(user_id,permission_key),
        KEY ix_staff_permission(permission_key,user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_desks (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(120) NOT NULL,
        slug VARCHAR(80) NOT NULL UNIQUE,
        description TEXT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_by BIGINT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_desk_categories (
        desk_id BIGINT UNSIGNED NOT NULL,
        category_id VARCHAR(40) NOT NULL,
        is_primary TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY(desk_id,category_id),
        KEY ix_desk_category(category_id,desk_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_desk_members (
        desk_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        can_view TINYINT(1) NOT NULL DEFAULT 1,
        can_edit TINYINT(1) NOT NULL DEFAULT 0,
        can_request_revision TINYINT(1) NOT NULL DEFAULT 1,
        can_final_approve TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(desk_id,user_id),
        KEY ix_desk_member_user(user_id,desk_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Legacy reviewers retain their previous moderation abilities. A super
    // admin can later narrow these permissions from the management UI.
    $reviewerIds = $db->query("SELECT id FROM mahda_users WHERE role='reviewer' AND is_active=1")->fetchAll(PDO::FETCH_COLUMN);
    $seedPerm = $db->prepare('INSERT IGNORE INTO mahda_staff_permissions(user_id,permission_key) VALUES(?,?)');
    foreach ($reviewerIds as $reviewerId) {
        foreach (['dashboard.view','content.view','content.edit','content.approve','content.request_revision','content.reject'] as $permission) {
            $seedPerm->execute([(int)$reviewerId,$permission]);
        }
    }

    // Useful starter desks. They can be renamed, disabled or replaced later.
    $deskSeed = $db->prepare('INSERT IGNORE INTO mahda_desks(name,slug,description,is_active) VALUES(?,?,?,1)');
    foreach ([
        ['پیشخوان بازی','game','بررسی بازی‌ها و فعالیت‌های گروهی'],
        ['پیشخوان قصه','story','بررسی قصه، داستان و محتوای روایی'],
        ['پیشخوان نمایش','theater','بررسی نمایش، پرده‌خوانی و اجرای نمایشی'],
        ['پیشخوان ساختنی','craft','بررسی کاردستی، اوریگامی و ساختنی‌ها'],
        ['پیشخوان آموزش','education','بررسی محتوای آموزشی، مقاله، آزمایش و برگه‌کار'],
    ] as [$name,$slug,$description]) {
        $deskSeed->execute([$name,$slug,$description]);
    }

    // Map known category labels without depending on hard-coded category ids.
    if (mahda_table_exists($db, 'mahda_categories')) {
        $desks = [];
        foreach ($db->query('SELECT id,slug FROM mahda_desks')->fetchAll() as $desk) {
            $desks[(string)$desk['slug']] = (int)$desk['id'];
        }
        $map = $db->prepare('INSERT IGNORE INTO mahda_desk_categories(desk_id,category_id,is_primary) VALUES(?,?,1)');
        foreach ($db->query('SELECT id,label FROM mahda_categories')->fetchAll() as $category) {
            $label = (string)$category['label'];
            $slug = null;
            if (preg_match('/بازی|فعالیت/u', $label)) $slug = 'game';
            elseif (preg_match('/قصه|داستان/u', $label)) $slug = 'story';
            elseif (preg_match('/نمایش|پرده/u', $label)) $slug = 'theater';
            elseif (preg_match('/اوریگامی|کاردستی|ساخت/u', $label)) $slug = 'craft';
            elseif (preg_match('/آموزش|مقاله|آزمایش|برگه|انیمیشن|موشن/u', $label)) $slug = 'education';
            if ($slug !== null && isset($desks[$slug])) {
                $map->execute([$desks[$slug], (string)$category['id']]);
            }
        }
        // Assign existing content to its primary desk where possible.
        $db->exec("UPDATE mahda_contents c
            JOIN (
                SELECT dc.category_id,MIN(dc.desk_id) AS desk_id
                FROM mahda_desk_categories dc
                JOIN mahda_desks d ON d.id=dc.desk_id AND d.is_active=1
                GROUP BY dc.category_id
            ) x ON x.category_id=c.category_id
            SET c.desk_id=x.desk_id
            WHERE c.desk_id IS NULL");
    }

    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(8)')->execute();
}

function mahda_permission_catalog(): array
{
    return [
        'dashboard.view' => 'مشاهده داشبورد',
        'content.view' => 'مشاهده همه محتواها',
        'content.edit' => 'ویرایش محتوای کاربران',
        'content.approve' => 'تأیید نهایی محتوا',
        'content.request_revision' => 'درخواست اصلاح',
        'content.reject' => 'رد ورود به بانک',
        'content.hide' => 'مخفی‌کردن عمومی',
        'content.archive' => 'آرشیو و بازگردانی',
        'content.delete' => 'حذف کامل محتوا',
        'content.assign' => 'ارجاع به پیشخوان',
        'users.view' => 'مشاهده کاربران',
        'users.manage' => 'مدیریت کاربران',
        'structure.manage' => 'مدیریت ساختار و دسته‌ها',
        'homepage.manage' => 'مدیریت صفحه اصلی',
        'reports.manage' => 'مدیریت گزارش‌ها',
        'atlas.manage' => 'مدیریت اطلس',
        'files.manage' => 'مدیریت فایل‌ها و فضای هاست',
        'desks.manage' => 'مدیریت پیشخوان‌ها',
        'staff.manage' => 'مدیریت مدیران و مجوزها',
        'settings.manage' => 'تنظیمات سامانه',
        'audit.view' => 'مشاهده سوابق مدیریتی',
    ];
}

function mahda_is_super_admin(PDO $db, int $userId): bool
{
    static $cache = [];
    if ($userId < 1) return false;
    $key = spl_object_id($db) . ':' . $userId;
    if (array_key_exists($key, $cache)) return $cache[$key];
    if (!mahda_column_exists($db, 'mahda_users', 'is_super_admin')) {
        return $cache[$key] = false;
    }
    $stmt = $db->prepare("SELECT is_super_admin FROM mahda_users WHERE id=? AND role='admin' AND is_active=1 LIMIT 1");
    $stmt->execute([$userId]);
    return $cache[$key] = (bool)$stmt->fetchColumn();
}

function mahda_staff_permissions(PDO $db, int $userId): array
{
    static $cache = [];
    if ($userId < 1) return [];
    $key = spl_object_id($db) . ':' . $userId;
    if (isset($cache[$key])) return $cache[$key];
    if (mahda_is_super_admin($db, $userId)) return $cache[$key] = array_keys(mahda_permission_catalog());
    if (!mahda_table_exists($db, 'mahda_staff_permissions')) return $cache[$key] = [];
    $stmt = $db->prepare('SELECT permission_key FROM mahda_staff_permissions WHERE user_id=? ORDER BY permission_key');
    $stmt->execute([$userId]);
    return $cache[$key] = array_values(array_filter(array_map('strval', $stmt->fetchAll(PDO::FETCH_COLUMN))));
}

function mahda_has_permission(PDO $db, array $user, string $permission): bool
{
    if (empty($user['id'])) return false;
    if (mahda_is_super_admin($db, (int)$user['id'])) return true;
    return in_array($permission, mahda_staff_permissions($db, (int)$user['id']), true);
}

function mahda_require_permission(PDO $db, string $permission): array
{
    $user = mahda_require_staff($db);
    if (!mahda_has_permission($db, $user, $permission)) {
        mahda_json(['error' => 'permission_denied', 'permission' => $permission], 403);
    }
    return $user;
}

function mahda_require_super_admin(PDO $db): array
{
    $user = mahda_require_admin($db);
    if (!mahda_is_super_admin($db, (int)$user['id'])) {
        mahda_json(['error' => 'super_admin_required'], 403);
    }
    return $user;
}

function mahda_staff_desk_access(PDO $db, int $userId, int $deskId): ?array
{
    static $cache = [];
    if ($deskId < 1 || $userId < 1) return null;
    $key = spl_object_id($db) . ':' . $userId . ':' . $deskId;
    if (array_key_exists($key, $cache)) return $cache[$key];
    if (!mahda_table_exists($db, 'mahda_desk_members')) return $cache[$key] = null;
    $stmt = $db->prepare('SELECT can_view,can_edit,can_request_revision,can_final_approve FROM mahda_desk_members dm JOIN mahda_desks d ON d.id=dm.desk_id AND d.is_active=1 WHERE dm.user_id=? AND dm.desk_id=? LIMIT 1');
    $stmt->execute([$userId,$deskId]);
    $row = $stmt->fetch();
    return $cache[$key] = ($row ? [
        'view'=>(bool)$row['can_view'],
        'edit'=>(bool)$row['can_edit'],
        'revision'=>(bool)$row['can_request_revision'],
        'approve'=>(bool)$row['can_final_approve'],
    ] : null);
}

function mahda_staff_desk_ids(PDO $db, int $userId, string $capability = 'view'): array
{
    if ($userId < 1 || !mahda_table_exists($db, 'mahda_desk_members')) return [];
    $column = match ($capability) {
        'edit' => 'can_edit',
        'revision' => 'can_request_revision',
        'approve' => 'can_final_approve',
        default => 'can_view',
    };
    $stmt = $db->prepare("SELECT dm.desk_id FROM mahda_desk_members dm JOIN mahda_desks d ON d.id=dm.desk_id AND d.is_active=1 WHERE dm.user_id=? AND dm.{$column}=1 ORDER BY dm.desk_id");
    $stmt->execute([$userId]);
    return array_values(array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN)));
}

function mahda_can_access_content(PDO $db, array $user, array $content, string $operation = 'view'): bool
{
    if (mahda_is_super_admin($db, (int)$user['id'])) return true;
    $permissionMap = [
        'view'=>'content.view',
        'edit'=>'content.edit',
        'approve'=>'content.approve',
        'revision'=>'content.request_revision',
        'reject'=>'content.reject',
        'hide'=>'content.hide',
        'archive'=>'content.archive',
        'delete'=>'content.delete',
        'assign'=>'content.assign',
    ];
    $permission = $permissionMap[$operation] ?? 'content.view';
    if (mahda_has_permission($db, $user, $permission)) return true;
    $deskId = (int)($content['desk_id'] ?? 0);
    $desk = mahda_staff_desk_access($db, (int)$user['id'], $deskId);
    if (!$desk) return false;
    return match ($operation) {
        'view' => $desk['view'],
        'edit' => $desk['edit'],
        'revision' => $desk['revision'],
        'approve', 'reject' => $desk['approve'],
        default => false,
    };
}

function mahda_assign_content_desk(PDO $db, int $contentId, string $categoryId): ?int
{
    if ($contentId < 1 || !mahda_table_exists($db, 'mahda_desk_categories')) return null;
    $stmt = $db->prepare('SELECT dc.desk_id FROM mahda_desk_categories dc JOIN mahda_desks d ON d.id=dc.desk_id AND d.is_active=1 WHERE dc.category_id=? ORDER BY dc.is_primary DESC,dc.desk_id LIMIT 1');
    $stmt->execute([$categoryId]);
    $deskId = (int)($stmt->fetchColumn() ?: 0);
    if ($deskId > 0) {
        $db->prepare('UPDATE mahda_contents SET desk_id=? WHERE id=?')->execute([$deskId,$contentId]);
        return $deskId;
    }
    return null;
}

function mahda_revision_storage_status(PDO $db): string
{
    try {
        $stmt = $db->query("SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='mahda_contents' AND COLUMN_NAME='review_status' LIMIT 1");
        $columnType = strtolower((string)$stmt->fetchColumn());
        if (str_starts_with($columnType, 'enum(') && !str_contains($columnType, "'revision'")) {
            return 'rejected';
        }
    } catch (Throwable $ignored) {
    }
    return 'revision';
}

function mahda_notify(PDO $db, int $recipientId, int $actorId, string $kind, ?int $contentId = null, ?int $profileId = null, array $meta = []): void
{
    if ($recipientId < 1 || $recipientId === $actorId || !in_array($kind, ['like','comment','executed','follow','review_approved','review_revision','review_rejected'], true)) {
        return;
    }
    $db->prepare('INSERT INTO mahda_notifications(recipient_user_id,actor_user_id,kind,content_id,profile_id,meta_json) VALUES(?,?,?,?,?,?)')
        ->execute([$recipientId,$actorId,$kind,$contentId,$profileId,$meta ? json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null]);
}

function mahda_list(mixed $value, int $max = 24): array
{
    if (!is_array($value)) {
        return [];
    }
    $items = [];
    foreach ($value as $item) {
        $item = mahda_string($item);
        if ($item !== '' && !in_array($item, $items, true)) {
            $items[] = $item;
        }
        if (count($items) >= $max) {
            break;
        }
    }
    return $items;
}

function mahda_persian_digits(string $value): string
{
    return strtr($value, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
}

function mahda_minutes(mixed $value): ?int
{
    $raw = mahda_persian_digits(trim((string)$value));
    if ($raw === '') {
        return null;
    }
    preg_match('/\d+/', $raw, $match);
    $minutes = isset($match[0]) ? (int)$match[0] : 0;
    return $minutes > 0 && $minutes <= 1440 ? $minutes : null;
}

function mahda_player_range(mixed $value): array
{
    $raw = mahda_persian_digits((string)$value);
    preg_match_all('/\d+/', $raw, $matches);
    $numbers = array_map('intval', $matches[0] ?? []);
    if (!$numbers) {
        return [null, null];
    }
    $min = max(1, min($numbers));
    $max = max($min, max($numbers));
    return [$min <= 10000 ? $min : null, $max <= 10000 ? $max : null];
}

function mahda_spaces(mixed $value): array
{
    $items = is_array($value) ? $value : [$value];
    $spaces = [];
    foreach ($items as $item) {
        $item = mahda_string($item, 40);
        if (($item === 'outdoor' || str_contains($item, 'باز')) && !in_array('outdoor', $spaces, true)) {
            $spaces[] = 'outdoor';
        }
        if (($item === 'indoor' || str_contains($item, 'بسته')) && !in_array('indoor', $spaces, true)) {
            $spaces[] = 'indoor';
        }
    }
    return $spaces;
}

function mahda_category(PDO $db, string $category): ?array
{
    $stmt = $db->prepare('SELECT id,label,icon,color FROM mahda_categories WHERE id=? AND is_active=1 LIMIT 1');
    $stmt->execute([$category]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function mahda_format_digits(int $number): string
{
    return strtr((string)$number, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
}

function mahda_item_payload(array $row, array $goalLabels, array $occasionLabels, array $toolLabels, array $files, array $interactionCounts, int $commentCount, string $publisherAvatar = ''): array
{
    $contentId = (int)$row['id'];
    $cover = null; $mainFile = null; $video = null; $audio = null; $attachments = [];
    $publicFile = static function(array $entry): array {
        return [
            'id'=>(int)$entry['id'], 'purpose'=>(string)$entry['purpose'],
            'name'=>(string)$entry['original_name'], 'mime'=>(string)$entry['mime_type'],
            'size'=>(int)$entry['size_bytes'],
            'url'=>'/mahda-api/index.php?action=file&id='.(int)$entry['id']
        ];
    };
    foreach ($files as $entry) {
        $purpose=(string)($entry['purpose']??'');
        if ($purpose === 'cover' && $cover === null) $cover=$publicFile($entry);
        elseif ($purpose === 'main_file' && $mainFile === null) $mainFile=$publicFile($entry);
        elseif ($purpose === 'execution_video' && $video === null) $video=$publicFile($entry);
        elseif ($purpose === 'execution_audio' && $audio === null) $audio=$publicFile($entry);
        elseif ($purpose === 'attachment') $attachments[]=$publicFile($entry);
    }
    $age=[]; if((int)$row['age_4_6']===1)$age[]='4-6'; if((int)$row['age_7_10']===1)$age[]='7-10';
    $spaces=[]; if((int)$row['indoor']===1)$spaces[]='indoor'; if((int)$row['outdoor']===1)$spaces[]='outdoor';
    $spaceLabel=null; if(count($spaces)===2)$spaceLabel='فضای باز و بسته'; elseif($spaces===['indoor'])$spaceLabel='فضای بسته'; elseif($spaces===['outdoor'])$spaceLabel='فضای باز';
    $durationMinutes=$row['duration_minutes']===null?null:(int)$row['duration_minutes'];
    $duration=$durationMinutes?mahda_format_digits($durationMinutes).' دقیقه':null;
    $players=null; if($row['players_min']!==null){$players=mahda_format_digits((int)$row['players_min']).' تا '.mahda_format_digits((int)($row['players_max']??$row['players_min'])).' نفر';}
    $extra=json_decode((string)($row['extra_fields_json']??''),true); if(!is_array($extra))$extra=[];
    $isAnonymous=(string)($extra['publisherType']??'')==='anonymous';
    $publisherName=$isAnonymous?'ناشناس':(string)$row['profile_name'];
    $general=(bool)($row['general_occasion']??false);
    $toolFreeSpecified=array_key_exists('toolFreeSpecified',$extra)?(bool)$extra['toolFreeSpecified']:((bool)$row['tool_free']||count($toolLabels)>0);
    return [
        'id'=>(string)$contentId,'title'=>(string)$row['title'],'category'=>(string)$row['category_id'],
        'categoryLabel'=>(string)$row['category_label'],'categoryIcon'=>(string)$row['category_icon'],'categoryColor'=>(string)$row['category_color'],
        'ages'=>$age,'duration'=>$duration,'durationMinutes'=>$durationMinutes,'image'=>$cover['url']??null,'cover'=>$cover,
        'mainText'=>(string)($row['body']??''),'directTextContent'=>(string)($row['body']??''),'description'=>(string)($row['body']??''),'executionText'=>(string)($row['execution_text']??''),
        'tags'=>array_values(array_unique(array_merge([(string)$row['category_label']],$goalLabels,$occasionLabels))),
        'status'=>(string)$row['review_status']==='approved'?'approved':'showcase','reviewStatus'=>(string)$row['review_status'],
        'goals'=>$goalLabels,'occasion'=>$occasionLabels[0]??null,'occasions'=>$occasionLabels,'generalOccasion'=>$general,
        'spaces'=>$spaces,'space'=>$spaceLabel,'author'=>$publisherName,'publisher'=>$publisherName,'publisherAvatar'=>$isAnonymous?'':$publisherAvatar,
        'authorId'=>(int)$row['author_id'],'profileId'=>$isAnonymous?0:(int)$row['profile_id'],'profileKind'=>(string)($row['profile_kind']??'personal'),
        'hasMahdaSeal'=>(string)$row['review_status']==='approved','audienceSize'=>$players,
        'playersMin'=>$row['players_min']===null?null:(int)$row['players_min'],'playersMax'=>$row['players_max']===null?null:(int)$row['players_max'],
        'activityLevel'=>['low'=>'کم','medium'=>'متوسط','high'=>'زیاد'][$row['activity_level']??'']??null,
        'activityLevelKey'=>$row['activity_level']??null,'gameStyle'=>$extra['gameStyle']??null,
        'theaterActorsCount'=>$extra['theaterActorsCount']??null,'theaterNeedCostume'=>array_key_exists('theaterNeedCostume',$extra)?$extra['theaterNeedCostume']:null,
        'theaterNeedStage'=>array_key_exists('theaterNeedStage',$extra)?$extra['theaterNeedStage']:null,
        'experimentDifficulty'=>$extra['experimentDifficulty']??null,'experimentNeedSupervision'=>array_key_exists('experimentNeedSupervision',$extra)?$extra['experimentNeedSupervision']:null,
        'customFields'=>is_array($extra['customFields']??null)?$extra['customFields']:[],
        'requiredTools'=>$toolLabels,'isToolFree'=>$toolFreeSpecified?(bool)$row['tool_free']:null,'toolFreeSpecified'=>$toolFreeSpecified,
        'executionMethod'=>$extra['executionMethod']??null,'presentationMethod'=>$extra['executionMethod']??($extra['presentationMethod']??null),'mainFile'=>$mainFile,'executionVideo'=>$video,'executionAudio'=>$audio,'attachments'=>$attachments,
        'attachmentFileName'=>$attachments[0]['name']??null,'attachmentFileSize'=>isset($attachments[0])?(string)$attachments[0]['size']:null,'attachmentDataUrl'=>$attachments[0]['url']??null,
        'videoUrl'=>$video['url']??null,'videoFileName'=>$video['name']??null,'voiceAudioUrl'=>$audio['url']??null,'voiceFileName'=>$audio['name']??null,
        'likeCount'=>(int)($interactionCounts['like']??0),'executedCount'=>(int)($interactionCounts['executed']??0),'bookmarkCount'=>(int)($interactionCounts['bookmark']??0),
        'commentCount'=>$commentCount,'createdAt'=>(string)$row['created_at'],
    ];
}

/**
 * Hydrate a list of content rows with a fixed number of SQL queries instead of
 * issuing several queries for every card. This keeps the bank and showcase
 * fast as the number of contents grows.
 */
function mahda_items(PDO $db, array $rows): array
{
    if (!$rows) { return []; }
    $ids = [];
    foreach ($rows as $row) {
        $id = (int)($row['id'] ?? 0);
        if ($id > 0) { $ids[$id] = $id; }
    }
    if (!$ids) { return []; }
    $ids = array_values($ids);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $goals = $occasions = $tools = $files = $counts = $comments = [];
    $profileAvatars = [];

    $stmt = $db->prepare("SELECT cg.content_id,g.label FROM mahda_content_goals cg JOIN mahda_goals g ON g.id=cg.goal_id WHERE cg.content_id IN ({$placeholders}) ORDER BY g.label");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) { $goals[(int)$r['content_id']][] = (string)$r['label']; }

    $stmt = $db->prepare("SELECT co.content_id,o.label FROM mahda_content_occasions co JOIN mahda_occasions o ON o.id=co.occasion_id WHERE co.content_id IN ({$placeholders}) ORDER BY o.label");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) { $occasions[(int)$r['content_id']][] = (string)$r['label']; }

    $stmt = $db->prepare("SELECT content_id,label FROM mahda_content_tools WHERE content_id IN ({$placeholders}) ORDER BY sort_order,id");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) { $tools[(int)$r['content_id']][] = (string)$r['label']; }

    $stmt = $db->prepare("SELECT id,content_id,original_name,mime_type,size_bytes,purpose FROM mahda_files WHERE content_id IN ({$placeholders}) AND purpose IN ('cover','main_file','attachment','execution_video','execution_audio') ORDER BY content_id,FIELD(purpose,'cover','main_file','execution_video','execution_audio','attachment'),id");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) { $files[(int)$r['content_id']][] = $r; }

    $stmt = $db->prepare("SELECT content_id,kind,COUNT(*) AS total FROM mahda_interactions WHERE content_id IN ({$placeholders}) GROUP BY content_id,kind");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) { $counts[(int)$r['content_id']][(string)$r['kind']] = (int)$r['total']; }

    $stmt = $db->prepare("SELECT content_id,COUNT(*) AS total FROM mahda_comments WHERE content_id IN ({$placeholders}) AND status='published' AND COALESCE(is_hidden,0)=0 GROUP BY content_id");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) { $comments[(int)$r['content_id']] = (int)$r['total']; }

    $profileIds = [];
    foreach ($rows as $row) {
        $profileId = (int)($row['profile_id'] ?? 0);
        if ($profileId > 0) $profileIds[$profileId] = $profileId;
    }
    if ($profileIds) {
        $profileIds = array_values($profileIds);
        $profilePlaceholders = implode(',', array_fill(0, count($profileIds), '?'));
        $profileStmt = $db->prepare("SELECT id,kind,profile_data_json FROM mahda_profiles WHERE id IN ({$profilePlaceholders})");
        $profileStmt->execute($profileIds);
        foreach ($profileStmt->fetchAll() as $profileRow) {
            $pid = (int)$profileRow['id'];
            $profileAvatars[$pid] = mahda_profile_avatar_url_db($db, $pid, (string)($profileRow['profile_data_json'] ?? ''), (string)($profileRow['kind'] ?? 'personal'));
        }
    }

    $items = [];
    foreach ($rows as $row) {
        $id = (int)$row['id'];
        $items[] = mahda_item_payload(
            $row,
            $goals[$id] ?? [],
            $occasions[$id] ?? [],
            $tools[$id] ?? [],
            $files[$id] ?? [],
            $counts[$id] ?? [],
            $comments[$id] ?? 0,
            $profileAvatars[(int)($row['profile_id'] ?? 0)] ?? ''
        );
    }
    return $items;
}

function mahda_item(PDO $db, array $row): array
{
    $items = mahda_items($db, [$row]);
    return $items[0] ?? [];
}

/** Return true only for a published content record that may be viewed publicly. */
function mahda_public_content_exists(PDO $db, int $contentId): bool
{
    if ($contentId < 1) return false;
    $stmt = $db->prepare("SELECT 1
        FROM mahda_contents c
        JOIN mahda_profiles p ON p.id=c.profile_id
        JOIN mahda_users owner ON owner.id=c.author_id
        WHERE c.id=? AND p.name<>''
          AND owner.is_active=1
          AND owner.email NOT LIKE 'guest-%@mahda.local'
          AND owner.email NOT LIKE 'test-phone-%@mahda.local'
          AND c.archived_at IS NULL AND (c.visibility='showcase' OR (c.visibility<>'hidden' AND c.review_status='approved'))
        LIMIT 1");
    $stmt->execute([$contentId]);
    return (bool)$stmt->fetchColumn();
}


/**
 * Admin stages 15-23: content structure, taxonomy management, profile
 * credibility, reports, homepage builder, atlas, file operations and system
 * health. Additive only; existing rows stay intact.
 */
function mahda_migrate_admin_stage23(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=9 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) {
        return;
    }

    if (mahda_table_exists($db, 'mahda_categories')) {
        foreach ([
            ['description', "TEXT NULL"],
            ['show_in_register', "TINYINT(1) NOT NULL DEFAULT 1"],
            ['show_in_bank', "TINYINT(1) NOT NULL DEFAULT 1"],
        ] as [$column,$definition]) {
            if (!mahda_column_exists($db, 'mahda_categories', $column)) {
                $db->exec("ALTER TABLE mahda_categories ADD COLUMN {$column} {$definition}");
            }
        }
    }

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_topics (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        label VARCHAR(140) NOT NULL,
        slug VARCHAR(100) NOT NULL UNIQUE,
        description TEXT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        created_by BIGINT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY ix_topic_active(is_active,sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_category_topics (
        category_id VARCHAR(40) NOT NULL,
        topic_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        PRIMARY KEY(category_id,topic_id),
        KEY ix_category_topic(topic_id,category_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_content_topics (
        content_id BIGINT UNSIGNED NOT NULL,
        topic_id BIGINT UNSIGNED NOT NULL,
        PRIMARY KEY(content_id,topic_id),
        KEY ix_content_topic(topic_id,content_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_category_fields (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        category_id VARCHAR(40) NOT NULL,
        field_key VARCHAR(80) NOT NULL,
        label VARCHAR(140) NOT NULL,
        help_text VARCHAR(600) NULL,
        field_type VARCHAR(24) NOT NULL DEFAULT 'text',
        options_json LONGTEXT NULL,
        is_required TINYINT(1) NOT NULL DEFAULT 0,
        show_in_search TINYINT(1) NOT NULL DEFAULT 0,
        show_in_detail TINYINT(1) NOT NULL DEFAULT 1,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY ux_category_field(category_id,field_key),
        KEY ix_category_field_order(category_id,is_active,sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if (mahda_table_exists($db, 'mahda_goals')) {
        foreach ([
            ['goal_group', "VARCHAR(24) NOT NULL DEFAULT 'ethical'"],
            ['search_terms_json', "LONGTEXT NULL"],
            ['sort_order', "INT NOT NULL DEFAULT 0"],
        ] as [$column,$definition]) {
            if (!mahda_column_exists($db, 'mahda_goals', $column)) {
                $db->exec("ALTER TABLE mahda_goals ADD COLUMN {$column} {$definition}");
            }
        }
    }
    if (mahda_table_exists($db, 'mahda_occasions')) {
        foreach ([
            ['description', "TEXT NULL"],
            ['sort_order', "INT NOT NULL DEFAULT 0"],
        ] as [$column,$definition]) {
            if (!mahda_column_exists($db, 'mahda_occasions', $column)) {
                $db->exec("ALTER TABLE mahda_occasions ADD COLUMN {$column} {$definition}");
            }
        }
    }

    if (mahda_table_exists($db, 'mahda_profiles')) {
        foreach ([
            ['profile_role', "VARCHAR(24) NOT NULL DEFAULT 'mentor'"],
            ['is_verified', "TINYINT(1) NOT NULL DEFAULT 0"],
            ['verification_note', "VARCHAR(500) NULL"],
            ['verified_at', "DATETIME NULL"],
            ['verified_by', "BIGINT UNSIGNED NULL"],
            ['atlas_visible', "TINYINT(1) NOT NULL DEFAULT 1"],
            ['province_id', "INT NULL"],
            ['city_id', "INT NULL"],
            ['latitude', "DECIMAL(10,7) NULL"],
            ['longitude', "DECIMAL(10,7) NULL"],
        ] as [$column,$definition]) {
            if (!mahda_column_exists($db, 'mahda_profiles', $column)) {
                $db->exec("ALTER TABLE mahda_profiles ADD COLUMN {$column} {$definition}");
            }
        }
        // Existing organization profiles are heiats; existing personal profiles
        // default to mentor until a manager explicitly changes the role.
        $db->exec("UPDATE mahda_profiles SET profile_role='heiat' WHERE kind='heiat' AND profile_role<>'heiat'");
    }

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_badges (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(120) NOT NULL,
        slug VARCHAR(80) NOT NULL UNIQUE,
        description VARCHAR(500) NULL,
        icon VARCHAR(80) NULL,
        color VARCHAR(30) NULL,
        applies_to VARCHAR(40) NOT NULL DEFAULT 'all',
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        created_by BIGINT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_profile_badges (
        profile_id BIGINT UNSIGNED NOT NULL,
        badge_id BIGINT UNSIGNED NOT NULL,
        granted_by BIGINT UNSIGNED NULL,
        note VARCHAR(500) NULL,
        granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(profile_id,badge_id),
        KEY ix_badge_profiles(badge_id,profile_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_heiat_memberships (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        heiat_profile_id BIGINT UNSIGNED NOT NULL,
        mentor_profile_id BIGINT UNSIGNED NOT NULL,
        invited_by BIGINT UNSIGNED NULL,
        status VARCHAR(24) NOT NULL DEFAULT 'pending',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        responded_at DATETIME NULL,
        UNIQUE KEY ux_heiat_mentor(heiat_profile_id,mentor_profile_id),
        KEY ix_membership_mentor(mentor_profile_id,status),
        KEY ix_membership_heiat(heiat_profile_id,status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if (mahda_table_exists($db, 'mahda_comments')) {
        foreach ([
            ['is_hidden', "TINYINT(1) NOT NULL DEFAULT 0"],
            ['hidden_by', "BIGINT UNSIGNED NULL"],
            ['hidden_reason', "VARCHAR(500) NULL"],
            ['hidden_at', "DATETIME NULL"],
        ] as [$column,$definition]) {
            if (!mahda_column_exists($db, 'mahda_comments', $column)) {
                $db->exec("ALTER TABLE mahda_comments ADD COLUMN {$column} {$definition}");
            }
        }
    }

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_reports (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        reporter_user_id BIGINT UNSIGNED NULL,
        target_type VARCHAR(24) NOT NULL,
        target_id BIGINT UNSIGNED NOT NULL,
        reason_key VARCHAR(40) NOT NULL,
        note TEXT NULL,
        status VARCHAR(24) NOT NULL DEFAULT 'new',
        assigned_to BIGINT UNSIGNED NULL,
        resolution_note TEXT NULL,
        resolved_by BIGINT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        resolved_at DATETIME NULL,
        KEY ix_report_queue(status,target_type,created_at),
        KEY ix_report_target(target_type,target_id),
        KEY ix_reporter(reporter_user_id,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_admin_notifications (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        recipient_user_id BIGINT UNSIGNED NULL,
        kind VARCHAR(40) NOT NULL,
        entity_type VARCHAR(30) NULL,
        entity_id BIGINT UNSIGNED NULL,
        title VARCHAR(190) NOT NULL,
        body VARCHAR(800) NULL,
        dedupe_key VARCHAR(190) NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY ux_admin_notification_dedupe(dedupe_key),
        KEY ix_admin_notification(recipient_user_id,is_read,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_home_sections (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        section_key VARCHAR(80) NOT NULL UNIQUE,
        section_type VARCHAR(40) NOT NULL,
        title VARCHAR(160) NOT NULL,
        subtitle VARCHAR(300) NULL,
        source_mode VARCHAR(20) NOT NULL DEFAULT 'auto',
        config_json LONGTEXT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        created_by BIGINT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY ix_home_section_order(is_active,sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_home_section_items (
        section_id BIGINT UNSIGNED NOT NULL,
        content_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        PRIMARY KEY(section_id,content_id),
        KEY ix_home_section_item(section_id,sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_special_pages (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(100) NOT NULL UNIQUE,
        title VARCHAR(180) NOT NULL,
        subtitle VARCHAR(400) NULL,
        cover_file_id BIGINT UNSIGNED NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        created_by BIGINT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_special_page_items (
        page_id BIGINT UNSIGNED NOT NULL,
        content_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        PRIMARY KEY(page_id,content_id),
        KEY ix_special_page_item(page_id,sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_provinces (
        id INT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        slug VARCHAR(120) NOT NULL,
        tel_prefix VARCHAR(10) NULL,
        latitude DECIMAL(10,7) NULL,
        longitude DECIMAL(10,7) NULL,
        UNIQUE KEY ux_province_slug(slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_cities (
        id INT PRIMARY KEY,
        province_id INT NOT NULL,
        name VARCHAR(120) NOT NULL,
        slug VARCHAR(140) NOT NULL,
        latitude DECIMAL(10,7) NULL,
        longitude DECIMAL(10,7) NULL,
        KEY ix_city_province(province_id,name),
        KEY ix_city_name(name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_system_errors (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        action_name VARCHAR(100) NULL,
        error_class VARCHAR(140) NULL,
        error_message VARCHAR(600) NULL,
        request_method VARCHAR(12) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        resolved_at DATETIME NULL,
        KEY ix_system_error_time(created_at),
        KEY ix_system_error_resolved(resolved_at,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Starter badges and homepage rows are real editable records, not UI mock data.
    $badge = $db->prepare('INSERT IGNORE INTO mahda_badges(title,slug,description,icon,color,applies_to,sort_order) VALUES(?,?,?,?,?,?,?)');
    foreach ([
        ['مهر مهدا','mahda-seal','اعتبار رسمی مهدا برای پروفایل‌های تأییدشده','sun','#EFB33D','all',10],
        ['نشان مشارکت','participation','برای مشارکت مستمر و مؤثر','star','#3972A5','all',20],
        ['نشان خدمت','service','ویژه خدمت فرهنگی و مجموعه‌ها','leaf','#2F9A48','heiat',30],
        ['نشان یادگیری','learning','ویژه مسیرهای آموزشی و خانواده‌ها','book','#7A56A3','all',40],
    ] as $row) {
        $badge->execute($row);
    }

    $section = $db->prepare('INSERT IGNORE INTO mahda_home_sections(section_key,section_type,title,subtitle,source_mode,is_active,sort_order) VALUES(?,?,?,?,?,?,?)');
    foreach ([
        ['hero','hero','اسلایدر اصلی','بنرها و پیشنهادهای ویژه','manual',1,10],
        ['search','search','جستجو','جستجوی محتوای مهدا','auto',1,20],
        ['main-grid','categories','بخش‌های اصلی','دسترسی سریع به بخش‌های اصلی','auto',1,30],
        ['seasonal','content_row','پیشنهادهای این روزها','محتوای منتخب و مناسبتی','manual',1,40],
        ['latest','content_row','تازه‌های مهدا','جدیدترین محتواهای تأییدشده','auto',1,50],
        ['packages','packages','بسته‌های آماده اجرا','مجموعه‌های محتوایی منتخب','manual',1,60],
        ['popular','content_row','محبوب‌ترین‌ها','محتواهای پرتعامل','auto',1,70],
    ] as $row) {
        $section->execute($row);
    }

    $setting = $db->prepare('INSERT IGNORE INTO mahda_settings(setting_key,setting_value) VALUES(?,?)');
    foreach ([
        ['upload_cover_max_mb','6'],
        ['upload_video_max_mb','100'],
        ['upload_audio_max_mb','30'],
        ['upload_attachment_max_mb','50'],
        ['allowed_upload_mimes','image/jpeg,image/png,image/webp,application/pdf,application/zip,application/x-zip-compressed,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,audio/webm,audio/mpeg,audio/ogg,application/ogg,audio/mp4,audio/wav,audio/x-wav,video/webm,video/mp4,video/quicktime,video/mpeg'],
        ['publish_rules_text',''],
    ] as $row) {
        $setting->execute($row);
    }

    mahda_seed_iran_places($db);

    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(9)')->execute();
}

function mahda_migrate_public_atlas(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=10 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) return;

    // Stage 23 introduced the canonical province/city dataset. Link older
    // profiles that only stored the city name so the public atlas is useful
    // immediately without requiring managers to re-enter existing locations.
    mahda_seed_iran_places($db);
    if (mahda_table_exists($db, 'mahda_profiles') && mahda_table_exists($db, 'mahda_cities')) {
        $db->exec("UPDATE mahda_profiles p
            JOIN mahda_cities c ON c.name=p.city
            SET p.city_id=c.id,p.province_id=c.province_id
            WHERE p.city_id IS NULL AND p.city IS NOT NULL AND p.city<>''");
        try {
            $db->exec("ALTER TABLE mahda_profiles ADD KEY ix_profile_atlas_location(atlas_visible,profile_role,province_id,city_id)");
        } catch (Throwable $ignored) {
            // Index may already exist on an installation that received a
            // manual schema patch; migration remains safe and idempotent.
        }
    }
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(10)')->execute();
}

function mahda_normalize_place_name(string $value): string
{
    $value = trim($value);
    $value = str_replace(["ي","ك","ۀ","ة","‌"], ["ی","ک","ه","ه"," "], $value);
    $value = preg_replace('/^\s*(?:استان|شهر)\s+/u', '', $value) ?? $value;
    $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
    return trim($value);
}

function mahda_resolve_city_name(PDO $db, string $cityName): ?array
{
    $needle = mahda_normalize_place_name($cityName);
    if ($needle === '') return null;
    static $cache = [];
    $cacheKey = spl_object_id($db);
    if (!isset($cache[$cacheKey])) {
        $rows = $db->query('SELECT id,province_id,name,latitude,longitude FROM mahda_cities')->fetchAll();
        $map = [];
        foreach ($rows as $row) {
            $key = mahda_normalize_place_name((string)$row['name']);
            if ($key !== '' && !isset($map[$key])) $map[$key] = $row;
        }
        $cache[$cacheKey] = $map;
    }
    return $cache[$cacheKey][$needle] ?? null;
}

function mahda_migrate_atlas_location_v11(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=11 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) return;
    mahda_seed_iran_places($db);
    if (mahda_table_exists($db, 'mahda_profiles') && mahda_table_exists($db, 'mahda_cities')) {
        $rows = $db->query("SELECT id,city FROM mahda_profiles WHERE city IS NOT NULL AND city<>''")->fetchAll();
        $update = $db->prepare('UPDATE mahda_profiles SET city=?,city_id=?,province_id=?,latitude=COALESCE(latitude,?),longitude=COALESCE(longitude,?) WHERE id=?');
        foreach ($rows as $row) {
            $city = mahda_resolve_city_name($db, (string)$row['city']);
            if (!$city) continue;
            $update->execute([(string)$city['name'],(int)$city['id'],(int)$city['province_id'],$city['latitude'],$city['longitude'],(int)$row['id']]);
        }
    }
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(11)')->execute();
}

function mahda_seed_iran_places(PDO $db): void
{
    if (!mahda_table_exists($db, 'mahda_provinces') || !mahda_table_exists($db, 'mahda_cities')) {
        return;
    }
    $count = (int)$db->query('SELECT COUNT(*) FROM mahda_cities')->fetchColumn();
    if ($count >= 1000) {
        return;
    }
    $path = __DIR__ . '/iran-places.json';
    if (!is_file($path)) {
        return;
    }
    $decoded = json_decode((string)file_get_contents($path), true);
    if (!is_array($decoded)) {
        return;
    }
    $province = $db->prepare('INSERT INTO mahda_provinces(id,name,slug,tel_prefix,latitude,longitude) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),slug=VALUES(slug),tel_prefix=VALUES(tel_prefix),latitude=VALUES(latitude),longitude=VALUES(longitude)');
    foreach (($decoded['provinces'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $province->execute([(int)$row['id'],mahda_string($row['name'] ?? '',100),mahda_string($row['slug'] ?? '',120),mahda_string($row['tel_prefix'] ?? '',10),$row['latitude'] ?? null,$row['longitude'] ?? null]);
    }
    $city = $db->prepare('INSERT INTO mahda_cities(id,province_id,name,slug,latitude,longitude) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE province_id=VALUES(province_id),name=VALUES(name),slug=VALUES(slug),latitude=VALUES(latitude),longitude=VALUES(longitude)');
    foreach (($decoded['cities'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $city->execute([(int)$row['id'],(int)$row['province_id'],mahda_string($row['name'] ?? '',120),mahda_string($row['slug'] ?? '',140),$row['latitude'] ?? null,$row['longitude'] ?? null]);
    }
}

function mahda_sync_category_fields_json(PDO $db, string $categoryId): void
{
    if ($categoryId === '' || !mahda_table_exists($db, 'mahda_category_fields')) return;
    $stmt = $db->prepare('SELECT field_key,label,help_text,field_type,options_json,is_required,show_in_search,show_in_detail,is_active,sort_order FROM mahda_category_fields WHERE category_id=? ORDER BY sort_order,id');
    $stmt->execute([$categoryId]);
    $fields = [];
    foreach ($stmt->fetchAll() as $row) {
        $options = json_decode((string)($row['options_json'] ?? ''), true);
        if (!is_array($options)) $options = [];
        $fields[(string)$row['field_key']] = [
            'key'=>(string)$row['field_key'],
            'label'=>(string)$row['label'],
            'help'=>(string)($row['help_text'] ?? ''),
            'type'=>(string)$row['field_type'],
            'options'=>$options,
            'required'=>(bool)$row['is_required'],
            'searchable'=>(bool)$row['show_in_search'],
            'showInDetail'=>(bool)$row['show_in_detail'],
            'active'=>(bool)$row['is_active'],
            'sortOrder'=>(int)$row['sort_order'],
        ];
    }
    $db->prepare('UPDATE mahda_categories SET fields_json=? WHERE id=?')->execute([json_encode($fields,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$categoryId]);
}

function mahda_admin_notify(PDO $db, string $kind, string $title, string $body = '', ?string $entityType = null, ?int $entityId = null, ?string $dedupeKey = null, ?int $recipientId = null): void
{
    if (!mahda_table_exists($db, 'mahda_admin_notifications')) return;
    try {
        $stmt = $db->prepare('INSERT IGNORE INTO mahda_admin_notifications(recipient_user_id,kind,entity_type,entity_id,title,body,dedupe_key) VALUES(?,?,?,?,?,?,?)');
        $stmt->execute([$recipientId,$kind,$entityType,$entityId,mahda_string($title,190),mahda_string($body,800),$dedupeKey]);
    } catch (Throwable $ignored) {
    }
}

function mahda_log_system_error(PDO $db, ?string $action, Throwable $error): void
{
    if (!mahda_table_exists($db, 'mahda_system_errors')) return;
    try {
        $stmt = $db->prepare('INSERT INTO mahda_system_errors(action_name,error_class,error_message,request_method) VALUES(?,?,?,?)');
        $stmt->execute([
            mahda_string($action ?? '',100),
            mahda_string(get_class($error),140),
            mahda_string($error->getMessage(),600),
            mahda_string($_SERVER['REQUEST_METHOD'] ?? '',12),
        ]);
    } catch (Throwable $ignored) {
    }
}

function mahda_ini_bytes(string $value): int
{
    $value=trim($value); if($value==='') return PHP_INT_MAX;
    if(preg_match('/^(\d+(?:\.\d+)?)\s*([KMG])?$/i',$value,$m)){
        $n=(float)$m[1]; $u=strtoupper((string)($m[2]??''));
        $mul=$u==='G'?1073741824:($u==='M'?1048576:($u==='K'?1024:1));
        return (int)floor($n*$mul);
    }
    return ctype_digit($value)?(int)$value:PHP_INT_MAX;
}

function mahda_effective_php_upload_limit(): int
{
    $upload=mahda_ini_bytes((string)ini_get('upload_max_filesize'));
    $post=mahda_ini_bytes((string)ini_get('post_max_size'));
    if($post!==PHP_INT_MAX) $post=max(0,$post-1024*1024);
    return min($upload,$post);
}

function mahda_upload_policy(PDO $db, string $purpose): array
{
    $map = [
        'cover' => ['setting'=>'upload_cover_max_mb','default'=>6],
        'execution_video' => ['setting'=>'upload_video_max_mb','default'=>100],
        'execution_audio' => ['setting'=>'upload_audio_max_mb','default'=>30],
        'main_file' => ['setting'=>'upload_main_file_max_mb','default'=>150],
        'attachment' => ['setting'=>'upload_attachment_max_mb','default'=>50],
    ];
    $spec = $map[$purpose] ?? ['setting'=>'upload_attachment_max_mb','default'=>50];
    $mb = (int)mahda_setting($db,$spec['setting'],(string)$spec['default']);
    $mb = max(1,min(500,$mb));
    $configuredBytes=$mb*1024*1024;
    if ($purpose === 'execution_video') {
        $configuredBytes = max($configuredBytes, (int)(mahda_media_config()['video_input_max_bytes'] ?? (150 * 1024 * 1024)));
    }
    $phpLimit=mahda_effective_php_upload_limit();
    $maxBytes=$phpLimit>0?min($configuredBytes,$phpLimit):$configuredBytes;
    $mimes = array_values(array_filter(array_map('trim',explode(',',(string)mahda_setting($db,'allowed_upload_mimes','image/jpeg,image/png,image/webp,application/pdf,application/zip,application/x-zip-compressed,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,audio/webm,audio/mpeg,audio/ogg,application/ogg,audio/mp4,audio/wav,audio/x-wav,video/webm,video/mp4,video/quicktime,video/mpeg')))));
    return ['max_bytes'=>$maxBytes,'mimes'=>$mimes,'configured_bytes'=>$configuredBytes,'php_limit_bytes'=>$phpLimit];
}

/**
 * Stage 12: trustworthy content registration and draft/file model (expanded to nine UI steps).
 * Additive only: existing content/files remain valid and are never rewritten.
 */
function mahda_migrate_content_registration_v12(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=12 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) return;

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_content_drafts (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        owner_id BIGINT UNSIGNED NOT NULL,
        profile_id BIGINT UNSIGNED NULL,
        category_id VARCHAR(40) NULL,
        client_key VARCHAR(80) NOT NULL,
        current_step TINYINT UNSIGNED NOT NULL DEFAULT 1,
        data_json LONGTEXT NULL,
        version INT UNSIGNED NOT NULL DEFAULT 1,
        completed_content_id BIGINT UNSIGNED NULL,
        completed_at DATETIME NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY ux_draft_owner_client(owner_id,client_key),
        KEY ix_draft_owner_active(owner_id,completed_at,updated_at),
        KEY ix_draft_content(completed_content_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_goal_suggestions (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        owner_id BIGINT UNSIGNED NOT NULL,
        draft_id BIGINT UNSIGNED NULL,
        proposed_label VARCHAR(190) NOT NULL,
        normalized_label VARCHAR(190) NOT NULL,
        status VARCHAR(24) NOT NULL DEFAULT 'pending',
        matched_goal_id BIGINT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        reviewed_at DATETIME NULL,
        reviewed_by BIGINT UNSIGNED NULL,
        KEY ix_goal_suggestion_status(status,created_at),
        KEY ix_goal_suggestion_owner(owner_id,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if (mahda_table_exists($db,'mahda_contents')) {
        foreach ([
            ['published_at','DATETIME NULL'],
            ['bank_requested_at','DATETIME NULL'],
            ['rules_version','VARCHAR(32) NULL'],
            ['source_draft_id','BIGINT UNSIGNED NULL'],
        ] as [$column,$definition]) {
            if (!mahda_column_exists($db,'mahda_contents',$column)) {
                $db->exec("ALTER TABLE mahda_contents ADD COLUMN {$column} {$definition}");
            }
        }
        try { $db->exec('CREATE UNIQUE INDEX ux_content_source_draft ON mahda_contents(source_draft_id)'); } catch (Throwable $ignored) {}
    }

    if (mahda_table_exists($db,'mahda_files')) {
        // New registration uploads are allowed before a content row exists.
        try { $db->exec('ALTER TABLE mahda_files MODIFY COLUMN content_id BIGINT UNSIGNED NULL'); } catch (Throwable $ignored) {}
        try { $db->exec('ALTER TABLE mahda_files MODIFY COLUMN purpose VARCHAR(32) NOT NULL'); } catch (Throwable $ignored) {}
        foreach ([
            ['draft_id','BIGINT UNSIGNED NULL'],
            ['status',"VARCHAR(24) NOT NULL DEFAULT 'ready'"],
            ['processing_error','VARCHAR(190) NULL'],
            ['original_storage_key','VARCHAR(255) NULL'],
            ['thumbnail_storage_key','VARCHAR(255) NULL'],
            ['width','INT UNSIGNED NULL'],
            ['height','INT UNSIGNED NULL'],
            ['is_temporary','TINYINT(1) NOT NULL DEFAULT 0'],
            ['updated_at','DATETIME NULL'],
        ] as [$column,$definition]) {
            if (!mahda_column_exists($db,'mahda_files',$column)) {
                $db->exec("ALTER TABLE mahda_files ADD COLUMN {$column} {$definition}");
            }
        }
        try { $db->exec('CREATE INDEX ix_files_draft ON mahda_files(draft_id,status,purpose)'); } catch (Throwable $ignored) {}
        try { $db->exec('CREATE INDEX ix_files_temporary ON mahda_files(is_temporary,created_at)'); } catch (Throwable $ignored) {}
    }

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_media_jobs (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        file_id BIGINT UNSIGNED NOT NULL,
        job_type VARCHAR(32) NOT NULL,
        status VARCHAR(24) NOT NULL DEFAULT 'pending',
        attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
        error_message VARCHAR(255) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        started_at DATETIME NULL,
        finished_at DATETIME NULL,
        UNIQUE KEY ux_media_job_file_type(file_id,job_type),
        KEY ix_media_job_status(status,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $seed = $db->prepare('INSERT IGNORE INTO mahda_settings(setting_key,setting_value) VALUES(?,?)');
    foreach ([
        ['content_rules_version','1'],
        ['content_draft_ttl_days','30'],
        ['upload_main_file_max_mb','150'],
    ] as [$key,$value]) $seed->execute([$key,$value]);

    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(12)')->execute();
}

function mahda_normalize_fa_text(string $text): string
{
    $text = strtr($text, ['ي'=>'ی','ى'=>'ی','ك'=>'ک','ۀ'=>'ه','ة'=>'ه','ؤ'=>'و','إ'=>'ا','أ'=>'ا']);
    $text = preg_replace('/[\x{064B}-\x{065F}\x{0670}\x{06D6}-\x{06ED}]/u','',$text) ?? $text;
    $text = str_replace(["\xE2\x80\x8C", "\xC2\xA0"], ' ', $text);
    $text = preg_replace('/\s+/u',' ',trim($text)) ?? trim($text);
    return $text;
}

function mahda_draft_payload(PDO $db, int $draftId, int $ownerId): ?array
{
    $stmt=$db->prepare('SELECT * FROM mahda_content_drafts WHERE id=? AND owner_id=? LIMIT 1');
    $stmt->execute([$draftId,$ownerId]); $row=$stmt->fetch();
    if(!$row) return null;
    $data=json_decode((string)($row['data_json']??''),true); if(!is_array($data))$data=[];
    mahda_recover_stale_media_v12($db,$draftId,$ownerId);
    $files=[];
    if(mahda_table_exists($db,'mahda_files') && mahda_column_exists($db,'mahda_files','draft_id')){
        $fs=$db->prepare("SELECT id,purpose,original_name,mime_type,size_bytes,status,processing_error,width,height,created_at FROM mahda_files WHERE draft_id=? AND owner_id=? ORDER BY purpose,id");
        $fs->execute([$draftId,$ownerId]);
        foreach($fs->fetchAll() as $f){$files[]=['id'=>(int)$f['id'],'purpose'=>(string)$f['purpose'],'name'=>(string)$f['original_name'],'mime'=>(string)$f['mime_type'],'size'=>(int)$f['size_bytes'],'status'=>(string)($f['status']??'ready'),'error'=>(string)($f['processing_error']??''),'width'=>$f['width']===null?null:(int)$f['width'],'height'=>$f['height']===null?null:(int)$f['height'],'url'=>'/mahda-api/index.php?action=file&id='.(int)$f['id']];}
    }
    return ['id'=>(int)$row['id'],'clientKey'=>(string)$row['client_key'],'category'=>(string)($row['category_id']??''),'profileId'=>$row['profile_id']===null?null:(int)$row['profile_id'],'step'=>(int)$row['current_step'],'version'=>(int)$row['version'],'data'=>$data,'files'=>$files,'completedContentId'=>$row['completed_content_id']===null?null:(int)$row['completed_content_id'],'updatedAt'=>(string)$row['updated_at']];
}

function mahda_private_upload_dir(): string
{
    return mahda_storage_adapter()->directory();
}

/** Primary private storage plus the legacy public folder kept for old files. */
function mahda_storage_dirs(): array
{
    return array_values(array_unique([mahda_private_upload_dir(), mahda_public_upload_path()]));
}

/**
 * A killed background worker must not leave a draft permanently blocked in
 * `processing`. The original upload remains in storage, so after 30 minutes
 * it is safe to expose that original again and record the processing failure.
 */
function mahda_recover_stale_media_v12(PDO $db, int $draftId, int $ownerId): int
{
    if ($draftId < 1 || $ownerId < 1 || !mahda_table_exists($db,'mahda_files')) return 0;
    $stmt=$db->prepare("SELECT id FROM mahda_files WHERE draft_id=? AND owner_id=? AND content_id IS NULL AND status='processing' AND COALESCE(updated_at,created_at)<DATE_SUB(NOW(),INTERVAL 30 MINUTE)");
    $stmt->execute([$draftId,$ownerId]);
    $ids=array_map('intval',$stmt->fetchAll(PDO::FETCH_COLUMN));
    if(!$ids) return 0;
    $markFile=$db->prepare("UPDATE mahda_files SET status='ready',processing_error='processing_timeout',updated_at=NOW() WHERE id=? AND status='processing'");
    $markJob=mahda_table_exists($db,'mahda_media_jobs')?$db->prepare("UPDATE mahda_media_jobs SET status='failed',finished_at=NOW(),error_message='processing_timeout' WHERE file_id=? AND status IN ('pending','processing')"):null;
    $recovered=0;
    foreach($ids as $id){$markFile->execute([$id]);if($markFile->rowCount()===1)$recovered++;if($markJob)$markJob->execute([$id]);}
    return $recovered;
}

function mahda_media_capabilities(): array
{
    $gd=function_exists('imagecreatetruecolor');
    $imagick=class_exists('Imagick');
    $ffmpegPath=trim((string)(getenv('MAHDA_FFMPEG_PATH') ?: ''));
    $ffprobePath=trim((string)(getenv('MAHDA_FFPROBE_PATH') ?: ''));
    $phpCli=trim((string)(getenv('MAHDA_PHP_CLI_PATH') ?: ''));
    $disabled=array_map('trim',explode(',',(string)ini_get('disable_functions')));
    $execOk=function_exists('exec') && !in_array('exec',$disabled,true);
    if($execOk){
        if($ffmpegPath==='' || !is_executable($ffmpegPath)){$out=[];$code=1;@exec('command -v ffmpeg 2>/dev/null',$out,$code);if($code===0&&!empty($out))$ffmpegPath=trim((string)$out[0]);}
        if($ffprobePath==='' || !is_executable($ffprobePath)){$out=[];$code=1;@exec('command -v ffprobe 2>/dev/null',$out,$code);if($code===0&&!empty($out))$ffprobePath=trim((string)$out[0]);}
        if($phpCli==='' || !is_executable($phpCli)){$out=[];$code=1;@exec('command -v php 2>/dev/null',$out,$code);if($code===0&&!empty($out))$phpCli=trim((string)$out[0]);}
    }
    $ffmpeg=$execOk && $ffmpegPath!=='' && is_executable($ffmpegPath);
    $ffprobe=$execOk && $ffprobePath!=='' && is_executable($ffprobePath);
    return ['gd'=>$gd,'imagick'=>$imagick,'ffmpeg'=>$ffmpeg,'ffmpegPath'=>$ffmpegPath,'ffprobe'=>$ffprobe,'ffprobePath'=>$ffprobePath,'backgroundTranscode'=>$ffmpeg&&$ffprobe,'phpCli'=>$phpCli,'exec'=>$execOk];
}

/** Fast metadata probe only; returns null when this host cannot run ffprobe. */
function mahda_probe_video_duration_v12(string $path): ?float
{
    $cap=mahda_media_capabilities();
    $ffprobe=(string)($cap['ffprobePath']??'');
    if(empty($cap['ffprobe'])||$ffprobe===''||!is_file($path))return null;
    $out=[];$code=1;
    @exec(escapeshellarg($ffprobe).' -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 '.escapeshellarg($path).' 2>&1',$out,$code);
    if($code!==0||!isset($out[0])||!is_numeric(trim((string)$out[0])))return null;
    $duration=(float)trim((string)$out[0]);
    return $duration>0?$duration:null;
}

function mahda_queue_media_processing_v12(PDO $db, int $fileId, string $purpose, string $mime): bool
{
    if($fileId<1||!in_array($purpose,['main_file','execution_video','execution_audio','attachment'],true))return false;
    if(!str_starts_with($mime,'video/')&&!str_starts_with($mime,'audio/'))return false;
    $cap=mahda_media_capabilities();
    if(empty($cap['ffmpeg'])) return false;

    // Videos already within the final 20 MB budget do not need a costly transcode.
    if(str_starts_with($mime,'video/')){
        $q=$db->prepare('SELECT size_bytes FROM mahda_files WHERE id=? LIMIT 1');$q->execute([$fileId]);
        $size=(int)($q->fetchColumn()?:0);
        $max=max(1024*1024,(int)(mahda_media_config()['video_output_max_bytes']??20*1024*1024));
        if($size>0&&$size<=$max)return false;
    }

    $db->prepare("INSERT INTO mahda_media_jobs(file_id,job_type,status) VALUES(?,?,'pending') ON DUPLICATE KEY UPDATE status=IF(status='done','done','pending'),error_message=NULL,finished_at=NULL")
       ->execute([$fileId,str_starts_with($mime,'video/')?'video_normalize':'audio_normalize']);
    $db->prepare("UPDATE mahda_files SET status='processing',processing_error=NULL,updated_at=NOW() WHERE id=?")->execute([$fileId]);

    $media = mahda_media_config();
    if (!empty($media['spawn_media_worker']) && !empty($cap['phpCli'])) {
        $php=(string)$cap['phpCli'];$worker=__DIR__.'/media-worker.php';
        $cmd=escapeshellarg($php).' '.escapeshellarg($worker).' '.(int)$fileId.' > /dev/null 2>&1 &';
        @exec($cmd);
    }
    return true;
}

function mahda_upload_allowed_map(string $purpose): array
{
    $image=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $video=['video/mp4'=>'mp4','video/webm'=>'webm','video/quicktime'=>'mov','video/mpeg'=>'mpeg'];
    $audio=['audio/webm'=>'webm','audio/mpeg'=>'mp3','audio/ogg'=>'ogg','application/ogg'=>'ogg','audio/mp4'=>'m4a','audio/wav'=>'wav','audio/x-wav'=>'wav'];
    $documents=['application/pdf'=>'pdf','application/zip'=>'zip','application/x-zip-compressed'=>'zip','application/msword'=>'doc','application/vnd.openxmlformats-officedocument.wordprocessingml.document'=>'docx'];
    if($purpose==='cover') return $image;
    if($purpose==='execution_video') return $video;
    if($purpose==='execution_audio') return $audio;
    if($purpose==='main_file') return $image+$video+$audio+$documents;
    if($purpose==='attachment') return $image+$video+$audio+$documents;
    return [];
}

function mahda_safe_remove_file_keys(array $row): void
{
    $storage = mahda_storage_adapter();
    foreach(['storage_key','original_storage_key','thumbnail_storage_key'] as $column){
        $key=basename((string)($row[$column]??'')); if($key===''||$key==='.'||$key==='..')continue;
        $storage->delete($key);
    }
}

function mahda_file_public_payload(array $row): array
{
    return ['id'=>(int)$row['id'],'purpose'=>(string)$row['purpose'],'name'=>(string)$row['original_name'],'mime'=>(string)$row['mime_type'],'size'=>(int)$row['size_bytes'],'status'=>(string)($row['status']??'ready'),'url'=>'/mahda-api/index.php?action=file&id='.(int)$row['id'],'width'=>isset($row['width'])&&$row['width']!==null?(int)$row['width']:null,'height'=>isset($row['height'])&&$row['height']!==null?(int)$row['height']:null];
}

function mahda_image_size_safe(string $path): array
{
    $info=@getimagesize($path); if(!is_array($info)||empty($info[0])||empty($info[1]))return [null,null];
    return [(int)$info[0],(int)$info[1]];
}

/** Best-effort image normalization. The source is replaced only after a valid output exists and is smaller. */
function mahda_optimize_image_file_v12(string $full, string $mime, string $purpose): void
{
    if (!is_file($full) || !in_array($mime, ['image/jpeg','image/png','image/webp'], true) || !function_exists('imagecreatetruecolor')) return;
    $target = max(32 * 1024, (int)(mahda_media_config()['image_target_bytes'] ?? 200 * 1024));
    // Browser-side preparation usually already delivers a <=200 KB image. Do not decode/re-encode it again on shared hosting.
    clearstatcache(true,$full);if((int)filesize($full)>0&&(int)filesize($full)<=$target)return;
    try {
        $src = null;
        if ($mime === 'image/jpeg' && function_exists('imagecreatefromjpeg')) $src = @imagecreatefromjpeg($full);
        elseif ($mime === 'image/png' && function_exists('imagecreatefrompng')) $src = @imagecreatefrompng($full);
        elseif ($mime === 'image/webp' && function_exists('imagecreatefromwebp')) $src = @imagecreatefromwebp($full);
        if (!$src) return;
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $exif = @exif_read_data($full);
            $orientation = is_array($exif) ? (int)($exif['Orientation'] ?? 1) : 1;
            $rotated = null;
            if ($orientation === 3) $rotated = @imagerotate($src, 180, 0);
            elseif ($orientation === 6) $rotated = @imagerotate($src, -90, 0);
            elseif ($orientation === 8) $rotated = @imagerotate($src, 90, 0);
            if ($rotated) { imagedestroy($src); $src = $rotated; }
        }
        $w=imagesx($src);$h=imagesy($src);if($w<1||$h<1){imagedestroy($src);return;}
        $max=$purpose==='cover'?1600:2200;
        $baseScale=min(1.0,$max/max($w,$h));
        $best=null;$bestSize=PHP_INT_MAX;
        $qualities=$mime==='image/png'?[9]:[82,74,66,58,50,42,34];
        foreach([1.0,.88,.76,.64,.54,.46,.38,.32,.26,.20,.16,.12] as $stepScale){
            $scale=$baseScale*$stepScale;
            $tw=max(96,(int)round($w*$scale));$th=max(96,(int)round($h*$scale));
            $dst=imagecreatetruecolor($tw,$th);
            if($mime==='image/png'||$mime==='image/webp'){imagealphablending($dst,false);imagesavealpha($dst,true);$transparent=imagecolorallocatealpha($dst,0,0,0,127);imagefilledrectangle($dst,0,0,$tw,$th,$transparent);}
            imagecopyresampled($dst,$src,0,0,0,0,$tw,$th,$w,$h);
            foreach($qualities as $quality){
                $tmp=$full.'.opt-'.bin2hex(random_bytes(5));$ok=false;
                if($mime==='image/jpeg')$ok=@imagejpeg($dst,$tmp,$quality);
                elseif($mime==='image/png')$ok=@imagepng($dst,$tmp,9);
                elseif($mime==='image/webp'&&function_exists('imagewebp'))$ok=@imagewebp($dst,$tmp,$quality);
                if(!$ok||!is_file($tmp)){@unlink($tmp);continue;}
                $size=(int)filesize($tmp);
                if($size>0&&$size<$bestSize){if($best)@unlink($best);$best=$tmp;$bestSize=$size;}else{@unlink($tmp);}
                if($size>0&&$size<=$target) break 2;
            }
            imagedestroy($dst);
        }
        if(isset($dst)&&is_resource($dst))@imagedestroy($dst);
        imagedestroy($src);
        if($best&&is_file($best)){
            @chmod($best,0640);
            if(!@rename($best,$full))@unlink($best);
        }
    } catch (Throwable $ignored) { /* caller enforces the final size */ }
}

function mahda_store_uploaded_v12(PDO $db, array $uploaded, string $purpose): array
{
    $error=(int)($uploaded['error']??UPLOAD_ERR_NO_FILE);
    if(in_array($error,[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE],true))throw new RuntimeException('file_too_large');
    if($error!==UPLOAD_ERR_OK || !is_uploaded_file((string)($uploaded['tmp_name']??'')))throw new RuntimeException($error===UPLOAD_ERR_NO_FILE?'file_required':'upload_failed');
    $policy=mahda_upload_policy($db,$purpose);$size=(int)($uploaded['size']??0);
    if($size<1||$size>(int)$policy['max_bytes'])throw new RuntimeException('file_too_large');
    $tmp=(string)$uploaded['tmp_name'];$mime='';
    if(function_exists('finfo_open')){$f=finfo_open(FILEINFO_MIME_TYPE);if($f){$mime=(string)finfo_file($f,$tmp);finfo_close($f);}}
    $clientMime=strtolower((string)($uploaded['type']??''));if($mime==='')$mime=$clientMime;
    $allowed=mahda_upload_allowed_map($purpose);if(!isset($allowed[$mime])&&isset($allowed[$clientMime]))$mime=$clientMime;
    $configured=array_map('strtolower',(array)($policy['mimes']??[]));
    if(!isset($allowed[$mime])||($configured&&!in_array(strtolower($mime),$configured,true)))throw new RuntimeException('file_type_not_allowed');
    $storage=mahda_storage_adapter();$storage->ensureReady();$dir=$storage->directory();
    $ext=$allowed[$mime];$key=bin2hex(random_bytes(24)).'.'.$ext;$full=$dir.'/'.$key;
    if(!move_uploaded_file($tmp,$full))throw new RuntimeException('storage_unavailable');chmod($full,0640);
    if(str_starts_with($mime,'video/')) {
        $cfg=mahda_media_config();$cap=mahda_media_capabilities();
        $maxOut=max(1024*1024,(int)($cfg['video_output_max_bytes']??20*1024*1024));
        $maxDuration=max(1,(int)($cfg['video_max_duration_seconds']??300));
        $duration=mahda_probe_video_duration_v12($full);
        if($duration!==null&&$duration>$maxDuration+0.25){@unlink($full);throw new RuntimeException('video_too_long');}
        // Shared hosting often has exec/ffmpeg disabled. Small ready-to-use videos must still upload.
        if((int)filesize($full)>$maxOut&&empty($cap['ffmpeg'])){@unlink($full);throw new RuntimeException('video_transcode_unavailable');}
    }
    if(str_starts_with($mime,'image/')) {
        mahda_optimize_image_file_v12($full,$mime,$purpose);
        $target=max(32*1024,(int)(mahda_media_config()['image_target_bytes']??200*1024));
        if((int)filesize($full)>$target){@unlink($full);throw new RuntimeException('image_compression_failed');}
    }
    if(in_array($mime,['application/zip','application/x-zip-compressed'],true)&&class_exists('ZipArchive')){
        $zip=new ZipArchive();$opened=$zip->open($full);if($opened===true){$danger=false;for($i=0;$i<$zip->numFiles;$i++){$name=strtolower((string)$zip->getNameIndex($i));if(preg_match('/\.(?:php[0-9]?|phtml|phar|cgi|pl|py|sh|exe|com|bat|cmd|msi|scr|jar)(?:$|[\/])/i',$name)){$danger=true;break;}}$zip->close();if($danger){@unlink($full);throw new RuntimeException('archive_contains_executable');}}
    }
    $width=$height=null;$thumbKey=null;
    if(str_starts_with($mime,'image/')){[$width,$height]=mahda_image_size_safe($full);if($purpose==='cover'&&$width&&$height){$ratio=$width/$height;if(abs($ratio-(4/3))>.035){@unlink($full);throw new RuntimeException('cover_ratio_required');}}
        // Generate a small thumbnail when GD is available. The source file is never deleted if processing fails.
        if(function_exists('imagecreatetruecolor')&&$width&&$height){try{$src=null;if($mime==='image/jpeg'&&function_exists('imagecreatefromjpeg'))$src=@imagecreatefromjpeg($full);elseif($mime==='image/png'&&function_exists('imagecreatefrompng'))$src=@imagecreatefrompng($full);elseif($mime==='image/webp'&&function_exists('imagecreatefromwebp'))$src=@imagecreatefromwebp($full);if($src){$tw=min(640,$width);$th=(int)round($tw*$height/$width);$dst=imagecreatetruecolor($tw,$th);imagecopyresampled($dst,$src,0,0,0,0,$tw,$th,$width,$height);$thumbKey='thumb-'.bin2hex(random_bytes(18)).'.jpg';$thumb=$dir.'/'.$thumbKey;if(!imagejpeg($dst,$thumb,82))$thumbKey=null;else chmod($thumb,0640);imagedestroy($dst);imagedestroy($src);}}catch(Throwable $ignored){$thumbKey=null;}}
    }
    try {
        $storage->putFile($key, $full);
        if ($thumbKey !== null) {
            $thumb = $dir . '/' . $thumbKey;
            if (is_file($thumb)) $storage->putFile($thumbKey, $thumb);
        }
    } catch (Throwable $e) {
        $storage->delete($key);
        if ($thumbKey !== null) $storage->delete($thumbKey);
        throw new RuntimeException('storage_unavailable');
    }
    return ['storage_key'=>$key,'original_storage_key'=>$key,'thumbnail_storage_key'=>$thumbKey,'mime'=>$mime,'size'=>(int)filesize($full),'sha256'=>hash_file('sha256',$full),'width'=>$width,'height'=>$height,'original_name'=>mahda_string(basename((string)($uploaded['name']??'file')),255)];
}


/** Infrastructure migration for national-ready request handling. */
function mahda_migrate_infrastructure_v24(PDO $db): void
{
    if (!mahda_table_exists($db, 'mahda_migrations')) return;
    $exists=$db->prepare('SELECT 1 FROM mahda_migrations WHERE version=24 LIMIT 1');
    $exists->execute(); if($exists->fetchColumn()) return;
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_rate_limits (
        bucket_key CHAR(64) NOT NULL,
        window_started DATETIME NOT NULL,
        hits INT UNSIGNED NOT NULL DEFAULT 0,
        expires_at DATETIME NOT NULL,
        PRIMARY KEY(bucket_key,window_started),
        KEY ix_rate_limit_expiry(expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    if (mahda_table_exists($db, 'mahda_settings')) {
        $seed=$db->prepare('INSERT INTO mahda_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=IF(setting_value IN (\'100\',\'150\'),VALUES(setting_value),setting_value)');
        $seed->execute(['upload_video_max_mb','150']);
        foreach ([['media_image_target_kb','200'],['media_video_output_max_mb','20'],['media_video_max_duration_seconds','300']] as [$k,$v]) {
            $db->prepare('INSERT IGNORE INTO mahda_settings(setting_key,setting_value) VALUES(?,?)')->execute([$k,$v]);
        }
    }
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(24)')->execute();
}

/** The one authoritative deploy-time migration sequence. */
function mahda_run_all_migrations(PDO $db): void
{
    mahda_seed_taxonomy($db);
    mahda_migrate_social($db);
    mahda_migrate_auth($db);
    mahda_migrate_admin($db);
    mahda_migrate_stage7($db);
    mahda_migrate_creator_studio($db);
    mahda_migrate_admin_stage14($db);
    mahda_migrate_admin_stage23($db);
    mahda_migrate_public_atlas($db);
    mahda_migrate_atlas_location_v11($db);
    mahda_migrate_content_registration_v12($db);
    mahda_migrate_profile_media_v13($db);
    mahda_migrate_contentchin_v1($db);
    mahda_migrate_infrastructure_v24($db);
    mahda_migrate_mobile_auth_v27($db);
    mahda_migrate_offline_sync_v28($db);
}

function mahda_redis_config(): array
{
    static $config;
    if (is_array($config ?? null)) return $config;
    $path = dirname(__DIR__) . '/config/redis.php';
    $config = is_file($path) ? require $path : ['enabled'=>false];
    if (!is_array($config)) $config = ['enabled'=>false];
    try {
        $private = mahda_config();
        if (isset($private['redis']) && is_array($private['redis'])) {
            $config = array_replace($config, $private['redis']);
        }
    } catch (Throwable $ignored) {}
    return $config;
}

function mahda_redis_client(): ?\Mahda\Core\Redis\RedisClient
{
    static $resolved = false;
    static $client = null;
    if ($resolved) return $client;
    $resolved = true;
    $client = \Mahda\Core\Redis\RedisClient::fromConfig(mahda_redis_config());
    return $client;
}

function mahda_client_ip(): string
{
    $candidate=(string)($_SERVER['REMOTE_ADDR']??'unknown');
    $trustProxy=in_array(strtolower((string)(getenv('MAHDA_TRUST_PROXY')?:'0')),['1','true','yes','on'],true);
    if($trustProxy){
        $forwarded=trim(explode(',',(string)($_SERVER['HTTP_X_FORWARDED_FOR']??''))[0]??'');
        if($forwarded!=='')$candidate=$forwarded;
    }
    return filter_var($candidate,FILTER_VALIDATE_IP)?$candidate:'unknown';
}

function mahda_enforce_rate_limit(PDO $db, string $action, int $limit, int $seconds): void
{
    if (!mahda_table_exists($db,'mahda_rate_limits')) return;
    $limiter=new \Mahda\Core\RateLimiter($db, mahda_redis_client());
    if(!$limiter->hit($action.'|'.mahda_client_ip(),$limit,$seconds)) {
        header('Retry-After: '.max(1,$seconds));
        mahda_json(['error'=>'rate_limited'],429);
    }
}
