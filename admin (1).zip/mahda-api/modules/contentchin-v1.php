<?php
declare(strict_types=1);

/**
 * محتواچین، مرحله اول: شروع سریع و ذخیره‌ی پیش‌نویس.
 *
 * این ماژول عمداً فقط داده‌های جدید و افزایشی می‌سازد. محتوای بانک، حساب‌ها
 * و جدول‌های ثبت محتوا را تغییر نمی‌دهد؛ مراحل چیدن، پیشنهاد هوشمند و انتشار
 * در نسخه‌های بعدی روی همین قرارداد توسعه پیدا می‌کنند.
 */

function mahda_contentchin_plan_types(): array
{
    return [
        ['id' => 'heiat', 'label' => 'برنامه هیئت', 'description' => 'یک مسیر تربیتی برای برنامه هیئت کودک', 'icon' => 'flag', 'color' => '#2f9b5b'],
        ['id' => 'mokeb', 'label' => 'برنامه موکب', 'description' => 'ایستگاه‌های کوتاه و آماده برای موکب', 'icon' => 'sparkles', 'color' => '#d68a2a'],
        ['id' => 'class', 'label' => 'کلاس تربیتی', 'description' => 'چند فعالیت هماهنگ برای کلاس', 'icon' => 'book', 'color' => '#4b83c8'],
        ['id' => 'family', 'label' => 'برنامه خانواده', 'description' => 'تجربه‌ای برای گفت‌وگو و همراهی خانواده', 'icon' => 'users', 'color' => '#7d66c4'],
        ['id' => 'celebration', 'label' => 'جشن', 'description' => 'ترکیب شاد و تربیتی برای یک جشن', 'icon' => 'gift', 'color' => '#df6e63'],
        ['id' => 'camp', 'label' => 'اردو', 'description' => 'مسیر مرحله‌به‌مرحله برای یک اردو', 'icon' => 'map', 'color' => '#4d9b91'],
        ['id' => 'free', 'label' => 'برنامه آزاد', 'description' => 'برنامه‌ای که خودت از صفر می‌چینی', 'icon' => 'wand', 'color' => '#b17b47'],
    ];
}

function mahda_contentchin_plan_type(string $id): ?array
{
    foreach (mahda_contentchin_plan_types() as $type) {
        if ($type['id'] === $id) {
            return $type;
        }
    }
    return null;
}

function mahda_migrate_contentchin_v1(PDO $db): void
{
    $exists = $db->prepare('SELECT 1 FROM mahda_migrations WHERE version=14 LIMIT 1');
    $exists->execute();
    if ($exists->fetchColumn()) {
        return;
    }

    // Do not add foreign keys here: several early Mahda installations have
    // legacy tables without the same engine/collation. Ownership is checked
    // explicitly in every API action instead.
    $db->exec("CREATE TABLE IF NOT EXISTS mahda_contentchin_plans (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        owner_user_id BIGINT UNSIGNED NOT NULL,
        owner_profile_id BIGINT UNSIGNED NOT NULL,
        client_key VARCHAR(80) NOT NULL,
        title VARCHAR(180) NOT NULL DEFAULT '',
        plan_type VARCHAR(40) NOT NULL,
        occasion_id BIGINT UNSIGNED NULL,
        age_group VARCHAR(20) NULL,
        suggested_duration_minutes SMALLINT UNSIGNED NULL,
        current_step TINYINT UNSIGNED NOT NULL DEFAULT 1,
        data_json LONGTEXT NULL,
        version INT UNSIGNED NOT NULL DEFAULT 1,
        status VARCHAR(24) NOT NULL DEFAULT 'draft',
        published_at DATETIME NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY ux_contentchin_owner_client(owner_user_id,client_key),
        KEY ix_contentchin_owner_status(owner_user_id,status,updated_at),
        KEY ix_contentchin_type(plan_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_contentchin_plan_items (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        plan_id BIGINT UNSIGNED NOT NULL,
        content_id BIGINT UNSIGNED NOT NULL,
        position INT UNSIGNED NOT NULL DEFAULT 0,
        note TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY ux_contentchin_plan_content(plan_id,content_id),
        KEY ix_contentchin_items_order(plan_id,position)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_contentchin_plan_blocks (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        plan_id BIGINT UNSIGNED NOT NULL,
        block_type VARCHAR(24) NOT NULL,
        title VARCHAR(180) NOT NULL DEFAULT '',
        body_text LONGTEXT NULL,
        media_id BIGINT UNSIGNED NULL,
        position INT UNSIGNED NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY ix_contentchin_blocks_order(plan_id,position)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS mahda_contentchin_templates (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(80) NOT NULL,
        title VARCHAR(180) NOT NULL,
        plan_type VARCHAR(40) NOT NULL,
        description VARCHAR(255) NOT NULL DEFAULT '',
        definition_json LONGTEXT NOT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY ux_contentchin_template_slug(slug),
        KEY ix_contentchin_template_active(is_active,sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // These are reusable empty skeletons, not user content or fake accounts.
    $templates = [
        ['heiat-45', 'برنامه ۴۵ دقیقه‌ای هیئت کودک', 'heiat', 'اسکلت آماده برای شروع، قصه، فعالیت و جمع‌بندی', [
            ['kind' => 'content', 'category' => 'game', 'label' => 'بازی شروع'],
            ['kind' => 'content', 'category' => 'story', 'label' => 'قصه'],
            ['kind' => 'content', 'category' => 'activity', 'label' => 'فعالیت'],
            ['kind' => 'personal_text', 'label' => 'جمع‌بندی مربی'],
        ], 10],
        ['mokeb-quick', 'برنامه کوتاه موکب', 'mokeb', 'ورود، سرگرمی، قصه و کار هنری در یک مسیر کوتاه', [
            ['kind' => 'content', 'category' => 'activity', 'label' => 'ورود و آشنایی'],
            ['kind' => 'content', 'category' => 'game', 'label' => 'سرگرمی'],
            ['kind' => 'content', 'category' => 'story', 'label' => 'قصه'],
            ['kind' => 'content', 'category' => 'craft', 'label' => 'کار هنری'],
        ], 20],
        ['celebration-simple', 'جشن مناسبتی', 'celebration', 'بازی، نمایش، سرود و یک پایان خاطره‌انگیز', [
            ['kind' => 'content', 'category' => 'game', 'label' => 'بازی'],
            ['kind' => 'content', 'category' => 'theater', 'label' => 'نمایش'],
            ['kind' => 'content', 'category' => 'song', 'label' => 'سرود'],
            ['kind' => 'personal_text', 'label' => 'پایان و هدیه'],
        ], 30],
        ['family-conversation', 'برنامه گفت‌وگوی خانواده', 'family', 'قصه، گفت‌وگو و یک فعالیت مشترک', [
            ['kind' => 'content', 'category' => 'story', 'label' => 'قصه'],
            ['kind' => 'personal_text', 'label' => 'گفت‌وگوی خانواده'],
            ['kind' => 'content', 'category' => 'activity', 'label' => 'فعالیت مشترک'],
        ], 40],
    ];
    $insert = $db->prepare('INSERT IGNORE INTO mahda_contentchin_templates(slug,title,plan_type,description,definition_json,sort_order) VALUES(?,?,?,?,?,?)');
    foreach ($templates as [$slug, $title, $planType, $description, $definition, $sort]) {
        $insert->execute([$slug, $title, $planType, $description, json_encode($definition, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $sort]);
    }
    $db->prepare('INSERT IGNORE INTO mahda_migrations(version) VALUES(14)')->execute();
}

function mahda_contentchin_templates(PDO $db): array
{
    if (!mahda_table_exists($db, 'mahda_contentchin_templates')) {
        return [];
    }
    $rows = $db->query('SELECT id,slug,title,plan_type,description,definition_json FROM mahda_contentchin_templates WHERE is_active=1 ORDER BY sort_order,id')->fetchAll();
    $items = [];
    foreach ($rows as $row) {
        $definition = json_decode((string)($row['definition_json'] ?? ''), true);
        $items[] = [
            'id' => (int)$row['id'],
            'slug' => (string)$row['slug'],
            'title' => (string)$row['title'],
            'planType' => (string)$row['plan_type'],
            'description' => (string)$row['description'],
            'definition' => is_array($definition) ? $definition : [],
        ];
    }
    return $items;
}

function mahda_contentchin_occasions(PDO $db): array
{
    if (!mahda_table_exists($db, 'mahda_occasions')) {
        return [];
    }
    $rows = $db->query('SELECT id,label,occasion_group FROM mahda_occasions WHERE is_active=1 ORDER BY occasion_group,label')->fetchAll();
    return array_map(static function (array $row): array {
        return [
            'id' => (int)$row['id'],
            'label' => (string)$row['label'],
            'group' => (string)($row['occasion_group'] ?? 'general'),
        ];
    }, $rows);
}

function mahda_contentchin_age_group(mixed $value): ?string
{
    $value = trim((string)$value);
    return in_array($value, ['4-6', '7-10'], true) ? $value : null;
}

function mahda_contentchin_duration(mixed $value): ?int
{
    $minutes = (int)$value;
    return in_array($minutes, [30, 60, 90], true) ? $minutes : null;
}

function mahda_contentchin_client_key(mixed $value): string
{
    $value = trim((string)$value);
    if ($value === '' || strlen($value) > 80 || preg_match('/^[A-Za-z0-9._:-]+$/', $value) !== 1) {
        return '';
    }
    return $value;
}

function mahda_contentchin_plan_payload(PDO $db, array $row, bool $includeData = true): array
{
    $data = [];
    if ($includeData) {
        $decoded = json_decode((string)($row['data_json'] ?? ''), true);
        $data = is_array($decoded) ? $decoded : [];
    }
    return [
        'id' => (int)$row['id'],
        'clientKey' => (string)$row['client_key'],
        'title' => (string)$row['title'],
        'planType' => (string)$row['plan_type'],
        'occasionId' => $row['occasion_id'] === null ? null : (int)$row['occasion_id'],
        'ageGroup' => $row['age_group'] === null ? null : (string)$row['age_group'],
        'suggestedDuration' => $row['suggested_duration_minutes'] === null ? null : (int)$row['suggested_duration_minutes'],
        'currentStep' => (int)$row['current_step'],
        'version' => (int)$row['version'],
        'status' => (string)$row['status'],
        'data' => $data,
        'createdAt' => (string)($row['created_at'] ?? ''),
        'updatedAt' => (string)($row['updated_at'] ?? ''),
    ];
}

function mahda_contentchin_find_plan(PDO $db, int $planId, int $ownerId): ?array
{
    $stmt = $db->prepare('SELECT id,owner_user_id,owner_profile_id,client_key,title,plan_type,occasion_id,age_group,suggested_duration_minutes,current_step,data_json,version,status,created_at,updated_at FROM mahda_contentchin_plans WHERE id=? AND owner_user_id=? LIMIT 1');
    $stmt->execute([$planId, $ownerId]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

function mahda_contentchin_validate_occasion(PDO $db, ?int $occasionId): ?int
{
    if ($occasionId === null || $occasionId < 1) {
        return null;
    }
    $stmt = $db->prepare('SELECT id FROM mahda_occasions WHERE id=? AND is_active=1 LIMIT 1');
    $stmt->execute([$occasionId]);
    return $stmt->fetchColumn() === false ? null : $occasionId;
}

function mahda_contentchin_profile_complete(PDO $db, array $user): bool
{
    if (!empty($user['guest']) || (int)($user['id'] ?? 0) < 1 || (int)($user['profile_id'] ?? 0) < 1) {
        return false;
    }
    $stmt = $db->prepare('SELECT kind,name,city,profile_data_json FROM mahda_profiles WHERE id=? AND owner_id=? LIMIT 1');
    $stmt->execute([(int)$user['profile_id'], (int)$user['id']]);
    $profile = $stmt->fetch();
    if (!is_array($profile)) {
        return false;
    }
    $profileData = json_decode((string)($profile['profile_data_json'] ?? ''), true);
    return mahda_profile_complete(is_array($profileData) ? $profileData : [], (string)$profile['kind'], (string)($user['display_name'] ?? ''), (string)$profile['name'], (string)($profile['city'] ?? ''));
}

function mahda_contentchin_dispatch(PDO $db, string $action): bool
{
    if (!in_array($action, ['contentchin_bootstrap_v1', 'contentchin_plan_start_v1', 'contentchin_plan_save_v1', 'contentchin_plan_get_v1'], true)) {
        return false;
    }

    if ($action === 'contentchin_bootstrap_v1' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $user = mahda_current_user($db, true);
        $drafts = [];
        $profileComplete = mahda_contentchin_profile_complete($db, $user);
        if (empty($user['guest'])) {
            $stmt = $db->prepare("SELECT id,client_key,title,plan_type,occasion_id,age_group,suggested_duration_minutes,current_step,version,status,created_at,updated_at FROM mahda_contentchin_plans WHERE owner_user_id=? AND status='draft' ORDER BY updated_at DESC LIMIT 30");
            $stmt->execute([(int)$user['id']]);
            foreach ($stmt->fetchAll() as $row) {
                $drafts[] = mahda_contentchin_plan_payload($db, $row, false);
            }
        }
        mahda_json([
            'ok' => true,
            'csrf' => mahda_csrf(),
            'authenticated' => empty($user['guest']) ? true : false,
            'canCreate' => empty($user['guest']) && $profileComplete,
            'user' => empty($user['guest']) ? ['id' => (int)$user['id'], 'profileId' => (int)$user['profile_id'], 'displayName' => (string)$user['display_name'], 'role' => (string)$user['role']] : null,
            'planTypes' => mahda_contentchin_plan_types(),
            'occasions' => mahda_contentchin_occasions($db),
            'templates' => mahda_contentchin_templates($db),
            'drafts' => $drafts,
        ]);
    }

    if ($action === 'contentchin_plan_start_v1' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = mahda_request_data();
        mahda_require_csrf($data);
        $user = mahda_require_complete_member($db);
        $clientKey = mahda_contentchin_client_key($data['clientKey'] ?? '');
        $planType = trim((string)($data['planType'] ?? ''));
        $type = mahda_contentchin_plan_type($planType);
        if ($clientKey === '') {
            mahda_json(['error' => 'invalid_client_key'], 422);
        }
        if ($type === null) {
            mahda_json(['error' => 'invalid_plan_type'], 422);
        }
        $title = mahda_string($data['title'] ?? '', 180);
        $occasionId = mahda_contentchin_validate_occasion($db, isset($data['occasionId']) && $data['occasionId'] !== '' ? (int)$data['occasionId'] : null);
        if (isset($data['occasionId']) && $data['occasionId'] !== '' && $occasionId === null) {
            mahda_json(['error' => 'invalid_occasion'], 422);
        }
        $ageGroup = mahda_contentchin_age_group($data['ageGroup'] ?? null);
        if (($data['ageGroup'] ?? '') !== '' && $ageGroup === null) {
            mahda_json(['error' => 'invalid_age_group'], 422);
        }
        $duration = mahda_contentchin_duration($data['suggestedDuration'] ?? null);
        if (($data['suggestedDuration'] ?? '') !== '' && $duration === null) {
            mahda_json(['error' => 'invalid_duration'], 422);
        }
        $initialData = [
            'title' => $title,
            'planType' => $planType,
            'occasionId' => $occasionId,
            'ageGroup' => $ageGroup,
            'suggestedDuration' => $duration,
            'currentStep' => 1,
        ];
        $stmt = $db->prepare("INSERT INTO mahda_contentchin_plans(owner_user_id,owner_profile_id,client_key,title,plan_type,occasion_id,age_group,suggested_duration_minutes,current_step,data_json,version,status) VALUES(?,?,?,?,?,?,?,?,?,?,1,'draft') ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id), owner_profile_id=VALUES(owner_profile_id), updated_at=CURRENT_TIMESTAMP");
        $stmt->execute([(int)$user['id'], (int)$user['profile_id'], $clientKey, $title, $planType, $occasionId, $ageGroup, $duration, 1, json_encode($initialData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        $planId = (int)$db->lastInsertId();
        $row = mahda_contentchin_find_plan($db, $planId, (int)$user['id']);
        if (!$row) {
            mahda_json(['error' => 'plan_not_saved'], 500);
        }
        mahda_json(['ok' => true, 'plan' => mahda_contentchin_plan_payload($db, $row)], 201);
    }

    if ($action === 'contentchin_plan_save_v1' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = mahda_request_data();
        mahda_require_csrf($data);
        $user = mahda_require_complete_member($db);
        $planId = max(0, (int)($data['planId'] ?? 0));
        $version = max(0, (int)($data['version'] ?? 0));
        if ($planId < 1 || $version < 1 || !is_array($data['plan'] ?? null)) {
            mahda_json(['error' => 'invalid_plan_payload'], 422);
        }
        $current = mahda_contentchin_find_plan($db, $planId, (int)$user['id']);
        if (!$current) {
            mahda_json(['error' => 'plan_not_found'], 404);
        }
        if ((string)$current['status'] !== 'draft') {
            mahda_json(['error' => 'plan_not_editable'], 409);
        }
        $plan = $data['plan'];
        $planType = trim((string)($plan['planType'] ?? $current['plan_type']));
        if (mahda_contentchin_plan_type($planType) === null) {
            mahda_json(['error' => 'invalid_plan_type'], 422);
        }
        $title = mahda_string($plan['title'] ?? '', 180);
        $occasionId = mahda_contentchin_validate_occasion($db, isset($plan['occasionId']) && $plan['occasionId'] !== '' ? (int)$plan['occasionId'] : null);
        if (($plan['occasionId'] ?? '') !== '' && $occasionId === null) {
            mahda_json(['error' => 'invalid_occasion'], 422);
        }
        $ageGroup = mahda_contentchin_age_group($plan['ageGroup'] ?? null);
        if (($plan['ageGroup'] ?? '') !== '' && $ageGroup === null) {
            mahda_json(['error' => 'invalid_age_group'], 422);
        }
        $duration = mahda_contentchin_duration($plan['suggestedDuration'] ?? null);
        if (($plan['suggestedDuration'] ?? '') !== '' && $duration === null) {
            mahda_json(['error' => 'invalid_duration'], 422);
        }
        $currentStep = min(7, max(1, (int)($plan['currentStep'] ?? $current['current_step'])));
        $safeData = [
            'title' => $title,
            'planType' => $planType,
            'occasionId' => $occasionId,
            'ageGroup' => $ageGroup,
            'suggestedDuration' => $duration,
            'currentStep' => $currentStep,
        ];
        $updated = $db->prepare('UPDATE mahda_contentchin_plans SET title=?,plan_type=?,occasion_id=?,age_group=?,suggested_duration_minutes=?,current_step=?,data_json=?,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND owner_user_id=? AND status=\'draft\' AND version=?');
        $updated->execute([$title, $planType, $occasionId, $ageGroup, $duration, $currentStep, json_encode($safeData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $planId, (int)$user['id'], $version]);
        if ($updated->rowCount() < 1) {
            $latest = mahda_contentchin_find_plan($db, $planId, (int)$user['id']);
            if (!$latest) {
                mahda_json(['error' => 'plan_not_found'], 404);
            }
            mahda_json(['error' => 'plan_conflict', 'plan' => mahda_contentchin_plan_payload($db, $latest)], 409);
        }
        $fresh = mahda_contentchin_find_plan($db, $planId, (int)$user['id']);
        mahda_json(['ok' => true, 'plan' => mahda_contentchin_plan_payload($db, $fresh ?: $current)]);
    }

    if ($action === 'contentchin_plan_get_v1' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $planId = max(0, (int)($_GET['id'] ?? 0));
        if ($planId < 1) {
            mahda_json(['error' => 'plan_not_found'], 404);
        }
        $user = mahda_current_user($db, true);
        if (!empty($user['guest'])) {
            mahda_json(['error' => 'plan_not_found'], 404);
        }
        $row = mahda_contentchin_find_plan($db, $planId, (int)$user['id']);
        if (!$row) {
            mahda_json(['error' => 'plan_not_found'], 404);
        }
        mahda_json(['ok' => true, 'plan' => mahda_contentchin_plan_payload($db, $row)]);
    }

    // A known action with an unsupported HTTP method should be explicit.
    mahda_json(['error' => 'method_not_allowed'], 405);
}
