<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/bootstrap.php';

$fileId = max(0, (int)($argv[1] ?? 0));

function mahda_probe_duration(string $ffprobe, string $source): float
{
    if ($ffprobe === '') throw new RuntimeException('ffprobe_unavailable');
    $out=[];$code=1;
    $cmd=escapeshellarg($ffprobe).' -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 '.escapeshellarg($source).' 2>&1';
    exec($cmd,$out,$code);
    if($code!==0||!isset($out[0])||!is_numeric(trim((string)$out[0]))) throw new RuntimeException('media_duration_unreadable');
    return (float)trim((string)$out[0]);
}

function mahda_encode_video(string $ffmpeg, string $source, string $out, float $duration, int $maxBytes, int $maxHeight, int $audioKbps, float $factor=1.0): void
{
    // Keep a safety margin for MP4 container overhead and bitrate variance.
    $budgetBits=max(1,($maxBytes-700*1024))*8;
    $totalKbps=max(160,(int)floor(($budgetBits/max(1.0,$duration))/1000*$factor));
    $audioKbps=max(32,min($audioKbps,96));
    $videoKbps=max(96,$totalKbps-$audioKbps-16);
    $maxRate=max($videoKbps,(int)floor($videoKbps*1.10));
    $buf=max(256,$maxRate*2);
    $vf="scale='min(iw,960)':-2:force_original_aspect_ratio=decrease,scale=-2:'min(ih,".$maxHeight.")':force_original_aspect_ratio=decrease";
    $cmd=escapeshellarg($ffmpeg).' -y -hide_banner -loglevel error -i '.escapeshellarg($source)
        .' -map_metadata -1 -c:v libx264 -preset veryfast -pix_fmt yuv420p -b:v '.$videoKbps.'k -maxrate '.$maxRate.'k -bufsize '.$buf.'k'
        .' -vf '.escapeshellarg($vf).' -c:a aac -b:a '.$audioKbps.'k -ac 2 -movflags +faststart '.escapeshellarg($out).' 2>&1';
    $lines=[];$code=1;exec($cmd,$lines,$code);
    if($code!==0||!is_file($out)||filesize($out)<1){@unlink($out);throw new RuntimeException('ffmpeg_failed');}
}

try {
    $db=mahda_db();

    if($fileId>0){
        $q=$db->prepare("SELECT id,file_id FROM mahda_media_jobs WHERE file_id=? AND status='pending' ORDER BY id LIMIT 1");
        $q->execute([$fileId]);
    } else {
        $q=$db->query("SELECT id,file_id FROM mahda_media_jobs WHERE status='pending' ORDER BY created_at,id LIMIT 1");
    }
    $job=$q->fetch();
    if(!$job) exit(0);
    $jobId=(int)$job['id'];$fileId=(int)$job['file_id'];

    // Atomic claim: only one worker can turn this specific pending row into processing.
    $claim=$db->prepare("UPDATE mahda_media_jobs SET status='processing',attempts=attempts+1,started_at=NOW(),finished_at=NULL WHERE id=? AND status='pending'");
    $claim->execute([$jobId]);
    if($claim->rowCount()!==1) exit(0);

    $st=$db->prepare("SELECT * FROM mahda_files WHERE id=? AND status='processing' LIMIT 1");
    $st->execute([$fileId]);$f=$st->fetch();if(!$f)throw new RuntimeException('file_not_processing');
    $source=mahda_existing_upload_path((string)$f['storage_key']);if(!$source)throw new RuntimeException('source_missing');

    $cap=mahda_media_capabilities();$ff=(string)($cap['ffmpegPath']??'');$ffprobe=(string)($cap['ffprobePath']??'');
    if($ff==='')throw new RuntimeException('ffmpeg_unavailable');
    $storage=mahda_storage_adapter();$storage->ensureReady();$dir=$storage->directory();
    $isVideo=str_starts_with((string)$f['mime_type'],'video/');
    $outKey=bin2hex(random_bytes(24)).($isVideo?'.mp4':'.mp3');$out=$dir.'/'.$outKey;

    if($isVideo){
        $cfg=mahda_media_config();
        $maxDuration=max(1,(int)($cfg['video_max_duration_seconds']??300));
        $maxBytes=max(1024*1024,(int)($cfg['video_output_max_bytes']??20*1024*1024));
        $maxHeight=max(240,(int)($cfg['video_max_height']??540));
        $audioKbps=max(32,(int)($cfg['video_audio_kbps']??64));
        $duration=mahda_probe_duration($ffprobe,$source);
        if($duration<=0||$duration>$maxDuration+0.25)throw new RuntimeException('video_too_long');

        mahda_encode_video($ff,$source,$out,$duration,$maxBytes,$maxHeight,$audioKbps,1.0);
        if((int)filesize($out)>$maxBytes){
            @unlink($out);
            mahda_encode_video($ff,$source,$out,$duration,$maxBytes,$maxHeight,$audioKbps,0.86);
        }
        if((int)filesize($out)>$maxBytes){@unlink($out);throw new RuntimeException('video_output_too_large');}
    } else {
        $cmd=escapeshellarg($ff).' -y -hide_banner -loglevel error -i '.escapeshellarg($source).' -map_metadata -1 -vn -c:a libmp3lame -b:a 96k '.escapeshellarg($out).' 2>&1';
        $lines=[];$code=1;exec($cmd,$lines,$code);if($code!==0||!is_file($out)||filesize($out)<1){@unlink($out);throw new RuntimeException('ffmpeg_failed');}
    }

    @chmod($out,0640);$newMime=$isVideo?'video/mp4':'audio/mpeg';$outSize=(int)filesize($out);$sha=hash_file('sha256',$out);
    $storage->putFile($outKey, $out);
    $db->prepare("UPDATE mahda_files SET original_storage_key=COALESCE(NULLIF(original_storage_key,''),storage_key),storage_key=?,mime_type=?,size_bytes=?,sha256=?,status='ready',processing_error=NULL,updated_at=NOW() WHERE id=?")
       ->execute([$outKey,$newMime,$outSize,$sha,$fileId]);
    $db->prepare("UPDATE mahda_media_jobs SET status='done',finished_at=NOW(),error_message=NULL WHERE id=?")->execute([$jobId]);
    $draftId=(int)($f['draft_id']??0);if($draftId>0){$dv=$db->prepare('SELECT version FROM mahda_content_drafts WHERE id=? AND owner_id=?');$dv->execute([$draftId,(int)$f['owner_id']]);mahda_record_sync_change($db,(int)$f['owner_id'],'content_draft',$draftId,(int)($dv->fetchColumn()?:0));}
    exit(0);
} catch(Throwable $e) {
    try {
        if(isset($storage,$outKey)) $storage->delete((string)$outKey);
        if(isset($db,$jobId,$fileId)){
            $message=substr($e->getMessage(),0,180);
            $db->prepare("UPDATE mahda_files SET status='failed',processing_error=?,updated_at=NOW() WHERE id=?")->execute([$message,$fileId]);
            $db->prepare("UPDATE mahda_media_jobs SET status='failed',finished_at=NOW(),error_message=? WHERE id=?")->execute([$message,$jobId]);
            if(isset($f)&&is_array($f)){$draftId=(int)($f['draft_id']??0);if($draftId>0){$dv=$db->prepare('SELECT version FROM mahda_content_drafts WHERE id=? AND owner_id=?');$dv->execute([$draftId,(int)$f['owner_id']]);mahda_record_sync_change($db,(int)$f['owner_id'],'content_draft',$draftId,(int)($dv->fetchColumn()?:0));}}
        }
    } catch(Throwable $ignored) {}
    fwrite(STDERR, ($e->getMessage() ?: 'media_worker_failed')."\n");
    exit(1);
}
