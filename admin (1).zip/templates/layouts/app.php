<?php
declare(strict_types=1);

$pageTitle = htmlspecialchars((string)($title ?? 'مهدا'), ENT_QUOTES, 'UTF-8');
$pageContent = (string)($content ?? '');
?><!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $pageTitle ?></title>
</head>
<body><?= $pageContent ?></body>
</html>

