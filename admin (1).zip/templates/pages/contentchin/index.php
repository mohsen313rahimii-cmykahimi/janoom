<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta name="mahda-build" content="20260916-php-modular-v3">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#f7faf4">
<meta name="description" content="محتواچین مهدا؛ ساخت برنامه تربیتی آماده اجرا">
<link rel="icon" href="/favicon.svg">
<style>@font-face{font-family:Vazirmatn;src:url('/assets/vazirmatn-arabic-wght-normal-Cafbb7Zc.woff2') format('woff2');font-weight:100 900;font-style:normal;font-display:swap}</style>
<link rel="stylesheet" href="/assets/mahda-shell-v3.css?v=8">
<link rel="stylesheet" href="/assets/contentchin-v2.css?v=2">
<script src="/assets/mahda-runtime.js?v=20260916-php-modular-v3" defer></script>
<title>محتواچین مهدا</title>
</head>
<body>
<div class="page">
  <div class="scene-left" aria-hidden="true"><div class="left-logo-wrap"><img class="left-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt=""><div class="left-slogan">نسل فردا،<br>با مهدا روشن‌تر</div></div><img class="left-child" src="/assets/child-garden-DajGLj7z.webp" alt=""></div>
  <div class="scene-right" aria-hidden="true"><img class="right-garden" src="/assets/persian-garden-CJRlRJZ1.webp" alt=""><img class="right-simorgh" src="/assets/simorgh-BobLCgG-.webp" alt=""></div>
  <div class="app-shell chin-shell">
    <header class="chin-header">
      <div class="chin-head-left"><a href="/" aria-label="صفحه اصلی مهدا"><img class="chin-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt="مهدا"></a></div>
      <div class="chin-head-title"><strong>محتواچین مهدا</strong><small>ساخت برنامه تربیتی آماده اجرا</small></div>
      <div class="chin-head-right"><button class="chin-back" type="button" data-fallback="/" aria-label="بازگشت"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="m11 6-6 6 6 6"/></svg></button></div>
    </header>
    <main class="chin-main" id="contentChinMain">
      <section class="chin-hero">
        <img class="chin-hero-art" src="/assets/child-garden-DajGLj7z.webp" alt="">
        <div class="chin-hero-copy"><span class="chin-kicker"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3 2.1 5.2L19 10l-4.9 1.8L12 17l-2.1-5.2L5 10l4.9-1.8Z"/><path d="m19 15 .7 1.7 1.7.7-1.7.7L19 20l-.7-1.9-1.7-.7 1.7-.7Z"/></svg>یک مسیر برای امشب</span><h1>برنامه‌ات را<br>با محتواچین بچین</h1><p>چند تجربه خوب مهدا را کنار هم بگذار و یک برنامه کامل و آماده اجرا بساز.</p><a class="chin-primary" href="/contentchin/new">شروع ساخت برنامه <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg></a></div>
      </section>

      <section class="chin-section" aria-labelledby="templatesTitle">
        <div class="chin-section-head"><div class="chin-heading"><span class="chin-heading-icon"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h16M4 12h16M4 18h10"/><circle cx="18" cy="18" r="3"/></svg></span><div><h2 id="templatesTitle">شروع سریع</h2><p>یک اسکلت آماده انتخاب کن و بعد محتواهایت را بچین</p></div></div></div>
        <div class="chin-template-grid" id="templateGrid"><div class="chin-state" style="grid-column:1/-1"><div><div class="chin-spinner"></div>در حال دریافت مسیرهای آماده مهدا…</div></div></div>
      </section>

      <section class="chin-section drafts" aria-labelledby="draftsTitle">
        <div class="chin-section-head"><div class="chin-heading"><span class="chin-heading-icon"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg></span><div><h2 id="draftsTitle">پیش‌نویس‌های من</h2><p>برنامه‌هایی که هنوز در حال ساخت هستند</p></div></div><a class="chin-section-link" href="/contentchin/new">برنامه تازه +</a></div>
        <div id="draftList"><div class="chin-state"><div><div class="chin-spinner"></div>در حال بررسی پیش‌نویس‌های تو…</div></div></div>
      </section>
    </main>
    <nav class="bottom-nav" aria-label="ناوبری اصلی">
      <a class="nav-item" href="/"><svg viewBox="0 0 24 24"><path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/></svg><span>خانه</span></a>
      <a class="nav-item" href="/search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg><span>جستجو</span></a>
      <a class="nav-item nav-showcase" href="/showcase"><span class="showcase-bubble"><svg viewBox="0 0 24 24"><path d="m12 2.8 2.75 5.57 6.15.9-4.45 4.34 1.05 6.12L12 16.84l-5.5 2.89-1.05-6.12L3.1 9.27l6.15-.9z"/></svg></span><span>ویترین</span></a>
      <a class="nav-item" href="/shelf"><svg viewBox="0 0 24 24"><path d="M4 5h6l2 2h8v12H4z"/><path d="M4 9h16"/></svg><span>قفسه</span></a>
      <a class="nav-item" href="/profile"><svg viewBox="0 0 24 24"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg><span>حساب</span></a>
    </nav>
  </div>
</div>
<div class="toast" id="toast" role="status"></div>
<script src="/assets/contentchin-v2.js?v=2" defer></script>
</body>
</html>
