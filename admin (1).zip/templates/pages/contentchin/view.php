<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta name="mahda-build" content="20260916-php-modular-v3">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#f7faf4">
<link rel="icon" href="/favicon.svg">
<style>@font-face{font-family:Vazirmatn;src:url('/assets/vazirmatn-arabic-wght-normal-Cafbb7Zc.woff2') format('woff2');font-weight:100 900;font-style:normal;font-display:swap}</style>
<link rel="stylesheet" href="/assets/mahda-shell-v3.css?v=8">
<link rel="stylesheet" href="/assets/contentchin-v2.css?v=2">
<script src="/assets/mahda-runtime.js?v=20260916-php-modular-v3" defer></script>
<title>برنامه مهدا</title>
</head>
<body>
<div class="page">
  <div class="scene-left" aria-hidden="true"><div class="left-logo-wrap"><img class="left-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt=""><div class="left-slogan">نسل فردا،<br>با مهدا روشن‌تر</div></div><img class="left-child" src="/assets/child-garden-DajGLj7z.webp" alt=""></div>
  <div class="scene-right" aria-hidden="true"><img class="right-garden" src="/assets/persian-garden-CJRlRJZ1.webp" alt=""><img class="right-simorgh" src="/assets/simorgh-BobLCgG-.webp" alt=""></div>
  <div class="app-shell chin-shell">
    <header class="chin-header">
      <div class="chin-head-left"><a href="/" aria-label="صفحه اصلی مهدا"><img class="chin-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt="مهدا"></a></div>
      <div class="chin-head-title"><strong>پیش‌نمایش برنامه</strong><small>محتواچین مهدا</small></div>
      <div class="chin-head-right"><button class="chin-back" type="button" data-fallback="/contentchin" aria-label="بازگشت"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="m11 6-6 6 6 6"/></svg></button></div>
    </header>
    <main class="chin-main" id="contentChinViewMain"><section id="planView" class="chin-view-card"><div class="chin-state"><div><div class="chin-spinner"></div>در حال دریافت برنامه…</div></div></section></main>
    <nav class="bottom-nav" aria-label="ناوبری اصلی">
      <a class="nav-item" href="/"><svg viewBox="0 0 24 24"><path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/></svg><span>خانه</span></a>
      <a class="nav-item" href="/search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg><span>جستجو</span></a>
      <a class="nav-item nav-showcase" href="/showcase"><span class="showcase-bubble"><svg viewBox="0 0 24 24"><path d="m12 2.8 2.75 5.57 6.15.9-4.45 4.34 1.05 6.12L12 16.84l-5.5 2.89-1.05-6.12L3.1 9.27l6.15-.9z"/></svg></span><span>ویترین</span></a>
      <a class="nav-item" href="/shelf"><svg viewBox="0 0 24 24"><path d="M4 5h6l2 2h8v12H4z"/><path d="M4 9h16"/></svg><span>قفسه</span></a>
      <a class="nav-item" href="/profile"><svg viewBox="0 0 24 24"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg><span>حساب</span></a>
    </nav>
  </div>
</div>
<div class="toast" id="toast" role="status"></div>
<script src="/assets/contentchin-v2.js?v=2" defer></script>
</body>
</html>
