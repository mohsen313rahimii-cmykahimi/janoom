<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta name="mahda-build" content="20260917-account-onboarding-fix">
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <meta name="theme-color" content="#f7faf4" />
  <meta name="description" content="بانک محتوای مهدا" />
  <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
  <link rel="manifest" href="/manifest.webmanifest" />
  <title>بانک محتوای مهدا</title>
  <style>
    @font-face{font-family:Vazirmatn;src:url('/assets/vazirmatn-arabic-wght-normal-Cafbb7Zc.woff2') format('woff2');font-weight:100 900;font-style:normal;font-display:swap}
  </style>
  <link rel="stylesheet" href="/assets/mahda-shell-v2.css?v=2" />
  <style>
    .bank-shell{background:linear-gradient(180deg,#fff 0%,#fbfcf8 46%,#f8fbf5 100%)}
    .bank-header{direction:rtl;gap:10px}
    .bank-header-right{display:flex;align-items:center;gap:8px;min-width:0;flex:1}
    .bank-back{width:44px;height:44px;min-width:44px;border:1px solid #dfe9da;border-radius:14px;background:#fff;color:#286e49;display:grid;place-items:center;box-shadow:0 5px 14px #23462912;cursor:pointer}
    .bank-header-icon{width:38px;height:38px;min-width:38px;border-radius:12px;background:#e9f5e7;color:#168354;display:grid;place-items:center}
    .bank-title{display:flex;flex-direction:column;text-align:right;min-width:0;line-height:1.45}
    .bank-title small{font-size:10px;color:#758577}.bank-title strong{font-size:14px;color:#214f39;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .bank-logo{width:96px;height:50px;object-fit:contain;display:block;mix-blend-mode:multiply}
    .bank-main{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;padding:10px 12px 104px;scrollbar-width:none;overscroll-behavior:contain}.bank-main::-webkit-scrollbar{display:none}
    .bank-hero{height:225px;min-height:225px;position:relative;overflow:hidden;border-radius:27px;background:#dcefd7;box-shadow:0 13px 34px #2553331f;isolation:isolate}
    .bank-hero img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:49% 50%;z-index:-3;filter:saturate(1.04) contrast(1.01)}
    .bank-hero:after{content:"";position:absolute;inset:0;z-index:-1;background:linear-gradient(270deg,#fffdebfa 1%,#faf9e2e8 38%,#eef7da38 68%,#0000 86%)}
    .bank-hero-copy{width:60%;margin-inline-start:auto;padding:34px 18px 25px 3px;text-align:right;display:flex;flex-direction:column;align-items:flex-start}
    .bank-badge{color:#26714a;background:#ffffffb3;border:1px solid #ffffffd1;border-radius:999px;margin-bottom:7px;padding:4px 10px;font-size:12px;font-weight:700;box-shadow:0 3px 10px #2e5f2c0f;backdrop-filter:blur(7px)}
    .bank-hero h1{color:#145d38;letter-spacing:-.02em;margin:0;font-size:28px;font-weight:900;line-height:1.45}.bank-hero p{color:#4c674f;margin:8px 0 0;font-size:12px;font-weight:550;line-height:1.85}
    .bank-search{display:block;margin:12px 2px 0}
    .bank-search-field{direction:rtl;color:#5b6881;background:#fffffff5;border:1px solid #e4ebdf;border-radius:19px;display:flex;align-items:center;gap:9px;min-width:0;min-height:58px;padding:0 15px;box-shadow:0 8px 22px #2f4c2717}.bank-search-field:focus-within{border-color:#77aa86;box-shadow:0 0 0 4px #2088511a,0 8px 22px #2f4c2717}
    .bank-search-field input{width:100%;min-width:0;border:0;outline:0;background:transparent;color:#263b4d;font-size:13px}.bank-search-field input::placeholder{color:#8a93a0}
    .divider{height:1px;width:calc(100% - 24px);margin:10px auto 8px;background:linear-gradient(90deg,#0000,#5e775d33 18% 82%,#0000)}
    .bank-categories,.fresh-section{border:1px solid #5c775221;border-radius:24px;box-shadow:0 7px 22px #2a432411,inset 0 1px #ffffffd1;padding:13px 11px 12px}.bank-categories{background:linear-gradient(145deg,#f6fbf1fa,#ebf6e8e6)}.fresh-section{background:linear-gradient(145deg,#f7fbf3,#eaf5e6);margin-top:8px}
    .section-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:13px}.heading-main{display:flex;align-items:center;gap:9px;min-width:0}.heading-icon{width:42px;height:42px;min-width:42px;border-radius:15px;display:grid;place-items:center;color:#168354;background:linear-gradient(145deg,#e9f8e5,#cfeaca);border:1px solid #ffffffe0;box-shadow:inset 0 2px 2px #ffffffdb,0 6px 12px #35502d1f;transform:rotate(-3deg)}.heading-text h2{margin:0;color:#20394a;font-size:18px;font-weight:900;line-height:1.5}.heading-text p{margin:1px 0 0;color:#78828e;font-size:11px;line-height:1.7}.section-link{border:0;background:transparent;color:#2b7c53;font-size:11px;font-weight:750;cursor:pointer;padding:7px 4px}
    .category-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px 6px;direction:rtl}
    .category-card{--category-color:#159658;min-width:0;min-height:88px;padding:9px 2px 7px;border-radius:18px;border:1px solid color-mix(in srgb,var(--category-color) 18%,#edf0e8);background:#fffffff5;color:#314258;display:flex;flex-direction:column;align-items:center;gap:7px;text-align:center;box-shadow:0 5px 14px #2448270e;cursor:pointer;transition:.18s transform,.18s box-shadow,.18s border-color}.category-card:hover{transform:translateY(-2px);border-color:color-mix(in srgb,var(--category-color) 42%,#fff);box-shadow:0 9px 22px color-mix(in srgb,var(--category-color) 14%,transparent)}
    .category-icon{width:44px;height:44px;border-radius:15px;display:grid;place-items:center;color:var(--category-color);background:color-mix(in srgb,var(--category-color) 12%,#fff);border:1px solid color-mix(in srgb,var(--category-color) 28%,#fff);box-shadow:inset 0 1px 0 #fff,0 4px 10px color-mix(in srgb,var(--category-color) 13%,transparent)}.category-icon svg{width:25px;height:25px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 2px 2px color-mix(in srgb,var(--category-color) 20%,transparent))}
    .category-card strong{color:#354459;display:flex;align-items:center;justify-content:center;min-height:30px;max-width:100%;font-size:10.3px;font-weight:750;line-height:1.45;overflow-wrap:anywhere}
    .fresh-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;direction:rtl}.content-card{background:#fff;border:1px solid #eaeee5;border-radius:20px;overflow:hidden;box-shadow:0 6px 18px #223f2213}.content-card>a{display:block;padding:4px 4px 9px;text-align:right}.content-cover{aspect-ratio:4/3;background:linear-gradient(145deg,#edf5e8,#dcebd6);border-radius:16px;position:relative;overflow:hidden}.content-cover img{width:100%;height:100%;object-fit:cover;display:block}.content-badge{position:absolute;right:7px;bottom:7px;display:inline-flex;align-items:center;gap:4px;min-height:27px;padding:3px 8px;border-radius:999px;color:#fff;background:var(--badge-color,#159658);border:1px solid #ffffffd1;font-size:10px;box-shadow:0 3px 9px color-mix(in srgb,var(--badge-color,#159658) 28%,transparent);backdrop-filter:blur(8px)}.content-card h3{margin:8px 8px 1px;color:#26384b;font-size:13px;font-weight:800;line-height:1.7;min-height:43px}.empty-fresh{grid-column:1/-1;min-height:128px;border:1px dashed #cfdcc8;border-radius:18px;background:#ffffff8f;display:grid;place-items:center;text-align:center;color:#708079;font-size:12px;padding:18px}
    .bank-footer{display:flex;justify-content:center;align-items:center;gap:6px;color:#809083;font-size:11px;padding:17px 0 7px}
    @media (max-width:600px){.bank-main{padding:8px 9px calc(104px + env(safe-area-inset-bottom, 0px))}.bank-hero{height:200px;min-height:200px;border-radius:22px}.bank-hero-copy{padding:25px 14px 18px 2px}.bank-hero h1{font-size:23px}.bank-search{grid-template-columns:minmax(0,1fr) 104px}.category-grid{gap:7px 5px}.category-card{min-height:84px;border-radius:16px}.category-icon{width:41px;height:41px}.category-card strong{font-size:9.5px}.bank-logo{width:88px}.bank-title strong{font-size:13px}}
  </style>
<script src="/assets/mahda-runtime.js?v=20260917-account-onboarding-fix" defer></script>
</head>
<body>
<div class="page">
  <div class="scene-left" aria-hidden="true">
    <div class="left-logo-wrap"><img class="left-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt=""/><div class="left-slogan">نسل فردا،<br>با مهدا روشن‌تر</div></div>
    <img class="left-child" src="/assets/child-garden-DajGLj7z.webp" alt=""/>
  </div>
  <div class="scene-right" aria-hidden="true">
    <img class="right-garden" src="/assets/persian-garden-CJRlRJZ1.webp" alt=""/>
    <img class="right-simorgh" src="/assets/simorgh-BobLCgG-.webp" alt=""/>
  </div>

  <div class="app-shell bank-shell">
    <header class="app-header bank-header">
      <div class="bank-header-right">
        <button class="bank-back" type="button" aria-label="بازگشت به خانه" onclick="location.href='/'">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg>
        </button>
        <span class="bank-header-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><path d="M12 2v15"/></svg></span>
        <div class="bank-title"><small>مهدا</small><strong>بانک محتوای مهدا</strong></div>
      </div>
      <a href="/" aria-label="خانه مهدا"><img class="bank-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt="مهدا"/></a>
    </header>

    <main class="bank-main" id="bankScroll">
      <section class="bank-hero">
        <img src="/assets/hero-lCC9Crht.webp" alt=""/>
        <div class="bank-hero-copy"><span class="bank-badge">بانک محتوای مهدا</span><h1>گنجینه تجربه‌های مهدا</h1><p>محتواهای تربیتی، بازی‌ها و تجربه‌های ارزشمند برای رشد کودکان</p></div>
      </section>

      <section class="bank-search" aria-label="جستجوی بانک محتوا">
        <div class="bank-search-field" id="searchWrap">
          <svg id="searchIcon" viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg>
          <input id="bankSearch" type="search" placeholder="جستجوی محتوا، موضوع، دسته..." autocomplete="off"/>
        </div>
      </section>

      <div class="divider"></div>

      <section class="bank-categories">
        <div class="section-heading">
          <div class="heading-main">
            <span class="heading-icon"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><path d="M12 2v15"/></svg></span>
            <div class="heading-text"><h2>چه محتوایی می‌خواهید؟</h2><p>از میان مسیرهای مهدا انتخاب کنید</p></div>
          </div>
        </div>
        <div class="category-grid" id="categoryGrid"></div>
      </section>

      <div class="divider"></div>

      <section class="fresh-section">
        <div class="section-heading">
          <div class="heading-main">
            <span class="heading-icon"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></span>
            <div class="heading-text"><h2>تازه‌های مهدا</h2><p>محتواهای تازه منتشرشده</p></div>
          </div>
          <button class="section-link" type="button" onclick="document.getElementById('bankSearch').focus()">مشاهده همه ←</button>
        </div>
        <div class="fresh-grid" id="freshGrid"><div class="empty-fresh">در حال دریافت محتوای مهدا…</div></div>
      </section>
      <footer class="bank-footer"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61C17.5 1.27 10 2.55 7.33 5.22c-2.68 2.68-1.39 10.17-4.73 13.51"/><path d="M9 15c2-1 4-3 5-5"/></svg><span>هر تجربه خوب، روشنایی یک مسیر تازه است</span></footer>
    </main>

    <nav class="bottom-nav" aria-label="ناوبری اصلی">
      <a class="nav-item" href="/"><svg viewBox="0 0 24 24"><path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/></svg><span>خانه</span></a>
      <a class="nav-item active" href="/search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg><span>جستجو</span></a>
      <a class="nav-item showcase" href="/showcase"><span class="showcase-bubble"><svg viewBox="0 0 24 24"><path d="m12 2.8 2.75 5.57 6.15.9-4.45 4.34 1.05 6.12L12 16.84l-5.5 2.89 1.05-6.12L3.1 9.27l6.15-.9z"/></svg></span><span class="nav-label">ویترین</span></a>
      <a class="nav-item" href="/shelf"><svg viewBox="0 0 24 24"><path d="M4 5h6l2 2h8v12H4z"/><path d="M4 9h16"/></svg><span>قفسه</span></a>
      <a class="nav-item" href="/profile"><svg viewBox="0 0 24 24"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg><span>حساب</span></a>
    </nav>
  </div>
</div>
<script>
(function(){
  const COLORS={game:'#159658',activity:'#69a833',story:'#e7a11f',theater:'#d85663',animation:'#477bd2',experiment:'#159d9d',craft:'#e68128',worksheet:'#3c92d4',heiat_lesson:'#147b4c',painting:'#8e57c8',pardeh_khani:'#9b6b39',magazine:'#2c9a87',pedagogical:'#d45f84',ambiance:'#d4a126',catering:'#62a82f'};
  const CATEGORIES=[
    ['game','بازی','gamepad'],['activity','فعالیت','puzzle'],['story','قصه و داستان','book'],['theater','نمایش','masks'],['animation','انیمیشن','film'],
    ['experiment','آزمایش','flask'],['craft','کاردستی و اوریگامی','scissors'],['worksheet','کاربرگ','clipboard'],['heiat_lesson','طرح درس هیئت','flag'],['painting','نقاشی و رنگ‌آمیزی','palette'],
    ['pardeh_khani','پرده‌خوانی','scroll'],['magazine','نشریه','newspaper'],['pedagogical','تربیتی','sparkles'],['ambiance','فضاسازی','sun'],['catering','پذیرایی','utensils']
  ];
  const PATHS={
    gamepad:'<path d="M8 8h8a5 5 0 0 1 4.7 6.7l-1.1 3a2.8 2.8 0 0 1-4.8.8L13.7 17h-3.4l-1.1 1.5a2.8 2.8 0 0 1-4.8-.8l-1.1-3A5 5 0 0 1 8 8Z"/><path d="M7 12v4M5 14h4"/><circle cx="16.5" cy="12.5" r=".8" fill="currentColor" stroke="none"/><circle cx="18.5" cy="14.5" r=".8" fill="currentColor" stroke="none"/>',
    puzzle:'<path d="M19 13h-2.2a2 2 0 1 0 0 4H19v3H5v-3h2.2a2 2 0 1 0 0-4H5V5h4V3.8a2 2 0 1 1 4 0V5h6v4h1.2a2 2 0 1 1 0 4Z"/>',
    book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H11V4H6.5A2.5 2.5 0 0 0 4 6.5Z"/><path d="M20 19.5a2.5 2.5 0 0 0-2.5-2.5H13V4h4.5A2.5 2.5 0 0 1 20 6.5Z"/>',
    masks:'<path d="M4 6c3-2 6-2 9 0v6c0 3-2 5-4.5 6C6 17 4 15 4 12Z"/><path d="M11 7c3-2 6-2 9 0v6c0 3-2 5-4.5 6a7 7 0 0 1-4-3"/><path d="M6.5 9.5h.01M10.5 9.5h.01M14 10h.01M18 10h.01"/><path d="M6.7 13c1.2 1 2.4 1 3.6 0M14 14c1-1 2-1 3 0"/>',
    film:'<path d="M3 6h18v14H3z"/><path d="M7 6V3M12 6V3M17 6V3"/><path d="m10 10 5 3-5 3z"/>',
    flask:'<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.7 3h10.6A2 2 0 0 0 19 18l-5-9V3"/><path d="M7.5 16h9"/>',
    scissors:'<circle cx="6" cy="7" r="3"/><circle cx="6" cy="17" r="3"/><path d="m8.7 8.4 11.3 6.1M8.7 15.6 20 9.5"/>',
    clipboard:'<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4.5V3h6v1.5M9 9h6M9 13h6M9 17h4"/>',
    flag:'<path d="M5 21V4"/><path d="M5 5c5-3 9 3 14 0v10c-5 3-9-3-14 0"/>',
    palette:'<path d="M12 3a9 9 0 1 0 0 18h1.4a2 2 0 0 0 1.7-3c-.7-1.2.1-2.7 1.5-2.7H18a3 3 0 0 0 3-3C21 7.2 17 3 12 3Z"/><circle cx="7.5" cy="11" r="1"/><circle cx="9.5" cy="7.5" r="1"/><circle cx="14" cy="7.5" r="1"/><circle cx="16.5" cy="11" r="1"/>',
    utensils:'<path d="M5 3v7M8 3v7M5 7h3M6.5 10v11M16 3v18M16 3c3 2 3 7 0 9"/>',
    sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.41M17.66 6.34l1.41-1.41"/>',
    sparkles:'<path d="m12 3-1.4 3.6L7 8l3.6 1.4L12 13l1.4-3.6L17 8l-3.6-1.4Z"/><path d="m18 14-.9 2.1L15 17l2.1.9L18 20l.9-2.1L21 17l-2.1-.9Z"/><path d="m5 14-.7 1.6-1.6.7 1.6.7L5 18.6l.7-1.6 1.6-.7-1.6-.7Z"/>',
    newspaper:'<path d="M4 4h14v16H6a2 2 0 0 1-2-2Z"/><path d="M18 8h2v10a2 2 0 0 1-2 2M8 8h6M8 12h6M8 16h3"/>',
    scroll:'<path d="M6 3h12v15a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3h12"/><path d="M6 3a3 3 0 0 0-3 3v1h3M9 8h6M9 12h6"/>'
  };
  function icon(name,size=25){return '<svg viewBox="0 0 24 24" width="'+size+'" height="'+size+'" aria-hidden="true">'+(PATHS[name]||PATHS.book)+'</svg>'}
  const grid=document.getElementById('categoryGrid');
  const categoryMeta=Object.fromEntries(CATEGORIES.map(x=>[x[0],x]));
  function renderCategories(items=[]){
    const normalized=items.map(x=>Array.isArray(x)?{id:x[0],label:x[1],iconKey:x[2],color:COLORS[x[0]]}:{id:String(x.id||''),label:String(x.label||''),iconKey:PATHS[String(x.icon||'')]?String(x.icon):(categoryMeta[String(x.id||'')]||[])[2]||'book',color:String(x.color||COLORS[String(x.id||'')]||'#159658')});
    grid.innerHTML=normalized.length?normalized.map(x=>'<button type="button" class="category-card" data-id="'+esc(x.id)+'" style="--category-color:'+esc(x.color)+'"><span class="category-icon">'+icon(x.iconKey)+'</span><strong>'+esc(x.label)+'</strong></button>').join(''):'<div class="empty-fresh" style="grid-column:1/-1">دسته فعالی برای بانک محتوا ثبت نشده است.</div>';
    grid.querySelectorAll('.category-card').forEach(btn=>btn.addEventListener('click',()=>{const u=new URL(location.href);u.pathname='/content';u.search='';u.searchParams.set('category',btn.dataset.id);location.href=u.pathname+u.search;}));
  }
  grid.innerHTML='<div class="empty-fresh" style="grid-column:1/-1">در حال دریافت دسته‌های مهدا…</div>';
  fetch('/mahda-api/index.php?action=categories',{credentials:'same-origin',cache:'no-store'}).then(r=>r.ok?r.json():Promise.reject()).then(d=>{const rows=(d.items||[]).filter(x=>x.showInBank!==false);renderCategories(rows)}).catch(()=>{grid.innerHTML='<div class="empty-fresh" style="grid-column:1/-1">دریافت دسته‌ها انجام نشد؛ دوباره تلاش کنید.</div>'});
  const input=document.getElementById('bankSearch');
  input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();const q=input.value.trim();if(q)location.href='/search?q='+encodeURIComponent(q)}});
  const params=new URLSearchParams(location.search);if(params.get('q'))input.value=params.get('q');
  const activeCategory=params.get('category')||'';
  function badgeIcon(category){const found=CATEGORIES.find(x=>x[0]===category);return icon(found?found[2]:'book',14)}
  function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
  function renderFresh(items){const box=document.getElementById('freshGrid');const valid=items.filter(it=>it&&String(it.title||'').trim()&&String(it.categoryLabel||'').trim()&&it.id);if(!valid.length){box.innerHTML='<div class="empty-fresh">هنوز محتوای تأییدشده‌ای در بانک منتشر نشده است.</div>';return;}box.innerHTML=valid.slice(0,4).map(it=>{const cat=String(it.category||'');const color=it.categoryColor||COLORS[cat]||'#159658';const img=it.image?'<img src="'+esc(it.image)+'" alt="" loading="lazy">':'<div style="width:100%;height:100%;display:grid;place-items:center;color:'+color+'">'+badgeIcon(cat)+'</div>';return '<article class="content-card"><a href="/content/item/'+encodeURIComponent(it.id)+'"><div class="content-cover">'+img+'<span class="content-badge" style="--badge-color:'+esc(color)+'">'+badgeIcon(cat)+esc(it.categoryLabel)+'</span></div><h3>'+esc(it.title)+'</h3></a></article>'}).join('');}
  const contentUrl=new URL('/mahda-api/index.php',location.origin);contentUrl.searchParams.set('action','contents');contentUrl.searchParams.set('limit',activeCategory?'40':'4');if(activeCategory)contentUrl.searchParams.set('category',activeCategory);
  if(activeCategory){document.querySelector('.fresh-section .heading-text h2').textContent='محتواهای این دسته';document.querySelector('.fresh-section .heading-text p').textContent='نتیجه‌های منتشرشده در بانک مهدا';}
  fetch(contentUrl,{credentials:'same-origin',cache:'no-store'}).then(r=>r.ok?r.json():Promise.reject()).then(data=>renderFresh(Array.isArray(data.items)?data.items:[])).catch(()=>{document.getElementById('freshGrid').innerHTML='<div class="empty-fresh">اتصال به بانک محتوا برقرار نشد؛ با تازه‌سازی صفحه دوباره تلاش کنید.</div>';});
})();
</script>
</body>
</html>
