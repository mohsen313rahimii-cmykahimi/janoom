<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta name="mahda-build" content="20260918-studio-edit-v2">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#f8fbf5">
<title>ثبت محتوای جدید | مهدا</title>
<link rel="icon" href="/favicon.svg">
<link rel="stylesheet" href="/assets/content-wizard-v14.css?v=20260918-studio-edit-v2">
<script src="/assets/mahda-runtime.js?v=20260918-studio-edit-v2" defer></script>
</head>
<body>
<div class="page">
  <div class="scene-left" aria-hidden="true"><div class="left-logo-wrap"><img src="/assets/mahda-logo-aUAXJ1di.webp" class="left-logo" alt=""><div class="left-slogan">نسل فردا،<br>با مهدا روشن‌تر</div></div><img src="/assets/child-garden-DajGLj7z.webp" class="left-child" alt=""></div>
  <div class="scene-right" aria-hidden="true"><img src="/assets/persian-garden-CJRlRJZ1.webp" class="right-garden" alt=""><img src="/assets/simorgh-BobLCgG-.webp" class="right-simorgh" alt=""></div>
  <section class="app-shell" id="appShell">
    <header class="wizard-head">
      <button class="round-btn close-btn" id="closeBtn" aria-label="بستن"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
      <div class="wizard-title"><strong id="wizardTitle">ثبت محتوای جدید</strong><small id="wizardStepText">گام ۱ از ۹</small></div>
      <button class="round-btn back-top" id="topBackBtn" aria-label="مرحله قبل"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button>
    </header>
    <div class="stepper" id="stepper"></div>
    <main class="wizard-main" id="wizardMain"><div class="state-card loading-state"><span class="spinner"></span><strong>در حال آماده‌سازی فرم…</strong><small>اطلاعات واقعی مهدا دریافت می‌شود.</small></div></main>
    <div class="wizard-actions" id="wizardActions" hidden><button type="button" class="secondary-action" id="secondaryBtn">بازگشت</button><button type="button" class="primary-action" id="primaryBtn">ادامه</button></div>
    <nav class="bottom-nav">
      <a href="/" class="nav-item"><svg viewBox="0 0 24 24"><path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/></svg><span>خانه</span></a>
      <a href="/search" class="nav-item active"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg><span>جستجو</span></a>
      <a href="/showcase" class="nav-item nav-showcase"><span class="showcase-bubble"><svg viewBox="0 0 24 24"><path d="m12 2.8 2.75 5.57 6.15.9-4.45 4.34 1.05 6.12L12 16.84l-5.5 2.89 1.05-6.12L3.1 9.27l6.15-.9z"/></svg></span><span>ویترین</span></a>
      <a href="/shelf" class="nav-item"><svg viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg><span>قفسه</span></a>
      <a href="/profile" class="nav-item"><svg viewBox="0 0 24 24"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg><span>حساب</span></a>
    </nav>
  </section>
</div>
<div id="toast" class="toast" role="status"></div>
<div id="modalRoot"></div>
<script src="/assets/content-wizard-v15.js?v=20260918-studio-edit-v2" defer></script>
</body>
</html>
