<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta name="mahda-build" content="20260916-php-modular-v3">
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <meta name="theme-color" content="#f7faf4" />
  <meta name="description" content="مهدا؛ نسل فردا، با مهدا روشن‌تر" />
  <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
  <link rel="manifest" href="/manifest.webmanifest" />
  <title>مهدا | نسل فردا، با مهدا روشن‌تر</title>
  <style>
    @font-face{font-family:Vazirmatn;src:url('/assets/vazirmatn-arabic-wght-normal-Cafbb7Zc.woff2') format('woff2');font-weight:100 900;font-style:normal;font-display:swap}
    *{box-sizing:border-box}
    html,body{margin:0;min-height:100%;font-family:Vazirmatn,Tahoma,Arial,sans-serif;color:#102c3f;background:#f5faf1}
    body{min-height:100vh;overflow-x:hidden}
    button,input{font:inherit}
    a{color:inherit;text-decoration:none}
    .page{min-height:100vh;position:relative;overflow:hidden;background:radial-gradient(circle at 50% 38%,#fff 0,#f8fbf4 39%,#f3f9ef 72%,#f0f7ec 100%)}
    .scene-left,.scene-right{position:fixed;inset:0;pointer-events:none;z-index:0}
    .left-logo-wrap{position:absolute;left:11.5vw;top:10.4vh;width:210px;text-align:center;color:#145e3a}
    .left-logo{width:100%;display:block;filter:drop-shadow(0 2px 0 rgba(255,255,255,.65))}
    .left-slogan{font-weight:650;font-size:26px;line-height:1.75;margin-top:6px;text-shadow:0 1px 0 #fff}
    .left-child{position:absolute;left:-1.2vw;bottom:-2px;width:min(34.5vw,580px);height:auto;display:block}
    .right-garden{position:absolute;right:-1.5vw;bottom:-8px;width:min(36.7vw,620px);height:min(86vh,815px);object-fit:cover;object-position:center bottom;display:block}
    .right-simorgh{position:absolute;right:7.4vw;top:6.2vh;width:min(21vw,350px);height:auto;display:block;filter:drop-shadow(0 16px 18px rgba(78,55,18,.10))}
    .app-shell{position:relative;z-index:3;width:min(530px,calc(100vw - 24px));height:min(846px,calc(100vh - 38px));min-height:720px;margin:20px auto 18px;background:linear-gradient(180deg,#fff 0%,#fcfdf9 52%,#f9fcf6 100%);border:1px solid rgba(195,211,188,.72);border-radius:30px;box-shadow:0 18px 54px rgba(49,87,48,.14),0 2px 8px rgba(28,60,34,.06);overflow:hidden;display:flex;flex-direction:column}
    .app-header{height:84px;min-height:84px;display:flex;align-items:center;justify-content:space-between;padding:10px 22px 8px;border-bottom:1px solid rgba(221,230,216,.72);background:rgba(255,255,255,.94)}
    .brand-logo{width:108px;height:54px;object-fit:contain;display:block}
    .header-actions{display:flex;align-items:center;gap:11px;min-width:0}
    .avatar{width:46px;height:46px;min-width:46px;border-radius:50%;border:1px solid #d8e4d3;background:#edf6e7;display:grid;place-items:center;color:#5a874c;overflow:hidden;box-shadow:inset 0 0 0 1px rgba(255,255,255,.9)}
    .avatar img{width:100%;height:100%;object-fit:cover;display:block}
    .greeting{line-height:1.35;text-align:right;white-space:nowrap}
    .greeting span{display:block;font-size:13px;color:#44576a}
    .greeting strong{display:block;font-size:15px;font-weight:650;color:#28384c;margin-top:2px}
    .bell{position:relative;width:45px;height:45px;border-radius:50%;border:1px solid #e5eadf;background:white;display:grid;place-items:center;color:#e6a000;cursor:pointer;box-shadow:0 3px 10px rgba(45,74,43,.04)}
    .main{flex:1;min-height:0;padding:10px 18px 98px;overflow:hidden}
    .hero{height:226px;border-radius:24px;border:1px solid #dfe8d8;position:relative;overflow:hidden;background:linear-gradient(90deg,#dfead3 0%,#edf2df 46%,#f7f2df 75%,#fbf8ea 100%);box-shadow:0 8px 18px rgba(63,85,48,.05)}
    .hero-photo{position:absolute;left:0;top:0;width:57%;height:100%;object-fit:cover;object-position:55% 57%;display:block;filter:saturate(.97) contrast(1.01)}
    .hero-fade{position:absolute;inset:0;background:linear-gradient(90deg,rgba(255,255,255,0) 0%,rgba(247,246,224,.06) 38%,rgba(248,247,229,.86) 62%,rgba(248,247,229,.98) 100%)}
    .hero-copy{position:absolute;right:25px;top:26px;width:46%;text-align:right;color:#16623d}
    .hero h1{font-size:28px;line-height:1.48;margin:0 0 8px;font-weight:800;letter-spacing:-.5px}
    .hero p{font-size:13px;margin:0;color:#557163;font-weight:500}
    .hero-cta{margin-top:18px;border:1px solid #e4e6dd;background:#fff;border-radius:22px;height:42px;padding:0 17px;display:inline-flex;align-items:center;gap:9px;color:#1d6f49;font-weight:650;box-shadow:0 5px 13px rgba(41,79,41,.08);cursor:pointer}
    .search-row{height:58px;margin-top:12px;display:flex;direction:ltr;gap:10px}
    .filter-btn{width:58px;min-width:58px;border-radius:16px;border:1px solid #e1e8dc;background:#fff;display:grid;place-items:center;color:#3e5870;box-shadow:0 7px 16px rgba(31,60,39,.07);cursor:pointer}
    .search-box{position:relative;flex:1;border-radius:17px;border:1px solid #e1e8dc;background:#fff;box-shadow:0 7px 16px rgba(31,60,39,.07);overflow:hidden;direction:rtl}
    .search-box input{width:100%;height:100%;border:0;outline:0;background:transparent;padding:0 52px 0 17px;color:#3e4d62;font-size:14px}
    .search-box input::placeholder{color:#8994a4}
    .search-ico{position:absolute;right:17px;top:50%;transform:translateY(-50%);color:#59718b;display:grid;place-items:center}
    .modules{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:14px;direction:rtl}
    .module{height:96px;border:1px solid #e1e8dc;border-radius:18px;background:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:11px;box-shadow:0 9px 22px rgba(43,73,45,.08);transition:.18s transform,.18s box-shadow}
    .module:hover{transform:translateY(-2px);box-shadow:0 12px 26px rgba(43,73,45,.12)}
    .module span{font-size:13px;font-weight:800;color:#20334a}.module small{font-size:7.5px;color:#8a958e;margin-top:-7px}
    .module svg{width:34px;height:34px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
    .bank{color:#0aa95d}.upload{color:#f59b00}.academy{color:#2875f2}.library{color:#d78a2b}.shelf{color:#8768c8}.connect{color:#d7617c}.chin{color:#5f67ce}.heiat{color:#0aa252}.atlas{color:#10a9b8}
    .tagline{height:47px;display:flex;align-items:center;justify-content:center;gap:7px;color:#71806f;font-size:13px;margin-top:9px}
    .tagline svg{width:17px;height:17px}
    .bottom-nav{position:absolute;left:10px;right:10px;bottom:8px;height:82px;border:1px solid #e0e7dc;background:rgba(255,255,255,.97);border-radius:22px;box-shadow:0 -2px 18px rgba(47,77,47,.07);display:grid;grid-template-columns:repeat(5,1fr);align-items:center;direction:rtl;padding:7px 7px 5px;z-index:7}
    .nav-item{height:66px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:4px;color:#60738a;font-size:12px;font-weight:600;position:relative}
    .nav-item svg{width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:1.85;stroke-linecap:round;stroke-linejoin:round}
    .nav-item.active{color:#14915b}
    .showcase{padding-bottom:0;color:#148d57}
    .showcase-bubble{width:54px;height:54px;border-radius:50%;background:linear-gradient(180deg,#27be78,#0fa65f);border:4px solid #f7fbf4;box-shadow:0 8px 20px rgba(18,151,89,.24);display:grid;place-items:center;margin-top:-27px;color:#ffd95b}
    .showcase-bubble svg{width:28px;height:28px;fill:currentColor;stroke:#fff0;filter:drop-shadow(0 1px 0 rgba(83,95,18,.15))}
    .showcase .nav-label{margin-top:0;font-weight:750}
    @media (max-height:800px) and (min-width:760px){.app-shell{transform:scale(.91);transform-origin:top center;margin-bottom:-58px}.left-logo-wrap{top:8vh}.right-simorgh{top:4vh}}
    @media (max-width:1080px){.scene-left,.scene-right{display:none}.page{background:#f4f9f0}.app-shell{margin:0 auto;width:min(620px,100vw);height:100vh;min-height:100vh;border-radius:0;border-top:0;border-bottom:0;box-shadow:none}.main{overflow:auto}.bottom-nav{position:fixed;left:50%;right:auto;transform:translateX(-50%);width:min(600px,calc(100vw - 18px));bottom:max(8px,env(safe-area-inset-bottom))}}
    @media (max-width:600px){.app-header{height:76px;min-height:76px;padding:8px 14px}.brand-logo{width:92px;height:46px}.avatar,.bell{width:42px;height:42px;min-width:42px}.greeting span{font-size:12px}.greeting strong{font-size:14px}.main{padding:9px 12px calc(96px + env(safe-area-inset-bottom, 0px))}.hero{height:194px;border-radius:20px}.hero-copy{right:17px;top:20px;width:48%}.hero h1{font-size:23px}.hero p{font-size:11.5px}.hero-cta{height:38px;margin-top:13px;padding:0 14px}.search-row{height:54px}.filter-btn{width:54px;min-width:54px}.modules{gap:9px;margin-top:11px}.module{height:88px;border-radius:16px;gap:6px}.module svg{width:30px;height:30px}.module span{font-size:13px}.tagline{font-size:12px;margin-top:4px}.bottom-nav{height:78px}.nav-item{font-size:11px}.showcase-bubble{width:50px;height:50px}}
  </style>
  <link rel="stylesheet" href="/assets/mahda-shell-v2.css?v=2" />
<style>.managed-home-rows{display:grid;gap:10px;margin:9px 0 0}.managed-home-section{border:1px solid #e1e9dd;border-radius:18px;background:#fff;padding:10px;box-shadow:0 5px 15px #2948280d}.managed-home-head{display:flex;align-items:end;justify-content:space-between;margin-bottom:8px}.managed-home-head h3{margin:0;color:#29483a;font-size:12px}.managed-home-head small{color:#859189;font-size:8.5px}.managed-home-cards{display:grid;grid-template-columns:repeat(2,1fr);gap:7px}.managed-home-card{border:1px solid #e6ece3;border-radius:13px;overflow:hidden;background:#fbfdf9}.managed-home-card img{width:100%;aspect-ratio:4/3;object-fit:cover;display:block}.managed-home-card b{display:block;padding:6px 7px;font-size:9.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#31463d}</style><script src="/assets/mahda-runtime.js?v=20260916-php-modular-v3" defer></script>
</head>
<body>
<div class="page">
  <div class="scene-left" aria-hidden="true">
    <div class="left-logo-wrap">
      <img class="left-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt="" />
      <div class="left-slogan">نسل فردا،<br>با مهدا روشن‌تر</div>
    </div>
    <img class="left-child" src="/assets/child-garden-DajGLj7z.webp" alt="" />
  </div>
  <div class="scene-right" aria-hidden="true">
    <img class="right-garden" src="/assets/persian-garden-CJRlRJZ1.webp" alt="" />
    <img class="right-simorgh" src="/assets/simorgh-BobLCgG-.webp" alt="" />
  </div>

  <div class="app-shell">
    <header class="app-header">
      <div class="header-actions">
        <a class="avatar" id="homeAvatar" href="/profile" aria-label="حساب کاربری">
          <svg id="avatarFallback" viewBox="0 0 24 24" width="25" height="25" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg>
        </a>
        <div class="greeting"><span>سلام،</span><strong id="greetingName">خوش آمدید</strong></div>
        <button class="bell" type="button" aria-label="اعلان‌ها" onclick="location.href='/notifications'">
          <svg viewBox="0 0 24 24" width="23" height="23" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg><span id="homeNotifDot" style="display:none;position:absolute;top:-3px;right:-3px;min-width:18px;height:18px;padding:0 4px;border-radius:999px;background:#e94b58;color:#fff;border:2px solid #fff;font-size:9px;font-weight:900;place-items:center"></span>
        </button>
      </div>
      <a href="/" aria-label="مهدا؛ صفحه اصلی"><img class="brand-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt="مهدا" /></a>
    </header>

    <main class="main">
      <section class="hero">
        <img class="hero-photo" src="/assets/child-garden-DajGLj7z.webp" alt="" />
        <div class="hero-fade"></div>
        <div class="hero-copy">
          <h1>با هم برای<br>فردایی روشن‌تر</h1>
          <p>محتوای آموزشی، مربی، اجتماعی</p>
          <button class="hero-cta" type="button" onclick="location.href='/profile'">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>
            همراه شویم
          </button>
        </div>
      </section>

      <form class="search-row" id="homeSearch">
        <button class="filter-btn" type="button" aria-label="فیلتر" onclick="location.href='/content'">
          <svg viewBox="0 0 24 24" width="25" height="25" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 6h10"/><path d="M18 6h2"/><path d="M4 12h3"/><path d="M11 12h9"/><path d="M4 18h8"/><path d="M16 18h4"/><circle cx="16" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="14" cy="18" r="2"/></svg>
        </button>
        <div class="search-box">
          <span class="search-ico"><svg viewBox="0 0 24 24" width="25" height="25" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg></span>
          <input id="homeSearchInput" type="search" placeholder="جستجوی محتوا، مربی، هیئت و ..." autocomplete="off" />
        </div>
      </form>

      <section class="modules" aria-label="بخش‌های مهدا">
        <a class="module bank" href="/content"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h6"/><path d="M9 17h6"/></svg><span>بانک محتوا</span></a>
        <a class="module upload" href="/content/new"><svg viewBox="0 0 24 24"><path d="M16 16l-4-4-4 4"/><path d="M12 12v9"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg><span>ثبت محتوا</span></a>
        <a class="module chin" href="/contentchin"><svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h10M4 18h16"/><circle cx="18" cy="12" r="2"/></svg><span>محتواچین</span></a>
        <a class="module shelf" href="/shelf"><svg viewBox="0 0 24 24"><path d="M4 5h6l2 2h8v12H4z"/><path d="M4 9h16"/></svg><span>قفسه</span></a>
        <a class="module library" href="/library"><svg viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><path d="M12 2v15"/></svg><span>کتابخانه</span><small>معرفی کتاب · به‌زودی</small></a>
        <a class="module connect" href="/connection"><svg viewBox="0 0 24 24"><path d="M8 12a4 4 0 1 0-4-4"/><path d="M16 12a4 4 0 1 1 4-4"/><path d="M8 12h8"/><path d="M5 20c1-3 3-5 7-5s6 2 7 5"/></svg><span>اتصال</span><small>مربی × هیئت · به‌زودی</small></a>
        <a class="module academy" href="/academy"><svg viewBox="0 0 24 24"><path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11.5v5L12 20l6-3.5v-5"/></svg><span>آموزشکده</span></a>
        <a class="module atlas" href="/atlas"><svg viewBox="0 0 24 24"><path d="M9 18l-6 3V6l6-3 6 3 6-3v15l-6 3z"/><path d="M9 3v15"/><path d="M15 6v15"/></svg><span>اطلس مهدا</span></a>
        <a class="module heiat" href="/heiat"><svg viewBox="0 0 24 24"><path d="M5 21V4"/><path d="M5 5c5-3 9 3 14 0v10c-5 3-9-3-14 0"/></svg><span>هیئت</span></a>
      </section>

      <div class="tagline">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61C17.5 1.27 10 2.55 7.33 5.22c-2.68 2.68-1.39 10.17-4.73 13.51"/><path d="M9 15c2-1 4-3 5-5"/></svg>
        نسل فردا با مهدا روشن‌تر
      </div>
      <div class="managed-home-rows" id="managedRows"></div>
    </main>

    <nav class="bottom-nav" aria-label="ناوبری اصلی">
      <a class="nav-item active" href="/"><svg viewBox="0 0 24 24"><path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/></svg><span>خانه</span></a>
      <a class="nav-item" href="/search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg><span>جستجو</span></a>
      <a class="nav-item showcase" href="/showcase"><span class="showcase-bubble"><svg viewBox="0 0 24 24"><path d="m12 2.8 2.75 5.57 6.15.9-4.45 4.34 1.05 6.12L12 16.84l-5.5 2.89 1.05-6.12L3.1 9.27l6.15-.9z"/></svg></span><span class="nav-label">ویترین</span></a>
      <a class="nav-item" href="/shelf"><svg viewBox="0 0 24 24"><path d="M4 5h6l2 2h8v12H4z"/><path d="M4 9h16"/></svg><span>قفسه</span></a>
      <a class="nav-item" href="/profile"><svg viewBox="0 0 24 24"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg><span>حساب</span></a>
    </nav>
  </div>
</div>
<script>
(function(){
  const f=document.getElementById('homeSearch'), q=document.getElementById('homeSearchInput');
  f.addEventListener('submit',function(e){e.preventDefault();const v=q.value.trim();location.href=v?('/search?q='+encodeURIComponent(v)):'/search';});
  fetch('/mahda-api/?action=session',{credentials:'same-origin',cache:'no-store'}).then(r=>r.ok?r.json():null).then(data=>{
    const u=data&&data.user?data.user:null;if(!u||u.guest)return;
    const name=(u.profile_name||u.display_name||'').trim();if(name)document.getElementById('greetingName').textContent=name.split(/\s+/)[0];
    const av=(u.avatar_url||'').trim();if(av){const a=document.getElementById('homeAvatar');const img=document.createElement('img');img.src=av;img.alt='';img.onerror=()=>img.remove();a.prepend(img);const fb=document.getElementById('avatarFallback');if(fb)fb.style.display='none';}
  }).catch(()=>{});
})();
</script>
<script>
(async function applyManagedHome(){
  const esc=s=>String(s??'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]||c));
  try{
    const r=await fetch('/mahda-api/index.php?action=homepage_config',{credentials:'same-origin',cache:'no-store'});if(!r.ok)return;const d=await r.json();const all=d.allSections||d.sections||[];
    const byKey=Object.fromEntries(all.map(x=>[x.section_key,x]));
    const hero=byKey.hero;if(hero){const el=document.querySelector('.hero');if(hero.active===false&&el)el.style.display='none';if(hero.active!==false){const h=document.querySelector('.hero h1'),p=document.querySelector('.hero p');if(h&&hero.title&&hero.title!=='اسلایدر اصلی')h.textContent=hero.title;if(p&&hero.subtitle&&hero.subtitle!=='بنرها و پیشنهادهای ویژه')p.textContent=hero.subtitle;}}
    const sr=byKey.search;if(sr?.active===false)document.querySelector('.search-row')?.remove();
    const mg=byKey['main-grid'];if(mg?.active===false)document.querySelector('.modules')?.remove();
    const manual=(d.sections||[]).filter(x=>x.source_mode==='manual'&&Array.isArray(x.contentIds)&&x.contentIds.length>0&&x.section_type==='content_row').slice(0,3);if(!manual.length)return;
    const root=document.getElementById('managedRows');for(const sec of manual){const results=await Promise.all(sec.contentIds.slice(0,4).map(id=>fetch('/mahda-api/index.php?action=content_detail&id='+id,{credentials:'same-origin',cache:'no-store'}).then(x=>x.ok?x.json():null).catch(()=>null)));const items=results.map(x=>x?.item).filter(Boolean);if(!items.length)continue;const wrap=document.createElement('section');wrap.className='managed-home-section';wrap.innerHTML='<div class="managed-home-head"><div><h3>'+esc(sec.title)+'</h3><small>'+esc(sec.subtitle||'')+'</small></div></div><div class="managed-home-cards">'+items.map(x=>'<a class="managed-home-card" href="/content/item/'+x.id+'">'+(x.image?'<img src="'+esc(x.image)+'" alt="">':'')+'<b>'+esc(x.title)+'</b></a>').join('')+'</div>';root.appendChild(wrap)}
  }catch(e){}
})();
</script><script>fetch('/mahda-api/index.php?action=notifications&limit=1',{credentials:'same-origin',cache:'no-store'}).then(r=>r.ok?r.json():null).then(d=>{if(d&&d.unread>0){const e=document.getElementById('homeNotifDot');if(e){e.textContent=d.unread>99?'۹۹+':Number(d.unread).toLocaleString('fa-IR');e.style.display='grid'}}}).catch(()=>{});</script></body>
</html>
