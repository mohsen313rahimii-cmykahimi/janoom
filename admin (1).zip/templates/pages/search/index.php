<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta name="mahda-build" content="20260918-guided-search-v1">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#f7faf4">
<title>جستجوی محتوا | مهدا</title>
<link rel="icon" href="/favicon.svg">
<style>@font-face{font-family:Vazirmatn;src:url('/assets/vazirmatn-arabic-wght-normal-Cafbb7Zc.woff2') format('woff2');font-weight:100 900;font-display:swap}</style>
<link rel="stylesheet" href="/assets/mahda-shell-v3.css?v=8">
<link rel="stylesheet" href="/assets/shelf-v1.css?v=1">
<link rel="stylesheet" href="/assets/search-guided-v1.css?v=1">
<script src="/assets/mahda-runtime.js?v=20260918-guided-search-v1" defer></script>
</head>
<body>
<div class="page">
  <div class="scene-left" aria-hidden="true">
    <div class="left-logo-wrap"><img class="left-logo" src="/assets/mahda-logo-aUAXJ1di.webp" alt=""><div class="left-slogan">نسل فردا،<br>با مهدا روشن‌تر</div></div>
    <img class="left-child" src="/assets/child-garden-DajGLj7z.webp" alt="">
  </div>
  <div class="scene-right" aria-hidden="true"><img class="right-simorgh" src="/assets/simorgh-BobLCgG-.webp" alt=""><img class="right-garden" src="/assets/persian-garden-CJRlRJZ1.webp" alt=""></div>
  <div class="app-shell">
    <header class="app-header">
      <div class="head-left"><a class="logo-button" href="/"><img src="/assets/mahda-logo-aUAXJ1di.webp" alt="مهدا"></a></div>
      <div class="head-center"><strong>جستجوی محتوا</strong><small>چند انتخاب کوتاه؛ پیشنهادهای دقیق‌تر</small></div>
      <div class="head-right">
        <a class="head-button has-badge" href="/notifications" aria-label="اعلان‌ها"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 10-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg><span class="notif-dot" id="notifDot"></span></a>
        <a class="head-button round head-avatar" href="/profile" id="headAvatar" aria-label="حساب"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg></a>
      </div>
    </header>

    <main class="app-main search-main">
      <div class="gs-shell">
        <div class="gs-intro">
          <span class="gs-intro-mark"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/><path d="m11 7 .8 2.1L14 10l-2.2.9L11 13l-.8-2.1L8 10l2.2-.9z"/></svg></span>
          <div><strong>مهدا کمکت می‌کنه انتخاب کنی</strong><small>به‌جای فیلترهای شلوغ، قدم‌به‌قدم جلو برو.</small></div>
        </div>
        <div class="gs-progress-meta"><span>مسیر پیدا کردن محتوا</span><b id="guidedProgressText">۱ از ۸</b></div>
        <div class="gs-progress" aria-hidden="true"><i id="guidedProgressFill"></i></div>
        <div class="gs-summary" id="guidedSummary"></div>
        <div id="guidedSearchRoot"></div>
      </div>
    </main>

    <nav class="bottom-nav">
      <a class="nav-item" href="/"><svg viewBox="0 0 24 24"><path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/></svg><span>خانه</span></a>
      <a class="nav-item active" href="/search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.7-3.7"/></svg><span>جستجو</span></a>
      <a class="nav-item nav-showcase" href="/showcase"><span class="showcase-bubble"><svg viewBox="0 0 24 24"><path d="m12 2.8 2.75 5.57 6.15.9-4.45 4.34 1.05 6.12L12 16.84l-5.5 2.89 1.05-6.12L3.1 9.27l6.15-.9z"/></svg></span><span>ویترین</span></a>
      <a class="nav-item" href="/shelf"><svg viewBox="0 0 24 24"><path d="M4 5h6l2 2h8v12H4z"/><path d="M4 9h16"/></svg><span>قفسه</span></a>
      <a class="nav-item" href="/profile"><svg viewBox="0 0 24 24"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg><span>حساب</span></a>
    </nav>
  </div>
</div>
<script src="/assets/shelf-picker-v1.js?v=1"></script>
<script src="/assets/search-guided-v1.js?v=1"></script>
</body>
</html>
