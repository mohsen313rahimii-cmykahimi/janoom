<?php
declare(strict_types=1);

$cardTitle = htmlspecialchars((string)($title ?? ''), ENT_QUOTES, 'UTF-8');
$cardImage = htmlspecialchars((string)($image ?? ''), ENT_QUOTES, 'UTF-8');
$cardColor = htmlspecialchars((string)($categoryColor ?? '#159658'), ENT_QUOTES, 'UTF-8');
?><article class="content-card" style="--badge-color:<?= $cardColor ?>">
    <a href="<?= htmlspecialchars((string)($href ?? '#'), ENT_QUOTES, 'UTF-8') ?>">
        <?php if ($cardImage !== ''): ?><img class="content-cover" src="<?= $cardImage ?>" alt="" loading="lazy"><?php endif; ?>
        <h3><?= $cardTitle ?></h3>
    </a>
</article>

