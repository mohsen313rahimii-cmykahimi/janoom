<?php
declare(strict_types=1);
?><div class="mahda-state mahda-state--empty" role="status">هنوز چیزی برای نمایش نیست.</div>

