<?php
declare(strict_types=1);
?><div class="category-grid" data-component="category-grid">
    <?= (string)($content ?? '') ?>
</div>

