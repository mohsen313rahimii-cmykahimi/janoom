<?php
declare(strict_types=1);
?><header class="mahda-header" data-component="header">
    <a href="/" aria-label="خانه مهدا">مهدا</a>
</header>

