<?php
declare(strict_types=1);
?><div class="mahda-state mahda-state--error" role="alert">دریافت اطلاعات با مشکل روبه‌رو شد. دوباره تلاش کنید.</div>

