<?php
declare(strict_types=1);
?><nav class="mahda-bottom-nav" aria-label="ناوبری اصلی" data-component="bottom-nav">
    <a href="/">خانه</a>
    <a href="/search/">جستجو</a>
    <a href="/showcase/">ویترین</a>
    <a href="/shelf">قفسه</a>
    <a href="/profile/">حساب</a>
</nav>

