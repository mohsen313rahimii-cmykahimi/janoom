<?php
declare(strict_types=1);
?><div class="mahda-state mahda-state--loading" role="status" aria-live="polite">در حال دریافت...</div>

