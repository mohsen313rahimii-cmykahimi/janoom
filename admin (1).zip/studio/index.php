<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/Modules/Studio/page.php';
